-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 07, 2014 at 04:37 AM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `qlcafe_demo`
--

-- --------------------------------------------------------

--
-- Table structure for table `cafehappy4_category`
--

CREATE TABLE IF NOT EXISTS `cafehappy4_category` (
  `id` int(25) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `picture` binary(255) DEFAULT NULL,
  `enable` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=26 ;

--
-- Dumping data for table `cafehappy4_category`
--

INSERT INTO `cafehappy4_category` (`id`, `name`, `picture`, `enable`) VALUES
(3, 'Cafe', NULL, 1),
(8, 'Sinh tố', NULL, 0),
(11, 'Nước ép', '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0', 1),
(13, 'Yaourt', NULL, 0),
(14, 'Nước giải khát', '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0', 1),
(15, 'Nước pha chế', NULL, 0),
(16, 'Lipton - Trà', '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0', 1),
(17, 'Sữa tươi', NULL, 0),
(21, 'Điểm tâm sáng', 'abc.com\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0', 1),
(23, 'Khác', '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0', 1),
(25, 'Thuốc lá', NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `cafehappy4_collect_customer`
--

CREATE TABLE IF NOT EXISTS `cafehappy4_collect_customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idcustomer` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cafehappy4_customer_collect_1` (`idcustomer`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `cafehappy4_collect_customer`
--


-- --------------------------------------------------------

--
-- Table structure for table `cafehappy4_collect_general`
--

CREATE TABLE IF NOT EXISTS `cafehappy4_collect_general` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_term` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cafehappy4_collect_1` (`id_term`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=12 ;

--
-- Dumping data for table `cafehappy4_collect_general`
--

INSERT INTO `cafehappy4_collect_general` (`id`, `id_term`, `date`, `value`, `note`) VALUES
(5, 2, '2013-05-18', 10, 'd'),
(6, 3, '2013-12-06', 2000000, 'Bổ sung quỹ'),
(7, 3, '2014-01-08', 1500000, 'Bổng sung quỹ (a. Thông)'),
(8, 3, '2014-01-09', 2321000, 'Quy kho 09.01.2014'),
(9, 3, '2014-01-10', 2272000, 'quỹ kho 10-01-2014'),
(10, 3, '2014-01-10', 45000, 'bán chai nhựa'),
(11, 3, '2014-01-11', 3096000, 'quỹ 11-01-2014');

-- --------------------------------------------------------

--
-- Table structure for table `cafehappy4_config`
--

CREATE TABLE IF NOT EXISTS `cafehappy4_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `param` varchar(125) COLLATE utf8_unicode_ci NOT NULL,
  `value` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=19 ;

--
-- Dumping data for table `cafehappy4_config`
--

INSERT INTO `cafehappy4_config` (`id`, `param`, `value`) VALUES
(5, 'DISCOUNT', '0'),
(6, 'ROW_PER_PAGE', '12'),
(7, 'GUEST_VISIT', '9247'),
(8, 'EVERY_5_MINUTES', '2000'),
(9, 'THEME', 'light-blue'),
(10, 'CATEGORY_AUTO', '3'),
(11, 'SWITCH_BOARD_CALL', '1'),
(12, 'RECEIPT_VIRTUAL_DOUBLE', '1'),
(13, 'CATEGORY_AUTO', '3'),
(14, 'CATEGORY_AUTO', '3'),
(15, 'N_MONTH_LOG', '1'),
(16, 'NAME', 'CAFE HAPPY 4'),
(17, 'ADDRESS', 'Cần Thơ'),
(18, 'PHONE', '0919 153 189');

-- --------------------------------------------------------

--
-- Table structure for table `cafehappy4_course`
--

CREATE TABLE IF NOT EXISTS `cafehappy4_course` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idcategory` int(25) DEFAULT NULL,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `shortname` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `unit` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `price1` bigint(20) NOT NULL,
  `price2` bigint(20) NOT NULL,
  `price3` bigint(20) NOT NULL,
  `price4` bigint(20) NOT NULL,
  `picture` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_discount` int(11) NOT NULL DEFAULT '1',
  `enable` int(11) NOT NULL,
  `prepare` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `foreign_field` (`idcategory`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=386 ;

--
-- Dumping data for table `cafehappy4_course`
--

INSERT INTO `cafehappy4_course` (`id`, `idcategory`, `name`, `shortname`, `unit`, `price1`, `price2`, `price3`, `price4`, `picture`, `is_discount`, `enable`, `prepare`) VALUES
(53, 8, 'Sinh tố Bơ', 'Sinh tố Bơ', 'Ly', 20000, 20000, 20000, 20000, '', 1, 1, 0),
(54, 8, 'Sinh tố Cà chua', 'Sinh tố Cà chua', 'Ly', 15000, 15000, 15000, 15000, '', 1, 1, 0),
(55, 8, 'Sinh tố Cà rốt', 'Sinh tố Cà rốt', 'Ly', 15000, 15000, 15000, 15000, '', 1, 1, 0),
(56, 8, 'Sinh tố cam', 'Sinh tố cam', 'Ly', 15000, 15000, 15000, 15000, '', 1, 1, 0),
(107, 3, 'Cafe đá', 'Cafe đá', 'Ly', 8000, 8000, 8000, 8000, '', 1, 1, 0),
(108, 3, 'Cafe nóng', 'Cafe nóng', 'Ly', 8000, 8000, 8000, 8000, '', 1, 1, 0),
(112, 3, 'Cafe Sữa nóng', 'Cafe Sữa nóng', 'Ly', 10000, 10000, 10000, 10000, '', 1, 1, 0),
(126, 8, 'Sinh tố chanh', 'Sinh tố chanh', 'Ly', 15000, 15000, 15000, 15000, '', 1, 1, 0),
(127, 8, 'Sinh tố dâu', 'Sinh tố dâu', 'Ly', 22000, 22000, 22000, 22000, '', 1, 1, 0),
(128, 8, 'Sinh tố Mãng cầu', 'Sinh tố Mãng cầu', 'Ly', 15000, 15000, 15000, 15000, '', 1, 1, 0),
(129, 8, 'Sinh tố sapô', 'Sinh tố sapô', 'Ly', 15000, 15000, 15000, 15000, '', 1, 1, 0),
(136, 8, 'Sinh tố thập cẩm', 'Sinh tố thập cẩm', 'Ly', 20000, 20000, 20000, 20000, '', 1, 1, 0),
(149, 13, 'Yaourt cam tươi', 'Yaourt cam tươi', 'Ly', 17000, 17000, 17000, 17000, '', 1, 1, 0),
(161, 13, 'Yaourt dâu', 'Yaourt dâu', 'Ly', 20000, 20000, 20000, 20000, '', 1, 1, 0),
(162, 13, 'Yaourt hủ', 'Yaourt hủ', 'Hủ', 10000, 10000, 10000, 10000, '', 1, 1, 0),
(174, 15, 'Dừa đá', 'Dừa đá', 'Ly', 12000, 12000, 12000, 12000, '', 1, 1, 0),
(175, 15, 'Dừa trái', 'Dừa trái', 'Trái', 12000, 12000, 12000, 12000, '', 1, 1, 0),
(176, 15, 'Đá me', 'Đá me', 'Ly', 8000, 8000, 8000, 8000, '', 1, 1, 0),
(177, 15, 'Đá me sữa', 'Đá me sữa', 'Ly', 12000, 12000, 12000, 12000, '', 1, 1, 0),
(178, 15, 'Rau má dừa', 'Rau má dừa', 'Ly', 13000, 13000, 13000, 13000, '', 1, 1, 0),
(179, 15, 'Rau má sữa', 'Rau má sữa', 'Ly', 15000, 15000, 15000, 15000, '', 1, 1, 0),
(180, 15, 'Rau má thường', 'Rau má thường', 'Ly', 8000, 8000, 8000, 8000, '', 1, 1, 0),
(181, 15, 'Tắc xí muội nóng', 'Tắc xí muội nóng', 'Ly', 14000, 14000, 14000, 14000, '', 1, 1, 0),
(182, 15, 'Chanh xí muội nóng', 'Chanh xí muội nóng', 'Ly', 12000, 12000, 12000, 12000, '', 1, 1, 0),
(183, 15, 'Xí muội đá', 'Xí muội đá', 'Ly', 15000, 15000, 15000, 15000, '', 1, 1, 0),
(184, 15, 'Sâm dứa', 'Sâm dứa', 'Ly', 13000, 13000, 13000, 13000, '', 1, 1, 0),
(185, 15, 'Sâm dứa sữa', 'Sâm dứa sữa', 'Ly', 15000, 15000, 15000, 15000, '', 1, 1, 0),
(187, 11, 'Ép cà chua', 'Ép cà chua', 'Ly', 18000, 18000, 18000, 18000, '', 1, 1, 0),
(188, 11, 'Ép carrot', 'Ép carrot', 'Ly', 18000, 18000, 18000, 18000, '', 1, 1, 0),
(189, 11, 'Ép cam', 'Ép cam', 'Ly', 15000, 15000, 15000, 15000, '', 1, 1, 0),
(190, 11, 'Ép dâu', 'Ép dâu', 'Ly', 25000, 25000, 25000, 25000, '', 1, 1, 0),
(191, 11, 'Ép lê', 'Ép lê', 'Ly', 20000, 20000, 20000, 20000, '', 1, 1, 0),
(192, 11, 'Ép táo', 'Ép táo', 'Ly', 20000, 20000, 20000, 20000, '', 1, 1, 0),
(193, 11, 'Ép thơm', 'Ép thơm', 'Ly', 18000, 18000, 18000, 18000, '', 1, 1, 0),
(194, 14, '7 up', '7 up', 'Chai', 12000, 12000, 12000, 12000, '', 1, 1, 0),
(196, 14, 'Cam Twister', 'Cam Twister', 'Chai', 13000, 13000, 13000, 13000, '', 1, 1, 0),
(197, 14, 'Dr Thanh', 'Dr Thanh', 'Chai', 13000, 13000, 13000, 13000, '', 1, 1, 0),
(198, 14, 'Đậu nành', 'Đậu nành', 'Chai', 12000, 12000, 12000, 12000, '', 1, 1, 0),
(199, 14, 'Sting dâu sữa', 'Sting dâu sữa', 'Chai', 15000, 15000, 15000, 15000, '', 1, 1, 0),
(201, 14, 'Nước suối', 'Nước suối', 'Chai', 7000, 7000, 7000, 7000, '', 1, 1, 0),
(202, 14, 'Pepsi', 'Pepsi', 'Chai', 12000, 12000, 12000, 12000, '', 1, 1, 0),
(203, 14, 'Coca (chai nhựa)', 'Coca (chai nhựa)', 'Chai', 12000, 12000, 12000, 12000, '', 1, 1, 0),
(204, 14, 'Sting dâu', 'Sting dâu', 'Chai', 12000, 12000, 12000, 12000, '', 1, 1, 0),
(205, 14, 'Trà xanh 0 độ', 'Trà xanh 0 độ', 'Chai', 12000, 12000, 12000, 12000, '', 1, 1, 0),
(208, 17, 'Sữa dâu tươi', 'Sữa dâu tươi', 'Ly', 20000, 20000, 20000, 20000, '', 1, 1, 0),
(209, 17, 'Sữa nóng', 'Sữa nóng', 'Ly', 10000, 10000, 10000, 10000, '', 1, 1, 0),
(210, 17, 'Sữa thêm', 'Sữa thêm', 'Ly', 5000, 5000, 5000, 5000, '', 1, 1, 0),
(211, 17, 'Sữa đá', 'Sữa đá', 'Ly', 12000, 12000, 12000, 12000, '', 1, 1, 0),
(212, 17, 'Sữa tươi', 'Sữa tươi', 'Ly', 10000, 10000, 10000, 10000, '', 1, 1, 0),
(218, 16, 'Lipton sữa đá', 'Lipton sữa đá', 'Ly', 15000, 15000, 15000, 15000, '', 1, 1, 0),
(219, 16, 'Lipton sữa nóng', 'Lipton sữa nóng', 'Ly', 13000, 13000, 13000, 13000, '', 1, 1, 0),
(220, 16, 'Trà sữa', 'Trà sữa', 'Ly', 15000, 15000, 15000, 15000, '', 1, 1, 0),
(221, 16, 'Trà chanh', 'Trà chanh', 'Ly', 10000, 10000, 10000, 10000, '', 1, 1, 0),
(222, 16, 'Trà đường đá', 'Trà đường đá', 'Ly', 8000, 8000, 8000, 8000, '', 1, 1, 0),
(223, 16, 'Trà đường nóng', 'Trà đường nóng', 'Ly', 8000, 8000, 8000, 8000, '', 1, 1, 0),
(224, 16, 'Lipton đá', 'Lipton đá', 'Ly', 8000, 8000, 8000, 8000, '', 1, 1, 0),
(225, 16, 'Lipton mật ong nóng', 'Lipton mật ong nóng', 'Ly', 13000, 13000, 13000, 13000, '', 1, 1, 0),
(226, 16, 'Lipton nóng', 'Lipton nóng', 'Ly', 8000, 8000, 8000, 8000, '', 1, 1, 0),
(228, 13, 'Yaourt sữa đá', 'Yaourt sữa đá', 'Ly', 15000, 15000, 15000, 15000, '', 1, 1, 0),
(229, 13, 'Yaourt trái cây', 'Yaourt trái cây', 'Ly', 20000, 20000, 20000, 20000, '', 1, 1, 0),
(230, 21, 'Bò bít tết trứng', 'Bò bít tết trứng', 'Phần', 30000, 30000, 30000, 30000, '0', 0, 1, 0),
(231, 21, 'Bò bít tết ko trứng', 'Bò bít tết ko trứng', 'Phần', 25000, 25000, 25000, 25000, '0', 0, 1, 0),
(232, 21, 'Mì Ý', 'Mì Ý', 'Phần', 25000, 25000, 25000, 25000, '', 0, 1, 0),
(233, 21, 'Bánh mì ốp la chả', 'Bánh mì ốp la chả', 'Phần', 12000, 12000, 12000, 12000, '', 0, 0, 0),
(234, 21, 'Bánh mì ốp la', 'Bánh mì ốp la', 'Phần', 10000, 10000, 10000, 10000, '', 0, 0, 0),
(235, 21, 'Mì gói xào bò', 'Mì gói xào bò', 'Phần', 20000, 20000, 20000, 20000, '', 0, 1, 0),
(236, 21, 'Nui xào bò', 'Nui xào bò', 'Phần', 20000, 20000, 20000, 20000, '', 0, 1, 0),
(237, 21, 'Mì gói nấu bò', 'Mì gói nấu bò', 'Phần', 15000, 15000, 15000, 15000, '', 0, 1, 0),
(238, 21, 'Trứng thêm', 'Trứng thêm', 'Cái', 5000, 5000, 5000, 5000, '', 0, 1, 0),
(239, 21, 'Mì gói thêm', 'Mì gói thêm', 'Gói', 5000, 5000, 5000, 5000, '', 0, 1, 0),
(240, 21, 'Bánh mì thêm', 'Bánh mì thêm', 'Cái', 5000, 5000, 5000, 5000, '', 0, 0, 0),
(246, 16, 'Lipton mật ong đá', 'Lipton mật ong đá', 'Ly', 15000, 15000, 15000, 15000, '', 1, 1, 0),
(247, 16, 'Lipton xí muội nóng', 'Lipton xí muội nóng', 'Ly', 13000, 13000, 13000, 13000, '', 1, 1, 0),
(248, 16, 'Lipton xí muội đá', 'Lipton xí muội đá', 'Ly', 15000, 15000, 15000, 15000, '', 1, 1, 0),
(249, 16, 'Lipton bạc hà', 'Lipton bạc hà', 'Ly', 15000, 15000, 15000, 15000, '', 1, 1, 0),
(250, 16, 'Lipton cam', 'Lipton cam', 'Ly', 15000, 15000, 15000, 15000, '', 1, 1, 0),
(252, 16, 'Trà cúc nóng', 'Trà cúc nóng', 'Ly', 10000, 10000, 10000, 10000, '', 1, 1, 0),
(253, 16, 'Trà cúc đá', 'Trà cúc đá', 'Ly', 10000, 10000, 10000, 10000, '', 1, 1, 0),
(255, 3, 'Cafe Sữa đá', 'Cafe Sữa đá', 'Ly', 12000, 12000, 12000, 12000, '', 0, 1, 0),
(260, 3, 'Cafe Miền Tây', 'Cafe Đam mê', 'Ly', 15000, 15000, 15000, 15000, '', 1, 1, 0),
(265, 15, 'Chanh nóng', 'Chanh nóng', 'Ly', 8000, 8000, 8000, 8000, '', 1, 1, 0),
(267, 15, 'Chanh muối nóng', 'Chanh muối nóng', 'Ly', 8000, 8000, 8000, 8000, '', 1, 1, 0),
(268, 15, 'Chanh muối đá', 'Chanh muối đá', 'Ly', 8000, 8000, 8000, 8000, '', 1, 1, 0),
(269, 15, 'Chanh rhum', 'Chanh rhum', 'Ly', 15000, 15000, 15000, 15000, '', 1, 1, 0),
(270, 15, 'Xí muội nóng', 'Xí muội nóng', 'Ly', 14000, 14000, 14000, 14000, '', 1, 1, 0),
(271, 15, 'Chanh xí muội đá', 'Chanh xí muội đá', 'Ly', 12000, 12000, 12000, 12000, '', 1, 1, 0),
(272, 15, 'Chanh muối xí muội', 'Chanh muối xí muội', 'Ly', 10000, 10000, 10000, 10000, '', 1, 1, 0),
(273, 15, 'Tắc xí muội đá', 'Tắc xí muội đá', 'Ly', 15000, 15000, 15000, 15000, '', 1, 1, 0),
(274, 15, 'Bạc hà', 'Bạc hà', 'Ly', 13000, 13000, 13000, 13000, '', 1, 1, 0),
(275, 15, 'Bạc hà sữa', 'Bạc hà sữa', 'Ly', 15000, 15000, 15000, 15000, '', 1, 1, 0),
(276, 15, 'Siro dâu', 'Siro dâu', 'Ly', 13000, 13000, 13000, 13000, '', 1, 1, 0),
(277, 15, 'Đá me xí muội', 'Đá me xí muội', 'Ly', 15000, 15000, 15000, 15000, '', 1, 1, 0),
(278, 15, 'Siro dâu sữa', 'Siro dâu sữa', 'Ly', 15000, 15000, 15000, 15000, '', 1, 1, 0),
(279, 8, 'Sinh tố chanh dây', 'Sinh tố chanh dây', 'Ly', 20000, 20000, 20000, 20000, '', 1, 1, 0),
(280, 8, 'Sinh tố Thơm', 'Sinh tố Thơm', 'Ly', 15000, 15000, 15000, 15000, '', 1, 1, 0),
(281, 8, 'Sinh tố Dừa', 'Sinh tố Dừa', 'Ly', 15000, 15000, 15000, 15000, '', 1, 1, 0),
(282, 8, 'Sinh tố Táo', 'Sinh tố Táo', 'Ly', 20000, 20000, 20000, 20000, '', 1, 1, 0),
(283, 8, 'Sinh tố Lê', 'Sinh tố Lê', 'Ly', 20000, 20000, 20000, 20000, '', 1, 1, 0),
(284, 8, 'ST rau má dừa', 'ST rau má dừa', 'Ly', 15000, 15000, 15000, 15000, '', 1, 1, 0),
(285, 8, 'Sinh tố Bưởi', 'Sinh tố Bưởi', 'Ly', 20000, 20000, 20000, 20000, '', 1, 1, 0),
(286, 8, 'Sinh tố Cafe', 'Sinh tố Cafe', 'Ly', 15000, 15000, 15000, 15000, '', 1, 1, 0),
(287, 8, 'ST tự chọn 2 món', 'ST tự chọn 2 món', 'Ly', 20000, 20000, 20000, 20000, '', 1, 1, 0),
(288, 8, 'ST tự chọn 3 món', 'ST tự chọn 3 món', 'Ly', 25000, 25000, 25000, 25000, '', 1, 1, 0),
(289, 8, 'ST tự chọn 4 món', 'ST tự chọn 4 món', 'Ly', 28000, 28000, 28000, 28000, '', 1, 1, 0),
(290, 8, 'ST chanh muối', 'ST chanh muối', 'Ly', 15000, 15000, 15000, 15000, '', 1, 1, 0),
(291, 8, 'Dâu dằm', 'Dâu dằm', 'Ly', 25000, 25000, 25000, 25000, '', 1, 1, 0),
(292, 8, 'Mãng cầu dằm', 'Mãng cầu dằm', 'Ly', 17000, 17000, 17000, 17000, '', 1, 1, 0),
(293, 8, 'Bơ dầm', 'Bơ dầm', 'Ly', 25000, 25000, 25000, 25000, '', 1, 1, 0),
(305, 11, 'Ép 4 mùa', 'Ép 4 mùa', 'Ly', 28000, 28000, 28000, 28000, '', 1, 1, 0),
(306, 11, 'Ép bưởi', 'Ép bưởi', 'Ly', 20000, 20000, 20000, 20000, '', 1, 1, 0),
(307, 11, 'Ép cam mật ong', 'Ép cam mật ong', 'Ly', 22000, 22000, 22000, 22000, '', 1, 1, 0),
(308, 11, 'Ép cam sữa', 'Ép cam sữa', 'Ly', 18000, 18000, 18000, 18000, '', 1, 1, 0),
(309, 11, 'Ép chanh dây', 'Ép chanh dây', 'Ly', 20000, 20000, 20000, 20000, '', 1, 1, 0),
(310, 11, 'Ép dâu sữa', 'Ép dâu sữa', 'Ly', 26000, 26000, 26000, 26000, '', 1, 1, 0),
(311, 11, 'Ép tự chọn 2 món', 'Ép tự chọn 2 món', 'Ly', 22000, 22000, 22000, 22000, '', 1, 1, 0),
(312, 11, 'Ép tự chọn 3 món', 'Ép tự chọn 3 món', 'Ly', 25000, 25000, 25000, 25000, '', 1, 1, 0),
(313, 13, 'Yaourt bạc hà', 'Yaourt bạc hà', 'Ly', 15000, 15000, 15000, 15000, '', 1, 1, 0),
(314, 13, 'Yaourt bưởi', 'Yaourt bưởi', 'Ly', 15000, 15000, 15000, 15000, '', 1, 1, 0),
(315, 13, 'Yaourt cafe đá', 'Yaourt cafe đá', 'Ly', 15000, 15000, 15000, 15000, '', 1, 1, 0),
(316, 13, 'Yaourt chanh dây', 'Yaourt chanh dây', 'Ly', 17000, 17000, 17000, 17000, '', 1, 1, 0),
(318, 17, 'Đậu nành nấu', 'Đậu nành nấu', 'Ly', 7000, 7000, 7000, 7000, '', 1, 1, 0),
(320, 17, 'Sữa chanh xí muội', 'Sữa chanh xí muội', 'Ly', 15000, 15000, 15000, 15000, '', 1, 1, 0),
(321, 17, 'Sữa tươi cacao đá', 'Sữa tươi cacao đá', 'Ly', 16000, 16000, 16000, 16000, '', 1, 1, 0),
(322, 17, 'Sữa tươi cafe', 'Sữa tươi cafe', 'Ly', 14000, 14000, 14000, 14000, '', 1, 1, 0),
(325, 23, 'Khăn lạnh', 'Khăn lạnh', 'Cái', 2000, 2000, 2000, 2000, '', 1, 1, 0),
(326, 23, 'Nước ép thêm', 'Nước ép thêm', 'Ly', 10000, 10000, 10000, 10000, '', 1, 1, 0),
(327, 23, 'Phụ thu nhạc', 'Phụ thu nhạc', 'Bàn', 5000, 5000, 5000, 5000, '', 0, 1, 0),
(328, 23, 'Phụ thu BĐ khuya/ người', 'Phụ thu BĐ khuya/ người', 'Phần', 2000, 2000, 2000, 2000, '', 0, 1, 0),
(329, 23, 'Rau má thêm', 'Rau má thêm', 'Ly', 5000, 5000, 5000, 5000, '', 1, 1, 0),
(330, 23, 'Trái cây dĩa lớn', 'Trái cây dĩa lớn', 'Dĩa', 35000, 35000, 35000, 35000, '', 1, 1, 0),
(331, 23, 'Trái cây dĩa nhỏ', 'Trái cây dĩa nhỏ', 'Dĩa', 25000, 25000, 25000, 25000, '', 1, 1, 0),
(332, 14, 'Rivive', 'Rivive', 'Chai', 12000, 12000, 12000, 12000, '', 0, 1, 0),
(333, 14, 'Mountain Dew', 'Mountain Dew', 'Chai', 12000, 12000, 12000, 12000, '', 0, 1, 0),
(334, 14, 'Trà Ô Long', 'Trà Ô Long', 'Chai', 12000, 12000, 12000, 12000, '', 0, 1, 0),
(335, 14, 'C2', 'C2', 'Chai', 10000, 10000, 10000, 10000, '', 0, 1, 0),
(338, 21, 'Mì không', 'Mì không', 'Gói', 7000, 7000, 7000, 7000, '', 0, 1, 0),
(349, 14, 'Samurai dâu', 'Samurai', 'Chai', 12000, 12000, 12000, 12000, '', 0, 1, 0),
(350, 14, 'Soda', 'Soda', 'Ly', 15000, 15000, 15000, 15000, '', 0, 1, 0),
(351, 8, 'Sinh tố mít', 'Sinh tố mít', 'Ly', 15000, 15000, 15000, 15000, '', 0, 1, 0),
(353, 14, 'Coca (chai thuỷ tinh)', 'Coca (chai thuỷ tinh)', 'Chai', 8000, 8000, 8000, 8000, '', 0, 1, 0),
(355, 15, 'Cam sữa', 'Cam sữa', 'Ly', 15000, 15000, 15000, 15000, '', 0, 1, 0),
(358, 15, 'Chanh đá', 'Chanh đá', 'Ly', 8000, 8000, 8000, 8000, '', 0, 1, 0),
(360, 25, 'Hero (20điếu)', 'Hero (20điếu)', 'Gói', 18000, 18000, 18000, 18000, '', 0, 1, 0),
(361, 25, 'Hero 1/2gói (10điếu)', 'Hero 1/2gói (10điếu)', 'Gói', 10000, 10000, 10000, 10000, '', 0, 1, 0),
(362, 25, 'Hero 1điếu', 'Hero 1điếu', 'Điếu', 1000, 1000, 1000, 1000, '', 0, 1, 0),
(363, 25, 'Jet (20điếu)', 'Jet (20điếu)', 'Gói', 20000, 20000, 20000, 20000, '', 0, 1, 0),
(364, 25, 'Jet 1 điếu', 'Jet 1 điếu', 'Điếu', 1000, 1000, 1000, 1000, '', 0, 1, 0),
(365, 25, 'Jet 1/2 gói (10điếu)', 'Jet 1/2 gói (10điếu)', 'Gói', 10000, 10000, 10000, 10000, '', 0, 1, 0),
(366, 25, 'Mèo lớn (20điếu)', 'Mèo lớn (20điếu)', 'Gói', 22000, 22000, 22000, 22000, '', 0, 1, 0),
(367, 25, 'Mèo trung (12điếu)', 'Mèo trung (12điếu)', 'Gói', 13000, 13000, 13000, 13000, '', 0, 1, 0),
(368, 25, 'Mèo tép (5điếu)', 'Mèo tép (5điếu)', 'Gói', 6000, 6000, 6000, 6000, '', 0, 1, 0),
(369, 25, 'Mèo (1điếu)', 'Mèo (1điếu)', 'Điếu', 1500, 1500, 1500, 1500, '', 0, 1, 0),
(370, 14, ' Tepy Cam', '', 'Chai', 12000, 12000, 12000, 12000, '', 0, 1, 0),
(371, 14, 'Nutri cam', '', 'Chai', 12000, 12000, 12000, 12000, '', 0, 1, 0),
(372, 15, 'TRà đường ca', 'TRà đường ca', 'Ly', 10000, 10000, 10000, 10000, '', 0, 1, 0),
(373, 14, 'nước suoi Dasani', 'nước suoi mang ve', 'Chai', 7000, 7000, 7000, 7000, '', 0, 1, 0),
(374, 14, 'Cam Fanta (chai thuy tinh)', 'Cam Fanta', 'Chai', 8000, 8000, 8000, 8000, '', 0, 1, 0),
(375, 14, 'Xá xị Fanta', '', 'Chai', 8000, 8000, 8000, 8000, '', 0, 1, 0),
(376, 14, 'Sprite chai thuy tinh', 'Sprite', 'Chai', 8000, 8000, 8000, 8000, '', 0, 1, 0),
(377, 14, 'Cam Fanta ( chai nhựa)', '', 'Chai', 12000, 12000, 12000, 12000, '', 0, 1, 0),
(378, 14, 'Sprite chai nhựa', '', 'Chai', 12000, 12000, 12000, 12000, '', 0, 1, 0),
(379, 14, 'Xá xị chai nhựa', '', 'Chai', 12000, 12000, 12000, 12000, '', 0, 1, 0),
(380, 14, 'Nước suối AQuat', '', 'Chai', 10000, 10000, 10000, 10000, '', 0, 1, 0),
(381, 14, 'Samurai tăng lực', '', 'Chai', 12000, 12000, 12000, 12000, '', 0, 1, 0),
(385, 3, 'ABVC', 'ABVC', 'Bàn', 2, 2, 2, 2, '', 0, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `cafehappy4_customer`
--

CREATE TABLE IF NOT EXISTS `cafehappy4_customer` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  `card` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `note` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `discount` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=14 ;

--
-- Dumping data for table `cafehappy4_customer`
--

INSERT INTO `cafehappy4_customer` (`id`, `name`, `type`, `card`, `phone`, `address`, `note`, `discount`) VALUES
(1, 'Khách lẻ', 0, '', '', '', '', 0),
(12, 'Nguyễn Văn A', 1, '123456789', '0919 111 222', 'Vĩnh Long', '', 5),
(13, 'Nguyễn Văn B', 0, '', '', '', '', 10);

-- --------------------------------------------------------

--
-- Table structure for table `cafehappy4_domain`
--

CREATE TABLE IF NOT EXISTS `cafehappy4_domain` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=8 ;

--
-- Dumping data for table `cafehappy4_domain`
--

INSERT INTO `cafehappy4_domain` (`id`, `name`) VALUES
(1, 'Số bàn'),
(7, 'Khách vãng lai');

-- --------------------------------------------------------

--
-- Table structure for table `cafehappy4_employee`
--

CREATE TABLE IF NOT EXISTS `cafehappy4_employee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `job` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `gender` tinyint(2) NOT NULL,
  `phone` varchar(13) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `salary_base` int(11) NOT NULL,
  `card` varchar(13) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=10 ;

--
-- Dumping data for table `cafehappy4_employee`
--

INSERT INTO `cafehappy4_employee` (`id`, `name`, `job`, `gender`, `phone`, `address`, `salary_base`, `card`) VALUES
(1, 'Ngọc', 'Phục vụ', 1, '01635758021', 'Mang Thít', 1800000, '12345678'),
(2, 'Trinh', 'Phục vụ', 1, '01649 359 321', 'Đồng Tháp', 1800000, ''),
(3, 'Nguyệt', 'Phục vụ', 1, '0164 220 95 9', 'Đồng Tháp', 1800000, ''),
(4, 'Nhi', 'Phục vụ', 1, '01629 655 287', 'Cần Thơ', 1800000, ''),
(5, 'Duy', 'Phục vụ', 0, '01882356234', 'P2, Tp.Vĩnh Long', 1800000, ''),
(6, 'Dũng', 'Giữ xe', 0, '0907 615 003', 'Quảng Bình', 1800000, ''),
(7, 'Nguyên', 'Nhân viên', 0, '01665685873', 'P3, TP VLong', 1800000, ''),
(8, 'Tân', 'Thu ngân', 0, '0989 975 603', 'Tam Bình', 2500000, ''),
(9, 'Hằng', 'NV', 1, '01286962340', 'vinh long', 1800000, '');

-- --------------------------------------------------------

--
-- Table structure for table `cafehappy4_guest`
--

CREATE TABLE IF NOT EXISTS `cafehappy4_guest` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(16) CHARACTER SET latin1 NOT NULL,
  `entry_time` varchar(32) CHARACTER SET latin1 NOT NULL,
  `exit_time` varchar(32) CHARACTER SET latin1 NOT NULL,
  `agent` varchar(16) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=150 ;

--
-- Dumping data for table `cafehappy4_guest`
--

INSERT INTO `cafehappy4_guest` (`id`, `ip`, `entry_time`, `exit_time`, `agent`) VALUES
(149, '115.78.94.118', '1383319305', '1383322905', '115.78.94.118');

-- --------------------------------------------------------

--
-- Table structure for table `cafehappy4_order_import`
--

CREATE TABLE IF NOT EXISTS `cafehappy4_order_import` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idsupplier` int(11) NOT NULL,
  `date` date NOT NULL,
  `description` varchar(50) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id`),
  KEY `cafehappy4_order_import_1` (`idsupplier`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=359 ;

--
-- Dumping data for table `cafehappy4_order_import`
--

INSERT INTO `cafehappy4_order_import` (`id`, `idsupplier`, `date`, `description`) VALUES
(348, 8, '2013-12-06', ''),
(349, 8, '2014-01-02', ''),
(350, 9, '2013-12-30', 'Nhập hàng lần 1'),
(352, 1, '2013-12-31', 'Đá viên'),
(353, 1, '2014-01-01', 'Đá viên'),
(354, 1, '2014-01-02', 'Đá viên'),
(355, 1, '2014-01-03', 'Đá viên'),
(356, 1, '2014-01-06', 'Đá viên + Đá ướp'),
(357, 12, '2014-01-06', 'Dừa'),
(358, 13, '2014-01-03', 'Trà lài');

-- --------------------------------------------------------

--
-- Table structure for table `cafehappy4_order_import_detail`
--

CREATE TABLE IF NOT EXISTS `cafehappy4_order_import_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idorder` int(11) NOT NULL,
  `idresource` int(11) NOT NULL,
  `count` float NOT NULL,
  `price` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `cafehappy4_order_import_detail_1` (`idorder`),
  KEY `cafehappy4_order_import_detail_2` (`idresource`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=653 ;

--
-- Dumping data for table `cafehappy4_order_import_detail`
--

INSERT INTO `cafehappy4_order_import_detail` (`id`, `idorder`, `idresource`, `count`, `price`) VALUES
(634, 348, 19, 2, 60000),
(635, 348, 20, 1, 80000),
(636, 348, 101, 1, 120000),
(637, 349, 19, 1, 60000),
(638, 350, 35, 2, 160000),
(639, 350, 36, 5, 185000),
(640, 350, 43, 5, 170000),
(641, 350, 103, 5, 105000),
(642, 350, 104, 2, 105000),
(643, 350, 105, 1, 174000),
(644, 350, 106, 1, 135000),
(645, 350, 109, 1, 142000),
(646, 352, 2, 9, 15000),
(647, 353, 2, 3, 15000),
(648, 354, 2, 4, 15000),
(649, 355, 2, 2, 15000),
(650, 356, 2, 5, 15000),
(651, 356, 14, 1, 10000),
(652, 357, 110, 10, 7000);

-- --------------------------------------------------------

--
-- Table structure for table `cafehappy4_paid_customer`
--

CREATE TABLE IF NOT EXISTS `cafehappy4_paid_customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idcustomer` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cafehappy4_customer_paid_1` (`idcustomer`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `cafehappy4_paid_customer`
--


-- --------------------------------------------------------

--
-- Table structure for table `cafehappy4_paid_employee`
--

CREATE TABLE IF NOT EXISTS `cafehappy4_paid_employee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_employee` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(150) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_employee` (`id_employee`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `cafehappy4_paid_employee`
--

INSERT INTO `cafehappy4_paid_employee` (`id`, `id_employee`, `date`, `value`, `note`) VALUES
(4, 2, '2014-01-06', 200000, 'ứng lương'),
(5, 8, '2014-01-03', 500000, 'ung luong');

-- --------------------------------------------------------

--
-- Table structure for table `cafehappy4_paid_general`
--

CREATE TABLE IF NOT EXISTS `cafehappy4_paid_general` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_term` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cafehappy4_paid_1` (`id_term`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=175 ;

--
-- Dumping data for table `cafehappy4_paid_general`
--

INSERT INTO `cafehappy4_paid_general` (`id`, `id_term`, `date`, `value`, `note`) VALUES
(9, 10, '2013-04-01', 157000, 'Chi tiền chợ'),
(10, 10, '2013-04-02', 146000, 'Tiền chợ'),
(11, 10, '2013-04-03', 189000, 'Tiền chợ'),
(12, 10, '2013-04-04', 184000, 'Tiền chợ'),
(66, 2, '2013-04-30', 2100000, 'Tạm tính'),
(111, 3, '2013-07-31', 1500000, 'Thuế TTĐB Tháng 07'),
(112, 1, '2013-07-31', 4000000, 'Tiền điện T07'),
(113, 2, '2013-07-31', 2000000, 'Tiền nước T07'),
(155, 3, '2013-08-31', 800000, 'Thuế TTĐB T08'),
(156, 3, '2013-09-30', 850000, 'Thuế TTĐB T09'),
(158, 1, '2013-08-31', 5800000, 'Tiền điện T08'),
(159, 1, '2013-09-30', 3700000, 'Tiền điện T09'),
(160, 2, '2013-08-31', 2200000, 'Tiền nước T08'),
(161, 2, '2013-09-30', 2300000, 'Tiền nước T09'),
(163, 1, '2013-05-31', 4700000, 'Tiền điện T05'),
(164, 1, '2013-06-30', 3900000, 'Tiền điện T06'),
(165, 2, '2013-05-31', 2350000, 'Tiền nước T05'),
(166, 2, '2013-06-30', 2260000, 'Tiền nước T06'),
(167, 11, '2014-01-06', 85000, 'Chi mua Cam'),
(168, 10, '2014-01-08', 186000, 'tien an sáng(30),com trưa( 84), cơm chều(72)'),
(169, 11, '2014-01-08', 256000, 'Chi mua cong tv 26, than da 50, chanh 30, sapo 16,'),
(170, 10, '2014-01-09', 207000, 'Tiền chợ'),
(171, 10, '2014-01-10', 163000, 'chợ'),
(172, 11, '2014-01-10', 70000, 'Dừa trái '),
(173, 11, '2014-01-10', 337000, '1c jet, 1c meo tet, giay ve sinh, xoai an'),
(174, 10, '2014-01-11', 128000, 'an sáng, chợ');

-- --------------------------------------------------------

--
-- Table structure for table `cafehappy4_paid_pay_roll`
--

CREATE TABLE IF NOT EXISTS `cafehappy4_paid_pay_roll` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_employee` int(11) NOT NULL,
  `date` date NOT NULL,
  `value_base` int(11) NOT NULL,
  `value_sub` int(11) NOT NULL,
  `value_pre` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cafehappy4_paid_pay_roll_1` (`id_employee`),
  KEY `id_employee` (`id_employee`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `cafehappy4_paid_pay_roll`
--


-- --------------------------------------------------------

--
-- Table structure for table `cafehappy4_paid_supplier`
--

CREATE TABLE IF NOT EXISTS `cafehappy4_paid_supplier` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idsupplier` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cafehappy4_supplier_paid_1` (`idsupplier`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=18 ;

--
-- Dumping data for table `cafehappy4_paid_supplier`
--

INSERT INTO `cafehappy4_paid_supplier` (`id`, `idsupplier`, `date`, `value`, `note`) VALUES
(1, 1, '2012-08-01', 2300000, 'được không ?'),
(2, 1, '2012-07-03', 350000, 'Ghi chú gì đây'),
(3, 1, '2012-07-26', 750000, 'Ghi ghi gì gì đó'),
(8, 6, '2012-09-19', 1000000, 'Thử nè được không đó !'),
(9, 1, '2012-09-19', 1000000, 'lung tung quá đi'),
(11, 1, '2012-01-01', 123, 'sdfdsfggf'),
(12, 1, '2012-09-24', 1230000, 'đâu biết'),
(13, 1, '2012-09-24', 1213232, ''),
(14, 1, '2012-09-24', 34243243, ''),
(15, 1, '2012-09-24', 21323, ''),
(16, 1, '2012-09-24', 123323, ''),
(17, 1, '2012-09-24', 21323, '');

-- --------------------------------------------------------

--
-- Table structure for table `cafehappy4_pay_roll`
--

CREATE TABLE IF NOT EXISTS `cafehappy4_pay_roll` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_employee` int(11) NOT NULL,
  `date` date NOT NULL,
  `session1` int(11) NOT NULL,
  `session2` int(11) NOT NULL,
  `session3` int(11) NOT NULL,
  `extra` int(11) NOT NULL,
  `late` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_employee` (`id_employee`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=410 ;

--
-- Dumping data for table `cafehappy4_pay_roll`
--

INSERT INTO `cafehappy4_pay_roll` (`id`, `id_employee`, `date`, `session1`, `session2`, `session3`, `extra`, `late`) VALUES
(131, 1, '2014-01-01', 0, 0, 0, 0, 0),
(132, 1, '2014-01-02', 0, 0, 0, 0, 0),
(133, 1, '2014-01-03', 0, 0, 0, 0, 0),
(134, 1, '2014-01-04', 0, 0, 0, 0, 0),
(135, 1, '2014-01-05', 0, 0, 0, 0, 0),
(136, 1, '2014-01-06', 0, 0, 0, 0, 0),
(137, 1, '2014-01-07', 0, 0, 0, 0, 0),
(138, 1, '2014-01-08', 1, 1, 1, 0, 0),
(139, 1, '2014-01-09', 1, 1, 1, 0, 0),
(140, 1, '2014-01-10', 1, 1, 1, 0, 0),
(141, 1, '2014-01-11', 1, 1, 1, 0, 0),
(142, 1, '2014-01-12', 0, 0, 0, 0, 0),
(143, 1, '2014-01-13', 0, 0, 0, 0, 0),
(144, 1, '2014-01-14', 0, 0, 0, 0, 0),
(145, 1, '2014-01-15', 0, 0, 0, 0, 0),
(146, 1, '2014-01-16', 0, 0, 0, 0, 0),
(147, 1, '2014-01-17', 0, 0, 0, 0, 0),
(148, 1, '2014-01-18', 0, 0, 0, 0, 0),
(149, 1, '2014-01-19', 0, 0, 0, 0, 0),
(150, 1, '2014-01-20', 0, 0, 0, 0, 0),
(151, 1, '2014-01-21', 0, 0, 0, 0, 0),
(152, 1, '2014-01-22', 0, 0, 0, 0, 0),
(153, 1, '2014-01-23', 0, 0, 0, 0, 0),
(154, 1, '2014-01-24', 0, 0, 0, 0, 0),
(155, 1, '2014-01-25', 0, 0, 0, 0, 0),
(156, 1, '2014-01-26', 0, 0, 0, 0, 0),
(157, 1, '2014-01-27', 0, 0, 0, 0, 0),
(158, 1, '2014-01-28', 0, 0, 0, 0, 0),
(159, 1, '2014-01-29', 0, 0, 0, 0, 0),
(160, 1, '2014-01-30', 0, 0, 0, 0, 0),
(161, 1, '2014-01-31', 0, 0, 0, 0, 0),
(162, 2, '2014-01-01', 0, 0, 0, 0, 0),
(163, 2, '2014-01-02', 0, 0, 0, 0, 0),
(164, 2, '2014-01-03', 0, 0, 0, 0, 0),
(165, 2, '2014-01-04', 0, 0, 0, 0, 0),
(166, 2, '2014-01-05', 0, 0, 0, 0, 0),
(167, 2, '2014-01-06', 0, 0, 0, 0, 0),
(168, 2, '2014-01-07', 0, 0, 0, 0, 0),
(169, 2, '2014-01-08', 0, 0, 1, 0, 0),
(170, 2, '2014-01-09', 0, 0, 1, 0, 0),
(171, 2, '2014-01-10', 0, 0, 0, 0, 0),
(172, 2, '2014-01-11', 0, 0, 0, 0, 0),
(173, 2, '2014-01-12', 0, 0, 0, 0, 0),
(174, 2, '2014-01-13', 0, 0, 0, 0, 0),
(175, 2, '2014-01-14', 0, 0, 0, 0, 0),
(176, 2, '2014-01-15', 0, 0, 0, 0, 0),
(177, 2, '2014-01-16', 0, 0, 0, 0, 0),
(178, 2, '2014-01-17', 0, 0, 0, 0, 0),
(179, 2, '2014-01-18', 0, 0, 0, 0, 0),
(180, 2, '2014-01-19', 0, 0, 0, 0, 0),
(181, 2, '2014-01-20', 0, 0, 0, 0, 0),
(182, 2, '2014-01-21', 0, 0, 0, 0, 0),
(183, 2, '2014-01-22', 0, 0, 0, 0, 0),
(184, 2, '2014-01-23', 0, 0, 0, 0, 0),
(185, 2, '2014-01-24', 0, 0, 0, 0, 0),
(186, 2, '2014-01-25', 0, 0, 0, 0, 0),
(187, 2, '2014-01-26', 0, 0, 0, 0, 0),
(188, 2, '2014-01-27', 0, 0, 0, 0, 0),
(189, 2, '2014-01-28', 0, 0, 0, 0, 0),
(190, 2, '2014-01-29', 0, 0, 0, 0, 0),
(191, 2, '2014-01-30', 0, 0, 0, 0, 0),
(192, 2, '2014-01-31', 0, 0, 0, 0, 0),
(193, 3, '2014-01-01', 0, 0, 0, 0, 0),
(194, 3, '2014-01-02', 0, 0, 0, 0, 0),
(195, 3, '2014-01-03', 0, 0, 0, 0, 0),
(196, 3, '2014-01-04', 0, 0, 0, 0, 0),
(197, 3, '2014-01-05', 0, 0, 0, 0, 0),
(198, 3, '2014-01-06', 0, 1, 1, 0, 0),
(199, 3, '2014-01-07', 0, 1, 1, 0, 0),
(200, 3, '2014-01-08', 0, 0, 1, 0, 0),
(201, 3, '2014-01-09', 0, 1, 1, 0, 0),
(202, 3, '2014-01-10', 0, 0, 0, 0, 0),
(203, 3, '2014-01-11', 0, 0, 0, 0, 0),
(204, 3, '2014-01-12', 0, 0, 0, 0, 0),
(205, 3, '2014-01-13', 0, 0, 0, 0, 0),
(206, 3, '2014-01-14', 0, 0, 0, 0, 0),
(207, 3, '2014-01-15', 0, 0, 0, 0, 0),
(208, 3, '2014-01-16', 0, 0, 0, 0, 0),
(209, 3, '2014-01-17', 0, 0, 0, 0, 0),
(210, 3, '2014-01-18', 0, 0, 0, 0, 0),
(211, 3, '2014-01-19', 0, 0, 0, 0, 0),
(212, 3, '2014-01-20', 0, 0, 0, 0, 0),
(213, 3, '2014-01-21', 0, 0, 0, 0, 0),
(214, 3, '2014-01-22', 0, 0, 0, 0, 0),
(215, 3, '2014-01-23', 0, 0, 0, 0, 0),
(216, 3, '2014-01-24', 0, 0, 0, 0, 0),
(217, 3, '2014-01-25', 0, 0, 0, 0, 0),
(218, 3, '2014-01-26', 0, 0, 0, 0, 0),
(219, 3, '2014-01-27', 0, 0, 0, 0, 0),
(220, 3, '2014-01-28', 0, 0, 0, 0, 0),
(221, 3, '2014-01-29', 0, 0, 0, 0, 0),
(222, 3, '2014-01-30', 0, 0, 0, 0, 0),
(223, 3, '2014-01-31', 0, 0, 0, 0, 0),
(224, 4, '2014-01-01', 0, 0, 0, 0, 0),
(225, 4, '2014-01-02', 0, 0, 0, 0, 0),
(226, 4, '2014-01-03', 0, 0, 0, 0, 0),
(227, 4, '2014-01-04', 0, 0, 0, 0, 0),
(228, 4, '2014-01-05', 0, 0, 0, 0, 0),
(229, 4, '2014-01-06', 0, 0, 0, 0, 0),
(230, 4, '2014-01-07', 0, 0, 0, 0, 0),
(231, 4, '2014-01-08', 0, 0, 0, 0, 0),
(232, 4, '2014-01-09', 0, 1, 0, 0, 0),
(233, 4, '2014-01-10', 0, 0, 0, 0, 0),
(234, 4, '2014-01-11', 0, 0, 0, 0, 0),
(235, 4, '2014-01-12', 0, 0, 0, 0, 0),
(236, 4, '2014-01-13', 0, 0, 0, 0, 0),
(237, 4, '2014-01-14', 0, 0, 0, 0, 0),
(238, 4, '2014-01-15', 0, 0, 0, 0, 0),
(239, 4, '2014-01-16', 0, 0, 0, 0, 0),
(240, 4, '2014-01-17', 0, 0, 0, 0, 0),
(241, 4, '2014-01-18', 0, 0, 0, 0, 0),
(242, 4, '2014-01-19', 0, 0, 0, 0, 0),
(243, 4, '2014-01-20', 0, 0, 0, 0, 0),
(244, 4, '2014-01-21', 0, 0, 0, 0, 0),
(245, 4, '2014-01-22', 0, 0, 0, 0, 0),
(246, 4, '2014-01-23', 0, 0, 0, 0, 0),
(247, 4, '2014-01-24', 0, 0, 0, 0, 0),
(248, 4, '2014-01-25', 0, 0, 0, 0, 0),
(249, 4, '2014-01-26', 0, 0, 0, 0, 0),
(250, 4, '2014-01-27', 0, 0, 0, 0, 0),
(251, 4, '2014-01-28', 0, 0, 0, 0, 0),
(252, 4, '2014-01-29', 0, 0, 0, 0, 0),
(253, 4, '2014-01-30', 0, 0, 0, 0, 0),
(254, 4, '2014-01-31', 0, 0, 0, 0, 0),
(255, 6, '2014-01-01', 0, 0, 0, 0, 0),
(256, 6, '2014-01-02', 0, 0, 0, 0, 0),
(257, 6, '2014-01-03', 0, 0, 0, 0, 0),
(258, 6, '2014-01-04', 0, 0, 0, 0, 0),
(259, 6, '2014-01-05', 0, 0, 0, 0, 0),
(260, 6, '2014-01-06', 1, 0, 1, 0, 0),
(261, 6, '2014-01-07', 1, 0, 1, 0, 0),
(262, 6, '2014-01-08', 1, 0, 1, 0, 0),
(263, 6, '2014-01-09', 1, 0, 1, 0, 0),
(264, 6, '2014-01-10', 0, 0, 0, 0, 0),
(265, 6, '2014-01-11', 0, 0, 0, 0, 0),
(266, 6, '2014-01-12', 0, 0, 0, 0, 0),
(267, 6, '2014-01-13', 0, 0, 0, 0, 0),
(268, 6, '2014-01-14', 0, 0, 0, 0, 0),
(269, 6, '2014-01-15', 0, 0, 0, 0, 0),
(270, 6, '2014-01-16', 0, 0, 0, 0, 0),
(271, 6, '2014-01-17', 0, 0, 0, 0, 0),
(272, 6, '2014-01-18', 0, 0, 0, 0, 0),
(273, 6, '2014-01-19', 0, 0, 0, 0, 0),
(274, 6, '2014-01-20', 0, 0, 0, 0, 0),
(275, 6, '2014-01-21', 0, 0, 0, 0, 0),
(276, 6, '2014-01-22', 0, 0, 0, 0, 0),
(277, 6, '2014-01-23', 0, 0, 0, 0, 0),
(278, 6, '2014-01-24', 0, 0, 0, 0, 0),
(279, 6, '2014-01-25', 0, 0, 0, 0, 0),
(280, 6, '2014-01-26', 0, 0, 0, 0, 0),
(281, 6, '2014-01-27', 0, 0, 0, 0, 0),
(282, 6, '2014-01-28', 0, 0, 0, 0, 0),
(283, 6, '2014-01-29', 0, 0, 0, 0, 0),
(284, 6, '2014-01-30', 0, 0, 0, 0, 0),
(285, 6, '2014-01-31', 0, 0, 0, 0, 0),
(286, 7, '2014-01-01', 0, 0, 0, 0, 0),
(287, 7, '2014-01-02', 0, 0, 0, 0, 0),
(288, 7, '2014-01-03', 0, 0, 0, 0, 0),
(289, 7, '2014-01-04', 0, 0, 0, 0, 0),
(290, 7, '2014-01-05', 0, 0, 0, 0, 0),
(291, 7, '2014-01-06', 1, 1, 0, 0, 0),
(292, 7, '2014-01-07', 1, 1, 0, 0, 0),
(293, 7, '2014-01-08', 1, 1, 0, 0, 0),
(294, 7, '2014-01-09', 1, 1, 0, 0, 0),
(295, 7, '2014-01-10', 0, 0, 0, 0, 0),
(296, 7, '2014-01-11', 0, 0, 0, 0, 0),
(297, 7, '2014-01-12', 0, 0, 0, 0, 0),
(298, 7, '2014-01-13', 0, 0, 0, 0, 0),
(299, 7, '2014-01-14', 0, 0, 0, 0, 0),
(300, 7, '2014-01-15', 0, 0, 0, 0, 0),
(301, 7, '2014-01-16', 0, 0, 0, 0, 0),
(302, 7, '2014-01-17', 0, 0, 0, 0, 0),
(303, 7, '2014-01-18', 0, 0, 0, 0, 0),
(304, 7, '2014-01-19', 0, 0, 0, 0, 0),
(305, 7, '2014-01-20', 0, 0, 0, 0, 0),
(306, 7, '2014-01-21', 0, 0, 0, 0, 0),
(307, 7, '2014-01-22', 0, 0, 0, 0, 0),
(308, 7, '2014-01-23', 0, 0, 0, 0, 0),
(309, 7, '2014-01-24', 0, 0, 0, 0, 0),
(310, 7, '2014-01-25', 0, 0, 0, 0, 0),
(311, 7, '2014-01-26', 0, 0, 0, 0, 0),
(312, 7, '2014-01-27', 0, 0, 0, 0, 0),
(313, 7, '2014-01-28', 0, 0, 0, 0, 0),
(314, 7, '2014-01-29', 0, 0, 0, 0, 0),
(315, 7, '2014-01-30', 0, 0, 0, 0, 0),
(316, 7, '2014-01-31', 0, 0, 0, 0, 0),
(317, 8, '2014-01-01', 1, 1, 1, 0, 0),
(318, 8, '2014-01-02', 1, 1, 1, 0, 0),
(319, 8, '2014-01-03', 1, 1, 1, 0, 0),
(320, 8, '2014-01-04', 1, 1, 1, 0, 0),
(321, 8, '2014-01-05', 1, 0, 0, 0, 0),
(322, 8, '2014-01-06', 1, 1, 1, 0, 0),
(323, 8, '2014-01-07', 1, 1, 1, 0, 0),
(324, 8, '2014-01-08', 1, 1, 1, 0, 0),
(325, 8, '2014-01-09', 1, 1, 1, 0, 0),
(326, 8, '2014-01-10', 0, 0, 0, 0, 0),
(327, 8, '2014-01-11', 0, 0, 0, 0, 0),
(328, 8, '2014-01-12', 0, 0, 0, 0, 0),
(329, 8, '2014-01-13', 0, 0, 0, 0, 0),
(330, 8, '2014-01-14', 0, 0, 0, 0, 0),
(331, 8, '2014-01-15', 0, 0, 0, 0, 0),
(332, 8, '2014-01-16', 0, 0, 0, 0, 0),
(333, 8, '2014-01-17', 0, 0, 0, 0, 0),
(334, 8, '2014-01-18', 0, 0, 0, 0, 0),
(335, 8, '2014-01-19', 0, 0, 0, 0, 0),
(336, 8, '2014-01-20', 0, 0, 0, 0, 0),
(337, 8, '2014-01-21', 0, 0, 0, 0, 0),
(338, 8, '2014-01-22', 0, 0, 0, 0, 0),
(339, 8, '2014-01-23', 0, 0, 0, 0, 0),
(340, 8, '2014-01-24', 0, 0, 0, 0, 0),
(341, 8, '2014-01-25', 0, 0, 0, 0, 0),
(342, 8, '2014-01-26', 0, 0, 0, 0, 0),
(343, 8, '2014-01-27', 0, 0, 0, 0, 0),
(344, 8, '2014-01-28', 0, 0, 0, 0, 0),
(345, 8, '2014-01-29', 0, 0, 0, 0, 0),
(346, 8, '2014-01-30', 0, 0, 0, 0, 0),
(347, 8, '2014-01-31', 0, 0, 0, 0, 0),
(348, 5, '2014-01-01', 0, 0, 0, 0, 0),
(349, 5, '2014-01-02', 0, 0, 0, 0, 0),
(350, 5, '2014-01-03', 0, 0, 0, 0, 0),
(351, 5, '2014-01-04', 0, 0, 0, 0, 0),
(352, 5, '2014-01-05', 0, 0, 0, 0, 0),
(353, 5, '2014-01-06', 0, 0, 0, 0, 0),
(354, 5, '2014-01-07', 0, 0, 0, 0, 0),
(355, 5, '2014-01-08', 0, 0, 0, 0, 0),
(356, 5, '2014-01-09', 0, 0, 0, 0, 0),
(357, 5, '2014-01-10', 0, 0, 0, 0, 0),
(358, 5, '2014-01-11', 0, 0, 0, 0, 0),
(359, 5, '2014-01-12', 0, 0, 0, 0, 0),
(360, 5, '2014-01-13', 0, 0, 0, 0, 0),
(361, 5, '2014-01-14', 0, 0, 0, 0, 0),
(362, 5, '2014-01-15', 0, 0, 0, 0, 0),
(363, 5, '2014-01-16', 0, 0, 0, 0, 0),
(364, 5, '2014-01-17', 0, 0, 0, 0, 0),
(365, 5, '2014-01-18', 0, 0, 0, 0, 0),
(366, 5, '2014-01-19', 0, 0, 0, 0, 0),
(367, 5, '2014-01-20', 0, 0, 0, 0, 0),
(368, 5, '2014-01-21', 0, 0, 0, 0, 0),
(369, 5, '2014-01-22', 0, 0, 0, 0, 0),
(370, 5, '2014-01-23', 0, 0, 0, 0, 0),
(371, 5, '2014-01-24', 0, 0, 0, 0, 0),
(372, 5, '2014-01-25', 0, 0, 0, 0, 0),
(373, 5, '2014-01-26', 0, 0, 0, 0, 0),
(374, 5, '2014-01-27', 0, 0, 0, 0, 0),
(375, 5, '2014-01-28', 0, 0, 0, 0, 0),
(376, 5, '2014-01-29', 0, 0, 0, 0, 0),
(377, 5, '2014-01-30', 0, 0, 0, 0, 0),
(378, 5, '2014-01-31', 0, 0, 0, 0, 0),
(379, 9, '2014-01-01', 0, 0, 0, 0, 0),
(380, 9, '2014-01-02', 0, 0, 0, 0, 0),
(381, 9, '2014-01-03', 0, 0, 0, 0, 0),
(382, 9, '2014-01-04', 0, 0, 0, 0, 0),
(383, 9, '2014-01-05', 0, 0, 0, 0, 0),
(384, 9, '2014-01-06', 0, 0, 0, 0, 0),
(385, 9, '2014-01-07', 1, 1, 1, 0, 0),
(386, 9, '2014-01-08', 1, 1, 1, 0, 0),
(387, 9, '2014-01-09', 1, 1, 1, 0, 0),
(388, 9, '2014-01-10', 0, 0, 0, 0, 0),
(389, 9, '2014-01-11', 0, 0, 0, 0, 0),
(390, 9, '2014-01-12', 0, 0, 0, 0, 0),
(391, 9, '2014-01-13', 0, 0, 0, 0, 0),
(392, 9, '2014-01-14', 0, 0, 0, 0, 0),
(393, 9, '2014-01-15', 0, 0, 0, 0, 0),
(394, 9, '2014-01-16', 0, 0, 0, 0, 0),
(395, 9, '2014-01-17', 0, 0, 0, 0, 0),
(396, 9, '2014-01-18', 0, 0, 0, 0, 0),
(397, 9, '2014-01-19', 0, 0, 0, 0, 0),
(398, 9, '2014-01-20', 0, 0, 0, 0, 0),
(399, 9, '2014-01-21', 0, 0, 0, 0, 0),
(400, 9, '2014-01-22', 0, 0, 0, 0, 0),
(401, 9, '2014-01-23', 0, 0, 0, 0, 0),
(402, 9, '2014-01-24', 0, 0, 0, 0, 0),
(403, 9, '2014-01-25', 0, 0, 0, 0, 0),
(404, 9, '2014-01-26', 0, 0, 0, 0, 0),
(405, 9, '2014-01-27', 0, 0, 0, 0, 0),
(406, 9, '2014-01-28', 0, 0, 0, 0, 0),
(407, 9, '2014-01-29', 0, 0, 0, 0, 0),
(408, 9, '2014-01-30', 0, 0, 0, 0, 0),
(409, 9, '2014-01-31', 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `cafehappy4_r2c`
--

CREATE TABLE IF NOT EXISTS `cafehappy4_r2c` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_course` int(11) NOT NULL,
  `id_resource` int(11) NOT NULL,
  `value1` double NOT NULL,
  `value2` double NOT NULL,
  PRIMARY KEY (`id`),
  KEY `cafehappy4_r2c_1` (`id_course`),
  KEY `cafehappy4_r2c_2` (`id_resource`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `cafehappy4_r2c`
--


-- --------------------------------------------------------

--
-- Table structure for table `cafehappy4_resource`
--

CREATE TABLE IF NOT EXISTS `cafehappy4_resource` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `idsupplier` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `unit` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `price` int(10) NOT NULL,
  `description` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `cafehappy4_resource_1` (`idsupplier`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=111 ;

--
-- Dumping data for table `cafehappy4_resource`
--

INSERT INTO `cafehappy4_resource` (`id`, `idsupplier`, `name`, `unit`, `price`, `description`) VALUES
(2, 1, 'Đá viên nhỏ', 'Bao', 15000, 'Nước đá viên - Bao 25kg'),
(14, 1, 'Nước đá ướp', 'Cây', 10000, 'Đá cây ướp trái cây'),
(17, 6, 'Bánh', 'Gói', 5000, ''),
(19, 8, 'Hạt loại 1', 'Kg', 60000, ''),
(20, 8, 'Hạt loại 2', 'Kg', 80000, ''),
(27, 6, 'Xúc xích', 'Gói', 17000, ''),
(35, 9, 'Trà xanh 0 độ', 'Thùng', 160000, 'Thùng 24 chai 500ml'),
(36, 9, 'Dr Thanh', 'Thùng', 185000, 'Thùng 24 chai 370 ml'),
(39, 9, 'Pepsi', 'Thùng', 150000, 'Thùng 24 lon 330 ml'),
(40, 9, 'Mirinda Cam', 'Thùng', 120000, 'Thùng 24 lon 330ml'),
(43, 9, 'Sting dâu', 'Thùng', 170000, 'Thùng 24 chai 330ml'),
(47, 12, 'Ổi', 'Kg', 9000, ''),
(48, 12, 'Củ sắn', 'Kg', 15000, ''),
(49, 12, 'Mít', 'Kg', 18000, ''),
(50, 12, 'Chôm chôm', 'Kg', 10000, ''),
(51, 12, 'Xoài Thái', 'Kg', 15000, ''),
(52, 12, 'Xoài Đài Loan', 'Kg', 15000, ''),
(53, 12, 'Xoài chua', 'Kg', 15000, ''),
(54, 12, 'Mận', 'Kg', 10000, ''),
(55, 12, 'Sơ ri', 'Kg', 12000, ''),
(56, 12, 'Thơm', 'Kg', 12000, ''),
(57, 12, 'Khóm', 'Kg', 10000, ''),
(79, 12, 'Dưa hấu', 'Kg', 10000, ''),
(82, 12, 'Táo', 'Kg', 10000, ''),
(84, 12, 'Cóc', 'Kg', 6000, ''),
(91, 1, 'Đá ống viên lớn', 'Kg', 800, 'Bao 20kg'),
(99, 12, 'Bưởi', 'Kg', 10000, ''),
(101, 8, 'Hạt loại 3', 'Kg', 120000, ''),
(102, 13, 'Duong', 'Kg', 20000, ''),
(103, 9, 'C2', 'Thùng', 105000, '24 chai'),
(104, 9, 'Lipton', 'Hộp', 105000, '100 gói'),
(105, 9, 'Revive', 'Thùng', 174000, '24 chai'),
(106, 9, 'Ô Long', 'Thùng', 135000, '24 chai'),
(107, 12, 'Cà chua', 'Kg', 0, ''),
(108, 12, 'Cà rốt', 'Kg', 0, ''),
(109, 9, 'Mountain Dew', 'Thùng', 142000, '24 chai'),
(110, 12, 'Dừa', 'Trái', 7000, 'gọt sẵn');

-- --------------------------------------------------------

--
-- Table structure for table `cafehappy4_session`
--

CREATE TABLE IF NOT EXISTS `cafehappy4_session` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idtable` int(11) NOT NULL,
  `iduser` int(11) NOT NULL,
  `idcustomer` int(11) NOT NULL,
  `idemployee` int(11) NOT NULL,
  `datetime` datetime NOT NULL,
  `datetimeend` datetime DEFAULT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `status` int(11) NOT NULL,
  `discount_value` int(11) NOT NULL,
  `discount_percent` int(11) NOT NULL,
  `surtax` int(11) NOT NULL,
  `payment` int(11) NOT NULL,
  `value` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idtable` (`idtable`),
  KEY `iduser` (`iduser`),
  KEY `cafehappy4_session_3` (`idcustomer`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=777 ;

--
-- Dumping data for table `cafehappy4_session`
--

INSERT INTO `cafehappy4_session` (`id`, `idtable`, `iduser`, `idcustomer`, `idemployee`, `datetime`, `datetimeend`, `note`, `status`, `discount_value`, `discount_percent`, `surtax`, `payment`, `value`) VALUES
(230, 32, 4, 1, 1, '2014-01-04 20:37:56', '2014-01-04 20:37:56', 'P', 1, 0, 0, 0, 0, 0),
(232, 41, 4, 1, 1, '2014-01-04 20:38:41', '2014-01-04 20:38:41', 'P', 1, 0, 0, 0, 0, 0),
(235, 38, 4, 1, 1, '2014-01-05 07:48:36', '2014-01-05 07:48:36', 'P', 1, 0, 0, 0, 0, 0),
(237, 178, 4, 1, 1, '2014-01-05 08:01:32', '2014-01-05 08:01:32', 'P', 1, 0, 0, 0, 0, 0),
(238, 34, 4, 1, 1, '2014-01-05 08:38:02', '2014-01-05 08:38:02', 'P', 1, 0, 0, 0, 0, 0),
(239, 31, 4, 1, 1, '2014-01-05 08:43:57', '2014-01-05 08:43:57', 'P', 1, 0, 0, 0, 0, 0),
(240, 32, 4, 1, 1, '2014-01-05 09:01:38', '2014-01-05 09:01:38', 'P', 1, 0, 0, 0, 0, 0),
(241, 143, 4, 1, 1, '2014-01-05 09:21:31', '2014-01-05 09:21:31', 'P', 1, 0, 0, 0, 0, 0),
(242, 30, 4, 1, 1, '2014-01-05 09:30:36', '2014-01-05 09:30:36', 'P', 1, 0, 0, 0, 0, 0),
(243, 38, 4, 1, 1, '2014-01-05 09:31:51', '2014-01-05 09:31:51', 'P', 1, 0, 0, 0, 0, 0),
(244, 156, 4, 1, 1, '2014-01-05 12:44:14', '2014-01-05 12:44:14', 'P', 1, 0, 0, 0, 0, 0),
(245, 150, 4, 1, 1, '2014-01-05 12:47:16', '2014-01-05 12:47:16', 'P', 1, 0, 0, 0, 0, 0),
(248, 31, 4, 1, 1, '2014-01-05 13:21:42', '2014-01-05 13:21:42', 'P', 1, 0, 0, 0, 0, 0),
(249, 33, 4, 1, 1, '2014-01-05 13:54:04', '2014-01-05 13:54:04', 'P', 1, 0, 0, 0, 0, 0),
(250, 149, 4, 1, 1, '2014-01-05 13:55:18', '2014-01-05 13:55:18', 'P', 1, 0, 0, 0, 0, 0),
(252, 136, 4, 1, 1, '2014-01-05 17:13:19', '2014-01-05 17:13:19', 'P', 1, 0, 0, 0, 0, 0),
(253, 149, 4, 1, 1, '2014-01-05 17:15:52', '2014-01-05 17:15:52', 'P', 1, 0, 0, 0, 0, 0),
(254, 137, 4, 1, 1, '2014-01-05 17:54:35', '2014-01-05 17:54:35', 'P', 1, 0, 0, 0, 0, 0),
(256, 178, 4, 1, 1, '2014-01-05 18:10:39', '2014-01-05 18:10:39', 'P', 1, 0, 0, 0, 0, 0),
(257, 133, 4, 1, 1, '2014-01-05 18:11:18', '2014-01-05 18:11:18', 'P', 1, 0, 0, 0, 0, 0),
(258, 2, 4, 1, 1, '2014-01-05 19:37:40', '2014-01-05 19:37:40', 'P', 1, 0, 0, 0, 0, 0),
(259, 1, 4, 1, 1, '2014-01-05 19:38:07', '2014-01-05 19:38:07', 'P', 1, 0, 0, 0, 0, 0),
(260, 140, 4, 1, 1, '2014-01-05 19:39:17', '2014-01-05 19:39:17', 'P', 1, 0, 0, 0, 0, 0),
(261, 177, 4, 1, 1, '2014-01-05 19:41:06', '2014-01-05 19:41:06', 'P', 1, 0, 0, 0, 0, 0),
(262, 33, 4, 1, 4, '2014-01-05 19:41:41', '2014-01-05 19:41:41', 'P', 1, 0, 0, 0, 0, 0),
(264, 1, 4, 1, 1, '2014-01-05 19:51:30', '2014-01-05 19:51:30', 'P', 1, 0, 0, 0, 0, 0),
(265, 178, 4, 1, 1, '2014-01-05 19:54:24', '2014-01-05 19:54:24', 'P', 1, 0, 0, 0, 0, 0),
(266, 29, 4, 1, 1, '2014-01-05 20:02:44', '2014-01-05 20:02:44', 'P', 1, 0, 0, 0, 0, 0),
(267, 137, 4, 1, 1, '2014-01-05 20:07:41', '2014-01-05 20:07:41', 'P', 1, 0, 0, 0, 0, 0),
(268, 133, 4, 1, 1, '2014-01-05 20:11:33', '2014-01-05 20:11:33', 'P', 1, 0, 0, 0, 0, 0),
(269, 156, 4, 1, 1, '2014-01-05 20:12:25', '2014-01-05 20:12:25', 'P', 1, 0, 0, 0, 0, 0),
(270, 188, 4, 1, 1, '2014-01-05 20:12:50', '2014-01-05 20:12:50', 'P', 1, 0, 0, 0, 0, 0),
(271, 1, 4, 1, 1, '2014-01-05 20:19:50', '2014-01-05 20:19:50', 'P', 1, 0, 0, 0, 0, 0),
(272, 143, 4, 1, 1, '2014-01-05 20:27:37', '2014-01-05 20:27:37', 'P', 1, 0, 0, 0, 0, 0),
(277, 38, 4, 1, 1, '2014-01-05 21:32:48', '2014-01-05 21:32:48', 'P', 1, 0, 0, 0, 0, 0),
(278, 162, 4, 1, 1, '2014-01-05 22:17:54', '2014-01-05 22:17:54', 'P', 1, 0, 0, 0, 0, 0),
(280, 162, 4, 1, 1, '2014-01-05 23:50:52', '2014-01-05 23:50:52', 'P', 1, 0, 0, 0, 0, 0),
(281, 28, 4, 1, 1, '2014-01-06 06:42:32', '2014-01-06 06:42:32', 'P', 1, 0, 0, 0, 0, 0),
(282, 28, 4, 1, 1, '2014-01-06 06:46:35', '2014-01-06 06:46:35', 'P', 1, 0, 0, 0, 0, 0),
(283, 38, 4, 1, 1, '2014-01-06 07:12:45', '2014-01-06 07:12:45', 'P', 1, 0, 0, 0, 0, 0),
(284, 143, 4, 1, 1, '2014-01-06 07:13:45', '2014-01-06 07:13:45', 'P', 1, 0, 0, 0, 0, 0),
(285, 41, 4, 1, 1, '2014-01-06 07:22:28', '2014-01-06 07:22:28', 'P', 1, 0, 0, 0, 0, 0),
(286, 38, 4, 1, 1, '2014-01-06 07:30:11', '2014-01-06 07:30:11', 'P', 1, 0, 0, 0, 0, 0),
(287, 150, 4, 1, 1, '2014-01-06 07:36:57', '2014-01-06 07:36:57', 'P', 1, 0, 0, 0, 0, 0),
(288, 145, 4, 1, 1, '2014-01-06 07:43:29', '2014-01-06 07:43:29', 'P', 1, 0, 0, 0, 0, 0),
(289, 41, 4, 1, 1, '2014-01-06 07:49:04', '2014-01-06 07:49:04', 'P', 1, 0, 0, 0, 0, 0),
(290, 135, 4, 1, 1, '2014-01-06 07:53:26', '2014-01-06 07:53:26', 'P', 1, 0, 0, 0, 0, 0),
(291, 34, 4, 1, 1, '2014-01-06 08:17:06', '2014-01-06 08:17:06', 'P', 1, 0, 0, 0, 0, 0),
(292, 143, 4, 1, 1, '2014-01-06 08:24:38', '2014-01-06 08:24:38', 'P', 1, 0, 0, 0, 0, 0),
(293, 150, 4, 1, 1, '2014-01-06 09:11:53', '2014-01-06 09:11:53', 'P', 1, 0, 0, 0, 0, 0),
(295, 1, 4, 1, 1, '2014-01-06 09:15:48', '2014-01-06 09:15:48', 'P', 1, 0, 0, 0, 0, 0),
(296, 145, 4, 1, 1, '2014-01-06 09:24:52', '2014-01-06 09:24:52', 'P', 1, 0, 0, 0, 0, 0),
(297, 151, 4, 1, 1, '2014-01-06 09:34:02', '2014-01-06 09:34:02', 'P', 1, 0, 0, 0, 0, 0),
(298, 32, 4, 1, 1, '2014-01-06 09:36:16', '2014-01-06 09:36:16', 'P', 1, 0, 0, 0, 0, 0),
(299, 28, 4, 1, 1, '2014-01-06 09:43:56', '2014-01-06 09:43:56', 'P', 1, 0, 0, 0, 0, 0),
(301, 135, 4, 1, 1, '2014-01-06 10:05:01', '2014-01-06 10:05:01', 'P', 1, 0, 0, 0, 0, 0),
(302, 1, 4, 1, 1, '2014-01-06 10:30:44', '2014-01-06 10:30:44', 'P', 1, 0, 0, 0, 0, 0),
(303, 166, 4, 1, 1, '2014-01-06 10:37:43', '2014-01-06 10:37:43', 'P', 1, 0, 0, 0, 0, 0),
(304, 149, 4, 1, 1, '2014-01-06 10:48:59', '2014-01-06 10:48:59', 'P', 1, 0, 0, 0, 0, 0),
(305, 150, 4, 1, 1, '2014-01-06 12:02:28', '2014-01-06 12:02:28', 'P', 1, 0, 0, 0, 0, 0),
(306, 150, 4, 1, 1, '2014-01-06 13:42:59', '2014-01-06 13:42:59', 'P', 1, 0, 0, 0, 0, 0),
(307, 168, 4, 1, 1, '2014-01-06 14:10:19', '2014-01-06 14:10:19', 'P', 1, 0, 0, 0, 0, 0),
(308, 144, 4, 1, 1, '2014-01-06 14:33:42', '2014-01-06 14:33:42', 'P', 1, 0, 0, 0, 0, 0),
(309, 142, 4, 1, 1, '2014-01-06 14:44:29', '2014-01-06 14:44:29', 'P', 1, 0, 0, 0, 0, 0),
(310, 35, 4, 1, 1, '2014-01-06 14:46:45', '2014-01-06 14:46:45', 'P', 1, 0, 0, 0, 0, 0),
(311, 178, 4, 1, 1, '2014-01-06 14:55:48', '2014-01-06 14:55:48', 'P', 1, 0, 0, 0, 0, 0),
(312, 1, 4, 1, 1, '2014-01-06 14:56:43', '2014-01-06 14:56:43', 'P', 1, 0, 0, 0, 0, 0),
(313, 141, 4, 1, 1, '2014-01-06 14:59:35', '2014-01-06 14:59:35', 'P', 1, 0, 0, 0, 0, 0),
(314, 142, 4, 1, 1, '2014-01-06 15:00:33', '2014-01-06 15:00:33', 'P', 1, 0, 0, 0, 0, 0),
(315, 140, 4, 1, 1, '2014-01-06 15:24:33', '2014-01-06 15:24:33', 'P', 1, 0, 0, 0, 0, 0),
(316, 185, 4, 1, 1, '2014-01-06 15:41:58', '2014-01-06 15:41:58', 'P', 1, 0, 0, 0, 0, 0),
(317, 32, 4, 1, 1, '2014-01-06 16:46:31', '2014-01-06 16:46:31', 'P', 1, 0, 0, 0, 0, 0),
(318, 31, 4, 1, 1, '2014-01-06 16:46:46', '2014-01-06 16:46:46', 'P', 1, 0, 0, 0, 0, 0),
(319, 4, 4, 1, 1, '2014-01-06 17:46:01', '2014-01-06 17:46:01', 'P', 1, 0, 0, 0, 0, 0),
(320, 32, 4, 1, 1, '2014-01-06 17:47:03', '2014-01-06 17:47:03', 'P', 1, 0, 0, 0, 0, 0),
(321, 28, 4, 1, 1, '2014-01-06 17:49:54', '2014-01-06 17:49:54', 'P', 1, 0, 0, 0, 0, 0),
(322, 136, 4, 1, 1, '2014-01-06 18:03:00', '2014-01-06 18:03:00', 'P', 1, 0, 0, 0, 0, 0),
(324, 3, 4, 1, 1, '2014-01-06 18:06:04', '2014-01-06 18:06:04', 'P', 1, 0, 0, 0, 0, 0),
(325, 1, 4, 1, 1, '2014-01-06 18:06:36', '2014-01-06 18:06:36', 'P', 1, 0, 0, 0, 0, 0),
(326, 38, 4, 1, 1, '2014-01-06 18:13:05', '2014-01-06 18:13:05', 'P', 1, 0, 0, 0, 0, 0),
(327, 41, 4, 1, 1, '2014-01-06 18:14:11', '2014-01-06 18:14:11', 'P', 1, 0, 0, 0, 0, 0),
(328, 133, 4, 1, 1, '2014-01-06 18:16:26', '2014-01-06 18:16:26', 'P', 1, 0, 0, 0, 0, 0),
(330, 33, 4, 1, 1, '2014-01-06 18:26:45', '2014-01-06 18:26:45', 'P', 1, 0, 0, 0, 0, 0),
(331, 2, 4, 1, 1, '2014-01-06 18:26:55', '2014-01-06 18:26:55', 'P', 1, 0, 0, 0, 0, 0),
(332, 30, 4, 1, 1, '2014-01-06 18:27:10', '2014-01-06 18:27:10', 'P', 1, 0, 0, 0, 0, 0),
(333, 135, 4, 1, 1, '2014-01-06 18:27:36', '2014-01-06 18:27:36', 'P', 1, 0, 0, 0, 0, 0),
(334, 178, 4, 1, 1, '2014-01-06 18:31:55', '2014-01-06 18:31:55', 'P', 1, 0, 0, 0, 0, 0),
(335, 135, 4, 1, 1, '2014-01-06 18:32:39', '2014-01-06 18:32:39', 'P', 1, 0, 0, 0, 0, 0),
(336, 137, 4, 1, 1, '2014-01-06 18:35:59', '2014-01-06 18:35:59', 'P', 1, 0, 0, 0, 0, 0),
(337, 141, 4, 1, 1, '2014-01-06 18:37:22', '2014-01-06 18:37:22', 'P', 1, 0, 0, 0, 0, 0),
(338, 140, 4, 1, 1, '2014-01-06 18:40:50', '2014-01-06 18:40:50', 'P', 1, 0, 0, 0, 0, 0),
(339, 34, 4, 1, 1, '2014-01-06 18:42:12', '2014-01-06 18:42:12', 'P', 1, 0, 0, 0, 0, 0),
(340, 143, 4, 1, 1, '2014-01-06 18:46:12', '2014-01-06 18:46:12', 'P', 1, 0, 0, 0, 0, 0),
(341, 2, 4, 1, 1, '2014-01-06 18:56:10', '2014-01-06 18:56:10', 'P', 1, 0, 0, 0, 0, 0),
(342, 2, 4, 1, 1, '2014-01-06 18:57:22', '2014-01-06 18:57:22', 'P', 1, 0, 0, 0, 0, 0),
(343, 142, 4, 1, 1, '2014-01-06 18:57:37', '2014-01-06 18:57:37', 'P', 1, 0, 0, 0, 0, 0),
(344, 136, 4, 1, 1, '2014-01-06 19:05:58', '2014-01-06 19:05:58', 'P', 1, 0, 0, 0, 0, 0),
(345, 136, 4, 1, 1, '2014-01-06 19:09:00', '2014-01-06 19:09:00', 'P', 1, 0, 0, 0, 0, 0),
(346, 38, 4, 1, 1, '2014-01-06 19:15:08', '2014-01-06 19:15:08', 'P', 1, 0, 0, 0, 0, 0),
(347, 144, 4, 1, 1, '2014-01-06 19:15:59', '2014-01-06 19:15:59', 'P', 1, 0, 0, 0, 0, 0),
(348, 149, 4, 1, 1, '2014-01-06 19:20:24', '2014-01-06 19:20:24', 'P', 1, 0, 0, 0, 0, 0),
(350, 31, 4, 1, 1, '2014-01-06 19:32:43', '2014-01-06 19:32:43', 'P', 1, 0, 0, 0, 0, 0),
(351, 178, 4, 1, 1, '2014-01-06 19:35:17', '2014-01-06 19:35:17', 'P', 1, 0, 0, 0, 0, 0),
(352, 34, 4, 1, 1, '2014-01-06 19:38:28', '2014-01-06 19:38:28', 'P', 1, 0, 0, 0, 0, 0),
(353, 143, 4, 1, 1, '2014-01-06 19:50:57', '2014-01-06 19:50:57', 'P', 1, 0, 0, 0, 0, 0),
(354, 151, 4, 1, 1, '2014-01-06 19:51:44', '2014-01-06 19:51:44', 'P', 1, 0, 0, 0, 0, 0),
(355, 144, 4, 1, 1, '2014-01-06 20:02:53', '2014-01-06 20:02:53', 'P', 1, 0, 0, 0, 0, 0),
(356, 2, 4, 1, 1, '2014-01-06 20:04:50', '2014-01-06 20:04:50', 'P', 1, 0, 0, 0, 0, 0),
(360, 41, 4, 1, 1, '2014-01-06 20:35:40', '2014-01-06 20:35:40', 'P', 1, 0, 0, 0, 0, 0),
(361, 2, 4, 1, 1, '2014-01-06 20:38:18', '2014-01-06 20:38:18', 'P', 1, 0, 0, 0, 0, 0),
(362, 136, 4, 1, 1, '2014-01-06 21:04:14', '2014-01-06 21:04:14', 'P', 1, 0, 0, 0, 0, 0),
(363, 178, 4, 1, 1, '2014-01-06 21:04:36', '2014-01-06 21:04:36', 'P', 1, 0, 0, 0, 0, 0),
(364, 1, 4, 1, 1, '2014-01-07 08:30:26', '2014-01-07 08:30:26', 'P', 1, 0, 0, 0, 0, 0),
(365, 177, 4, 1, 1, '2014-01-07 08:31:34', '2014-01-07 08:31:34', 'P', 1, 0, 0, 0, 0, 0),
(366, 2, 4, 1, 1, '2014-01-07 08:35:35', '2014-01-07 08:35:35', 'P', 1, 0, 0, 0, 0, 0),
(367, 41, 4, 1, 1, '2014-01-07 08:39:33', '2014-01-07 08:39:33', 'P', 1, 0, 0, 0, 0, 0),
(368, 32, 4, 1, 1, '2014-01-07 09:03:16', '2014-01-07 09:03:16', 'P', 1, 0, 0, 0, 0, 0),
(369, 35, 4, 1, 1, '2014-01-07 09:04:15', '2014-01-07 09:04:15', 'P', 1, 0, 0, 0, 0, 0),
(370, 28, 4, 1, 1, '2014-01-07 09:34:56', '2014-01-07 09:34:56', 'P', 1, 0, 0, 0, 0, 0),
(371, 35, 4, 1, 1, '2014-01-07 09:44:53', '2014-01-07 09:44:53', 'P', 1, 0, 0, 0, 0, 0),
(372, 2, 4, 1, 1, '2014-01-07 10:01:55', '2014-01-07 10:01:55', 'P', 1, 0, 0, 0, 0, 0),
(373, 34, 4, 1, 1, '2014-01-07 10:20:17', '2014-01-07 10:20:17', 'P', 1, 0, 0, 0, 0, 0),
(374, 1, 4, 1, 1, '2014-01-07 10:20:37', '2014-01-07 10:20:37', 'P', 1, 0, 0, 0, 0, 0),
(375, 140, 4, 1, 1, '2014-01-07 10:31:07', '2014-01-07 10:31:07', 'P', 1, 0, 0, 0, 0, 0),
(376, 140, 4, 1, 1, '2014-01-07 10:42:28', '2014-01-07 10:42:28', 'P', 1, 0, 0, 0, 0, 0),
(377, 166, 4, 1, 1, '2014-01-07 11:01:47', '2014-01-07 11:01:47', 'P', 1, 0, 0, 0, 0, 0),
(378, 29, 4, 1, 1, '2014-01-07 11:21:16', '2014-01-07 11:21:16', 'P', 1, 0, 0, 0, 0, 0),
(379, 149, 4, 1, 1, '2014-01-07 11:29:38', '2014-01-07 11:29:38', 'P', 1, 0, 0, 0, 0, 0),
(380, 168, 4, 1, 1, '2014-01-07 11:30:06', '2014-01-07 11:30:06', 'P', 1, 0, 0, 0, 0, 0),
(381, 144, 4, 1, 1, '2014-01-07 11:39:54', '2014-01-07 11:39:54', 'P', 1, 0, 0, 0, 0, 0),
(382, 140, 4, 1, 1, '2014-01-07 11:46:32', '2014-01-07 11:46:32', 'P', 1, 0, 0, 0, 0, 0),
(383, 1, 4, 1, 1, '2014-01-07 11:46:57', '2014-01-07 11:46:57', 'P', 1, 0, 0, 0, 0, 0),
(384, 179, 4, 1, 1, '2014-01-07 12:30:51', '2014-01-07 12:30:51', 'P', 1, 0, 0, 0, 0, 0),
(385, 2, 4, 1, 1, '2014-01-07 13:02:18', '2014-01-07 13:02:18', 'P', 1, 0, 0, 0, 0, 0),
(386, 149, 4, 1, 1, '2014-01-07 13:24:18', '2014-01-07 13:24:18', 'P', 1, 0, 0, 0, 0, 0),
(387, 143, 4, 1, 1, '2014-01-07 13:49:33', '2014-01-07 13:49:33', 'P', 1, 0, 0, 0, 0, 0),
(388, 144, 4, 1, 1, '2014-01-07 13:50:41', '2014-01-07 13:50:41', 'P', 1, 0, 0, 0, 0, 0),
(389, 175, 4, 1, 1, '2014-01-07 14:10:49', '2014-01-07 14:10:49', 'P', 1, 0, 0, 0, 0, 0),
(390, 33, 4, 1, 1, '2014-01-07 15:09:26', '2014-01-07 15:09:26', 'P', 1, 0, 0, 0, 0, 0),
(391, 144, 4, 1, 1, '2014-01-07 15:42:35', '2014-01-07 15:42:35', 'P', 1, 0, 0, 0, 0, 0),
(392, 156, 4, 1, 1, '2014-01-07 16:04:11', '2014-01-07 16:04:11', 'P', 1, 0, 0, 0, 0, 0),
(393, 143, 4, 1, 1, '2014-01-07 16:42:13', '2014-01-07 16:42:13', 'P', 1, 0, 0, 0, 0, 0),
(394, 1, 4, 1, 1, '2014-01-07 16:45:27', '2014-01-07 16:45:27', 'P', 1, 0, 0, 0, 0, 0),
(395, 41, 4, 1, 1, '2014-01-07 17:20:11', '2014-01-07 17:20:11', 'P', 1, 0, 0, 0, 0, 0),
(396, 177, 4, 1, 1, '2014-01-07 17:23:03', '2014-01-07 17:23:03', 'P', 1, 0, 0, 0, 0, 0),
(397, 32, 4, 1, 1, '2014-01-07 17:58:55', '2014-01-07 17:58:55', 'P', 1, 0, 0, 0, 0, 0),
(398, 133, 4, 1, 1, '2014-01-07 18:06:02', '2014-01-07 18:06:02', 'P', 1, 0, 0, 0, 0, 0),
(399, 28, 4, 1, 1, '2014-01-07 18:20:15', '2014-01-07 18:20:15', 'P', 1, 0, 0, 0, 0, 0),
(400, 2, 4, 1, 1, '2014-01-07 18:24:13', '2014-01-07 18:24:13', 'P', 1, 0, 0, 0, 0, 0),
(401, 135, 4, 1, 1, '2014-01-07 18:49:17', '2014-01-07 18:49:17', 'P', 1, 0, 0, 0, 0, 0),
(402, 30, 4, 1, 1, '2014-01-07 18:58:20', '2014-01-07 18:58:20', 'P', 1, 0, 0, 0, 0, 0),
(403, 2, 4, 1, 1, '2014-01-07 19:27:11', '2014-01-07 19:27:11', 'P', 1, 0, 0, 0, 0, 0),
(404, 41, 4, 1, 1, '2014-01-07 19:48:00', '2014-01-07 19:48:00', 'P', 1, 0, 0, 0, 0, 0),
(405, 142, 4, 1, 1, '2014-01-07 19:50:41', '2014-01-07 19:50:41', 'P', 1, 0, 0, 0, 0, 0),
(406, 177, 4, 1, 1, '2014-01-07 19:52:35', '2014-01-07 19:52:35', 'P', 1, 0, 0, 0, 0, 0),
(407, 185, 4, 1, 1, '2014-01-07 20:06:54', '2014-01-07 20:06:54', 'P', 1, 0, 0, 0, 0, 0),
(408, 144, 4, 1, 1, '2014-01-07 20:46:01', '2014-01-07 20:46:01', 'P', 1, 0, 0, 0, 0, 0),
(409, 33, 4, 1, 1, '2014-01-07 20:50:20', '2014-01-07 20:50:20', 'P', 1, 0, 0, 0, 0, 0),
(410, 140, 4, 1, 1, '2014-01-07 21:12:23', '2014-01-07 21:12:23', 'P', 1, 0, 0, 0, 0, 0),
(412, 142, 4, 1, 1, '2014-01-07 21:26:41', '2014-01-07 21:26:41', 'P', 1, 0, 0, 0, 0, 0),
(413, 41, 4, 1, 1, '2014-01-08 06:53:47', '2014-01-08 06:53:47', 'P', 1, 0, 0, 0, 0, 0),
(414, 34, 4, 1, 1, '2014-01-08 06:54:38', '2014-01-08 06:54:38', 'P', 1, 0, 0, 0, 0, 0),
(415, 38, 4, 1, 1, '2014-01-08 07:08:59', '2014-01-08 07:08:59', 'P', 1, 0, 0, 0, 0, 0),
(416, 4, 4, 1, 1, '2014-01-08 07:34:31', '2014-01-08 07:34:31', 'P', 1, 0, 0, 0, 0, 0),
(417, 38, 4, 1, 1, '2014-01-08 07:39:25', '2014-01-08 07:39:25', 'P', 1, 0, 0, 0, 0, 0),
(418, 151, 4, 1, 1, '2014-01-08 07:39:52', '2014-01-08 07:39:52', 'P', 1, 0, 0, 0, 0, 0),
(419, 136, 4, 1, 1, '2014-01-08 08:33:18', '2014-01-08 08:33:18', 'P', 1, 0, 0, 0, 0, 0),
(420, 150, 4, 1, 1, '2014-01-08 09:32:56', '2014-01-08 09:32:56', 'P', 1, 0, 0, 0, 0, 0),
(421, 136, 4, 1, 1, '2014-01-08 09:33:30', '2014-01-08 09:33:30', 'P', 1, 0, 0, 0, 0, 0),
(422, 140, 4, 1, 1, '2014-01-08 09:33:46', '2014-01-08 09:33:46', 'P', 1, 0, 0, 0, 0, 0),
(423, 156, 4, 1, 1, '2014-01-08 09:37:40', '2014-01-08 09:37:40', 'P', 1, 0, 0, 0, 0, 0),
(424, 2, 4, 1, 1, '2014-01-08 09:49:32', '2014-01-08 09:49:32', 'P', 1, 0, 0, 0, 0, 0),
(425, 150, 4, 1, 1, '2014-01-08 10:36:17', '2014-01-08 10:36:17', 'P', 1, 0, 0, 0, 0, 0),
(426, 33, 4, 1, 1, '2014-01-08 10:46:30', '2014-01-08 10:46:30', 'P', 1, 0, 0, 0, 0, 0),
(427, 31, 4, 1, 1, '2014-01-08 10:46:46', '2014-01-08 10:46:46', 'P', 1, 0, 0, 0, 0, 0),
(428, 166, 4, 1, 1, '2014-01-08 10:50:51', '2014-01-08 10:50:51', 'P', 1, 0, 0, 0, 0, 0),
(429, 34, 4, 1, 1, '2014-01-08 11:46:33', '2014-01-08 11:46:33', 'P', 1, 0, 0, 0, 0, 0),
(430, 150, 4, 1, 1, '2014-01-08 11:59:30', '2014-01-08 11:59:30', 'P', 1, 0, 0, 0, 0, 0),
(431, 140, 4, 1, 1, '2014-01-08 12:07:29', '2014-01-08 12:07:29', 'P', 1, 0, 0, 0, 0, 0),
(432, 185, 4, 1, 1, '2014-01-08 12:28:42', '2014-01-08 12:28:42', 'P', 1, 0, 0, 0, 0, 0),
(433, 31, 4, 1, 1, '2014-01-08 14:20:23', '2014-01-08 14:20:23', 'P', 1, 0, 0, 0, 0, 0),
(434, 2, 4, 1, 1, '2014-01-08 14:21:42', '2014-01-08 14:21:42', 'P', 1, 0, 0, 0, 0, 0),
(435, 177, 4, 1, 1, '2014-01-08 14:26:40', '2014-01-08 14:26:40', 'P', 1, 0, 0, 0, 0, 0),
(436, 29, 4, 1, 1, '2014-01-08 14:37:50', '2014-01-08 14:37:50', 'P', 1, 0, 0, 0, 0, 0),
(437, 1, 4, 1, 1, '2014-01-08 15:06:41', '2014-01-08 15:06:41', 'P', 1, 0, 0, 0, 0, 0),
(438, 2, 4, 1, 1, '2014-01-08 15:07:07', '2014-01-08 15:07:07', 'P', 1, 0, 0, 0, 0, 0),
(439, 144, 4, 1, 1, '2014-01-08 15:09:44', '2014-01-08 15:09:44', 'P', 1, 0, 0, 0, 0, 0),
(440, 144, 4, 1, 1, '2014-01-08 15:17:23', '2014-01-08 15:17:23', 'P', 1, 0, 0, 0, 0, 0),
(441, 34, 4, 1, 1, '2014-01-08 15:19:12', '2014-01-08 15:19:12', 'P', 1, 0, 0, 0, 0, 0),
(442, 31, 4, 1, 1, '2014-01-08 16:03:18', '2014-01-08 16:03:18', 'P', 1, 0, 0, 0, 0, 0),
(443, 185, 4, 1, 1, '2014-01-08 16:05:59', '2014-01-08 16:05:59', 'P', 1, 0, 0, 0, 0, 0),
(444, 32, 4, 1, 1, '2014-01-08 16:25:40', '2014-01-08 16:25:40', 'P', 1, 0, 0, 0, 0, 0),
(445, 3, 4, 1, 1, '2014-01-08 17:29:03', '2014-01-08 17:29:03', 'P', 1, 0, 0, 0, 0, 0),
(446, 35, 4, 1, 1, '2014-01-08 17:29:25', '2014-01-08 17:29:25', 'P', 1, 0, 0, 0, 0, 0),
(447, 1, 4, 1, 1, '2014-01-08 17:36:16', '2014-01-08 17:36:16', 'P', 1, 0, 0, 0, 0, 0),
(448, 1, 4, 1, 1, '2014-01-08 17:40:26', '2014-01-08 17:40:26', 'P', 1, 0, 0, 0, 0, 0),
(449, 32, 4, 1, 1, '2014-01-08 17:43:48', '2014-01-08 17:43:48', 'P', 1, 0, 0, 0, 0, 0),
(450, 33, 4, 1, 1, '2014-01-08 17:46:48', '2014-01-08 17:46:48', 'P', 1, 0, 0, 0, 0, 0),
(451, 28, 4, 1, 1, '2014-01-08 17:51:47', '2014-01-08 17:51:47', 'P', 1, 0, 0, 0, 0, 0),
(452, 137, 4, 1, 1, '2014-01-08 17:53:36', '2014-01-08 17:53:36', 'P', 1, 0, 0, 0, 0, 0),
(453, 4, 4, 1, 1, '2014-01-08 17:54:54', '2014-01-08 17:54:54', 'P', 1, 0, 0, 0, 0, 0),
(454, 34, 4, 1, 1, '2014-01-08 17:56:39', '2014-01-08 17:56:39', 'P', 1, 0, 0, 0, 0, 0),
(455, 1, 4, 1, 1, '2014-01-08 17:57:46', '2014-01-08 17:57:46', 'P', 1, 0, 0, 0, 0, 0),
(456, 184, 4, 1, 1, '2014-01-08 17:58:42', '2014-01-08 17:58:42', 'P', 1, 0, 0, 0, 0, 0),
(457, 35, 4, 1, 1, '2014-01-08 18:03:18', '2014-01-08 18:03:18', 'P', 1, 0, 0, 0, 0, 0),
(458, 178, 4, 1, 1, '2014-01-08 18:05:44', '2014-01-08 18:05:44', 'P', 1, 0, 0, 0, 0, 0),
(459, 1, 4, 1, 1, '2014-01-08 18:09:26', '2014-01-08 18:09:26', 'P', 1, 0, 0, 0, 0, 0),
(460, 33, 4, 1, 1, '2014-01-08 18:10:02', '2014-01-08 18:10:02', 'P', 1, 0, 0, 0, 0, 0),
(461, 178, 4, 1, 1, '2014-01-08 18:10:41', '2014-01-08 18:10:41', 'P', 1, 0, 0, 0, 0, 0),
(462, 1, 4, 1, 1, '2014-01-08 18:11:52', '2014-01-08 18:11:52', 'P', 1, 0, 0, 0, 0, 0),
(463, 29, 4, 1, 1, '2014-01-08 18:12:49', '2014-01-08 18:12:49', 'P', 1, 0, 0, 0, 0, 0),
(464, 184, 4, 1, 1, '2014-01-08 18:15:05', '2014-01-08 18:15:05', 'P', 1, 0, 0, 0, 0, 0),
(465, 183, 4, 1, 1, '2014-01-08 18:15:53', '2014-01-08 18:15:53', 'P', 1, 0, 0, 0, 0, 0),
(466, 135, 4, 1, 1, '2014-01-08 18:17:40', '2014-01-08 18:17:40', 'P', 1, 0, 0, 0, 0, 0),
(467, 41, 4, 1, 1, '2014-01-08 18:18:06', '2014-01-08 18:18:06', 'P', 1, 0, 0, 0, 0, 0),
(468, 32, 4, 1, 1, '2014-01-08 18:19:17', '2014-01-08 18:19:17', 'P', 1, 0, 0, 0, 0, 0),
(469, 136, 4, 1, 1, '2014-01-08 18:20:06', '2014-01-08 18:20:06', 'P', 1, 0, 0, 0, 0, 0),
(470, 136, 4, 1, 1, '2014-01-08 18:21:10', '2014-01-08 18:21:10', 'P', 1, 0, 0, 0, 0, 0),
(471, 34, 4, 1, 1, '2014-01-08 18:24:34', '2014-01-08 18:24:34', 'P', 1, 0, 0, 0, 0, 0),
(472, 138, 4, 1, 1, '2014-01-08 18:26:24', '2014-01-08 18:26:24', 'P', 1, 0, 0, 0, 0, 0),
(473, 33, 4, 1, 1, '2014-01-08 18:29:19', '2014-01-08 18:29:19', 'P', 1, 0, 0, 0, 0, 0),
(474, 3, 4, 1, 1, '2014-01-08 18:30:52', '2014-01-08 18:30:52', 'P', 1, 0, 0, 0, 0, 0),
(475, 38, 4, 1, 1, '2014-01-08 18:31:25', '2014-01-08 18:31:25', 'P', 1, 0, 0, 0, 0, 0),
(476, 142, 4, 1, 1, '2014-01-08 18:32:35', '2014-01-08 18:32:35', 'P', 1, 0, 0, 0, 0, 0),
(477, 179, 4, 1, 1, '2014-01-08 18:33:13', '2014-01-08 18:33:13', 'P', 1, 0, 0, 0, 0, 0),
(478, 142, 4, 1, 1, '2014-01-08 18:38:14', '2014-01-08 18:38:14', 'P', 1, 0, 0, 0, 0, 0),
(479, 151, 4, 1, 1, '2014-01-08 18:38:44', '2014-01-08 18:38:44', 'P', 1, 0, 0, 0, 0, 0),
(480, 133, 4, 1, 1, '2014-01-08 18:40:07', '2014-01-08 18:40:07', 'P', 1, 0, 0, 0, 0, 0),
(481, 41, 4, 1, 1, '2014-01-08 18:46:19', '2014-01-08 18:46:19', 'P', 1, 0, 0, 0, 0, 0),
(482, 133, 4, 1, 1, '2014-01-08 18:47:14', '2014-01-08 18:47:14', 'P', 1, 0, 0, 0, 0, 0),
(483, 135, 4, 1, 1, '2014-01-08 18:49:32', '2014-01-08 18:49:32', 'P', 1, 0, 0, 0, 0, 0),
(484, 141, 4, 1, 1, '2014-01-08 18:57:27', '2014-01-08 18:57:27', 'P', 1, 0, 0, 0, 0, 0),
(485, 166, 4, 1, 1, '2014-01-08 19:04:14', '2014-01-08 19:04:14', 'P', 1, 0, 0, 0, 0, 0),
(486, 41, 4, 1, 1, '2014-01-08 19:06:03', '2014-01-08 19:06:03', 'P', 1, 0, 0, 0, 0, 0),
(487, 185, 4, 1, 1, '2014-01-08 19:19:41', '2014-01-08 19:19:41', 'P', 1, 0, 0, 0, 0, 0),
(488, 185, 4, 1, 1, '2014-01-08 19:23:39', '2014-01-08 19:23:39', 'P', 1, 0, 0, 0, 0, 0),
(489, 143, 4, 1, 1, '2014-01-08 19:34:00', '2014-01-08 19:34:00', 'P', 1, 0, 0, 0, 0, 0),
(490, 41, 4, 1, 1, '2014-01-08 19:45:15', '2014-01-08 19:45:15', 'P', 1, 0, 0, 0, 0, 0),
(491, 133, 4, 1, 1, '2014-01-08 20:09:43', '2014-01-08 20:09:43', 'P', 1, 0, 0, 0, 0, 0),
(492, 156, 4, 1, 1, '2014-01-08 20:13:26', '2014-01-08 20:13:26', 'P', 1, 0, 0, 0, 0, 0),
(493, 166, 4, 1, 1, '2014-01-08 20:17:45', '2014-01-08 20:17:45', 'P', 1, 0, 0, 0, 0, 0),
(494, 158, 4, 1, 1, '2014-01-08 20:20:40', '2014-01-08 20:20:40', 'P', 1, 0, 0, 0, 0, 0),
(495, 141, 4, 1, 1, '2014-01-08 20:23:51', '2014-01-08 20:23:51', 'P', 1, 0, 0, 0, 0, 0),
(496, 34, 4, 1, 1, '2014-01-08 20:59:17', '2014-01-08 20:59:17', 'P', 1, 0, 0, 0, 0, 0),
(497, 136, 4, 1, 1, '2014-01-08 21:22:37', '2014-01-08 21:22:37', 'P', 1, 0, 0, 0, 0, 0),
(498, 135, 4, 1, 1, '2014-01-09 06:54:48', '2014-01-09 06:54:48', 'P', 1, 0, 0, 0, 0, 0),
(499, 151, 4, 1, 1, '2014-01-09 07:30:49', '2014-01-09 07:30:49', 'P', 1, 0, 0, 0, 0, 0),
(500, 150, 4, 1, 1, '2014-01-09 07:58:23', '2014-01-09 07:58:23', 'P', 1, 0, 0, 0, 0, 0),
(501, 142, 4, 1, 1, '2014-01-09 07:59:35', '2014-01-09 07:59:35', 'P', 1, 0, 0, 0, 0, 0),
(502, 158, 4, 1, 1, '2014-01-09 08:15:01', '2014-01-09 08:15:01', 'P', 1, 0, 0, 0, 0, 0),
(503, 173, 4, 1, 1, '2014-01-09 08:26:13', '2014-01-09 08:26:13', 'P', 1, 0, 0, 0, 0, 0),
(504, 33, 4, 1, 1, '2014-01-09 08:49:16', '2014-01-09 08:49:16', 'P', 1, 0, 0, 0, 0, 0),
(505, 135, 4, 1, 1, '2014-01-09 08:49:56', '2014-01-09 08:49:56', 'P', 1, 0, 0, 0, 0, 0),
(506, 166, 4, 1, 1, '2014-01-09 08:50:23', '2014-01-09 08:50:23', 'P', 1, 0, 0, 0, 0, 0),
(507, 155, 4, 1, 1, '2014-01-09 08:50:39', '2014-01-09 08:50:39', 'P', 1, 0, 0, 0, 0, 0),
(508, 35, 4, 1, 1, '2014-01-09 09:00:34', '2014-01-09 09:00:34', 'P', 1, 0, 0, 0, 0, 0),
(509, 156, 4, 1, 1, '2014-01-09 09:06:38', '2014-01-09 09:06:38', 'P', 1, 0, 0, 0, 0, 0),
(510, 2, 4, 1, 1, '2014-01-09 09:09:18', '2014-01-09 09:09:18', 'P', 1, 0, 0, 0, 0, 0),
(511, 32, 4, 1, 1, '2014-01-09 10:01:28', '2014-01-09 10:01:28', 'P', 1, 0, 0, 0, 0, 0),
(512, 35, 4, 1, 1, '2014-01-09 10:37:05', '2014-01-09 10:37:05', 'P', 1, 0, 0, 0, 0, 0),
(513, 30, 4, 1, 1, '2014-01-09 10:38:02', '2014-01-09 10:38:02', 'P', 1, 0, 0, 0, 0, 0),
(514, 150, 4, 1, 1, '2014-01-09 11:33:03', '2014-01-09 11:33:03', 'P', 1, 0, 0, 0, 0, 0),
(515, 166, 4, 1, 1, '2014-01-09 11:38:30', '2014-01-09 11:38:30', 'P', 1, 0, 0, 0, 0, 0),
(516, 33, 4, 1, 1, '2014-01-09 11:39:09', '2014-01-09 11:39:09', 'P', 1, 0, 0, 0, 0, 0),
(517, 35, 4, 1, 1, '2014-01-09 12:06:09', '2014-01-09 12:06:09', 'P', 1, 0, 0, 0, 0, 0),
(518, 143, 4, 1, 1, '2014-01-09 12:55:18', '2014-01-09 12:55:18', 'P', 1, 0, 0, 0, 0, 0),
(519, 32, 4, 1, 1, '2014-01-09 13:09:25', '2014-01-09 13:09:25', 'P', 1, 0, 0, 0, 0, 0),
(520, 149, 4, 1, 1, '2014-01-09 14:11:19', '2014-01-09 14:11:19', 'P', 1, 0, 0, 0, 0, 0),
(521, 150, 4, 1, 1, '2014-01-09 14:20:15', '2014-01-09 14:20:15', 'P', 1, 0, 0, 0, 0, 0),
(522, 152, 4, 1, 1, '2014-01-09 14:38:51', '2014-01-09 14:38:51', 'P', 1, 0, 0, 0, 0, 0),
(523, 142, 4, 1, 1, '2014-01-09 14:39:46', '2014-01-09 14:39:46', 'P', 1, 0, 0, 0, 0, 0),
(524, 145, 4, 1, 1, '2014-01-09 14:41:23', '2014-01-09 14:41:23', 'P', 1, 0, 0, 0, 0, 0),
(525, 30, 4, 1, 1, '2014-01-09 15:24:13', '2014-01-09 15:24:13', 'P', 1, 0, 0, 0, 0, 0),
(526, 29, 4, 1, 1, '2014-01-09 15:25:03', '2014-01-09 15:25:03', 'P', 1, 0, 0, 0, 0, 0),
(527, 155, 4, 1, 1, '2014-01-09 16:24:48', '2014-01-09 16:24:48', 'P', 1, 0, 0, 0, 0, 0),
(528, 33, 4, 1, 1, '2014-01-09 16:29:41', '2014-01-09 16:29:41', 'P', 1, 0, 0, 0, 0, 0),
(529, 38, 4, 1, 1, '2014-01-09 16:57:51', '2014-01-09 16:57:51', 'P', 1, 0, 0, 0, 0, 0),
(530, 141, 4, 1, 1, '2014-01-09 18:25:19', '2014-01-09 18:25:19', 'P', 1, 0, 0, 0, 0, 0),
(531, 135, 4, 1, 1, '2014-01-09 18:28:59', '2014-01-09 18:28:59', 'P', 1, 0, 0, 0, 0, 0),
(532, 35, 4, 1, 1, '2014-01-09 18:44:58', '2014-01-09 18:44:58', 'P', 1, 0, 0, 0, 0, 0),
(533, 35, 4, 1, 1, '2014-01-09 18:47:39', '2014-01-09 18:47:39', 'P', 1, 0, 0, 0, 0, 0),
(534, 2, 4, 1, 1, '2014-01-09 18:48:11', '2014-01-09 18:48:11', 'P', 1, 0, 0, 0, 0, 0),
(535, 133, 4, 1, 1, '2014-01-09 18:53:20', '2014-01-09 18:53:20', 'P', 1, 0, 0, 0, 0, 0),
(536, 166, 4, 1, 1, '2014-01-09 19:00:29', '2014-01-09 19:00:29', 'P', 1, 0, 0, 0, 0, 0),
(537, 185, 4, 1, 1, '2014-01-09 19:04:07', '2014-01-09 19:04:07', 'P', 1, 0, 0, 0, 0, 0),
(538, 178, 4, 1, 1, '2014-01-09 19:12:18', '2014-01-09 19:12:18', 'P', 1, 0, 0, 0, 0, 0),
(539, 32, 4, 1, 1, '2014-01-09 19:39:50', '2014-01-09 19:39:50', 'P', 1, 0, 0, 0, 0, 0),
(540, 34, 4, 1, 1, '2014-01-09 19:52:40', '2014-01-09 19:52:40', 'P', 1, 0, 0, 0, 0, 0),
(541, 28, 4, 1, 1, '2014-01-09 19:53:46', '2014-01-09 19:53:46', 'P', 1, 0, 0, 0, 0, 0),
(542, 133, 4, 1, 1, '2014-01-09 20:51:41', '2014-01-09 20:51:41', 'P', 1, 0, 0, 0, 0, 0),
(543, 135, 4, 1, 1, '2014-01-09 21:05:31', '2014-01-09 21:05:31', 'P', 1, 0, 0, 0, 0, 0),
(544, 33, 4, 1, 1, '2014-01-09 21:30:47', '2014-01-09 21:30:47', 'P', 1, 0, 0, 0, 0, 0),
(545, 33, 4, 1, 1, '2014-01-09 21:45:55', '2014-01-09 21:45:55', 'P', 1, 0, 0, 0, 0, 0),
(546, 2, 4, 1, 1, '2014-01-10 09:13:21', '2014-01-10 09:13:21', 'P', 1, 0, 0, 0, 0, 0),
(547, 166, 4, 1, 1, '2014-01-10 09:13:36', '2014-01-10 09:13:36', 'P', 1, 0, 0, 0, 0, 0),
(548, 144, 4, 1, 1, '2014-01-10 09:13:50', '2014-01-10 09:13:50', 'P', 1, 0, 0, 0, 0, 0),
(549, 142, 4, 1, 1, '2014-01-10 09:14:22', '2014-01-10 09:14:22', 'P', 1, 0, 0, 0, 0, 0),
(550, 135, 4, 1, 1, '2014-01-10 09:14:49', '2014-01-10 09:14:49', 'P', 1, 0, 0, 0, 0, 0),
(551, 33, 4, 1, 1, '2014-01-10 09:15:02', '2014-01-10 09:15:02', 'P', 1, 0, 0, 0, 0, 0),
(552, 2, 4, 1, 1, '2014-01-10 09:15:23', '2014-01-10 09:15:23', 'P', 1, 0, 0, 0, 0, 0),
(553, 133, 4, 1, 1, '2014-01-10 09:15:44', '2014-01-10 09:15:44', 'P', 1, 0, 0, 0, 0, 0),
(554, 145, 4, 1, 1, '2014-01-10 09:15:58', '2014-01-10 09:15:58', 'P', 1, 0, 0, 0, 0, 0),
(555, 31, 4, 1, 1, '2014-01-10 09:16:24', '2014-01-10 09:16:24', 'P', 1, 0, 0, 0, 0, 0),
(556, 185, 4, 1, 1, '2014-01-10 09:16:56', '2014-01-10 09:16:56', 'P', 1, 0, 0, 0, 0, 0),
(557, 177, 4, 1, 1, '2014-01-10 09:37:44', '2014-01-10 09:37:44', 'P', 1, 0, 0, 0, 0, 0),
(558, 28, 4, 1, 1, '2014-01-10 09:39:54', '2014-01-10 09:39:54', 'P', 1, 0, 0, 0, 0, 0),
(559, 1, 4, 1, 1, '2014-01-10 09:40:38', '2014-01-10 09:40:38', 'P', 1, 0, 0, 0, 0, 0),
(560, 3, 4, 1, 1, '2014-01-10 09:42:18', '2014-01-10 09:42:18', 'P', 1, 0, 0, 0, 0, 0),
(561, 143, 4, 1, 1, '2014-01-10 09:46:48', '2014-01-10 09:46:48', 'P', 1, 0, 0, 0, 0, 0),
(562, 4, 4, 1, 1, '2014-01-10 10:13:55', '2014-01-10 10:13:55', 'P', 1, 0, 0, 0, 0, 0),
(563, 31, 4, 1, 1, '2014-01-10 10:14:06', '2014-01-10 10:14:06', 'P', 1, 0, 0, 0, 0, 0),
(564, 174, 4, 1, 1, '2014-01-10 10:34:27', '2014-01-10 10:34:27', 'P', 1, 0, 0, 0, 0, 0),
(565, 145, 4, 1, 1, '2014-01-10 11:11:21', '2014-01-10 11:11:21', 'P', 1, 0, 0, 0, 0, 0),
(566, 177, 4, 1, 1, '2014-01-10 11:57:48', '2014-01-10 11:57:48', 'P', 1, 0, 0, 0, 0, 0),
(567, 31, 4, 1, 1, '2014-01-10 11:58:00', '2014-01-10 11:58:00', 'P', 1, 0, 0, 0, 0, 0),
(568, 143, 4, 1, 1, '2014-01-10 11:58:27', '2014-01-10 11:58:27', 'P', 1, 0, 0, 0, 0, 0),
(569, 166, 4, 1, 1, '2014-01-10 12:58:28', '2014-01-10 12:58:28', 'P', 1, 0, 0, 0, 0, 0),
(570, 150, 4, 1, 1, '2014-01-10 13:43:28', '2014-01-10 13:43:28', 'P', 1, 0, 0, 0, 0, 0),
(571, 152, 4, 1, 1, '2014-01-10 13:47:44', '2014-01-10 13:47:44', 'P', 1, 0, 0, 0, 0, 0),
(572, 185, 4, 1, 1, '2014-01-10 14:01:03', '2014-01-10 14:01:03', 'P', 1, 0, 0, 0, 0, 0),
(573, 140, 4, 1, 1, '2014-01-10 15:13:30', '2014-01-10 15:13:30', 'P', 1, 0, 0, 0, 0, 0),
(574, 3, 4, 1, 1, '2014-01-10 15:21:12', '2014-01-10 15:21:12', 'P', 1, 0, 0, 0, 0, 0),
(575, 1, 4, 1, 1, '2014-01-10 15:21:25', '2014-01-10 15:21:25', 'P', 1, 0, 0, 0, 0, 0),
(576, 151, 4, 1, 1, '2014-01-10 15:36:27', '2014-01-10 15:36:27', 'P', 1, 0, 0, 0, 0, 0),
(577, 35, 4, 1, 1, '2014-01-10 15:55:12', '2014-01-10 15:55:12', 'P', 1, 0, 0, 0, 0, 0),
(578, 33, 4, 1, 1, '2014-01-10 16:01:01', '2014-01-10 16:01:01', 'P', 1, 0, 0, 0, 0, 0),
(579, 189, 4, 1, 1, '2014-01-10 17:27:38', '2014-01-10 17:27:38', 'P', 1, 0, 0, 0, 0, 0),
(580, 31, 4, 1, 1, '2014-01-10 17:36:26', '2014-01-10 17:36:26', 'P', 1, 0, 0, 0, 0, 0),
(581, 3, 4, 1, 1, '2014-01-10 17:41:05', '2014-01-10 17:41:05', 'P', 1, 0, 0, 0, 0, 0),
(582, 133, 4, 1, 1, '2014-01-10 17:49:48', '2014-01-10 17:49:48', 'P', 1, 0, 0, 0, 0, 0),
(583, 32, 4, 1, 1, '2014-01-10 17:53:57', '2014-01-10 17:53:57', 'P', 1, 0, 0, 0, 0, 0),
(584, 2, 4, 1, 1, '2014-01-10 18:04:39', '2014-01-10 18:04:39', 'P', 1, 0, 0, 0, 0, 0),
(585, 35, 4, 1, 1, '2014-01-10 18:06:46', '2014-01-10 18:06:46', 'P', 1, 0, 0, 0, 0, 0),
(586, 177, 4, 1, 1, '2014-01-10 18:07:59', '2014-01-10 18:07:59', 'P', 1, 0, 0, 0, 0, 0),
(587, 2, 4, 1, 1, '2014-01-10 18:12:25', '2014-01-10 18:12:25', 'P', 1, 0, 0, 0, 0, 0),
(588, 2, 4, 1, 1, '2014-01-10 18:17:01', '2014-01-10 18:17:01', 'P', 1, 0, 0, 0, 0, 0),
(589, 133, 4, 1, 1, '2014-01-10 18:20:54', '2014-01-10 18:20:54', 'P', 1, 0, 0, 0, 0, 0),
(590, 191, 4, 1, 1, '2014-01-10 18:25:43', '2014-01-10 18:25:43', 'P', 1, 0, 0, 0, 0, 0),
(591, 34, 4, 1, 1, '2014-01-10 18:26:45', '2014-01-10 18:26:45', 'P', 1, 0, 0, 0, 0, 0),
(592, 190, 4, 1, 1, '2014-01-10 18:27:08', '2014-01-10 18:27:08', 'P', 1, 0, 0, 0, 0, 0),
(593, 32, 4, 1, 1, '2014-01-10 18:33:12', '2014-01-10 18:33:12', 'P', 1, 0, 0, 0, 0, 0),
(594, 177, 4, 1, 1, '2014-01-10 18:34:58', '2014-01-10 18:34:58', 'P', 1, 0, 0, 0, 0, 0),
(595, 2, 4, 1, 1, '2014-01-10 18:38:51', '2014-01-10 18:38:51', 'P', 1, 0, 0, 0, 0, 0),
(596, 32, 4, 1, 1, '2014-01-10 18:39:40', '2014-01-10 18:39:40', 'P', 1, 0, 0, 0, 0, 0),
(597, 141, 4, 1, 1, '2014-01-10 18:43:32', '2014-01-10 18:43:32', 'P', 1, 0, 0, 0, 0, 0),
(598, 145, 4, 1, 1, '2014-01-10 18:51:37', '2014-01-10 18:51:37', 'P', 1, 0, 0, 0, 0, 0),
(599, 135, 4, 1, 1, '2014-01-10 18:55:36', '2014-01-10 18:55:36', 'P', 1, 0, 0, 0, 0, 0),
(600, 141, 4, 1, 1, '2014-01-10 18:57:14', '2014-01-10 18:57:14', 'P', 1, 0, 0, 0, 0, 0),
(601, 30, 4, 1, 1, '2014-01-10 18:59:18', '2014-01-10 18:59:18', 'P', 1, 0, 0, 0, 0, 0),
(602, 142, 4, 1, 1, '2014-01-10 19:02:30', '2014-01-10 19:02:30', 'P', 1, 0, 0, 0, 0, 0),
(603, 2, 4, 1, 1, '2014-01-10 19:07:18', '2014-01-10 19:07:18', 'P', 1, 0, 0, 0, 0, 0),
(604, 41, 4, 1, 1, '2014-01-10 19:07:41', '2014-01-10 19:07:41', 'P', 1, 0, 0, 0, 0, 0),
(605, 35, 4, 1, 1, '2014-01-10 19:30:45', '2014-01-10 19:30:45', 'P', 1, 0, 0, 0, 0, 0),
(606, 136, 4, 1, 1, '2014-01-10 19:44:23', '2014-01-10 19:44:23', 'P', 1, 0, 0, 0, 0, 0),
(607, 32, 4, 1, 1, '2014-01-10 19:53:02', '2014-01-10 19:53:02', 'P', 1, 0, 0, 0, 0, 0),
(608, 28, 4, 1, 1, '2014-01-10 19:54:03', '2014-01-10 19:54:03', 'P', 1, 0, 0, 0, 0, 0),
(609, 138, 4, 1, 1, '2014-01-10 20:06:51', '2014-01-10 20:06:51', 'P', 1, 0, 0, 0, 0, 0),
(610, 142, 4, 1, 1, '2014-01-10 20:14:27', '2014-01-10 20:14:27', 'P', 1, 0, 0, 0, 0, 0),
(611, 151, 4, 1, 1, '2014-01-10 20:53:06', '2014-01-10 20:53:06', 'P', 1, 0, 0, 0, 0, 0),
(612, 1, 4, 1, 1, '2014-01-10 20:53:18', '2014-01-10 20:53:18', 'P', 1, 0, 0, 0, 0, 0),
(613, 32, 4, 1, 1, '2014-01-10 20:58:30', '2014-01-10 20:58:30', 'P', 1, 0, 0, 0, 0, 0),
(614, 32, 4, 1, 1, '2014-01-10 21:45:54', '2014-01-10 21:45:54', 'P', 1, 0, 0, 0, 0, 0),
(615, 33, 4, 1, 1, '2014-01-10 22:13:59', '2014-01-10 22:13:59', 'P', 1, 0, 0, 0, 0, 0),
(616, 140, 4, 1, 1, '2014-01-11 06:45:22', '2014-01-11 06:45:22', 'P', 1, 0, 0, 0, 0, 0),
(617, 34, 4, 1, 1, '2014-01-11 06:45:40', '2014-01-11 06:45:40', 'P', 1, 0, 0, 0, 0, 0),
(619, 30, 4, 1, 1, '2014-01-11 07:40:51', '2014-01-11 07:40:51', 'P', 1, 0, 0, 0, 0, 0),
(620, 41, 4, 1, 1, '2014-01-11 08:14:58', '2014-01-11 08:14:58', 'P', 1, 0, 0, 0, 0, 0),
(621, 150, 4, 1, 1, '2014-01-11 08:28:17', '2014-01-11 08:28:17', 'P', 1, 0, 0, 0, 0, 0),
(622, 142, 4, 1, 1, '2014-01-11 08:29:27', '2014-01-11 08:29:27', 'P', 1, 0, 0, 0, 0, 0),
(623, 35, 4, 1, 1, '2014-01-11 08:37:07', '2014-01-11 08:37:07', 'P', 1, 0, 0, 0, 0, 0),
(624, 3, 4, 1, 1, '2014-01-11 09:01:48', '2014-01-11 09:01:48', 'P', 1, 0, 0, 0, 0, 0),
(625, 143, 4, 1, 1, '2014-01-11 09:42:26', '2014-01-11 09:42:26', 'P', 1, 0, 0, 0, 0, 0),
(626, 31, 4, 1, 1, '2014-01-11 09:51:40', '2014-01-11 09:51:40', 'P', 1, 0, 0, 0, 0, 0),
(627, 35, 4, 1, 1, '2014-01-11 10:32:57', '2014-01-11 10:32:57', 'P', 1, 0, 0, 0, 0, 0),
(628, 4, 4, 1, 1, '2014-01-11 12:07:08', '2014-01-11 12:07:08', 'P', 1, 0, 0, 0, 0, 0),
(629, 166, 4, 1, 1, '2014-01-11 12:07:25', '2014-01-11 12:07:25', 'P', 1, 0, 0, 0, 0, 0),
(630, 150, 4, 1, 1, '2014-01-11 12:47:13', '2014-01-11 12:47:13', 'P', 1, 0, 0, 0, 0, 0),
(631, 28, 4, 1, 1, '2014-01-11 13:16:19', '2014-01-11 13:16:19', 'P', 1, 0, 0, 0, 0, 0),
(632, 3, 4, 1, 1, '2014-01-11 13:19:22', '2014-01-11 13:19:22', 'P', 1, 0, 0, 0, 0, 0),
(633, 166, 4, 1, 1, '2014-01-11 13:31:22', '2014-01-11 13:31:22', 'P', 1, 0, 0, 0, 0, 0),
(634, 175, 4, 1, 1, '2014-01-11 13:31:57', '2014-01-11 13:31:57', 'P', 1, 0, 0, 0, 0, 0),
(635, 191, 4, 1, 1, '2014-01-11 14:03:48', '2014-01-11 14:03:48', 'P', 1, 0, 0, 0, 0, 0),
(636, 29, 4, 1, 1, '2014-01-11 14:04:05', '2014-01-11 14:04:05', 'P', 1, 0, 0, 0, 0, 0),
(637, 4, 4, 1, 1, '2014-01-11 14:07:24', '2014-01-11 14:07:24', 'P', 1, 0, 0, 0, 0, 0),
(638, 185, 4, 1, 1, '2014-01-11 14:19:44', '2014-01-11 14:19:44', 'P', 1, 0, 0, 0, 0, 0),
(639, 135, 4, 1, 1, '2014-01-11 14:56:49', '2014-01-11 14:56:49', 'P', 1, 0, 0, 0, 0, 0),
(640, 185, 4, 1, 1, '2014-01-11 15:07:49', '2014-01-11 15:07:49', 'P', 1, 0, 0, 0, 0, 0),
(641, 157, 4, 1, 1, '2014-01-11 16:00:50', '2014-01-11 16:00:50', 'P', 1, 0, 0, 0, 0, 0),
(642, 135, 4, 1, 1, '2014-01-11 16:34:05', '2014-01-11 16:34:05', 'P', 1, 0, 0, 0, 0, 0),
(643, 33, 4, 1, 1, '2014-01-11 18:58:22', '2014-01-11 18:58:22', 'P', 1, 0, 0, 0, 0, 0),
(644, 3, 4, 1, 1, '2014-01-11 18:58:55', '2014-01-11 18:58:55', 'P', 1, 0, 0, 0, 0, 0),
(645, 133, 4, 1, 1, '2014-01-11 18:59:10', '2014-01-11 18:59:10', 'P', 1, 0, 0, 0, 0, 0),
(646, 35, 4, 1, 1, '2014-01-11 19:07:22', '2014-01-11 19:07:22', 'P', 1, 0, 0, 0, 0, 0),
(647, 41, 4, 1, 1, '2014-01-11 19:12:04', '2014-01-11 19:12:04', 'P', 1, 0, 0, 0, 0, 0),
(648, 2, 4, 1, 1, '2014-01-11 19:22:50', '2014-01-11 19:22:50', 'P', 1, 0, 0, 0, 0, 0),
(649, 141, 4, 1, 1, '2014-01-11 19:27:12', '2014-01-11 19:27:12', 'P', 1, 0, 0, 0, 0, 0),
(650, 31, 4, 1, 1, '2014-01-11 19:30:19', '2014-01-11 19:30:19', 'P', 1, 0, 0, 0, 0, 0),
(651, 28, 4, 1, 1, '2014-01-11 19:32:27', '2014-01-11 19:32:27', 'P', 1, 0, 0, 0, 0, 0),
(652, 1, 4, 1, 1, '2014-01-11 19:34:51', '2014-01-11 19:34:51', 'P', 1, 0, 0, 0, 0, 0),
(653, 31, 4, 1, 1, '2014-01-11 19:44:49', '2014-01-11 19:44:49', 'P', 1, 0, 0, 0, 0, 0),
(654, 133, 4, 1, 1, '2014-01-11 19:47:35', '2014-01-11 19:47:35', 'P', 1, 0, 0, 0, 0, 0),
(655, 137, 4, 1, 1, '2014-01-11 19:55:09', '2014-01-11 19:55:09', 'P', 1, 0, 0, 0, 0, 0),
(656, 33, 4, 1, 1, '2014-01-11 19:58:14', '2014-01-11 19:58:14', 'P', 1, 0, 0, 0, 0, 0),
(657, 166, 4, 1, 1, '2014-01-11 20:01:15', '2014-01-11 20:01:15', 'P', 1, 0, 0, 0, 0, 0),
(658, 138, 4, 1, 1, '2014-01-11 20:42:32', '2014-01-11 20:42:32', 'P', 1, 0, 0, 0, 0, 0),
(659, 35, 4, 1, 1, '2014-01-11 21:47:02', '2014-01-11 21:47:02', 'P', 1, 0, 0, 0, 0, 0),
(660, 1, 4, 1, 1, '2014-01-11 22:02:45', '2014-01-11 22:02:45', 'P', 1, 0, 0, 0, 0, 0),
(662, 32, 4, 1, 1, '2014-01-12 00:08:51', '2014-01-12 00:08:51', 'P', 1, 0, 0, 0, 0, 0),
(664, 1, 4, 1, 1, '2014-01-12 01:28:10', '2014-01-12 01:28:10', 'P', 1, 0, 0, 0, 0, 0),
(665, 2, 4, 1, 1, '2014-01-12 01:43:54', '2014-01-12 01:43:54', 'P', 1, 0, 0, 0, 0, 0),
(666, 38, 4, 1, 1, '2014-01-12 07:14:11', '2014-01-12 07:14:11', 'P', 1, 0, 0, 0, 0, 0),
(667, 2, 4, 1, 1, '2014-01-12 07:48:24', '2014-01-12 07:48:24', 'P', 1, 0, 0, 0, 0, 0),
(668, 144, 4, 1, 1, '2014-01-12 07:50:08', '2014-01-12 07:50:08', 'P', 1, 0, 0, 0, 0, 0),
(669, 30, 4, 1, 1, '2014-01-12 07:51:39', '2014-01-12 07:51:39', 'P', 1, 0, 0, 0, 0, 0),
(670, 156, 4, 1, 1, '2014-01-12 07:52:15', '2014-01-12 07:52:15', 'P', 1, 0, 0, 0, 0, 0),
(671, 141, 4, 1, 1, '2014-01-12 07:53:44', '2014-01-12 07:53:44', 'P', 1, 0, 0, 0, 0, 0),
(672, 185, 4, 1, 1, '2014-01-12 08:13:37', '2014-01-12 08:13:37', 'P', 1, 0, 0, 0, 0, 0),
(673, 163, 4, 1, 1, '2014-01-12 08:15:25', '2014-01-12 08:15:25', 'P', 1, 0, 0, 0, 0, 0),
(674, 41, 4, 1, 1, '2014-01-12 08:30:06', '2014-01-12 08:30:06', 'P', 1, 0, 0, 0, 0, 0),
(675, 4, 4, 1, 1, '2014-01-12 08:36:19', '2014-01-12 08:36:19', 'P', 1, 0, 0, 0, 0, 0),
(677, 31, 4, 1, 1, '2014-01-12 08:42:00', '2014-01-12 08:42:00', 'P', 1, 0, 0, 0, 0, 0),
(678, 185, 4, 1, 1, '2014-01-12 08:43:00', '2014-01-12 08:43:00', 'P', 1, 0, 0, 0, 0, 0),
(679, 186, 4, 1, 1, '2014-01-12 08:43:34', '2014-01-12 08:43:34', 'P', 1, 0, 0, 0, 0, 0),
(680, 143, 4, 1, 1, '2014-01-12 09:12:04', '2014-01-12 09:12:04', 'P', 1, 0, 0, 0, 0, 0),
(681, 1, 4, 1, 1, '2014-01-12 09:18:31', '2014-01-12 09:18:31', 'P', 1, 0, 0, 0, 0, 0),
(682, 133, 4, 1, 1, '2014-01-12 09:37:25', '2014-01-12 09:37:25', 'P', 1, 0, 0, 0, 0, 0),
(683, 32, 4, 1, 1, '2014-01-12 09:40:56', '2014-01-12 09:40:56', 'P', 1, 0, 0, 0, 0, 0),
(684, 166, 4, 1, 1, '2014-01-12 09:41:28', '2014-01-12 09:41:28', 'P', 1, 0, 0, 0, 0, 0),
(685, 30, 4, 1, 1, '2014-01-12 10:29:57', '2014-01-12 10:29:57', 'P', 1, 0, 0, 0, 0, 0),
(686, 150, 4, 1, 1, '2014-01-12 11:27:53', '2014-01-12 11:27:53', 'P', 1, 0, 0, 0, 0, 0),
(687, 145, 4, 1, 1, '2014-01-12 11:29:33', '2014-01-12 11:29:33', 'P', 1, 0, 0, 0, 0, 0),
(688, 166, 4, 1, 1, '2014-01-12 11:47:08', '2014-01-12 11:47:08', 'P', 1, 0, 0, 0, 0, 0),
(689, 3, 4, 1, 1, '2014-01-12 14:06:38', '2014-01-12 14:06:38', 'P', 1, 0, 0, 0, 0, 0),
(690, 2, 4, 1, 1, '2014-01-12 14:25:45', '2014-01-12 14:25:45', 'P', 1, 0, 0, 0, 0, 0),
(691, 145, 4, 1, 1, '2014-01-12 15:03:25', '2014-01-12 15:03:25', 'P', 1, 0, 0, 0, 0, 0),
(692, 33, 4, 1, 1, '2014-01-12 15:03:41', '2014-01-12 15:03:41', 'P', 1, 0, 0, 0, 0, 0),
(693, 166, 4, 1, 1, '2014-01-12 15:18:31', '2014-01-12 15:18:31', 'P', 1, 0, 0, 0, 0, 0),
(694, 142, 4, 1, 1, '2014-01-12 15:26:45', '2014-01-12 15:26:45', 'P', 1, 0, 0, 0, 0, 0),
(695, 178, 4, 1, 1, '2014-01-12 17:57:02', '2014-01-12 17:57:02', 'P', 1, 0, 0, 0, 0, 0),
(696, 149, 4, 1, 1, '2014-01-12 17:57:41', '2014-01-12 17:57:41', 'P', 1, 0, 0, 0, 0, 0),
(697, 156, 4, 1, 1, '2014-01-12 18:16:31', '2014-01-12 18:16:31', 'P', 1, 0, 0, 0, 0, 0),
(698, 33, 4, 1, 1, '2014-01-12 18:46:22', '2014-01-12 18:46:22', 'P', 1, 0, 0, 0, 0, 0),
(699, 34, 4, 1, 1, '2014-01-12 19:07:09', '2014-01-12 19:07:09', 'P', 1, 0, 0, 0, 0, 0),
(700, 2, 4, 1, 1, '2014-01-12 20:08:24', '2014-01-12 20:08:24', 'P', 1, 0, 0, 0, 0, 0),
(701, 136, 4, 1, 1, '2014-01-12 20:11:36', '2014-01-12 20:11:36', 'P', 1, 0, 0, 0, 0, 0),
(702, 178, 4, 1, 1, '2014-01-12 20:27:19', '2014-01-12 20:27:19', 'P', 1, 0, 0, 0, 0, 0),
(703, 33, 4, 1, 1, '2014-01-12 20:45:18', '2014-01-12 20:45:18', 'P', 1, 0, 0, 0, 0, 0),
(704, 1, 4, 1, 1, '2014-01-12 20:49:32', '2014-01-12 20:49:32', 'P', 1, 0, 0, 0, 0, 0),
(705, 32, 4, 1, 1, '2014-01-12 20:54:58', '2014-01-12 20:54:58', 'P', 1, 0, 0, 0, 0, 0),
(706, 31, 4, 1, 1, '2014-01-12 20:55:39', '2014-01-12 20:55:39', 'P', 1, 0, 0, 0, 0, 0),
(707, 3, 4, 1, 1, '2014-01-12 20:56:10', '2014-01-12 20:56:10', 'P', 1, 0, 0, 0, 0, 0),
(708, 3, 4, 1, 1, '2014-01-12 21:17:04', '2014-01-12 21:17:04', 'P', 1, 0, 0, 0, 0, 0),
(709, 28, 4, 1, 1, '2014-01-12 21:17:42', '2014-01-12 21:17:42', 'P', 1, 0, 0, 0, 0, 0),
(710, 41, 4, 1, 1, '2014-01-12 21:25:42', '2014-01-12 21:25:42', 'P', 1, 0, 0, 0, 0, 0),
(711, 133, 4, 1, 1, '2014-01-12 21:46:05', '2014-01-12 21:46:05', 'P', 1, 0, 0, 0, 0, 0),
(712, 4, 4, 1, 1, '2014-01-12 21:49:56', '2014-01-12 21:49:56', 'P', 1, 0, 0, 0, 0, 0),
(713, 2, 4, 1, 1, '2014-01-12 22:10:20', '2014-01-12 22:10:20', 'P', 1, 0, 0, 0, 0, 0),
(714, 185, 4, 1, 1, '2014-01-12 22:15:48', '2014-01-12 22:15:48', 'P', 1, 0, 0, 0, 0, 0),
(715, 3, 4, 1, 1, '2014-01-12 22:37:42', '2014-01-12 22:37:42', 'P', 1, 0, 0, 0, 0, 0),
(716, 142, 4, 1, 1, '2014-01-13 07:17:03', '2014-01-13 07:17:03', 'P', 1, 0, 0, 0, 0, 0),
(717, 38, 4, 1, 1, '2014-01-13 08:25:48', '2014-01-13 08:25:48', 'P', 1, 0, 0, 0, 0, 0),
(718, 31, 4, 1, 1, '2014-01-13 08:27:04', '2014-01-13 08:27:04', 'P', 1, 0, 0, 0, 0, 0),
(719, 152, 4, 1, 1, '2014-01-13 08:27:15', '2014-01-13 08:27:15', 'P', 1, 0, 0, 0, 0, 0),
(720, 32, 4, 1, 1, '2014-01-13 08:27:33', '2014-01-13 08:27:33', 'P', 1, 0, 0, 0, 0, 0),
(721, 2, 4, 1, 1, '2014-01-13 08:30:22', '2014-01-13 08:30:22', 'P', 1, 0, 0, 0, 0, 0),
(722, 1, 4, 1, 1, '2014-01-13 08:32:18', '2014-01-13 08:32:18', 'P', 1, 0, 0, 0, 0, 0),
(723, 166, 4, 1, 1, '2014-01-13 08:49:37', '2014-01-13 08:49:37', 'P', 1, 0, 0, 0, 0, 0),
(724, 141, 4, 1, 1, '2014-01-13 08:49:59', '2014-01-13 08:49:59', 'P', 1, 0, 0, 0, 0, 0),
(725, 4, 4, 1, 1, '2014-01-13 09:05:11', '2014-01-13 09:05:11', 'P', 1, 0, 0, 0, 0, 0),
(726, 145, 4, 1, 1, '2014-01-13 09:16:20', '2014-01-13 09:16:20', 'P', 1, 0, 0, 0, 0, 0),
(727, 34, 4, 1, 1, '2014-01-13 09:19:56', '2014-01-13 09:19:56', 'P', 1, 0, 0, 0, 0, 0),
(728, 149, 4, 1, 1, '2014-01-13 09:27:23', '2014-01-13 09:27:23', 'P', 1, 0, 0, 0, 0, 0),
(729, 166, 4, 1, 1, '2014-01-13 09:58:12', '2014-01-13 09:58:12', 'P', 1, 0, 0, 0, 0, 0),
(730, 172, 4, 1, 1, '2014-01-13 10:00:54', '2014-01-13 10:00:54', 'P', 1, 0, 0, 0, 0, 0),
(731, 178, 4, 1, 1, '2014-01-13 10:43:11', '2014-01-13 10:43:11', 'P', 1, 0, 0, 0, 0, 0),
(732, 2, 4, 1, 1, '2014-01-13 10:54:25', '2014-01-13 10:54:25', 'P', 1, 0, 0, 0, 0, 0),
(734, 168, 4, 1, 1, '2014-01-13 11:26:05', '2014-01-13 11:26:05', 'P', 1, 0, 0, 0, 0, 0),
(735, 28, 4, 1, 1, '2014-01-13 12:39:42', '2014-01-13 12:39:42', 'P', 1, 0, 0, 0, 0, 0),
(736, 170, 4, 1, 1, '2014-01-13 14:08:54', '2014-01-13 14:08:54', 'P', 1, 0, 0, 0, 0, 0),
(737, 28, 4, 1, 1, '2014-01-13 14:09:04', '2014-01-13 14:09:04', 'P', 1, 0, 0, 0, 0, 0),
(738, 185, 4, 1, 1, '2014-01-13 14:09:42', '2014-01-13 14:09:42', 'P', 1, 0, 0, 0, 0, 0),
(739, 186, 4, 1, 1, '2014-01-13 14:10:12', '2014-01-13 14:10:12', 'P', 1, 0, 0, 0, 0, 0),
(740, 140, 4, 1, 1, '2014-01-13 14:16:23', '2014-01-13 14:16:23', 'P', 1, 0, 0, 0, 0, 0),
(741, 175, 4, 1, 1, '2014-01-13 14:58:07', '2014-01-13 14:58:07', 'P', 1, 0, 0, 0, 0, 0),
(742, 151, 4, 1, 1, '2014-01-13 15:05:16', '2014-01-13 15:05:16', 'P', 1, 0, 0, 0, 0, 0),
(743, 137, 4, 1, 1, '2014-01-13 15:25:32', '2014-01-13 15:25:32', 'P', 1, 0, 0, 0, 0, 0),
(744, 140, 4, 1, 1, '2014-01-13 17:01:25', '2014-01-13 17:01:25', 'P', 1, 0, 0, 0, 0, 0),
(745, 38, 4, 1, 1, '2014-01-13 17:21:27', '2014-01-13 17:21:27', 'P', 1, 0, 0, 0, 0, 0),
(746, 133, 4, 1, 1, '2014-01-13 17:24:28', '2014-01-13 17:24:28', 'P', 1, 0, 0, 0, 0, 0),
(747, 138, 4, 1, 1, '2014-01-13 17:30:25', '2014-01-13 17:30:25', 'P', 1, 0, 0, 0, 0, 0),
(748, 38, 4, 1, 1, '2014-01-13 18:25:20', '2014-01-13 18:25:20', 'P', 1, 0, 0, 0, 0, 0),
(749, 34, 4, 1, 1, '2014-01-13 18:47:51', '2014-01-13 18:47:51', 'P', 1, 0, 0, 0, 0, 0),
(750, 38, 4, 1, 1, '2014-01-13 19:22:23', '2014-01-13 19:22:23', 'P', 1, 0, 0, 0, 0, 0),
(751, 133, 4, 1, 1, '2014-01-13 19:34:26', '2014-01-13 19:34:26', 'P', 1, 0, 0, 0, 0, 0),
(752, 166, 4, 1, 1, '2014-01-13 19:35:44', '2014-01-13 19:35:44', 'P', 1, 0, 0, 0, 0, 0),
(753, 137, 4, 1, 1, '2014-01-13 19:36:34', '2014-01-13 19:36:34', 'P', 1, 0, 0, 0, 0, 0),
(754, 152, 4, 1, 1, '2014-01-13 19:46:02', '2014-01-13 19:46:02', 'P', 1, 0, 0, 0, 0, 0),
(755, 32, 4, 1, 1, '2014-01-13 20:11:03', '2014-01-13 20:11:03', 'P', 1, 0, 0, 0, 0, 0),
(756, 35, 4, 1, 1, '2014-01-13 20:15:30', '2014-01-13 20:15:30', 'P', 1, 0, 0, 0, 0, 0),
(757, 136, 4, 1, 1, '2014-01-13 20:16:08', '2014-01-13 20:16:08', 'P', 1, 0, 0, 0, 0, 0),
(758, 34, 4, 1, 1, '2014-01-13 20:31:00', '2014-01-13 20:31:00', 'P', 1, 0, 0, 0, 0, 0),
(759, 2, 4, 1, 1, '2014-01-13 20:44:50', '2014-01-13 20:44:50', 'P', 1, 0, 0, 0, 0, 0),
(760, 138, 4, 1, 1, '2014-01-13 21:21:08', '2014-01-13 21:21:08', 'P', 1, 0, 0, 0, 0, 0),
(761, 31, 4, 1, 1, '2014-01-14 06:44:58', '2014-01-14 06:44:58', 'P', 1, 0, 0, 0, 0, 0),
(762, 38, 4, 1, 1, '2014-01-14 07:32:31', '2014-01-14 07:32:31', 'P', 1, 0, 0, 0, 0, 0),
(763, 185, 4, 1, 1, '2014-01-14 07:35:57', '2014-01-14 07:35:57', 'P', 1, 0, 0, 0, 0, 0),
(764, 2, 4, 1, 1, '2014-01-14 07:41:23', '2014-01-14 07:41:23', 'P', 1, 0, 0, 0, 0, 0),
(765, 31, 4, 1, 1, '2014-01-14 07:45:48', '2014-01-14 07:45:48', 'P', 1, 0, 0, 0, 0, 0),
(766, 34, 4, 1, 1, '2014-01-14 08:32:37', '2014-01-14 08:32:37', 'P', 1, 0, 0, 0, 0, 0),
(767, 30, 4, 1, 1, '2014-01-14 08:59:16', '2014-01-14 08:59:16', 'P', 1, 0, 0, 0, 0, 0),
(768, 33, 4, 1, 1, '2014-01-14 09:00:17', '2014-01-14 09:00:17', '', 0, 0, 0, 0, 0, 0),
(769, 30, 4, 1, 1, '2014-01-14 09:01:49', '2014-01-14 09:01:49', '', 0, 0, 0, 0, 0, 0),
(770, 143, 4, 1, 1, '2014-01-14 09:42:45', '2014-01-14 09:42:45', 'P', 0, 0, 0, 0, 0, 0),
(771, 3, 4, 1, 1, '2014-01-14 10:03:44', '2014-01-14 10:03:44', '', 0, 0, 0, 0, 0, 0),
(772, 151, 4, 1, 1, '2014-01-14 10:15:56', '2014-01-14 10:15:56', '', 0, 0, 0, 0, 0, 0),
(773, 34, 4, 1, 1, '2014-01-14 10:41:55', '2014-01-14 10:41:55', '', 0, 0, 0, 0, 0, 0),
(774, 37, 4, 1, 1, '2014-01-15 18:20:49', '2014-01-15 18:20:49', '', 0, 0, 0, 0, 0, 0),
(775, 1, 4, 1, 1, '2014-01-20 16:22:01', '2014-01-20 16:22:01', '', 0, 0, 0, 0, 0, 0),
(776, 149, 4, 1, 1, '2014-02-02 03:30:47', '2014-02-02 03:30:47', '', 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `cafehappy4_session_detail`
--

CREATE TABLE IF NOT EXISTS `cafehappy4_session_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idsession` int(11) NOT NULL,
  `idcourse` int(11) NOT NULL,
  `count` int(11) NOT NULL,
  `price` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idsession` (`idsession`),
  KEY `idcourse` (`idcourse`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1259 ;

--
-- Dumping data for table `cafehappy4_session_detail`
--

INSERT INTO `cafehappy4_session_detail` (`id`, `idsession`, `idcourse`, `count`, `price`) VALUES
(128, 230, 107, 1, 8000),
(129, 230, 255, 1, 10000),
(131, 232, 224, 1, 8000),
(136, 235, 107, 4, 8000),
(140, 235, 222, 1, 10000),
(144, 237, 107, 2, 8000),
(145, 237, 174, 1, 12000),
(146, 237, 255, 3, 10000),
(147, 238, 107, 2, 8000),
(148, 238, 224, 1, 8000),
(149, 239, 224, 1, 8000),
(150, 240, 107, 2, 8000),
(151, 241, 212, 1, 12000),
(152, 242, 204, 2, 12000),
(153, 243, 107, 1, 8000),
(155, 244, 107, 3, 8000),
(157, 244, 180, 1, 12000),
(161, 245, 224, 2, 8000),
(162, 245, 107, 2, 8000),
(165, 244, 175, 1, 12000),
(169, 248, 107, 1, 8000),
(170, 248, 180, 1, 12000),
(173, 249, 224, 2, 8000),
(174, 250, 107, 2, 8000),
(180, 252, 255, 1, 10000),
(181, 252, 128, 1, 15000),
(183, 253, 107, 2, 8000),
(186, 254, 107, 1, 8000),
(187, 254, 222, 1, 8000),
(190, 256, 205, 1, 12000),
(191, 256, 335, 1, 10000),
(192, 257, 107, 1, 8000),
(193, 257, 255, 1, 10000),
(194, 258, 107, 1, 8000),
(195, 259, 107, 1, 8000),
(196, 260, 224, 1, 8000),
(197, 260, 204, 1, 12000),
(198, 261, 107, 1, 8000),
(199, 261, 268, 1, 8000),
(200, 262, 255, 1, 10000),
(201, 262, 107, 2, 8000),
(202, 262, 204, 2, 12000),
(205, 262, 177, 1, 15000),
(206, 262, 180, 1, 12000),
(209, 264, 107, 2, 8000),
(210, 265, 204, 2, 12000),
(211, 266, 107, 3, 8000),
(212, 266, 224, 2, 8000),
(213, 266, 189, 1, 18000),
(215, 267, 107, 1, 8000),
(216, 267, 56, 1, 15000),
(217, 265, 255, 2, 10000),
(218, 265, 335, 1, 10000),
(220, 262, 212, 1, 12000),
(221, 268, 224, 3, 8000),
(222, 268, 177, 3, 15000),
(223, 268, 179, 1, 15000),
(224, 269, 107, 2, 8000),
(226, 271, 107, 1, 8000),
(227, 271, 255, 2, 10000),
(228, 269, 176, 1, 10000),
(229, 262, 176, 2, 10000),
(230, 272, 176, 1, 10000),
(231, 272, 224, 1, 8000),
(232, 272, 221, 1, 10000),
(233, 267, 224, 1, 8000),
(240, 277, 178, 1, 13000),
(241, 265, 222, 1, 8000),
(242, 278, 204, 1, 12000),
(246, 281, 107, 1, 8000),
(247, 282, 107, 1, 8000),
(248, 283, 107, 1, 8000),
(249, 284, 107, 2, 8000),
(250, 284, 201, 1, 8000),
(251, 285, 112, 1, 10000),
(252, 285, 197, 1, 15000),
(253, 286, 107, 2, 8000),
(255, 287, 107, 1, 8000),
(256, 287, 204, 1, 12000),
(257, 288, 107, 2, 8000),
(259, 288, 255, 2, 12000),
(260, 288, 224, 1, 8000),
(262, 289, 107, 3, 8000),
(263, 290, 107, 1, 8000),
(264, 290, 176, 1, 8000),
(265, 289, 222, 1, 8000),
(266, 291, 204, 1, 12000),
(267, 291, 255, 1, 12000),
(268, 291, 107, 3, 8000),
(269, 292, 107, 1, 8000),
(270, 291, 174, 1, 12000),
(272, 292, 204, 2, 12000),
(276, 293, 107, 1, 8000),
(277, 293, 218, 1, 15000),
(280, 293, 175, 1, 12000),
(283, 295, 107, 1, 8000),
(286, 286, 176, 1, 8000),
(287, 296, 255, 2, 12000),
(290, 296, 212, 1, 10000),
(291, 293, 255, 1, 12000),
(292, 297, 107, 4, 8000),
(293, 298, 107, 1, 8000),
(294, 299, 107, 2, 8000),
(297, 301, 107, 2, 8000),
(298, 302, 107, 3, 8000),
(299, 302, 265, 1, 8000),
(300, 302, 197, 1, 15000),
(301, 303, 107, 4, 8000),
(303, 302, 175, 1, 12000),
(304, 302, 204, 1, 12000),
(305, 302, 315, 2, 15000),
(306, 302, 212, 1, 10000),
(307, 302, 255, 1, 12000),
(308, 302, 353, 1, 8000),
(309, 301, 205, 1, 12000),
(310, 304, 107, 1, 8000),
(312, 304, 204, 1, 12000),
(313, 305, 107, 2, 8000),
(316, 306, 176, 1, 8000),
(317, 307, 107, 1, 8000),
(318, 308, 175, 1, 12000),
(319, 308, 107, 1, 8000),
(320, 308, 212, 1, 10000),
(321, 309, 218, 1, 15000),
(322, 309, 224, 2, 8000),
(323, 309, 107, 1, 8000),
(324, 309, 255, 2, 12000),
(325, 310, 176, 1, 8000),
(326, 310, 268, 1, 8000),
(328, 311, 174, 1, 12000),
(329, 311, 107, 1, 8000),
(330, 312, 255, 3, 12000),
(331, 312, 224, 3, 8000),
(332, 312, 176, 1, 8000),
(333, 310, 112, 1, 10000),
(334, 310, 204, 1, 12000),
(335, 313, 107, 2, 8000),
(336, 314, 224, 1, 8000),
(337, 312, 107, 2, 8000),
(338, 312, 351, 1, 15000),
(339, 315, 224, 1, 8000),
(340, 315, 107, 2, 8000),
(352, 317, 224, 1, 8000),
(354, 319, 177, 1, 12000),
(355, 319, 107, 1, 8000),
(356, 320, 107, 5, 8000),
(357, 321, 107, 1, 8000),
(358, 322, 228, 1, 15000),
(359, 320, 189, 1, 18000),
(360, 324, 204, 1, 12000),
(361, 325, 107, 2, 8000),
(362, 321, 129, 1, 15000),
(366, 322, 107, 1, 8000),
(367, 326, 224, 2, 8000),
(369, 326, 179, 1, 15000),
(375, 328, 255, 5, 12000),
(376, 328, 204, 1, 12000),
(377, 328, 353, 1, 8000),
(378, 319, 180, 1, 8000),
(379, 319, 204, 3, 12000),
(380, 331, 224, 1, 8000),
(381, 327, 255, 1, 12000),
(382, 330, 107, 2, 8000),
(383, 331, 107, 1, 8000),
(384, 331, 255, 2, 12000),
(385, 332, 224, 1, 8000),
(386, 332, 107, 1, 8000),
(387, 333, 107, 1, 8000),
(388, 333, 224, 1, 8000),
(389, 334, 107, 1, 8000),
(390, 334, 351, 1, 15000),
(392, 335, 107, 1, 8000),
(394, 336, 107, 3, 8000),
(395, 320, 176, 2, 8000),
(396, 337, 107, 1, 8000),
(397, 337, 224, 1, 8000),
(398, 331, 255, 2, 12000),
(399, 338, 224, 1, 8000),
(400, 338, 335, 1, 10000),
(401, 339, 107, 2, 8000),
(402, 340, 107, 2, 8000),
(403, 340, 176, 1, 8000),
(404, 328, 175, 1, 12000),
(405, 339, 255, 1, 12000),
(406, 320, 224, 1, 8000),
(407, 341, 255, 1, 12000),
(409, 343, 203, 1, 12000),
(411, 343, 189, 1, 18000),
(412, 318, 107, 1, 8000),
(413, 318, 268, 1, 8000),
(414, 344, 107, 2, 8000),
(415, 344, 224, 1, 8000),
(416, 345, 107, 1, 8000),
(417, 345, 204, 1, 12000),
(418, 346, 107, 1, 8000),
(419, 347, 107, 1, 8000),
(420, 347, 224, 2, 8000),
(421, 348, 255, 5, 12000),
(423, 350, 107, 1, 8000),
(425, 352, 107, 1, 8000),
(428, 355, 355, 1, 15000),
(429, 356, 204, 1, 12000),
(433, 360, 107, 1, 8000),
(434, 360, 364, 5, 1000),
(435, 361, 107, 1, 8000),
(436, 354, 334, 4, 12000),
(437, 362, 226, 1, 8000),
(438, 363, 107, 2, 8000),
(439, 363, 204, 1, 12000),
(440, 363, 364, 6, 1000),
(444, 365, 255, 1, 12000),
(445, 365, 175, 2, 12000),
(446, 366, 107, 2, 8000),
(447, 316, 189, 1, 18000),
(448, 316, 308, 1, 22000),
(449, 316, 107, 4, 8000),
(450, 367, 107, 2, 8000),
(451, 368, 107, 2, 8000),
(452, 369, 107, 1, 8000),
(453, 369, 179, 2, 15000),
(454, 370, 107, 5, 8000),
(455, 370, 224, 2, 8000),
(456, 370, 177, 1, 12000),
(457, 370, 370, 1, 12000),
(458, 371, 107, 2, 8000),
(459, 370, 371, 1, 12000),
(460, 370, 364, 5, 1000),
(461, 370, 358, 1, 8000),
(462, 372, 224, 1, 8000),
(463, 373, 224, 1, 8000),
(464, 374, 224, 1, 8000),
(465, 375, 107, 2, 8000),
(466, 375, 218, 1, 15000),
(467, 375, 204, 1, 12000),
(468, 375, 362, 4, 1000),
(469, 373, 226, 1, 8000),
(470, 376, 204, 2, 12000),
(471, 377, 107, 3, 8000),
(472, 377, 224, 1, 8000),
(473, 378, 107, 1, 8000),
(474, 379, 107, 4, 8000),
(475, 380, 255, 1, 12000),
(476, 380, 107, 3, 8000),
(477, 380, 224, 1, 8000),
(478, 380, 176, 1, 8000),
(479, 381, 204, 1, 12000),
(480, 381, 332, 1, 12000),
(481, 382, 107, 2, 8000),
(482, 383, 255, 3, 12000),
(483, 383, 107, 2, 8000),
(484, 382, 368, 1, 7000),
(485, 383, 368, 1, 7000),
(486, 379, 268, 1, 8000),
(487, 384, 107, 1, 8000),
(488, 383, 204, 1, 12000),
(489, 385, 203, 1, 12000),
(490, 386, 335, 1, 10000),
(491, 386, 197, 1, 13000),
(492, 386, 204, 1, 12000),
(493, 383, 362, 5, 1000),
(494, 387, 129, 1, 15000),
(495, 387, 176, 1, 8000),
(496, 386, 358, 1, 8000),
(497, 388, 358, 1, 8000),
(499, 388, 177, 1, 12000),
(500, 388, 204, 4, 12000),
(501, 388, 107, 1, 8000),
(502, 388, 224, 1, 8000),
(503, 387, 255, 1, 12000),
(504, 389, 255, 1, 12000),
(505, 389, 358, 1, 8000),
(506, 389, 364, 5, 1000),
(507, 390, 107, 1, 8000),
(508, 377, 364, 5, 1000),
(509, 391, 255, 3, 12000),
(510, 391, 335, 1, 10000),
(511, 391, 197, 1, 13000),
(512, 392, 224, 1, 8000),
(513, 392, 351, 1, 15000),
(514, 392, 128, 1, 15000),
(515, 392, 174, 1, 12000),
(516, 392, 364, 5, 1000),
(517, 393, 334, 1, 12000),
(518, 393, 204, 1, 12000),
(519, 393, 351, 1, 15000),
(520, 393, 128, 1, 15000),
(521, 394, 107, 2, 8000),
(522, 395, 224, 2, 8000),
(523, 396, 107, 1, 8000),
(524, 396, 224, 1, 8000),
(525, 397, 224, 1, 8000),
(526, 397, 107, 2, 8000),
(527, 397, 353, 1, 8000),
(528, 398, 107, 1, 8000),
(529, 399, 107, 2, 8000),
(530, 400, 224, 1, 8000),
(531, 401, 107, 2, 8000),
(532, 401, 368, 1, 7000),
(533, 402, 204, 1, 12000),
(534, 403, 107, 1, 8000),
(535, 403, 228, 1, 15000),
(536, 404, 107, 2, 8000),
(537, 405, 107, 1, 8000),
(538, 405, 292, 1, 17000),
(539, 405, 365, 1, 10000),
(540, 406, 107, 2, 8000),
(541, 398, 199, 1, 15000),
(542, 398, 255, 3, 12000),
(543, 398, 212, 1, 10000),
(544, 407, 127, 1, 24000),
(545, 398, 180, 1, 8000),
(546, 405, 204, 1, 12000),
(547, 405, 224, 1, 8000),
(548, 408, 107, 9, 8000),
(549, 408, 224, 1, 8000),
(550, 408, 255, 2, 12000),
(551, 409, 107, 3, 8000),
(552, 410, 224, 3, 8000),
(553, 409, 107, 1, 8000),
(554, 409, 176, 1, 8000),
(555, 412, 364, 5, 1000),
(556, 413, 107, 2, 8000),
(558, 414, 255, 1, 12000),
(559, 415, 107, 1, 8000),
(560, 416, 107, 2, 8000),
(561, 417, 107, 1, 8000),
(562, 418, 107, 1, 8000),
(563, 419, 226, 1, 8000),
(564, 419, 255, 1, 12000),
(566, 419, 108, 2, 8000),
(567, 420, 228, 2, 15000),
(568, 421, 224, 1, 8000),
(569, 422, 224, 1, 8000),
(570, 422, 364, 4, 1000),
(572, 423, 255, 1, 12000),
(573, 423, 364, 5, 1000),
(575, 423, 175, 2, 12000),
(576, 423, 129, 1, 15000),
(577, 424, 107, 1, 8000),
(578, 424, 128, 1, 15000),
(579, 424, 224, 1, 8000),
(580, 424, 255, 1, 12000),
(581, 420, 107, 1, 8000),
(582, 425, 364, 5, 1000),
(583, 426, 107, 1, 8000),
(584, 427, 107, 2, 8000),
(585, 427, 176, 1, 8000),
(587, 427, 368, 1, 6000),
(588, 428, 107, 1, 8000),
(589, 428, 365, 1, 10000),
(590, 429, 224, 2, 8000),
(591, 430, 107, 1, 8000),
(592, 430, 268, 1, 8000),
(593, 431, 224, 1, 8000),
(594, 431, 362, 5, 1000),
(595, 431, 107, 1, 8000),
(596, 431, 194, 1, 12000),
(597, 432, 363, 1, 20000),
(598, 433, 107, 1, 8000),
(599, 433, 129, 1, 15000),
(600, 434, 107, 1, 8000),
(601, 435, 255, 6, 12000),
(602, 435, 176, 1, 8000),
(603, 435, 107, 2, 8000),
(604, 435, 209, 1, 10000),
(606, 434, 228, 1, 15000),
(607, 436, 107, 1, 8000),
(608, 435, 177, 1, 12000),
(609, 437, 368, 1, 6000),
(610, 438, 107, 3, 8000),
(611, 437, 107, 4, 8000),
(612, 439, 204, 1, 12000),
(613, 439, 226, 1, 8000),
(614, 439, 255, 1, 12000),
(615, 440, 107, 2, 8000),
(616, 440, 255, 1, 12000),
(617, 441, 255, 4, 12000),
(618, 441, 107, 1, 8000),
(619, 441, 204, 1, 12000),
(620, 441, 197, 1, 13000),
(621, 440, 224, 1, 8000),
(622, 442, 107, 5, 8000),
(623, 442, 224, 1, 8000),
(624, 441, 224, 1, 8000),
(626, 443, 372, 1, 10000),
(627, 444, 107, 2, 8000),
(628, 445, 107, 1, 8000),
(629, 446, 107, 1, 8000),
(630, 447, 205, 1, 12000),
(631, 447, 255, 1, 12000),
(632, 448, 107, 1, 8000),
(633, 449, 107, 1, 8000),
(634, 450, 107, 2, 8000),
(635, 451, 212, 1, 10000),
(636, 451, 107, 1, 8000),
(637, 452, 107, 1, 8000),
(638, 452, 204, 1, 12000),
(639, 453, 107, 2, 8000),
(640, 454, 107, 1, 8000),
(641, 455, 107, 1, 8000),
(642, 455, 176, 1, 8000),
(643, 456, 255, 3, 12000),
(644, 456, 107, 1, 8000),
(646, 457, 335, 1, 10000),
(647, 457, 204, 1, 12000),
(648, 458, 107, 2, 8000),
(649, 458, 224, 1, 8000),
(650, 459, 107, 1, 8000),
(651, 460, 107, 1, 8000),
(652, 460, 358, 1, 8000),
(653, 461, 228, 1, 15000),
(654, 462, 107, 1, 8000),
(655, 463, 107, 1, 8000),
(656, 464, 255, 4, 12000),
(657, 464, 209, 1, 10000),
(658, 464, 218, 1, 15000),
(659, 465, 107, 1, 8000),
(660, 466, 107, 2, 8000),
(661, 467, 224, 2, 8000),
(662, 467, 222, 1, 8000),
(663, 468, 224, 1, 8000),
(664, 468, 107, 1, 8000),
(665, 469, 107, 1, 8000),
(666, 470, 224, 1, 8000),
(667, 471, 107, 1, 8000),
(668, 472, 224, 1, 8000),
(669, 472, 107, 3, 8000),
(670, 473, 107, 1, 8000),
(671, 473, 367, 1, 13000),
(672, 474, 107, 1, 8000),
(673, 475, 194, 1, 12000),
(674, 475, 180, 1, 8000),
(675, 475, 335, 1, 10000),
(676, 476, 107, 2, 8000),
(677, 476, 255, 1, 12000),
(678, 477, 107, 1, 8000),
(679, 477, 255, 2, 12000),
(680, 478, 365, 1, 10000),
(681, 479, 224, 2, 8000),
(682, 479, 107, 1, 8000),
(683, 480, 107, 1, 8000),
(684, 481, 255, 1, 12000),
(685, 481, 355, 1, 15000),
(686, 482, 107, 1, 8000),
(687, 483, 107, 1, 8000),
(688, 483, 197, 1, 13000),
(689, 484, 107, 1, 8000),
(690, 484, 364, 2, 1000),
(691, 485, 107, 2, 8000),
(692, 485, 364, 4, 1000),
(693, 486, 224, 2, 8000),
(694, 486, 335, 1, 10000),
(695, 487, 107, 1, 8000),
(696, 488, 364, 2, 1000),
(697, 489, 107, 1, 8000),
(698, 489, 209, 1, 10000),
(699, 490, 204, 1, 12000),
(700, 491, 128, 1, 15000),
(701, 492, 107, 1, 8000),
(702, 492, 204, 1, 12000),
(703, 493, 364, 5, 1000),
(704, 494, 107, 3, 8000),
(705, 494, 224, 1, 8000),
(706, 494, 335, 1, 10000),
(707, 495, 228, 1, 15000),
(709, 496, 107, 1, 8000),
(710, 494, 365, 1, 10000),
(711, 495, 226, 1, 8000),
(712, 497, 107, 1, 8000),
(713, 497, 222, 1, 8000),
(714, 497, 364, 2, 1000),
(715, 498, 107, 6, 8000),
(716, 499, 107, 2, 8000),
(717, 499, 365, 1, 10000),
(718, 500, 107, 1, 8000),
(719, 501, 107, 1, 8000),
(720, 502, 128, 1, 15000),
(721, 503, 205, 1, 12000),
(722, 504, 107, 2, 8000),
(723, 504, 175, 1, 12000),
(724, 505, 222, 1, 8000),
(725, 506, 228, 1, 15000),
(726, 507, 107, 4, 8000),
(727, 507, 366, 1, 22000),
(728, 508, 255, 2, 12000),
(729, 509, 224, 3, 8000),
(730, 509, 222, 2, 8000),
(731, 509, 107, 1, 8000),
(732, 510, 107, 4, 8000),
(733, 510, 224, 6, 8000),
(734, 510, 255, 2, 12000),
(735, 510, 226, 1, 8000),
(736, 510, 204, 1, 12000),
(737, 511, 107, 2, 8000),
(738, 511, 364, 4, 1000),
(739, 512, 107, 5, 8000),
(740, 513, 107, 1, 8000),
(741, 514, 205, 1, 12000),
(742, 514, 369, 4, 1500),
(743, 515, 335, 1, 10000),
(744, 515, 364, 5, 1000),
(745, 516, 107, 4, 8000),
(746, 516, 224, 2, 8000),
(747, 516, 255, 1, 12000),
(749, 518, 224, 1, 8000),
(750, 518, 268, 1, 8000),
(751, 519, 107, 2, 8000),
(752, 519, 364, 2, 1000),
(753, 516, 364, 5, 1000),
(754, 520, 107, 1, 8000),
(755, 520, 175, 1, 12000),
(756, 521, 224, 1, 8000),
(757, 521, 222, 1, 8000),
(758, 522, 224, 1, 8000),
(759, 523, 358, 1, 8000),
(760, 523, 222, 1, 8000),
(761, 524, 107, 1, 8000),
(762, 524, 222, 1, 8000),
(763, 524, 364, 4, 1000),
(764, 522, 358, 1, 8000),
(767, 526, 107, 2, 8000),
(768, 526, 364, 4, 1000),
(769, 527, 224, 1, 8000),
(770, 527, 222, 1, 8000),
(771, 528, 224, 1, 8000),
(772, 528, 107, 2, 8000),
(773, 529, 222, 1, 8000),
(774, 530, 107, 3, 8000),
(775, 531, 334, 1, 12000),
(776, 532, 107, 1, 8000),
(777, 531, 107, 1, 8000),
(778, 531, 224, 1, 8000),
(779, 533, 364, 2, 1000),
(780, 534, 107, 2, 8000),
(781, 535, 175, 1, 12000),
(782, 536, 107, 1, 8000),
(783, 536, 364, 3, 1000),
(785, 537, 373, 2, 5000),
(786, 538, 224, 2, 8000),
(787, 538, 358, 1, 8000),
(788, 530, 364, 4, 1000),
(789, 535, 212, 2, 10000),
(790, 535, 204, 1, 12000),
(791, 534, 362, 4, 1000),
(792, 538, 107, 1, 8000),
(793, 539, 107, 3, 8000),
(794, 540, 107, 3, 8000),
(795, 541, 204, 2, 12000),
(796, 541, 224, 1, 8000),
(797, 541, 107, 1, 8000),
(798, 530, 367, 1, 13000),
(799, 542, 107, 2, 8000),
(800, 542, 358, 1, 8000),
(801, 543, 107, 1, 8000),
(802, 544, 107, 2, 8000),
(803, 542, 224, 2, 8000),
(804, 545, 107, 2, 8000),
(805, 546, 107, 2, 8000),
(806, 547, 255, 1, 12000),
(807, 548, 107, 1, 8000),
(808, 548, 364, 3, 1000),
(809, 549, 107, 1, 8000),
(810, 550, 107, 1, 8000),
(811, 551, 107, 4, 8000),
(812, 551, 224, 1, 8000),
(813, 552, 107, 2, 8000),
(814, 553, 228, 1, 15000),
(815, 553, 107, 1, 8000),
(816, 554, 107, 2, 8000),
(817, 555, 224, 1, 8000),
(818, 555, 255, 1, 12000),
(821, 552, 224, 1, 8000),
(822, 555, 363, 1, 20000),
(823, 557, 175, 2, 12000),
(824, 557, 212, 1, 10000),
(825, 557, 365, 1, 10000),
(826, 558, 255, 2, 12000),
(827, 558, 368, 1, 6000),
(828, 559, 107, 1, 8000),
(829, 559, 255, 1, 12000),
(830, 560, 255, 2, 12000),
(831, 560, 364, 5, 1000),
(832, 559, 224, 1, 8000),
(833, 561, 224, 1, 8000),
(835, 557, 255, 1, 12000),
(836, 559, 373, 1, 7000),
(837, 558, 197, 1, 13000),
(838, 562, 107, 1, 8000),
(839, 563, 107, 1, 8000),
(840, 564, 107, 1, 8000),
(841, 565, 107, 1, 8000),
(842, 566, 107, 2, 8000),
(843, 567, 362, 4, 1000),
(844, 567, 224, 2, 8000),
(845, 568, 364, 10, 1000),
(846, 568, 107, 2, 8000),
(848, 567, 174, 1, 12000),
(850, 569, 107, 1, 8000),
(852, 569, 362, 3, 1000),
(853, 570, 175, 1, 12000),
(854, 570, 107, 1, 8000),
(855, 570, 129, 1, 15000),
(856, 571, 224, 1, 8000),
(857, 572, 107, 3, 8000),
(858, 572, 255, 2, 12000),
(859, 572, 128, 2, 15000),
(860, 573, 107, 1, 8000),
(861, 574, 107, 1, 8000),
(862, 574, 175, 1, 12000),
(864, 575, 367, 1, 13000),
(865, 576, 176, 1, 8000),
(866, 576, 177, 1, 12000),
(867, 576, 268, 1, 8000),
(868, 577, 107, 1, 8000),
(870, 578, 107, 3, 8000),
(871, 578, 368, 1, 6000),
(872, 577, 362, 2, 1000),
(873, 578, 176, 5, 8000),
(874, 578, 255, 2, 12000),
(875, 578, 224, 1, 8000),
(876, 579, 107, 2, 8000),
(877, 578, 365, 1, 10000),
(878, 580, 107, 2, 8000),
(879, 581, 107, 1, 8000),
(880, 581, 226, 1, 8000),
(881, 582, 107, 1, 8000),
(882, 582, 176, 1, 8000),
(883, 583, 255, 1, 12000),
(884, 584, 204, 1, 12000),
(885, 585, 176, 1, 8000),
(887, 586, 107, 1, 8000),
(888, 585, 335, 1, 10000),
(889, 587, 205, 1, 12000),
(890, 588, 205, 1, 12000),
(891, 589, 107, 1, 8000),
(892, 590, 107, 1, 8000),
(893, 590, 176, 1, 8000),
(894, 590, 368, 1, 6000),
(895, 591, 224, 2, 8000),
(896, 592, 255, 1, 12000),
(897, 592, 353, 1, 8000),
(898, 593, 107, 1, 8000),
(899, 593, 212, 1, 10000),
(900, 594, 224, 2, 8000),
(901, 595, 224, 1, 8000),
(902, 596, 180, 1, 8000),
(903, 597, 255, 1, 12000),
(904, 598, 224, 1, 8000),
(905, 599, 255, 1, 12000),
(906, 599, 351, 1, 15000),
(907, 600, 255, 1, 12000),
(908, 601, 107, 1, 8000),
(909, 601, 255, 1, 12000),
(910, 602, 355, 1, 15000),
(911, 603, 335, 1, 10000),
(912, 604, 175, 2, 12000),
(913, 605, 189, 2, 15000),
(914, 606, 107, 2, 8000),
(915, 607, 358, 1, 8000),
(916, 608, 107, 1, 8000),
(917, 608, 224, 2, 8000),
(918, 609, 226, 1, 8000),
(919, 610, 204, 1, 12000),
(920, 610, 255, 1, 12000),
(921, 611, 176, 2, 8000),
(922, 612, 107, 1, 8000),
(923, 613, 228, 1, 15000),
(924, 613, 334, 1, 12000),
(925, 613, 205, 1, 12000),
(926, 613, 194, 3, 12000),
(927, 613, 332, 2, 12000),
(928, 613, 129, 5, 15000),
(929, 613, 176, 1, 8000),
(930, 614, 364, 5, 1000),
(931, 615, 107, 1, 8000),
(932, 616, 107, 2, 8000),
(933, 616, 222, 1, 8000),
(934, 617, 107, 3, 8000),
(935, 617, 255, 1, 12000),
(936, 617, 107, 1, 8000),
(937, 617, 255, 1, 12000),
(938, 617, 353, 1, 8000),
(939, 619, 107, 1, 8000),
(940, 620, 364, 5, 1000),
(941, 620, 176, 1, 8000),
(942, 620, 180, 2, 8000),
(943, 620, 107, 1, 8000),
(944, 621, 107, 2, 8000),
(945, 621, 222, 1, 8000),
(946, 622, 202, 2, 12000),
(947, 622, 107, 2, 8000),
(948, 622, 176, 1, 8000),
(949, 622, 364, 2, 1000),
(950, 623, 107, 1, 8000),
(951, 623, 255, 1, 12000),
(952, 623, 368, 1, 6000),
(953, 624, 224, 1, 8000),
(954, 623, 226, 1, 8000),
(955, 625, 255, 1, 12000),
(956, 626, 358, 1, 8000),
(957, 626, 176, 2, 8000),
(959, 628, 107, 1, 8000),
(960, 629, 107, 2, 8000),
(961, 625, 107, 1, 8000),
(962, 630, 107, 2, 8000),
(963, 631, 107, 1, 8000),
(964, 632, 107, 1, 8000),
(965, 633, 204, 1, 12000),
(966, 633, 222, 1, 8000),
(967, 634, 129, 2, 15000),
(968, 634, 128, 1, 15000),
(969, 634, 127, 1, 22000),
(970, 635, 224, 3, 8000),
(971, 635, 107, 1, 8000),
(972, 635, 255, 1, 12000),
(973, 636, 255, 1, 12000),
(974, 637, 107, 2, 8000),
(975, 636, 107, 1, 8000),
(976, 636, 127, 1, 22000),
(977, 638, 107, 1, 8000),
(978, 639, 180, 1, 8000),
(979, 639, 176, 2, 8000),
(980, 640, 380, 1, 10000),
(981, 639, 128, 1, 15000),
(982, 639, 268, 1, 8000),
(983, 641, 107, 2, 8000),
(985, 641, 224, 1, 8000),
(986, 641, 203, 1, 12000),
(987, 642, 335, 1, 10000),
(988, 642, 197, 1, 13000),
(989, 642, 292, 1, 17000),
(990, 643, 107, 1, 8000),
(991, 644, 204, 1, 12000),
(992, 644, 107, 3, 8000),
(993, 645, 255, 1, 12000),
(994, 645, 107, 1, 8000),
(995, 645, 292, 1, 17000),
(996, 646, 107, 1, 8000),
(997, 647, 107, 1, 8000),
(998, 647, 255, 1, 12000),
(999, 646, 129, 1, 15000),
(1000, 648, 129, 1, 15000),
(1001, 648, 176, 3, 8000),
(1002, 648, 364, 4, 1000),
(1003, 649, 255, 1, 12000),
(1004, 649, 224, 1, 8000),
(1005, 650, 255, 1, 12000),
(1006, 650, 335, 1, 10000),
(1007, 651, 176, 1, 8000),
(1008, 651, 351, 1, 15000),
(1009, 651, 255, 1, 12000),
(1010, 652, 107, 1, 8000),
(1011, 653, 222, 1, 8000),
(1012, 654, 107, 1, 8000),
(1013, 654, 176, 1, 8000),
(1014, 655, 107, 3, 8000),
(1015, 656, 107, 1, 8000),
(1016, 657, 107, 1, 8000),
(1017, 658, 107, 2, 8000),
(1018, 658, 364, 4, 1000),
(1019, 658, 368, 2, 6000),
(1020, 659, 107, 1, 8000),
(1021, 660, 204, 1, 12000),
(1022, 660, 365, 1, 10000),
(1024, 662, 107, 2, 8000),
(1025, 662, 176, 1, 8000),
(1026, 662, 328, 3, 2000),
(1028, 664, 204, 1, 12000),
(1029, 664, 328, 1, 2000),
(1030, 665, 112, 2, 10000),
(1031, 665, 107, 1, 8000),
(1032, 665, 365, 1, 10000),
(1033, 665, 328, 3, 2000),
(1034, 666, 107, 1, 8000),
(1035, 667, 107, 1, 8000),
(1036, 667, 224, 1, 8000),
(1037, 667, 363, 1, 20000),
(1038, 668, 107, 3, 8000),
(1039, 668, 212, 2, 10000),
(1040, 668, 363, 1, 20000),
(1041, 669, 107, 1, 8000),
(1042, 670, 107, 3, 8000),
(1043, 671, 107, 1, 8000),
(1044, 672, 107, 3, 8000),
(1045, 672, 222, 1, 8000),
(1046, 670, 204, 1, 12000),
(1047, 673, 107, 5, 8000),
(1048, 668, 175, 1, 12000),
(1049, 670, 255, 2, 12000),
(1050, 670, 364, 5, 1000),
(1051, 673, 112, 1, 10000),
(1052, 667, 255, 1, 12000),
(1053, 674, 107, 2, 8000),
(1054, 675, 107, 1, 8000),
(1055, 675, 255, 1, 12000),
(1056, 674, 222, 1, 8000),
(1058, 677, 255, 1, 12000),
(1059, 678, 107, 2, 8000),
(1060, 678, 255, 2, 12000),
(1061, 679, 107, 2, 8000),
(1062, 679, 255, 2, 12000),
(1063, 680, 180, 1, 8000),
(1064, 681, 107, 1, 8000),
(1066, 682, 255, 1, 12000),
(1067, 682, 176, 1, 8000),
(1068, 683, 107, 1, 8000),
(1069, 684, 107, 1, 8000),
(1070, 684, 364, 5, 1000),
(1071, 685, 180, 2, 8000),
(1072, 685, 107, 1, 8000),
(1073, 685, 197, 1, 13000),
(1074, 686, 176, 2, 8000),
(1075, 686, 364, 9, 1000),
(1076, 687, 224, 1, 8000),
(1077, 687, 175, 1, 12000),
(1078, 688, 107, 1, 8000),
(1079, 688, 224, 1, 8000),
(1080, 689, 107, 1, 8000),
(1081, 690, 107, 1, 8000),
(1082, 691, 107, 1, 8000),
(1083, 692, 107, 1, 8000),
(1084, 693, 107, 1, 8000),
(1085, 693, 176, 2, 8000),
(1086, 694, 255, 1, 12000),
(1087, 691, 176, 1, 8000),
(1088, 686, 224, 1, 8000),
(1089, 694, 364, 3, 1000),
(1090, 695, 107, 2, 8000),
(1091, 696, 128, 2, 15000),
(1092, 697, 177, 1, 12000),
(1093, 697, 335, 1, 10000),
(1094, 698, 107, 1, 8000),
(1095, 699, 107, 2, 8000),
(1096, 699, 176, 1, 8000),
(1097, 699, 364, 2, 1000),
(1098, 700, 107, 2, 8000),
(1100, 701, 107, 2, 8000),
(1101, 702, 162, 1, 10000),
(1102, 702, 204, 1, 12000),
(1103, 702, 107, 1, 8000),
(1104, 702, 368, 1, 6000),
(1105, 701, 112, 1, 10000),
(1106, 703, 205, 1, 12000),
(1107, 704, 204, 1, 12000),
(1108, 704, 255, 1, 12000),
(1109, 704, 315, 1, 15000),
(1111, 704, 224, 1, 8000),
(1112, 705, 107, 1, 8000),
(1113, 703, 176, 1, 8000),
(1114, 706, 107, 1, 8000),
(1115, 707, 226, 1, 8000),
(1116, 707, 107, 1, 8000),
(1117, 704, 107, 2, 8000),
(1118, 703, 364, 4, 1000),
(1119, 708, 224, 1, 8000),
(1120, 708, 358, 1, 8000),
(1121, 709, 175, 3, 12000),
(1122, 710, 107, 2, 8000),
(1123, 711, 107, 1, 8000),
(1124, 708, 365, 1, 10000),
(1125, 712, 255, 1, 12000),
(1126, 713, 364, 5, 1000),
(1127, 713, 212, 1, 10000),
(1128, 714, 255, 2, 12000),
(1129, 715, 107, 1, 8000),
(1130, 715, 176, 1, 8000),
(1131, 716, 107, 5, 8000),
(1132, 716, 204, 1, 12000),
(1133, 716, 255, 1, 12000),
(1134, 717, 107, 2, 8000),
(1135, 717, 222, 1, 8000),
(1136, 718, 255, 2, 12000),
(1137, 719, 107, 1, 8000),
(1138, 720, 175, 1, 12000),
(1139, 720, 255, 1, 12000),
(1140, 720, 205, 1, 12000),
(1141, 721, 224, 0, 8000),
(1142, 722, 107, 2, 8000),
(1143, 722, 255, 1, 12000),
(1144, 723, 107, 2, 8000),
(1145, 724, 107, 2, 8000),
(1146, 724, 224, 1, 8000),
(1147, 719, 365, 1, 10000),
(1148, 725, 107, 1, 8000),
(1149, 725, 368, 1, 6000),
(1150, 721, 107, 2, 8000),
(1151, 726, 107, 1, 8000),
(1152, 726, 255, 1, 12000),
(1153, 726, 176, 1, 8000),
(1154, 726, 368, 2, 6000),
(1155, 727, 107, 2, 8000),
(1156, 725, 224, 1, 8000),
(1157, 727, 176, 1, 8000),
(1158, 728, 107, 4, 8000),
(1159, 728, 224, 1, 8000),
(1160, 729, 107, 1, 8000),
(1161, 729, 368, 1, 6000),
(1163, 730, 255, 1, 12000),
(1164, 731, 107, 1, 8000),
(1165, 732, 107, 1, 8000),
(1166, 732, 224, 1, 8000),
(1167, 727, 364, 5, 1000),
(1168, 731, 112, 1, 10000),
(1169, 734, 107, 3, 8000),
(1170, 734, 204, 1, 12000),
(1171, 718, 107, 1, 8000),
(1172, 734, 268, 1, 8000),
(1173, 735, 107, 1, 8000),
(1174, 734, 224, 1, 8000),
(1175, 734, 365, 1, 10000),
(1176, 736, 175, 2, 12000),
(1177, 737, 107, 1, 8000),
(1178, 737, 176, 1, 8000),
(1179, 738, 107, 0, 8000),
(1180, 739, 351, 1, 15000),
(1181, 739, 129, 2, 15000),
(1182, 739, 228, 1, 15000),
(1183, 739, 222, 0, 8000),
(1184, 737, 212, 1, 10000),
(1185, 740, 180, 1, 8000),
(1186, 741, 179, 2, 15000),
(1187, 741, 255, 1, 12000),
(1188, 741, 365, 1, 10000),
(1189, 742, 204, 2, 12000),
(1190, 743, 224, 2, 8000),
(1191, 744, 224, 1, 8000),
(1192, 741, 175, 1, 12000),
(1193, 745, 107, 1, 8000),
(1194, 746, 107, 2, 8000),
(1195, 747, 107, 2, 8000),
(1197, 747, 368, 2, 6000),
(1198, 748, 107, 1, 8000),
(1199, 749, 107, 1, 8000),
(1200, 750, 107, 2, 8000),
(1201, 750, 204, 2, 12000),
(1203, 750, 364, 4, 1000),
(1204, 751, 127, 2, 22000),
(1205, 751, 107, 2, 8000),
(1206, 751, 180, 1, 8000),
(1207, 752, 127, 2, 22000),
(1208, 752, 255, 3, 12000),
(1209, 752, 363, 1, 20000),
(1210, 753, 107, 1, 8000),
(1211, 754, 107, 2, 8000),
(1212, 754, 255, 1, 12000),
(1213, 754, 364, 5, 1000),
(1214, 753, 176, 1, 8000),
(1215, 752, 107, 2, 8000),
(1216, 755, 255, 2, 12000),
(1217, 755, 335, 1, 10000),
(1218, 755, 189, 1, 15000),
(1219, 756, 204, 3, 12000),
(1220, 757, 127, 1, 22000),
(1221, 758, 364, 5, 1000),
(1222, 759, 107, 2, 8000),
(1223, 752, 197, 1, 13000),
(1224, 760, 204, 1, 12000),
(1225, 761, 107, 3, 8000),
(1226, 762, 107, 3, 8000),
(1227, 762, 267, 1, 8000),
(1228, 763, 107, 1, 8000),
(1229, 764, 224, 1, 8000),
(1230, 765, 107, 1, 8000),
(1231, 766, 107, 2, 8000),
(1232, 766, 368, 1, 6000),
(1233, 767, 107, 2, 8000),
(1234, 767, 226, 1, 8000),
(1235, 767, 364, 4, 1000),
(1236, 768, 107, 2, 8000),
(1237, 769, 107, 6, 8000),
(1238, 769, 335, 1, 10000),
(1239, 770, 224, 1, 8000),
(1240, 770, 255, 1, 12000),
(1241, 771, 107, 2, 8000),
(1242, 772, 180, 2, 8000),
(1243, 771, 176, 2, 8000),
(1244, 771, 255, 1, 12000),
(1245, 773, 107, 1, 8000),
(1246, 774, 107, 2, 8000),
(1247, 769, 176, 1, 8000),
(1248, 769, 222, 1, 8000),
(1249, 769, 368, 1, 6000),
(1250, 770, 176, 4, 8000),
(1251, 770, 175, 1, 12000),
(1252, 770, 192, 1, 20000),
(1253, 775, 231, 1, 25000),
(1254, 775, 230, 2, 30000),
(1255, 776, 107, 20, 8000),
(1256, 775, 107, 1, 8000),
(1257, 775, 204, 1, 12000),
(1258, 775, 194, 1, 12000);

-- --------------------------------------------------------

--
-- Table structure for table `cafehappy4_store`
--

CREATE TABLE IF NOT EXISTS `cafehappy4_store` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `note` varchar(125) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `cafehappy4_store`
--

INSERT INTO `cafehappy4_store` (`id`, `name`, `note`) VALUES
(1, 'Kho nhà', 'Ghi chú gì đây ?');

-- --------------------------------------------------------

--
-- Table structure for table `cafehappy4_supplier`
--

CREATE TABLE IF NOT EXISTS `cafehappy4_supplier` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `note` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `debt` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=14 ;

--
-- Dumping data for table `cafehappy4_supplier`
--

INSERT INTO `cafehappy4_supplier` (`id`, `name`, `phone`, `address`, `note`, `debt`) VALUES
(1, 'ĐL NƯỚC ĐÁ', '0913796043', 'Phường 8', 'Cung cấp nước đá', 0),
(6, 'Siêu thị COOP MART', 'chưa cập nhật', 'Vĩnh Long', '', 0),
(8, 'ĐL Cafe hạt', '0703 111 222', 'P4 Vĩnh Long', '', 0),
(9, 'ĐL Nước ngọt Thiên Tân', '', 'P1, TP Vĩnh Long', '', 0),
(12, 'VỰA TRÁI CÂY', '', '', '', 0),
(13, 'NCC A', '80830803', 'p5 tpvl', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `cafehappy4_table`
--

CREATE TABLE IF NOT EXISTS `cafehappy4_table` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iddomain` int(11) NOT NULL,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `iduser` int(11) DEFAULT NULL,
  `type` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `iddomain` (`iddomain`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=192 ;

--
-- Dumping data for table `cafehappy4_table`
--

INSERT INTO `cafehappy4_table` (`id`, `iddomain`, `name`, `iduser`, `type`) VALUES
(1, 1, '01', 1, '0'),
(2, 1, '02', 1, '0'),
(3, 1, '03', 1, '0'),
(4, 1, '04', 1, '0'),
(28, 1, '05', 1, '0'),
(29, 1, '06', 1, '0'),
(30, 1, '07', 1, '0'),
(31, 1, '08', 1, '0'),
(32, 1, '09', 1, '0'),
(33, 1, '10', 1, '0'),
(34, 1, '11', 1, '0'),
(35, 1, '12', 1, '0'),
(37, 1, '13', 1, '0'),
(38, 1, '14', 1, '0'),
(41, 1, '15', 1, '0'),
(133, 1, '16', 1, '0'),
(135, 1, '17', 1, '0'),
(136, 1, '18', 1, '0'),
(137, 1, '19', 1, '0'),
(138, 1, '20', 1, '0'),
(139, 1, '21', 1, '0'),
(140, 1, '22', 1, '0'),
(141, 1, '23', 1, '0'),
(142, 1, '24', 1, '0'),
(143, 1, '25', 1, '0'),
(144, 1, '26', 1, '0'),
(145, 1, '27', 1, '0'),
(146, 1, '28', 1, '0'),
(147, 1, '29', 1, '0'),
(148, 1, '30', 1, '0'),
(149, 1, '31', 1, '0'),
(150, 1, '32', 1, '0'),
(151, 1, '33', 1, '0'),
(152, 1, '34', 1, '0'),
(153, 1, '35', 1, '0'),
(154, 1, '36', 1, '0'),
(155, 1, '37', 1, '0'),
(156, 1, '38', 1, '0'),
(157, 1, '39', 1, '0'),
(158, 1, '40', 1, '0'),
(159, 1, '41', 1, '0'),
(160, 1, '42', 1, '0'),
(161, 1, '43', 1, '0'),
(162, 1, '44', 1, '0'),
(163, 1, '45', 1, '0'),
(164, 1, '46', 1, '0'),
(165, 1, '47', 1, '0'),
(166, 1, '48', 1, '0'),
(167, 1, '49', 1, '0'),
(168, 1, '50', 1, '0'),
(169, 1, '51', 1, '0'),
(170, 1, '52', 1, '0'),
(171, 1, '53', 1, '0'),
(172, 1, '54', 1, '0'),
(173, 1, '55', 1, '0'),
(174, 1, '56', 1, '0'),
(175, 1, '57', 1, '0'),
(176, 1, '58', 1, '0'),
(177, 1, '59', 1, '0'),
(178, 1, '60', 1, '0'),
(179, 1, '61', 1, '0'),
(180, 1, '62', 1, '0'),
(181, 1, '63', 1, '0'),
(182, 1, '64', 1, '0'),
(183, 1, '65', 1, '0'),
(184, 1, '66', 1, '0'),
(185, 7, 'Quý Khách 1', 1, '0'),
(186, 7, 'Quý Khách 2', 1, '0'),
(187, 7, 'Quý Khách 3', 1, '0'),
(188, 7, 'Quý Khách 4', 1, '0'),
(189, 1, '67', 1, '0'),
(190, 1, '68', 1, '0'),
(191, 1, '69', 1, '0');

-- --------------------------------------------------------

--
-- Table structure for table `cafehappy4_table_log`
--

CREATE TABLE IF NOT EXISTS `cafehappy4_table_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iduser` int(11) NOT NULL,
  `idtable` int(11) NOT NULL,
  `datetime` datetime NOT NULL,
  `note` varchar(250) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idtable` (`idtable`),
  KEY `iduser` (`iduser`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `cafehappy4_table_log`
--


-- --------------------------------------------------------

--
-- Table structure for table `cafehappy4_term`
--

CREATE TABLE IF NOT EXISTS `cafehappy4_term` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=12 ;

--
-- Dumping data for table `cafehappy4_term`
--

INSERT INTO `cafehappy4_term` (`id`, `name`, `type`) VALUES
(1, 'Tiền Điện', 0),
(2, 'Tiền Nước', 0),
(3, 'Thuế', 0),
(10, 'Tiền Ăn Nhân Viên', 0),
(11, 'CP Khác', 0);

-- --------------------------------------------------------

--
-- Table structure for table `cafehappy4_term_collect`
--

CREATE TABLE IF NOT EXISTS `cafehappy4_term_collect` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Dumping data for table `cafehappy4_term_collect`
--

INSERT INTO `cafehappy4_term_collect` (`id`, `name`) VALUES
(2, 'Phụ Phẩm'),
(3, 'Đặc Biệt');

-- --------------------------------------------------------

--
-- Table structure for table `cafehappy4_tracking`
--

CREATE TABLE IF NOT EXISTS `cafehappy4_tracking` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_start` date NOT NULL,
  `date_end` date NOT NULL,
  `paid_general` int(11) NOT NULL,
  `paid_pay_roll` int(11) NOT NULL,
  `paid_import` int(11) NOT NULL,
  `collect_general` int(11) NOT NULL,
  `collect_customer` int(11) NOT NULL,
  `collect_selling_debt` int(11) NOT NULL,
  `collect_selling_nodebt` int(11) NOT NULL,
  `estate_rate` int(11) NOT NULL,
  `store_value` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=16 ;

--
-- Dumping data for table `cafehappy4_tracking`
--

INSERT INTO `cafehappy4_tracking` (`id`, `date_start`, `date_end`, `paid_general`, `paid_pay_roll`, `paid_import`, `collect_general`, `collect_customer`, `collect_selling_debt`, `collect_selling_nodebt`, `estate_rate`, `store_value`) VALUES
(13, '2014-01-01', '2014-01-31', 0, 0, 0, 0, 0, 0, 0, 0, 0),
(15, '2014-02-01', '2014-02-28', 0, 0, 0, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `cafehappy4_tracking_course`
--

CREATE TABLE IF NOT EXISTS `cafehappy4_tracking_course` (
  `id` int(11) NOT NULL,
  `id_tracking` int(11) NOT NULL,
  `id_td` int(11) NOT NULL,
  `id_course` int(11) NOT NULL,
  `count` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `value` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cafehappy4_tracking_course`
--

INSERT INTO `cafehappy4_tracking_course` (`id`, `id_tracking`, `id_td`, `id_course`, `count`, `price`, `value`) VALUES
(0, 13, 39, 194, 2, 0, 0),
(0, 13, 39, 335, 4, 0, 0),
(0, 13, 39, 107, 85, 0, 0),
(0, 13, 39, 108, 2, 0, 0),
(0, 13, 39, 255, 28, 0, 0),
(0, 13, 39, 355, 1, 0, 0),
(0, 13, 39, 358, 1, 0, 0),
(0, 13, 39, 268, 1, 0, 0),
(0, 13, 39, 197, 2, 0, 0),
(0, 13, 39, 175, 2, 0, 0),
(0, 13, 39, 176, 3, 0, 0),
(0, 13, 39, 177, 1, 0, 0),
(0, 13, 39, 362, 5, 0, 0),
(0, 13, 39, 363, 1, 0, 0),
(0, 13, 39, 364, 29, 0, 0),
(0, 13, 39, 365, 3, 0, 0),
(0, 13, 39, 224, 20, 0, 0),
(0, 13, 39, 226, 3, 0, 0),
(0, 13, 39, 218, 1, 0, 0),
(0, 13, 39, 368, 2, 0, 0),
(0, 13, 39, 367, 1, 0, 0),
(0, 13, 39, 180, 1, 0, 0),
(0, 13, 39, 128, 2, 0, 0),
(0, 13, 39, 129, 2, 0, 0),
(0, 13, 39, 204, 6, 0, 0),
(0, 13, 39, 209, 3, 0, 0),
(0, 13, 39, 212, 1, 0, 0),
(0, 13, 39, 372, 1, 0, 0),
(0, 13, 39, 222, 2, 0, 0),
(0, 13, 39, 205, 1, 0, 0),
(0, 13, 39, 228, 5, 0, 0),
(0, 13, 43, 335, 1, 0, 0),
(0, 13, 43, 107, 57, 0, 0),
(0, 13, 43, 255, 15, 0, 0),
(0, 13, 43, 112, 4, 0, 0),
(0, 13, 43, 358, 1, 0, 0),
(0, 13, 43, 197, 1, 0, 0),
(0, 13, 43, 175, 5, 0, 0),
(0, 13, 43, 176, 10, 0, 0),
(0, 13, 43, 177, 1, 0, 0),
(0, 13, 43, 363, 2, 0, 0),
(0, 13, 43, 364, 33, 0, 0),
(0, 13, 43, 365, 2, 0, 0),
(0, 13, 43, 224, 6, 0, 0),
(0, 13, 43, 226, 1, 0, 0),
(0, 13, 43, 368, 1, 0, 0),
(0, 13, 43, 328, 7, 0, 0),
(0, 13, 43, 180, 3, 0, 0),
(0, 13, 43, 128, 2, 0, 0),
(0, 13, 43, 204, 4, 0, 0),
(0, 13, 43, 212, 3, 0, 0),
(0, 13, 43, 222, 2, 0, 0),
(0, 13, 43, 205, 1, 0, 0),
(0, 13, 43, 315, 1, 0, 0),
(0, 13, 43, 162, 1, 0, 0),
(0, 13, 44, 335, 1, 0, 0),
(0, 13, 44, 107, 51, 0, 0),
(0, 13, 44, 255, 14, 0, 0),
(0, 13, 44, 112, 1, 0, 0),
(0, 13, 44, 268, 1, 0, 0),
(0, 13, 44, 197, 1, 0, 0),
(0, 13, 44, 175, 4, 0, 0),
(0, 13, 44, 176, 4, 0, 0),
(0, 13, 44, 189, 1, 0, 0),
(0, 13, 44, 363, 1, 0, 0),
(0, 13, 44, 364, 19, 0, 0),
(0, 13, 44, 365, 3, 0, 0),
(0, 13, 44, 224, 8, 0, 0),
(0, 13, 44, 368, 6, 0, 0),
(0, 13, 44, 179, 2, 0, 0),
(0, 13, 44, 180, 2, 0, 0),
(0, 13, 44, 127, 5, 0, 0),
(0, 13, 44, 351, 1, 0, 0),
(0, 13, 44, 129, 2, 0, 0),
(0, 13, 44, 204, 10, 0, 0),
(0, 13, 44, 212, 1, 0, 0),
(0, 13, 44, 222, 1, 0, 0),
(0, 13, 44, 205, 1, 0, 0),
(0, 13, 44, 228, 1, 0, 0),
(0, 13, 38, 370, 1, 0, 0),
(0, 13, 38, 335, 2, 0, 0),
(0, 13, 38, 107, 63, 0, 0),
(0, 13, 38, 255, 15, 0, 0),
(0, 13, 38, 358, 4, 0, 0),
(0, 13, 38, 268, 1, 0, 0),
(0, 13, 38, 203, 1, 0, 0),
(0, 13, 38, 353, 1, 0, 0),
(0, 13, 38, 197, 2, 0, 0),
(0, 13, 38, 174, 1, 0, 0),
(0, 13, 38, 175, 2, 0, 0),
(0, 13, 38, 176, 3, 0, 0),
(0, 13, 38, 177, 2, 0, 0),
(0, 13, 38, 362, 9, 0, 0),
(0, 13, 38, 364, 25, 0, 0),
(0, 13, 38, 365, 1, 0, 0),
(0, 13, 38, 224, 19, 0, 0),
(0, 13, 38, 226, 1, 0, 0),
(0, 13, 38, 218, 1, 0, 0),
(0, 13, 38, 292, 1, 0, 0),
(0, 13, 38, 368, 3, 0, 0),
(0, 13, 38, 371, 1, 0, 0),
(0, 13, 38, 179, 2, 0, 0),
(0, 13, 38, 180, 1, 0, 0),
(0, 13, 38, 332, 1, 0, 0),
(0, 13, 38, 127, 1, 0, 0),
(0, 13, 38, 128, 2, 0, 0),
(0, 13, 38, 351, 2, 0, 0),
(0, 13, 38, 129, 1, 0, 0),
(0, 13, 38, 204, 13, 0, 0),
(0, 13, 38, 199, 1, 0, 0),
(0, 13, 38, 212, 1, 0, 0),
(0, 13, 38, 334, 1, 0, 0),
(0, 13, 38, 228, 1, 0, 0),
(0, 13, 45, 335, 1, 0, 0),
(0, 13, 45, 107, 23, 0, 0),
(0, 13, 45, 255, 2, 0, 0),
(0, 13, 45, 267, 1, 0, 0),
(0, 13, 45, 176, 3, 0, 0),
(0, 13, 45, 364, 4, 0, 0),
(0, 13, 45, 224, 3, 0, 0),
(0, 13, 45, 226, 1, 0, 0),
(0, 13, 45, 368, 2, 0, 0),
(0, 13, 45, 180, 2, 0, 0),
(0, 13, 45, 222, 1, 0, 0),
(0, 13, 36, 335, 2, 0, 0),
(0, 13, 36, 107, 37, 0, 0),
(0, 13, 36, 255, 10, 0, 0),
(0, 13, 36, 268, 1, 0, 0),
(0, 13, 36, 174, 1, 0, 0),
(0, 13, 36, 175, 1, 0, 0),
(0, 13, 36, 176, 4, 0, 0),
(0, 13, 36, 177, 4, 0, 0),
(0, 13, 36, 189, 1, 0, 0),
(0, 13, 36, 224, 14, 0, 0),
(0, 13, 36, 178, 1, 0, 0),
(0, 13, 36, 179, 1, 0, 0),
(0, 13, 36, 180, 3, 0, 0),
(0, 13, 36, 56, 1, 0, 0),
(0, 13, 36, 128, 1, 0, 0),
(0, 13, 36, 204, 8, 0, 0),
(0, 13, 36, 212, 2, 0, 0),
(0, 13, 36, 221, 1, 0, 0),
(0, 13, 36, 222, 3, 0, 0),
(0, 13, 36, 205, 1, 0, 0),
(0, 13, 35, 107, 1, 0, 0),
(0, 13, 35, 255, 1, 0, 0),
(0, 13, 35, 224, 1, 0, 0),
(0, 13, 37, 335, 1, 0, 0),
(0, 13, 37, 107, 90, 0, 0),
(0, 13, 37, 255, 29, 0, 0),
(0, 13, 37, 112, 2, 0, 0),
(0, 13, 37, 355, 1, 0, 0),
(0, 13, 37, 268, 2, 0, 0),
(0, 13, 37, 265, 1, 0, 0),
(0, 13, 37, 203, 1, 0, 0),
(0, 13, 37, 353, 2, 0, 0),
(0, 13, 37, 197, 2, 0, 0),
(0, 13, 37, 174, 2, 0, 0),
(0, 13, 37, 175, 4, 0, 0),
(0, 13, 37, 176, 8, 0, 0),
(0, 13, 37, 177, 1, 0, 0),
(0, 13, 37, 189, 3, 0, 0),
(0, 13, 37, 308, 1, 0, 0),
(0, 13, 37, 364, 11, 0, 0),
(0, 13, 37, 224, 20, 0, 0),
(0, 13, 37, 226, 1, 0, 0),
(0, 13, 37, 218, 2, 0, 0),
(0, 13, 37, 201, 1, 0, 0),
(0, 13, 37, 179, 1, 0, 0),
(0, 13, 37, 180, 1, 0, 0),
(0, 13, 37, 351, 2, 0, 0),
(0, 13, 37, 129, 1, 0, 0),
(0, 13, 37, 204, 15, 0, 0),
(0, 13, 37, 212, 3, 0, 0),
(0, 13, 37, 222, 1, 0, 0),
(0, 13, 37, 334, 4, 0, 0),
(0, 13, 37, 205, 1, 0, 0),
(0, 13, 37, 315, 2, 0, 0),
(0, 13, 37, 228, 1, 0, 0),
(0, 13, 40, 335, 1, 0, 0),
(0, 13, 40, 107, 64, 0, 0),
(0, 13, 40, 255, 5, 0, 0),
(0, 13, 40, 358, 4, 0, 0),
(0, 13, 40, 268, 1, 0, 0),
(0, 13, 40, 175, 3, 0, 0),
(0, 13, 40, 362, 4, 0, 0),
(0, 13, 40, 364, 33, 0, 0),
(0, 13, 40, 365, 1, 0, 0),
(0, 13, 40, 224, 22, 0, 0),
(0, 13, 40, 226, 1, 0, 0),
(0, 13, 40, 369, 4, 0, 0),
(0, 13, 40, 366, 1, 0, 0),
(0, 13, 40, 367, 1, 0, 0),
(0, 13, 40, 373, 2, 0, 0),
(0, 13, 40, 128, 1, 0, 0),
(0, 13, 40, 204, 4, 0, 0),
(0, 13, 40, 212, 2, 0, 0),
(0, 13, 40, 222, 8, 0, 0),
(0, 13, 40, 334, 1, 0, 0),
(0, 13, 40, 205, 2, 0, 0),
(0, 13, 40, 228, 1, 0, 0),
(0, 13, 41, 194, 3, 0, 0),
(0, 13, 41, 335, 2, 0, 0),
(0, 13, 41, 107, 50, 0, 0),
(0, 13, 41, 255, 19, 0, 0),
(0, 13, 41, 355, 1, 0, 0),
(0, 13, 41, 358, 1, 0, 0),
(0, 13, 41, 268, 1, 0, 0),
(0, 13, 41, 353, 1, 0, 0),
(0, 13, 41, 197, 1, 0, 0),
(0, 13, 41, 174, 1, 0, 0),
(0, 13, 41, 175, 6, 0, 0),
(0, 13, 41, 176, 12, 0, 0),
(0, 13, 41, 177, 1, 0, 0),
(0, 13, 41, 189, 2, 0, 0),
(0, 13, 41, 362, 9, 0, 0),
(0, 13, 41, 363, 1, 0, 0),
(0, 13, 41, 364, 23, 0, 0),
(0, 13, 41, 365, 2, 0, 0),
(0, 13, 41, 224, 17, 0, 0),
(0, 13, 41, 226, 2, 0, 0),
(0, 13, 41, 368, 3, 0, 0),
(0, 13, 41, 367, 1, 0, 0),
(0, 13, 41, 373, 1, 0, 0),
(0, 13, 41, 180, 1, 0, 0),
(0, 13, 41, 332, 2, 0, 0),
(0, 13, 41, 128, 2, 0, 0),
(0, 13, 41, 351, 1, 0, 0),
(0, 13, 41, 129, 6, 0, 0),
(0, 13, 41, 204, 2, 0, 0),
(0, 13, 41, 212, 2, 0, 0),
(0, 13, 41, 334, 1, 0, 0),
(0, 13, 41, 205, 3, 0, 0),
(0, 13, 41, 228, 2, 0, 0),
(0, 13, 42, 335, 2, 0, 0),
(0, 13, 42, 107, 45, 0, 0),
(0, 13, 42, 255, 11, 0, 0),
(0, 13, 42, 358, 1, 0, 0),
(0, 13, 42, 268, 1, 0, 0),
(0, 13, 42, 203, 1, 0, 0),
(0, 13, 42, 353, 1, 0, 0),
(0, 13, 42, 197, 1, 0, 0),
(0, 13, 42, 176, 11, 0, 0),
(0, 13, 42, 364, 15, 0, 0),
(0, 13, 42, 365, 1, 0, 0),
(0, 13, 42, 224, 6, 0, 0),
(0, 13, 42, 226, 1, 0, 0),
(0, 13, 42, 292, 2, 0, 0),
(0, 13, 42, 368, 3, 0, 0),
(0, 13, 42, 380, 1, 0, 0),
(0, 13, 42, 202, 2, 0, 0),
(0, 13, 42, 180, 3, 0, 0),
(0, 13, 42, 127, 2, 0, 0),
(0, 13, 42, 128, 2, 0, 0),
(0, 13, 42, 351, 1, 0, 0),
(0, 13, 42, 129, 4, 0, 0),
(0, 13, 42, 204, 3, 0, 0),
(0, 13, 42, 222, 4, 0, 0),
(0, 13, 46, 107, 2, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `cafehappy4_tracking_customer`
--

CREATE TABLE IF NOT EXISTS `cafehappy4_tracking_customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_tracking` int(11) NOT NULL,
  `id_customer` int(11) NOT NULL,
  `value_session1` int(11) NOT NULL,
  `value_session2` int(11) NOT NULL,
  `value_collect` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `cafehappy4_tracking_customer`
--


-- --------------------------------------------------------

--
-- Table structure for table `cafehappy4_tracking_daily`
--

CREATE TABLE IF NOT EXISTS `cafehappy4_tracking_daily` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_tracking` int(11) NOT NULL,
  `date` date NOT NULL,
  `selling` bigint(20) NOT NULL,
  `import` bigint(20) NOT NULL,
  `store` bigint(20) NOT NULL,
  `paid` bigint(20) NOT NULL,
  `collect` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=119 ;

--
-- Dumping data for table `cafehappy4_tracking_daily`
--

INSERT INTO `cafehappy4_tracking_daily` (`id`, `id_tracking`, `date`, `selling`, `import`, `store`, `paid`, `collect`) VALUES
(1, 12, '2013-12-01', 0, 0, 0, 0, 0),
(2, 12, '2013-12-02', 0, 0, 0, 0, 0),
(3, 12, '2013-12-03', 0, 0, 0, 0, 0),
(4, 12, '2013-12-04', 0, 0, 0, 0, 0),
(5, 12, '2013-12-05', 0, 0, 0, 0, 0),
(6, 12, '2013-12-06', 390000, 320000, 146000, 0, 2000000),
(7, 12, '2013-12-07', 0, 0, 0, 0, 0),
(8, 12, '2013-12-08', 0, 0, 0, 0, 0),
(9, 12, '2013-12-09', 0, 0, 0, 0, 0),
(10, 12, '2013-12-10', 0, 0, 0, 0, 0),
(11, 12, '2013-12-11', 0, 0, 0, 0, 0),
(12, 12, '2013-12-12', 0, 0, 0, 0, 0),
(13, 12, '2013-12-13', 0, 0, 0, 0, 0),
(14, 12, '2013-12-14', 0, 0, 0, 0, 0),
(15, 12, '2013-12-15', 0, 0, 0, 0, 0),
(16, 12, '2013-12-16', 0, 0, 0, 0, 0),
(17, 12, '2013-12-17', 0, 0, 0, 0, 0),
(18, 12, '2013-12-18', 0, 0, 0, 0, 0),
(19, 12, '2013-12-19', 0, 0, 0, 0, 0),
(20, 12, '2013-12-20', 0, 0, 0, 0, 0),
(21, 12, '2013-12-21', 0, 0, 0, 0, 0),
(22, 12, '2013-12-22', 0, 0, 0, 0, 0),
(23, 12, '2013-12-23', 0, 0, 0, 0, 0),
(24, 12, '2013-12-24', 0, 0, 0, 0, 0),
(25, 12, '2013-12-25', 0, 0, 0, 0, 0),
(26, 12, '2013-12-26', 0, 0, 0, 0, 0),
(27, 12, '2013-12-27', 0, 0, 0, 0, 0),
(28, 12, '2013-12-28', 0, 0, 0, 0, 0),
(29, 12, '2013-12-29', 0, 0, 146000, 0, 0),
(30, 12, '2013-12-30', 0, 0, 146000, 0, 0),
(31, 12, '2013-12-31', 0, 0, 146000, 0, 0),
(32, 13, '2014-01-01', 0, 45000, 0, 0, 0),
(33, 13, '2014-01-02', 0, 120000, 0, 0, 0),
(34, 13, '2014-01-03', 0, 30000, 0, 0, 0),
(35, 13, '2014-01-04', 26000, 0, 0, 0, 0),
(36, 13, '2014-01-05', 940000, 0, 0, 0, 0),
(37, 13, '2014-01-06', 2027000, 155000, 0, 85000, 0),
(38, 13, '2014-01-07', 1512000, 0, 0, 0, 0),
(39, 13, '2014-01-08', 1814000, 0, 0, 442000, 1500000),
(40, 13, '2014-01-09', 1138000, 0, 0, 207000, 2321000),
(41, 13, '2014-01-10', 1509000, 0, 0, 570000, 2317000),
(42, 13, '2014-01-11', 1057000, 0, 0, 128000, 3096000),
(43, 13, '2014-01-12', 1213000, 0, 0, 0, 0),
(44, 13, '2014-01-13', 1247000, 0, 0, 0, 0),
(45, 13, '2014-01-14', 322000, 0, 0, 0, 0),
(46, 13, '2014-01-15', 16000, 0, 0, 0, 0),
(47, 13, '2014-01-16', 0, 0, 0, 0, 0),
(48, 13, '2014-01-17', 0, 0, 0, 0, 0),
(49, 13, '2014-01-18', 0, 0, 0, 0, 0),
(50, 13, '2014-01-19', 0, 0, 0, 0, 0),
(51, 13, '2014-01-20', 0, 0, 0, 0, 0),
(52, 13, '2014-01-21', 0, 0, 0, 0, 0),
(53, 13, '2014-01-22', 0, 0, 0, 0, 0),
(54, 13, '2014-01-23', 0, 0, 0, 0, 0),
(55, 13, '2014-01-24', 0, 0, 0, 0, 0),
(56, 13, '2014-01-25', 0, 0, 0, 0, 0),
(57, 13, '2014-01-26', 0, 0, 0, 0, 0),
(58, 13, '2014-01-27', 0, 0, 0, 0, 0),
(59, 13, '2014-01-28', 0, 0, 0, 0, 0),
(60, 13, '2014-01-29', 0, 0, 0, 0, 0),
(61, 13, '2014-01-30', 0, 0, 0, 0, 0),
(62, 13, '2014-01-31', 0, 0, 0, 0, 0),
(63, 14, '2014-02-01', 0, 0, 0, 0, 0),
(64, 14, '2014-02-02', 0, 0, 0, 0, 0),
(65, 14, '2014-02-03', 0, 0, 0, 0, 0),
(66, 14, '2014-02-04', 0, 0, 0, 0, 0),
(67, 14, '2014-02-05', 0, 0, 0, 0, 0),
(68, 14, '2014-02-06', 0, 0, 0, 0, 0),
(69, 14, '2014-02-07', 0, 0, 0, 0, 0),
(70, 14, '2014-02-08', 0, 0, 0, 0, 0),
(71, 14, '2014-02-09', 0, 0, 0, 0, 0),
(72, 14, '2014-02-10', 0, 0, 0, 0, 0),
(73, 14, '2014-02-11', 0, 0, 0, 0, 0),
(74, 14, '2014-02-12', 0, 0, 0, 0, 0),
(75, 14, '2014-02-13', 0, 0, 0, 0, 0),
(76, 14, '2014-02-14', 0, 0, 0, 0, 0),
(77, 14, '2014-02-15', 0, 0, 0, 0, 0),
(78, 14, '2014-02-16', 0, 0, 0, 0, 0),
(79, 14, '2014-02-17', 0, 0, 0, 0, 0),
(80, 14, '2014-02-18', 0, 0, 0, 0, 0),
(81, 14, '2014-02-19', 0, 0, 0, 0, 0),
(82, 14, '2014-02-20', 0, 0, 0, 0, 0),
(83, 14, '2014-02-21', 0, 0, 0, 0, 0),
(84, 14, '2014-02-22', 0, 0, 0, 0, 0),
(85, 14, '2014-02-23', 0, 0, 0, 0, 0),
(86, 14, '2014-02-24', 0, 0, 0, 0, 0),
(87, 14, '2014-02-25', 0, 0, 0, 0, 0),
(88, 14, '2014-02-26', 0, 0, 0, 0, 0),
(89, 14, '2014-02-27', 0, 0, 0, 0, 0),
(90, 14, '2014-02-28', 0, 0, 0, 0, 0),
(91, 15, '2014-02-01', 0, 0, 0, 0, 0),
(92, 15, '2014-02-02', 0, 0, 0, 0, 0),
(93, 15, '2014-02-03', 0, 0, 0, 0, 0),
(94, 15, '2014-02-04', 0, 0, 0, 0, 0),
(95, 15, '2014-02-05', 0, 0, 0, 0, 0),
(96, 15, '2014-02-06', 0, 0, 0, 0, 0),
(97, 15, '2014-02-07', 0, 0, 0, 0, 0),
(98, 15, '2014-02-08', 0, 0, 0, 0, 0),
(99, 15, '2014-02-09', 0, 0, 0, 0, 0),
(100, 15, '2014-02-10', 0, 0, 0, 0, 0),
(101, 15, '2014-02-11', 0, 0, 0, 0, 0),
(102, 15, '2014-02-12', 0, 0, 0, 0, 0),
(103, 15, '2014-02-13', 0, 0, 0, 0, 0),
(104, 15, '2014-02-14', 0, 0, 0, 0, 0),
(105, 15, '2014-02-15', 0, 0, 0, 0, 0),
(106, 15, '2014-02-16', 0, 0, 0, 0, 0),
(107, 15, '2014-02-17', 0, 0, 0, 0, 0),
(108, 15, '2014-02-18', 0, 0, 0, 0, 0),
(109, 15, '2014-02-19', 0, 0, 0, 0, 0),
(110, 15, '2014-02-20', 0, 0, 0, 0, 0),
(111, 15, '2014-02-21', 0, 0, 0, 0, 0),
(112, 15, '2014-02-22', 0, 0, 0, 0, 0),
(113, 15, '2014-02-23', 0, 0, 0, 0, 0),
(114, 15, '2014-02-24', 0, 0, 0, 0, 0),
(115, 15, '2014-02-25', 0, 0, 0, 0, 0),
(116, 15, '2014-02-26', 0, 0, 0, 0, 0),
(117, 15, '2014-02-27', 0, 0, 0, 0, 0),
(118, 15, '2014-02-28', 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `cafehappy4_tracking_store`
--

CREATE TABLE IF NOT EXISTS `cafehappy4_tracking_store` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_tracking` int(11) NOT NULL,
  `id_td` int(11) NOT NULL,
  `id_resource` int(11) NOT NULL,
  `count_old` float NOT NULL,
  `count_import` float NOT NULL,
  `count_export` float NOT NULL,
  `price` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1723 ;

--
-- Dumping data for table `cafehappy4_tracking_store`
--

INSERT INTO `cafehappy4_tracking_store` (`id`, `id_tracking`, `id_td`, `id_resource`, `count_old`, `count_import`, `count_export`, `price`) VALUES
(1707, 12, 6, 19, 0, 2, 0.9, 60000),
(1708, 12, 6, 20, 0, 1, 0, 80000),
(1709, 12, 6, 35, 0, 0, 0, 160000),
(1710, 12, 6, 36, 0, 0, 0, 185000),
(1711, 12, 30, 19, 1.1, 0, 0, 60000),
(1712, 12, 30, 20, 1, 0, 0, 80000),
(1713, 12, 30, 35, 0, 0, 0, 160000),
(1714, 12, 30, 36, 0, 0, 0, 185000),
(1715, 12, 29, 19, 1.1, 0, 0, 60000),
(1716, 12, 29, 20, 1, 0, 0, 80000),
(1717, 12, 29, 35, 0, 0, 0, 160000),
(1718, 12, 29, 36, 0, 0, 0, 185000),
(1719, 12, 31, 19, 1.1, 0, 0, 60000),
(1720, 12, 31, 20, 1, 0, 0, 80000),
(1721, 12, 31, 35, 0, 0, 0, 160000),
(1722, 12, 31, 36, 0, 0, 0, 185000);

-- --------------------------------------------------------

--
-- Table structure for table `cafehappy4_unit`
--

CREATE TABLE IF NOT EXISTS `cafehappy4_unit` (
  `id` int(25) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=29 ;

--
-- Dumping data for table `cafehappy4_unit`
--

INSERT INTO `cafehappy4_unit` (`id`, `name`) VALUES
(1, 'Ly'),
(2, 'Điếu'),
(3, 'Chai'),
(4, 'Lon'),
(5, 'Dĩa'),
(6, 'Thùng'),
(7, 'Két'),
(9, 'Bịch'),
(10, 'Gói'),
(20, 'Trái'),
(21, 'Cái'),
(22, 'Hủ'),
(23, 'Kg'),
(24, 'Phần'),
(25, 'Bàn'),
(26, 'Hộp'),
(27, 'Bao'),
(28, 'Cây');

-- --------------------------------------------------------

--
-- Table structure for table `cafehappy4_user`
--

CREATE TABLE IF NOT EXISTS `cafehappy4_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pass` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gender` int(11) NOT NULL,
  `note` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `datecreate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dateupdate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `dateactivity` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `type` tinyint(4) NOT NULL,
  `code` varchar(13) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

--
-- Dumping data for table `cafehappy4_user`
--

INSERT INTO `cafehappy4_user` (`id`, `name`, `email`, `pass`, `gender`, `note`, `datecreate`, `dateupdate`, `dateactivity`, `type`, `code`) VALUES
(3, 'Thanh Tân', 'tsontung@yahoo.com', '123456', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 2, ''),
(4, 'Quan Ly', 'tuanbuithanh@gmail.com', '123456', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 4, '');

-- --------------------------------------------------------

--
-- Table structure for table `cafepassion_category`
--

CREATE TABLE IF NOT EXISTS `cafepassion_category` (
  `id` int(25) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `picture` binary(255) DEFAULT NULL,
  `enable` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=24 ;

--
-- Dumping data for table `cafepassion_category`
--

INSERT INTO `cafepassion_category` (`id`, `name`, `picture`, `enable`) VALUES
(3, 'Cafe', '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0', 1),
(8, 'Sinh tố', NULL, 0),
(11, 'Nước ép', NULL, 0),
(12, 'Kem', '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0', 1),
(13, 'Yaourt', NULL, 0),
(14, 'Nước giải khát', NULL, 0),
(15, 'Nước pha chế', NULL, 0),
(16, 'Lipton - Trà', '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0', 1),
(17, 'Rau má - Sữa', NULL, 0),
(20, 'Thuốc lá', NULL, 0),
(21, 'Điểm tâm sáng', '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0', 1),
(22, 'Cơm trưa VP', '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0', 1),
(23, 'Khác', '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0', 1);

-- --------------------------------------------------------

--
-- Table structure for table `cafepassion_collect_customer`
--

CREATE TABLE IF NOT EXISTS `cafepassion_collect_customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idcustomer` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cafepassion_customer_collect_1` (`idcustomer`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `cafepassion_collect_customer`
--


-- --------------------------------------------------------

--
-- Table structure for table `cafepassion_collect_general`
--

CREATE TABLE IF NOT EXISTS `cafepassion_collect_general` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_term` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cafepassion_collect_1` (`id_term`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=12 ;

--
-- Dumping data for table `cafepassion_collect_general`
--

INSERT INTO `cafepassion_collect_general` (`id`, `id_term`, `date`, `value`, `note`) VALUES
(5, 2, '2013-05-18', 10, 'd'),
(6, 3, '2013-12-06', 2000000, 'Bổ sung quỹ'),
(7, 3, '2014-01-08', 1500000, 'Bổng sung quỹ (a. Thông)'),
(8, 3, '2014-01-09', 2321000, 'Quy kho 09.01.2014'),
(9, 3, '2014-01-10', 2272000, 'quỹ kho 10-01-2014'),
(10, 3, '2014-01-10', 45000, 'bán chai nhựa'),
(11, 3, '2014-01-11', 3096000, 'quỹ 11-01-2014');

-- --------------------------------------------------------

--
-- Table structure for table `cafepassion_config`
--

CREATE TABLE IF NOT EXISTS `cafepassion_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `param` varchar(125) COLLATE utf8_unicode_ci NOT NULL,
  `value` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=15 ;

--
-- Dumping data for table `cafepassion_config`
--

INSERT INTO `cafepassion_config` (`id`, `param`, `value`) VALUES
(5, 'DISCOUNT', '0'),
(6, 'ROW_PER_PAGE', '12'),
(7, 'GUEST_VISIT', '9247'),
(8, 'EVERY_5_MINUTES', '2000'),
(9, 'THEME', 'light-blue'),
(10, 'CATEGORY_AUTO', '3'),
(11, 'SWITCH_BOARD_CALL', '1'),
(12, 'RECEIPT_VIRTUAL_DOUBLE', '1'),
(13, 'CATEGORY_AUTO', '3'),
(14, 'CATEGORY_AUTO', '3');

-- --------------------------------------------------------

--
-- Table structure for table `cafepassion_course`
--

CREATE TABLE IF NOT EXISTS `cafepassion_course` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idcategory` int(25) DEFAULT NULL,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `shortname` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `unit` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `price1` bigint(20) NOT NULL,
  `price2` bigint(20) NOT NULL,
  `price3` bigint(20) NOT NULL,
  `price4` bigint(20) NOT NULL,
  `picture` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_discount` int(11) NOT NULL DEFAULT '1',
  `enable` int(11) NOT NULL,
  `prepare` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `foreign_field` (`idcategory`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=332 ;

--
-- Dumping data for table `cafepassion_course`
--

INSERT INTO `cafepassion_course` (`id`, `idcategory`, `name`, `shortname`, `unit`, `price1`, `price2`, `price3`, `price4`, `picture`, `is_discount`, `enable`, `prepare`) VALUES
(53, 8, 'Sinh tố bơ', 'Sinh tố bơ', 'Ly', 25000, 25000, 25000, 25000, '', 1, 0, 0),
(54, 8, 'Sinh tố cà chua', 'Sinh tố cà chua', 'Ly', 18000, 18000, 18000, 18000, '', 1, 0, 0),
(55, 8, 'Sinh tố cà rốt', 'Sinh tố cà rốt', 'Ly', 18000, 18000, 18000, 18000, '', 1, 0, 0),
(56, 8, 'Sinh tố cam', 'Sinh tố cam', 'Ly', 20000, 20000, 20000, 20000, '', 1, 0, 0),
(107, 3, 'Cafe đá', 'Cafe đá', 'Ly', 10000, 10000, 10000, 10000, '', 1, 1, 0),
(108, 3, 'Cafe nóng', 'Cafe nóng', 'Ly', 10000, 10000, 10000, 10000, '', 1, 1, 0),
(110, 12, 'Kem 3 viên', 'Kem 3 viên', 'Ly', 26000, 26000, 26000, 26000, '', 1, 0, 0),
(111, 3, 'Cafe sữa đá', 'Cafe sữa đá', 'Ly', 15000, 15000, 15000, 15000, '', 1, 1, 0),
(112, 3, 'Cafe sữa nóng', 'Cafe sữa nóng', 'Ly', 14000, 14000, 14000, 14000, '', 1, 0, 0),
(117, 12, 'Kem cafe', 'Kem cafe', 'Ly', 24000, 24000, 24000, 24000, '', 1, 0, 0),
(118, 12, 'Kem dâu', 'Kem dâu', 'Ly', 22000, 22000, 22000, 22000, '', 1, 0, 0),
(119, 12, 'Kem sầu riêng', 'Kem sầu riêng', 'Ly', 22000, 22000, 22000, 22000, '', 1, 0, 0),
(120, 12, 'Kem chocolate', 'Kem chocolate', 'Ly', 22000, 22000, 22000, 22000, '', 1, 0, 0),
(121, 12, 'Kem thập cẩm', 'Kem thập cẩm', 'Ly', 27000, 27000, 27000, 27000, '', 1, 0, 0),
(122, 12, 'Kem trái dừa', 'Kem trái dừa', 'Ly', 30000, 30000, 30000, 30000, '', 1, 0, 0),
(126, 8, 'Sinh tố chanh', 'Sinh tố chanh', 'Ly', 18000, 18000, 18000, 18000, '', 1, 0, 0),
(127, 8, 'Sinh tố dâu', 'Sinh tố dâu', 'Ly', 24000, 24000, 24000, 24000, '', 1, 0, 0),
(128, 8, 'Sinh tố mãng cầu', 'Sinh tố mãng cầu', 'Ly', 20000, 20000, 20000, 20000, '', 1, 0, 0),
(129, 8, 'Sinh tố sapô', 'Sinh tố sapô', 'Ly', 20000, 20000, 20000, 20000, '', 1, 0, 0),
(136, 8, 'Sinh tố thập cẩm', 'Sinh tố thập cẩm', 'Ly', 20000, 20000, 20000, 20000, '', 1, 0, 0),
(149, 13, 'Yaourt cam tươi', 'Yaourt cam tươi', 'Ly', 20000, 20000, 20000, 20000, '', 1, 0, 0),
(161, 13, 'Yaourt dâu', 'Yaourt dâu', 'Ly', 25000, 25000, 25000, 25000, '', 1, 0, 0),
(162, 13, 'Yaourt hủ', 'Yaourt hủ', 'Hủ', 10000, 10000, 10000, 10000, '', 1, 0, 0),
(174, 15, 'Dừa đá', 'Dừa đá', 'Ly', 16000, 16000, 16000, 16000, '', 1, 0, 0),
(175, 15, 'Dừa trái', 'Dừa trái', 'Trái', 15000, 15000, 15000, 15000, '', 1, 0, 0),
(176, 15, 'Đá me', 'Đá me', 'Ly', 13000, 13000, 13000, 13000, '', 1, 0, 0),
(177, 15, 'Đá me sữa', 'Đá me sữa', 'Ly', 15000, 15000, 15000, 15000, '', 1, 0, 0),
(178, 15, 'Rau má dừa', 'Rau má dừa', 'Ly', 16000, 16000, 16000, 16000, '', 1, 0, 0),
(179, 15, 'Rau má sữa', 'Rau má sữa', 'Ly', 16000, 16000, 16000, 16000, '', 1, 0, 0),
(180, 15, 'Rau má thường', 'Rau má thường', 'Ly', 14000, 14000, 14000, 14000, '', 1, 0, 0),
(181, 15, 'Tắc xí muội nóng', 'Tắc xí muội nóng', 'Ly', 14000, 14000, 14000, 14000, '', 1, 0, 0),
(182, 15, 'Chanh xí muội nóng', 'Chanh xí muội nóng', 'Ly', 14000, 14000, 14000, 14000, '', 1, 0, 0),
(183, 15, 'Xí muội đá', 'Xí muội đá', 'Ly', 15000, 15000, 15000, 15000, '', 1, 0, 0),
(184, 15, 'Sâm dứa', 'Sâm dứa', 'Ly', 13000, 13000, 13000, 13000, '', 1, 0, 0),
(185, 15, 'Sâm dứa sữa', 'Sâm dứa sữa', 'Ly', 15000, 15000, 15000, 15000, '', 1, 0, 0),
(187, 11, 'Ép cà chua', 'Ép cà chua', 'Ly', 18000, 18000, 18000, 18000, '', 1, 0, 0),
(188, 11, 'Ép carrot', 'Ép carrot', 'Ly', 18000, 18000, 18000, 18000, '', 1, 0, 0),
(189, 11, 'Ép cam', 'Ép cam', 'Ly', 18000, 18000, 18000, 18000, '', 1, 0, 0),
(190, 11, 'Ép dâu', 'Ép dâu', 'Ly', 25000, 25000, 25000, 25000, '', 1, 0, 0),
(191, 11, 'Ép lê', 'Ép lê', 'Ly', 20000, 20000, 20000, 20000, '', 1, 0, 0),
(192, 11, 'Ép táo', 'Ép táo', 'Ly', 20000, 20000, 20000, 20000, '', 1, 0, 0),
(193, 11, 'Ép thơm', 'Ép thơm', 'Ly', 18000, 18000, 18000, 18000, '', 1, 0, 0),
(194, 14, '7 up', '7 up', 'Chai', 15000, 15000, 15000, 15000, '', 1, 0, 0),
(196, 14, 'Cam Twister', 'Cam Twister', 'Chai', 14000, 14000, 14000, 14000, '', 1, 0, 0),
(197, 14, 'Dr Thanh', 'Dr Thanh', 'Chai', 16000, 16000, 16000, 16000, '', 1, 0, 0),
(198, 14, 'Đậu nành', 'Đậu nành', 'Chai', 12000, 12000, 12000, 12000, '', 1, 0, 0),
(199, 14, 'Sting dâu sữa', 'Sting dâu sữa', 'Chai', 16000, 16000, 16000, 16000, '', 1, 0, 0),
(200, 14, 'Nước tăng lực', 'Nước tăng lực', 'Chai', 16000, 16000, 16000, 16000, '', 1, 0, 0),
(201, 14, 'Nước suối', 'Nước suối', 'Chai', 12000, 12000, 12000, 12000, '', 1, 0, 0),
(202, 14, 'Pepsi', 'Pepsi', 'Chai', 15000, 15000, 15000, 15000, '', 1, 0, 0),
(203, 14, 'Coca cola', 'Coca cola', 'Chai', 15000, 15000, 15000, 15000, '', 1, 0, 0),
(204, 14, 'Sting dâu', 'Sting dâu', 'Chai', 13000, 13000, 13000, 13000, '', 1, 0, 0),
(205, 14, 'Trà xanh 0 độ', 'Trà xanh 0 độ', 'Chai', 15000, 15000, 15000, 15000, '', 1, 0, 0),
(206, 17, 'Rau má dừa', 'Rau má dừa', 'Ly', 15000, 15000, 15000, 15000, '', 1, 0, 0),
(207, 17, 'Rau má sữa', 'Rau má sữa', 'Ly', 15000, 15000, 15000, 15000, '', 1, 0, 0),
(208, 17, 'Sữa dâu tươi', 'Sữa dâu tươi', 'Ly', 20000, 20000, 20000, 20000, '', 1, 0, 0),
(209, 17, 'Sữa nóng', 'Sữa nóng', 'Ly', 10000, 10000, 10000, 10000, '', 1, 0, 0),
(210, 17, 'Sữa thêm', 'Sữa thêm', 'Ly', 5000, 5000, 5000, 5000, '', 1, 0, 0),
(211, 17, 'Sữa đá', 'Sữa đá', 'Ly', 12000, 12000, 12000, 12000, '', 1, 0, 0),
(212, 17, 'Sữa tươi', 'Sữa tươi', 'Ly', 12000, 12000, 12000, 12000, '', 1, 0, 0),
(213, 20, '555 1/2 gói', '555 1/2 gói', 'Gói', 18000, 18000, 18000, 18000, '', 0, 0, 0),
(214, 20, '555 điếu', '555 điếu', 'Điếu', 2000, 2000, 2000, 2000, '0', 0, 0, 0),
(215, 20, 'Mèo lớn', 'Mèo lớn', 'Gói', 25000, 25000, 25000, 25000, '', 0, 0, 0),
(216, 20, 'Mèo điếu', 'Mèo điếu', 'Điếu', 1500, 1500, 1500, 1500, '0', 0, 0, 0),
(217, 20, 'Mèo tép', 'Mèo tép', 'Gói', 7000, 7000, 7000, 7000, '0', 0, 0, 0),
(218, 16, 'Lipton sữa đá', 'Lipton sữa đá', 'Ly', 15000, 15000, 15000, 15000, '', 1, 0, 0),
(219, 16, 'Lipton sữa nóng', 'Lipton sữa nóng', 'Ly', 13000, 13000, 13000, 13000, '', 1, 0, 0),
(220, 16, 'Trà sữa', 'Trà sữa', 'Ly', 15000, 15000, 15000, 15000, '', 1, 0, 0),
(221, 16, 'Trà chanh', 'Trà chanh', 'Ly', 12000, 12000, 12000, 12000, '', 1, 0, 0),
(222, 16, 'Trà đường đá', 'Trà đường đá', 'Ly', 10000, 10000, 10000, 10000, '', 1, 0, 0),
(223, 16, 'Trà đường nóng', 'Trà đường nóng', 'Ly', 8000, 8000, 8000, 8000, '', 1, 0, 0),
(224, 16, 'Lipton đá', 'Lipton đá', 'Ly', 12000, 12000, 12000, 12000, '', 1, 0, 0),
(225, 16, 'Lipton mật ong nóng', 'Lipton mật ong nóng', 'Ly', 13000, 13000, 13000, 13000, '', 1, 0, 0),
(226, 16, 'Lipton nóng', 'Lipton nóng', 'Ly', 10000, 10000, 10000, 10000, '', 1, 0, 0),
(228, 13, 'Yaourt sữa đá', 'Yaourt sữa đá', 'Ly', 15000, 15000, 15000, 15000, '', 1, 0, 0),
(229, 13, 'Yaourt trái cây', 'Yaourt trái cây', 'Ly', 25000, 25000, 25000, 25000, '', 1, 0, 0),
(230, 21, 'Bò bít tết trứng', 'Bò bít tết trứng', 'Phần', 30000, 30000, 30000, 30000, '0', 0, 0, 0),
(231, 21, 'Bò bít tết ko trứng', 'Bò bít tết ko trứng', 'Phần', 25000, 25000, 25000, 25000, '0', 0, 0, 0),
(232, 21, 'Mỳ Ý', 'Mỳ Ý', 'Phần', 25000, 25000, 25000, 25000, '0', 0, 0, 0),
(233, 21, 'Bánh mì ốp la chả', 'Bánh mì ốp la chả', 'Phần', 20000, 20000, 20000, 20000, '0', 0, 0, 0),
(234, 21, 'Bánh mì ốp la', 'Bánh mì ốp la', 'Phần', 15000, 15000, 15000, 15000, '0', 0, 0, 0),
(235, 21, 'Mì gói xào bò', 'Mì gói xào bò', 'Phần', 20000, 20000, 20000, 20000, '', 0, 0, 0),
(236, 21, 'Nui xào bò', 'Nui xào bò', 'Phần', 20000, 20000, 20000, 20000, '', 0, 0, 0),
(237, 21, 'Mì gói nấu bò', 'Mì gói nấu bò', 'Phần', 20000, 20000, 20000, 20000, '', 0, 0, 0),
(238, 21, 'Trứng thêm', 'Trứng thêm', 'Cái', 5000, 5000, 5000, 5000, '', 0, 0, 0),
(239, 21, 'Mì gói thêm', 'Mì gói thêm', 'Gói', 5000, 5000, 5000, 5000, '', 0, 0, 0),
(240, 21, 'Bánh mì thêm', 'Bánh mì thêm', 'Cái', 5000, 5000, 5000, 5000, '', 0, 0, 0),
(241, 22, 'Cơm gà kho', 'Cơm gà kho', 'Phần', 22000, 22000, 22000, 22000, '', 0, 0, 0),
(242, 22, 'Cơm cá kho tộ', 'Cơm cá kho tộ', 'Phần', 22000, 22000, 22000, 22000, '', 0, 0, 0),
(243, 22, 'Cơm tép ram', 'Cơm tép ram', 'Phần', 22000, 22000, 22000, 22000, '', 0, 0, 0),
(244, 22, 'Cơm sườn ram', 'Cơm sườn ram', 'Phần', 22000, 22000, 22000, 22000, '', 0, 0, 0),
(245, 22, 'Cơm cánh gà chiên', 'Cơm cánh gà chiên', 'Phần', 22000, 22000, 22000, 22000, '', 0, 0, 0),
(246, 16, 'Lipton mật ong đá', 'Lipton mật ong đá', 'Ly', 15000, 15000, 15000, 15000, '', 1, 0, 0),
(247, 16, 'Lipton xí muội nóng', 'Lipton xí muội nóng', 'Ly', 13000, 13000, 13000, 13000, '', 1, 0, 0),
(248, 16, 'Lipton xí muội đá', 'Lipton xí muội đá', 'Ly', 15000, 15000, 15000, 15000, '', 1, 0, 0),
(249, 16, 'Lipton bạc hà', 'Lipton bạc hà', 'Ly', 15000, 15000, 15000, 15000, '', 1, 0, 0),
(250, 16, 'Lipton cam', 'Lipton cam', 'Ly', 18000, 18000, 18000, 18000, '', 1, 0, 0),
(251, 16, 'Lipton 3 tầng', 'Lipton 3 tầng', 'Ly', 18000, 18000, 18000, 18000, '', 1, 0, 0),
(252, 16, 'Trà cúc nóng', 'Trà cúc nóng', 'Ly', 10000, 10000, 10000, 10000, '', 1, 0, 0),
(253, 16, 'Trà cúc đá', 'Trà cúc đá', 'Ly', 12000, 12000, 12000, 12000, '', 1, 0, 0),
(254, 3, 'Bạc xỉu nóng', 'Bạc xỉu nóng', 'Ly', 14000, 14000, 14000, 14000, '', 1, 0, 0),
(255, 3, 'Bạc xỉu đá', 'Bạc xỉu đá', 'Ly', 15000, 15000, 15000, 15000, '', 1, 0, 0),
(256, 3, 'Cafe Kem', 'Cafe Kem', 'Ly', 22000, 22000, 22000, 22000, '', 1, 0, 0),
(257, 3, 'Cafe Rhum', 'Cafe Rhum', 'Ly', 20000, 20000, 20000, 20000, '', 1, 0, 0),
(258, 3, 'Cafe Baileys', 'Cafe Baileys', 'Ly', 26000, 26000, 26000, 26000, '', 1, 0, 0),
(259, 3, 'Cafe sữa Baileys', 'Cafe sữa Baileys', 'Ly', 28000, 28000, 28000, 28000, '', 1, 0, 0),
(260, 3, 'Cafe Đam mê', 'Cafe Đam mê', 'Ly', 28000, 28000, 28000, 28000, '', 1, 0, 0),
(261, 3, 'Cacao nóng', 'Cacao nóng', 'Ly', 14000, 14000, 14000, 14000, '', 1, 0, 0),
(262, 3, 'Cacao đá', 'Cacao đá', 'Ly', 15000, 15000, 15000, 15000, '', 1, 0, 0),
(263, 3, 'Cacao sữa nóng', 'Cacao sữa nóng', 'Ly', 15000, 15000, 15000, 15000, '', 1, 0, 0),
(264, 3, 'Cacao sữa đá', 'Cacao sữa đá', 'Ly', 17000, 17000, 17000, 17000, '', 1, 0, 0),
(265, 15, 'Chanh nóng', 'Chanh nóng', 'Ly', 10000, 10000, 10000, 10000, '', 1, 0, 0),
(266, 15, 'Chanh đá', 'Chanh đá', 'Ly', 12000, 12000, 12000, 12000, '', 1, 0, 0),
(267, 15, 'Chanh muối nóng', 'Chanh muối nóng', 'Ly', 10000, 10000, 10000, 10000, '', 1, 0, 0),
(268, 15, 'Chanh muối đá', 'Chanh muối đá', 'Ly', 12000, 12000, 12000, 12000, '', 1, 0, 0),
(269, 15, 'Chanh rhum', 'Chanh rhum', 'Ly', 15000, 15000, 15000, 15000, '', 1, 0, 0),
(270, 15, 'Xí muội nóng', 'Xí muội nóng', 'Ly', 14000, 14000, 14000, 14000, '', 1, 0, 0),
(271, 15, 'Chanh xí muội đá', 'Chanh xí muội đá', 'Ly', 15000, 15000, 15000, 15000, '', 1, 0, 0),
(272, 15, 'Chanh muối xí muội', 'Chanh muối xí muội', 'Ly', 15000, 15000, 15000, 15000, '', 1, 0, 0),
(273, 15, 'Tắc xí muội đá', 'Tắc xí muội đá', 'Ly', 15000, 15000, 15000, 15000, '', 1, 0, 0),
(274, 15, 'Bạc hà', 'Bạc hà', 'Ly', 13000, 13000, 13000, 13000, '', 1, 0, 0),
(275, 15, 'Bạc hà sữa', 'Bạc hà sữa', 'Ly', 15000, 15000, 15000, 15000, '', 1, 0, 0),
(276, 15, 'Siro dâu', 'Siro dâu', 'Ly', 13000, 13000, 13000, 13000, '', 1, 0, 0),
(277, 15, 'Đá me xí muội', 'Đá me xí muội', 'Ly', 15000, 15000, 15000, 15000, '', 1, 0, 0),
(278, 15, 'Siro dâu sữa', 'Siro dâu sữa', 'Ly', 15000, 15000, 15000, 15000, '', 1, 0, 0),
(279, 8, 'Sinh tố chanh dây', 'Sinh tố chanh dây', 'Ly', 20000, 20000, 20000, 20000, '', 1, 0, 0),
(280, 8, 'Sinh tố Thơm', 'Sinh tố Thơm', 'Ly', 18000, 18000, 18000, 18000, '', 1, 0, 0),
(281, 8, 'Sinh tố Dừa', 'Sinh tố Dừa', 'Ly', 20000, 20000, 20000, 20000, '', 1, 0, 0),
(282, 8, 'Sinh tố Táo', 'Sinh tố Táo', 'Ly', 20000, 20000, 20000, 20000, '', 1, 0, 0),
(283, 8, 'Sinh tố Lê', 'Sinh tố Lê', 'Ly', 20000, 20000, 20000, 20000, '', 1, 0, 0),
(284, 8, 'ST rau má dừa', 'ST rau má dừa', 'Ly', 18000, 18000, 18000, 18000, '', 1, 0, 0),
(285, 8, 'Sinh tố Bưởi', 'Sinh tố Bưởi', 'Ly', 20000, 20000, 20000, 20000, '', 1, 0, 0),
(286, 8, 'Sinh tố cafe', 'Sinh tố cafe', 'Ly', 20000, 20000, 20000, 20000, '', 1, 0, 0),
(287, 8, 'ST tự chọn 2 món', 'ST tự chọn 2 món', 'Ly', 22000, 22000, 22000, 22000, '', 1, 0, 0),
(288, 8, 'ST tự chọn 3 món', 'ST tự chọn 3 món', 'Ly', 25000, 25000, 25000, 25000, '', 1, 0, 0),
(289, 8, 'ST tự chọn 4 món', 'ST tự chọn 4 món', 'Ly', 28000, 28000, 28000, 28000, '', 1, 0, 0),
(290, 8, 'ST chanh muối', 'ST chanh muối', 'Ly', 18000, 18000, 18000, 18000, '', 1, 0, 0),
(291, 8, 'Dâu dằm', 'Dâu dằm', 'Ly', 25000, 25000, 25000, 25000, '', 1, 0, 0),
(292, 8, 'Mãng cầu dằm', 'Mãng cầu dằm', 'Ly', 25000, 25000, 25000, 25000, '', 1, 0, 0),
(293, 8, 'Bơ dầm', 'Bơ dầm', 'Ly', 25000, 25000, 25000, 25000, '', 1, 0, 0),
(294, 12, 'Kem 1 viên', 'Kem 1 viên', 'Ly', 12000, 12000, 12000, 12000, '', 1, 0, 0),
(295, 12, 'Kem 2 viên', 'Kem 2 viên', 'Ly', 22000, 22000, 22000, 22000, '', 1, 0, 0),
(296, 12, 'Kem dừa', 'Kem dừa', 'Ly', 22000, 22000, 22000, 22000, '', 1, 0, 0),
(297, 12, 'Kem vani', 'Kem vani', 'Ly', 22000, 22000, 22000, 22000, '', 1, 0, 0),
(298, 12, 'Kem Khoai môn', 'Kem Khoai môn', 'Ly', 22000, 22000, 22000, 22000, '', 1, 0, 0),
(299, 12, 'Kem cacao', 'Kem cacao', 'Ly', 22000, 22000, 22000, 22000, '', 1, 0, 0),
(300, 12, 'Kem sum vầy', 'Kem sum vầy', 'Ly', 27000, 27000, 27000, 27000, '', 1, 0, 0),
(301, 12, 'Kem chủ nhật hồng', 'Kem chủ nhật hồng', 'Ly', 27000, 27000, 27000, 27000, '', 1, 0, 0),
(302, 12, 'Kem nước cam', 'Kem nước cam', 'Ly', 25000, 25000, 25000, 25000, '', 1, 0, 0),
(303, 12, 'Kem đậu xanh', 'Kem đậu xanh', 'Ly', 22000, 22000, 22000, 22000, '', 1, 0, 0),
(304, 12, 'Kem Rhum', 'Kem Rhum', 'Ly', 24000, 24000, 24000, 24000, '', 1, 0, 0),
(305, 11, 'Ép 4 mùa', 'Ép 4 mùa', 'Ly', 28000, 28000, 28000, 28000, '', 1, 0, 0),
(306, 11, 'Ép bưởi', 'Ép bưởi', 'Ly', 20000, 20000, 20000, 20000, '', 1, 0, 0),
(307, 11, 'Ép cam mật ong', 'Ép cam mật ong', 'Ly', 22000, 22000, 22000, 22000, '', 1, 0, 0),
(308, 11, 'Ép cam sữa', 'Ép cam sữa', 'Ly', 22000, 22000, 22000, 22000, '', 1, 0, 0),
(309, 11, 'Ép chanh dây', 'Ép chanh dây', 'Ly', 20000, 20000, 20000, 20000, '', 1, 0, 0),
(310, 11, 'Ép dâu sữa', 'Ép dâu sữa', 'Ly', 26000, 26000, 26000, 26000, '', 1, 0, 0),
(311, 11, 'Ép tự chọn 2 món', 'Ép tự chọn 2 món', 'Ly', 22000, 22000, 22000, 22000, '', 1, 0, 0),
(312, 11, 'Ép tự chọn 3 món', 'Ép tự chọn 3 món', 'Ly', 25000, 25000, 25000, 25000, '', 1, 0, 0),
(313, 13, 'Yaourt bạc hà', 'Yaourt bạc hà', 'Ly', 18000, 18000, 18000, 18000, '', 1, 0, 0),
(314, 13, 'Yaourt bưởi', 'Yaourt bưởi', 'Ly', 20000, 20000, 20000, 20000, '', 1, 0, 0),
(315, 13, 'Yaourt cafe đá', 'Yaourt cafe đá', 'Ly', 16000, 16000, 16000, 16000, '', 1, 0, 0),
(316, 13, 'Yaourt chanh dây', 'Yaourt chanh dây', 'Ly', 20000, 20000, 20000, 20000, '', 1, 0, 0),
(317, 13, 'Yaourt Đam mê', 'Yaourt Đam mê', 'Ly', 28000, 28000, 28000, 28000, '', 1, 0, 0),
(318, 17, 'Đậu nành nấu', 'Đậu nành nấu', 'Ly', 7000, 7000, 7000, 7000, '', 0, 0, 0),
(319, 17, 'Rau má', 'Rau má', 'Ly', 13000, 13000, 13000, 13000, '', 1, 0, 0),
(320, 17, 'Sữa chanh xí muội', 'Sữa chanh xí muội', 'Ly', 16000, 16000, 16000, 16000, '', 1, 0, 0),
(321, 17, 'Sữa tươi cacao đá', 'Sữa tươi cacao đá', 'Ly', 16000, 16000, 16000, 16000, '', 1, 0, 0),
(322, 17, 'Sữa tươi cafe', 'Sữa tươi cafe', 'Ly', 14000, 14000, 14000, 14000, '', 1, 0, 0),
(323, 20, '555 gói lớn', '555 gói lớn', 'Gói', 35000, 35000, 35000, 35000, '', 0, 0, 0),
(324, 20, 'Mèo trung', 'Mèo trung', 'Gói', 22000, 22000, 22000, 22000, '', 0, 0, 0),
(325, 23, 'Khăn lạnh', 'Khăn lạnh', 'Cái', 2000, 2000, 2000, 2000, '', 1, 0, 0),
(326, 23, 'Nước ép thêm', 'Nước ép thêm', 'Ly', 10000, 10000, 10000, 10000, '', 1, 0, 0),
(327, 23, 'Phụ thu nhạc', 'Phụ thu nhạc', 'Bàn', 5000, 5000, 5000, 5000, '', 0, 0, 0),
(328, 23, 'Phụ thu PL', 'Phụ thu PL', 'Bàn', 50000, 50000, 50000, 50000, '', 0, 0, 0),
(329, 23, 'Rau má thêm', 'Rau má thêm', 'Ly', 5000, 5000, 5000, 5000, '', 1, 0, 0),
(330, 23, 'Trái cây dĩa lớn', 'Trái cây dĩa lớn', 'Dĩa', 35000, 35000, 35000, 35000, '', 1, 0, 0),
(331, 23, 'Trái cây dĩa nhỏ', 'Trái cây dĩa nhỏ', 'Dĩa', 25000, 25000, 25000, 25000, '', 1, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `cafepassion_customer`
--

CREATE TABLE IF NOT EXISTS `cafepassion_customer` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  `card` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `note` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `discount` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=14 ;

--
-- Dumping data for table `cafepassion_customer`
--

INSERT INTO `cafepassion_customer` (`id`, `name`, `type`, `card`, `phone`, `address`, `note`, `discount`) VALUES
(1, 'Khách lẻ', 0, '', '', '', '', 0),
(12, 'Nguyễn Văn A', 1, '123456789', '0919 111 222', 'Vĩnh Long', '', 5),
(13, 'Nguyễn Văn B', 0, '', '', '', '', 10);

-- --------------------------------------------------------

--
-- Table structure for table `cafepassion_domain`
--

CREATE TABLE IF NOT EXISTS `cafepassion_domain` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Dumping data for table `cafepassion_domain`
--

INSERT INTO `cafepassion_domain` (`id`, `name`) VALUES
(1, 'PHÒNG LẠNH 1'),
(2, 'PHÒNG LẠNH 2'),
(3, 'SÂN VƯỜN');

-- --------------------------------------------------------

--
-- Table structure for table `cafepassion_employee`
--

CREATE TABLE IF NOT EXISTS `cafepassion_employee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `job` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `gender` tinyint(2) NOT NULL,
  `phone` varchar(13) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `salary_base` int(11) NOT NULL,
  `card` varchar(13) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=10 ;

--
-- Dumping data for table `cafepassion_employee`
--

INSERT INTO `cafepassion_employee` (`id`, `name`, `job`, `gender`, `phone`, `address`, `salary_base`, `card`) VALUES
(1, 'Ngọc', 'Phục vụ', 1, '01635758021', 'Mang Thít', 1800000, '12345678'),
(2, 'Trinh', 'Phục vụ', 1, '01649 359 321', 'Đồng Tháp', 1800000, ''),
(3, 'Nguyệt', 'Phục vụ', 1, '0164 220 95 9', 'Đồng Tháp', 1800000, ''),
(4, 'Nhi', 'Phục vụ', 1, '01629 655 287', 'Cần Thơ', 1800000, ''),
(5, 'Duy', 'Phục vụ', 0, '01882356234', 'P2, Tp.Vĩnh Long', 1800000, ''),
(6, 'Dũng', 'Giữ xe', 0, '0907 615 003', 'Quảng Bình', 1800000, ''),
(7, 'Nguyên', 'Nhân viên', 0, '01665685873', 'P3, TP VLong', 1800000, ''),
(8, 'Tân', 'Thu ngân', 0, '0989 975 603', 'Tam Bình', 2500000, ''),
(9, 'Hằng', 'NV', 1, '01286962340', 'vinh long', 1800000, '');

-- --------------------------------------------------------

--
-- Table structure for table `cafepassion_guest`
--

CREATE TABLE IF NOT EXISTS `cafepassion_guest` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(16) CHARACTER SET latin1 NOT NULL,
  `entry_time` varchar(32) CHARACTER SET latin1 NOT NULL,
  `exit_time` varchar(32) CHARACTER SET latin1 NOT NULL,
  `agent` varchar(16) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=150 ;

--
-- Dumping data for table `cafepassion_guest`
--

INSERT INTO `cafepassion_guest` (`id`, `ip`, `entry_time`, `exit_time`, `agent`) VALUES
(149, '115.78.94.118', '1383319305', '1383322905', '115.78.94.118');

-- --------------------------------------------------------

--
-- Table structure for table `cafepassion_order_import`
--

CREATE TABLE IF NOT EXISTS `cafepassion_order_import` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idsupplier` int(11) NOT NULL,
  `date` date NOT NULL,
  `description` varchar(50) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id`),
  KEY `cafepassion_order_import_1` (`idsupplier`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=359 ;

--
-- Dumping data for table `cafepassion_order_import`
--

INSERT INTO `cafepassion_order_import` (`id`, `idsupplier`, `date`, `description`) VALUES
(348, 8, '2013-12-06', ''),
(349, 8, '2014-01-02', ''),
(350, 9, '2013-12-30', 'Nhập hàng lần 1'),
(352, 1, '2013-12-31', 'Đá viên'),
(353, 1, '2014-01-01', 'Đá viên'),
(354, 1, '2014-01-02', 'Đá viên'),
(355, 1, '2014-01-03', 'Đá viên'),
(356, 1, '2014-01-06', 'Đá viên + Đá ướp'),
(357, 12, '2014-01-06', 'Dừa'),
(358, 13, '2014-01-03', 'Trà lài');

-- --------------------------------------------------------

--
-- Table structure for table `cafepassion_order_import_detail`
--

CREATE TABLE IF NOT EXISTS `cafepassion_order_import_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idorder` int(11) NOT NULL,
  `idresource` int(11) NOT NULL,
  `count` float NOT NULL,
  `price` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `cafepassion_order_import_detail_1` (`idorder`),
  KEY `cafepassion_order_import_detail_2` (`idresource`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=653 ;

--
-- Dumping data for table `cafepassion_order_import_detail`
--

INSERT INTO `cafepassion_order_import_detail` (`id`, `idorder`, `idresource`, `count`, `price`) VALUES
(634, 348, 19, 2, 60000),
(635, 348, 20, 1, 80000),
(636, 348, 101, 1, 120000),
(637, 349, 19, 1, 60000),
(638, 350, 35, 2, 160000),
(639, 350, 36, 5, 185000),
(640, 350, 43, 5, 170000),
(641, 350, 103, 5, 105000),
(642, 350, 104, 2, 105000),
(643, 350, 105, 1, 174000),
(644, 350, 106, 1, 135000),
(645, 350, 109, 1, 142000),
(646, 352, 2, 9, 15000),
(647, 353, 2, 3, 15000),
(648, 354, 2, 4, 15000),
(649, 355, 2, 2, 15000),
(650, 356, 2, 5, 15000),
(651, 356, 14, 1, 10000),
(652, 357, 110, 10, 7000);

-- --------------------------------------------------------

--
-- Table structure for table `cafepassion_paid_customer`
--

CREATE TABLE IF NOT EXISTS `cafepassion_paid_customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idcustomer` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cafepassion_customer_paid_1` (`idcustomer`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `cafepassion_paid_customer`
--


-- --------------------------------------------------------

--
-- Table structure for table `cafepassion_paid_employee`
--

CREATE TABLE IF NOT EXISTS `cafepassion_paid_employee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_employee` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(150) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_employee` (`id_employee`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `cafepassion_paid_employee`
--

INSERT INTO `cafepassion_paid_employee` (`id`, `id_employee`, `date`, `value`, `note`) VALUES
(4, 2, '2014-01-06', 200000, 'ứng lương'),
(5, 8, '2014-01-03', 500000, 'ung luong');

-- --------------------------------------------------------

--
-- Table structure for table `cafepassion_paid_general`
--

CREATE TABLE IF NOT EXISTS `cafepassion_paid_general` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_term` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cafepassion_paid_1` (`id_term`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=175 ;

--
-- Dumping data for table `cafepassion_paid_general`
--

INSERT INTO `cafepassion_paid_general` (`id`, `id_term`, `date`, `value`, `note`) VALUES
(9, 10, '2013-04-01', 157000, 'Chi tiền chợ'),
(10, 10, '2013-04-02', 146000, 'Tiền chợ'),
(11, 10, '2013-04-03', 189000, 'Tiền chợ'),
(12, 10, '2013-04-04', 184000, 'Tiền chợ'),
(66, 2, '2013-04-30', 2100000, 'Tạm tính'),
(111, 3, '2013-07-31', 1500000, 'Thuế TTĐB Tháng 07'),
(112, 1, '2013-07-31', 4000000, 'Tiền điện T07'),
(113, 2, '2013-07-31', 2000000, 'Tiền nước T07'),
(155, 3, '2013-08-31', 800000, 'Thuế TTĐB T08'),
(156, 3, '2013-09-30', 850000, 'Thuế TTĐB T09'),
(158, 1, '2013-08-31', 5800000, 'Tiền điện T08'),
(159, 1, '2013-09-30', 3700000, 'Tiền điện T09'),
(160, 2, '2013-08-31', 2200000, 'Tiền nước T08'),
(161, 2, '2013-09-30', 2300000, 'Tiền nước T09'),
(163, 1, '2013-05-31', 4700000, 'Tiền điện T05'),
(164, 1, '2013-06-30', 3900000, 'Tiền điện T06'),
(165, 2, '2013-05-31', 2350000, 'Tiền nước T05'),
(166, 2, '2013-06-30', 2260000, 'Tiền nước T06'),
(167, 11, '2014-01-06', 85000, 'Chi mua Cam'),
(168, 10, '2014-01-08', 186000, 'tien an sáng(30),com trưa( 84), cơm chều(72)'),
(169, 11, '2014-01-08', 256000, 'Chi mua cong tv 26, than da 50, chanh 30, sapo 16,'),
(170, 10, '2014-01-09', 207000, 'Tiền chợ'),
(171, 10, '2014-01-10', 163000, 'chợ'),
(172, 11, '2014-01-10', 70000, 'Dừa trái '),
(173, 11, '2014-01-10', 337000, '1c jet, 1c meo tet, giay ve sinh, xoai an'),
(174, 10, '2014-01-11', 128000, 'an sáng, chợ');

-- --------------------------------------------------------

--
-- Table structure for table `cafepassion_paid_pay_roll`
--

CREATE TABLE IF NOT EXISTS `cafepassion_paid_pay_roll` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_employee` int(11) NOT NULL,
  `date` date NOT NULL,
  `value_base` int(11) NOT NULL,
  `value_sub` int(11) NOT NULL,
  `value_pre` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cafepassion_paid_pay_roll_1` (`id_employee`),
  KEY `id_employee` (`id_employee`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `cafepassion_paid_pay_roll`
--


-- --------------------------------------------------------

--
-- Table structure for table `cafepassion_paid_supplier`
--

CREATE TABLE IF NOT EXISTS `cafepassion_paid_supplier` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idsupplier` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cafepassion_supplier_paid_1` (`idsupplier`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=18 ;

--
-- Dumping data for table `cafepassion_paid_supplier`
--

INSERT INTO `cafepassion_paid_supplier` (`id`, `idsupplier`, `date`, `value`, `note`) VALUES
(1, 1, '2012-08-01', 2300000, 'được không ?'),
(2, 1, '2012-07-03', 350000, 'Ghi chú gì đây'),
(3, 1, '2012-07-26', 750000, 'Ghi ghi gì gì đó'),
(8, 6, '2012-09-19', 1000000, 'Thử nè được không đó !'),
(9, 1, '2012-09-19', 1000000, 'lung tung quá đi'),
(11, 1, '2012-01-01', 123, 'sdfdsfggf'),
(12, 1, '2012-09-24', 1230000, 'đâu biết'),
(13, 1, '2012-09-24', 1213232, ''),
(14, 1, '2012-09-24', 34243243, ''),
(15, 1, '2012-09-24', 21323, ''),
(16, 1, '2012-09-24', 123323, ''),
(17, 1, '2012-09-24', 21323, '');

-- --------------------------------------------------------

--
-- Table structure for table `cafepassion_pay_roll`
--

CREATE TABLE IF NOT EXISTS `cafepassion_pay_roll` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_employee` int(11) NOT NULL,
  `date` date NOT NULL,
  `session1` int(11) NOT NULL,
  `session2` int(11) NOT NULL,
  `session3` int(11) NOT NULL,
  `extra` int(11) NOT NULL,
  `late` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_employee` (`id_employee`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=410 ;

--
-- Dumping data for table `cafepassion_pay_roll`
--

INSERT INTO `cafepassion_pay_roll` (`id`, `id_employee`, `date`, `session1`, `session2`, `session3`, `extra`, `late`) VALUES
(131, 1, '2014-01-01', 0, 0, 0, 0, 0),
(132, 1, '2014-01-02', 0, 0, 0, 0, 0),
(133, 1, '2014-01-03', 0, 0, 0, 0, 0),
(134, 1, '2014-01-04', 0, 0, 0, 0, 0),
(135, 1, '2014-01-05', 0, 0, 0, 0, 0),
(136, 1, '2014-01-06', 0, 0, 0, 0, 0),
(137, 1, '2014-01-07', 0, 0, 0, 0, 0),
(138, 1, '2014-01-08', 1, 1, 1, 0, 0),
(139, 1, '2014-01-09', 1, 1, 1, 0, 0),
(140, 1, '2014-01-10', 1, 1, 1, 0, 0),
(141, 1, '2014-01-11', 1, 1, 1, 0, 0),
(142, 1, '2014-01-12', 0, 0, 0, 0, 0),
(143, 1, '2014-01-13', 0, 0, 0, 0, 0),
(144, 1, '2014-01-14', 0, 0, 0, 0, 0),
(145, 1, '2014-01-15', 0, 0, 0, 0, 0),
(146, 1, '2014-01-16', 0, 0, 0, 0, 0),
(147, 1, '2014-01-17', 0, 0, 0, 0, 0),
(148, 1, '2014-01-18', 0, 0, 0, 0, 0),
(149, 1, '2014-01-19', 0, 0, 0, 0, 0),
(150, 1, '2014-01-20', 0, 0, 0, 0, 0),
(151, 1, '2014-01-21', 0, 0, 0, 0, 0),
(152, 1, '2014-01-22', 0, 0, 0, 0, 0),
(153, 1, '2014-01-23', 0, 0, 0, 0, 0),
(154, 1, '2014-01-24', 0, 0, 0, 0, 0),
(155, 1, '2014-01-25', 0, 0, 0, 0, 0),
(156, 1, '2014-01-26', 0, 0, 0, 0, 0),
(157, 1, '2014-01-27', 0, 0, 0, 0, 0),
(158, 1, '2014-01-28', 0, 0, 0, 0, 0),
(159, 1, '2014-01-29', 0, 0, 0, 0, 0),
(160, 1, '2014-01-30', 0, 0, 0, 0, 0),
(161, 1, '2014-01-31', 0, 0, 0, 0, 0),
(162, 2, '2014-01-01', 0, 0, 0, 0, 0),
(163, 2, '2014-01-02', 0, 0, 0, 0, 0),
(164, 2, '2014-01-03', 0, 0, 0, 0, 0),
(165, 2, '2014-01-04', 0, 0, 0, 0, 0),
(166, 2, '2014-01-05', 0, 0, 0, 0, 0),
(167, 2, '2014-01-06', 0, 0, 0, 0, 0),
(168, 2, '2014-01-07', 0, 0, 0, 0, 0),
(169, 2, '2014-01-08', 0, 0, 1, 0, 0),
(170, 2, '2014-01-09', 0, 0, 1, 0, 0),
(171, 2, '2014-01-10', 0, 0, 0, 0, 0),
(172, 2, '2014-01-11', 0, 0, 0, 0, 0),
(173, 2, '2014-01-12', 0, 0, 0, 0, 0),
(174, 2, '2014-01-13', 0, 0, 0, 0, 0),
(175, 2, '2014-01-14', 0, 0, 0, 0, 0),
(176, 2, '2014-01-15', 0, 0, 0, 0, 0),
(177, 2, '2014-01-16', 0, 0, 0, 0, 0),
(178, 2, '2014-01-17', 0, 0, 0, 0, 0),
(179, 2, '2014-01-18', 0, 0, 0, 0, 0),
(180, 2, '2014-01-19', 0, 0, 0, 0, 0),
(181, 2, '2014-01-20', 0, 0, 0, 0, 0),
(182, 2, '2014-01-21', 0, 0, 0, 0, 0),
(183, 2, '2014-01-22', 0, 0, 0, 0, 0),
(184, 2, '2014-01-23', 0, 0, 0, 0, 0),
(185, 2, '2014-01-24', 0, 0, 0, 0, 0),
(186, 2, '2014-01-25', 0, 0, 0, 0, 0),
(187, 2, '2014-01-26', 0, 0, 0, 0, 0),
(188, 2, '2014-01-27', 0, 0, 0, 0, 0),
(189, 2, '2014-01-28', 0, 0, 0, 0, 0),
(190, 2, '2014-01-29', 0, 0, 0, 0, 0),
(191, 2, '2014-01-30', 0, 0, 0, 0, 0),
(192, 2, '2014-01-31', 0, 0, 0, 0, 0),
(193, 3, '2014-01-01', 0, 0, 0, 0, 0),
(194, 3, '2014-01-02', 0, 0, 0, 0, 0),
(195, 3, '2014-01-03', 0, 0, 0, 0, 0),
(196, 3, '2014-01-04', 0, 0, 0, 0, 0),
(197, 3, '2014-01-05', 0, 0, 0, 0, 0),
(198, 3, '2014-01-06', 0, 1, 1, 0, 0),
(199, 3, '2014-01-07', 0, 1, 1, 0, 0),
(200, 3, '2014-01-08', 0, 0, 1, 0, 0),
(201, 3, '2014-01-09', 0, 1, 1, 0, 0),
(202, 3, '2014-01-10', 0, 0, 0, 0, 0),
(203, 3, '2014-01-11', 0, 0, 0, 0, 0),
(204, 3, '2014-01-12', 0, 0, 0, 0, 0),
(205, 3, '2014-01-13', 0, 0, 0, 0, 0),
(206, 3, '2014-01-14', 0, 0, 0, 0, 0),
(207, 3, '2014-01-15', 0, 0, 0, 0, 0),
(208, 3, '2014-01-16', 0, 0, 0, 0, 0),
(209, 3, '2014-01-17', 0, 0, 0, 0, 0),
(210, 3, '2014-01-18', 0, 0, 0, 0, 0),
(211, 3, '2014-01-19', 0, 0, 0, 0, 0),
(212, 3, '2014-01-20', 0, 0, 0, 0, 0),
(213, 3, '2014-01-21', 0, 0, 0, 0, 0),
(214, 3, '2014-01-22', 0, 0, 0, 0, 0),
(215, 3, '2014-01-23', 0, 0, 0, 0, 0),
(216, 3, '2014-01-24', 0, 0, 0, 0, 0),
(217, 3, '2014-01-25', 0, 0, 0, 0, 0),
(218, 3, '2014-01-26', 0, 0, 0, 0, 0),
(219, 3, '2014-01-27', 0, 0, 0, 0, 0),
(220, 3, '2014-01-28', 0, 0, 0, 0, 0),
(221, 3, '2014-01-29', 0, 0, 0, 0, 0),
(222, 3, '2014-01-30', 0, 0, 0, 0, 0),
(223, 3, '2014-01-31', 0, 0, 0, 0, 0),
(224, 4, '2014-01-01', 0, 0, 0, 0, 0),
(225, 4, '2014-01-02', 0, 0, 0, 0, 0),
(226, 4, '2014-01-03', 0, 0, 0, 0, 0),
(227, 4, '2014-01-04', 0, 0, 0, 0, 0),
(228, 4, '2014-01-05', 0, 0, 0, 0, 0),
(229, 4, '2014-01-06', 0, 0, 0, 0, 0),
(230, 4, '2014-01-07', 0, 0, 0, 0, 0),
(231, 4, '2014-01-08', 0, 0, 0, 0, 0),
(232, 4, '2014-01-09', 0, 1, 0, 0, 0),
(233, 4, '2014-01-10', 0, 0, 0, 0, 0),
(234, 4, '2014-01-11', 0, 0, 0, 0, 0),
(235, 4, '2014-01-12', 0, 0, 0, 0, 0),
(236, 4, '2014-01-13', 0, 0, 0, 0, 0),
(237, 4, '2014-01-14', 0, 0, 0, 0, 0),
(238, 4, '2014-01-15', 0, 0, 0, 0, 0),
(239, 4, '2014-01-16', 0, 0, 0, 0, 0),
(240, 4, '2014-01-17', 0, 0, 0, 0, 0),
(241, 4, '2014-01-18', 0, 0, 0, 0, 0),
(242, 4, '2014-01-19', 0, 0, 0, 0, 0),
(243, 4, '2014-01-20', 0, 0, 0, 0, 0),
(244, 4, '2014-01-21', 0, 0, 0, 0, 0),
(245, 4, '2014-01-22', 0, 0, 0, 0, 0),
(246, 4, '2014-01-23', 0, 0, 0, 0, 0),
(247, 4, '2014-01-24', 0, 0, 0, 0, 0),
(248, 4, '2014-01-25', 0, 0, 0, 0, 0),
(249, 4, '2014-01-26', 0, 0, 0, 0, 0),
(250, 4, '2014-01-27', 0, 0, 0, 0, 0),
(251, 4, '2014-01-28', 0, 0, 0, 0, 0),
(252, 4, '2014-01-29', 0, 0, 0, 0, 0),
(253, 4, '2014-01-30', 0, 0, 0, 0, 0),
(254, 4, '2014-01-31', 0, 0, 0, 0, 0),
(255, 6, '2014-01-01', 0, 0, 0, 0, 0),
(256, 6, '2014-01-02', 0, 0, 0, 0, 0),
(257, 6, '2014-01-03', 0, 0, 0, 0, 0),
(258, 6, '2014-01-04', 0, 0, 0, 0, 0),
(259, 6, '2014-01-05', 0, 0, 0, 0, 0),
(260, 6, '2014-01-06', 1, 0, 1, 0, 0),
(261, 6, '2014-01-07', 1, 0, 1, 0, 0),
(262, 6, '2014-01-08', 1, 0, 1, 0, 0),
(263, 6, '2014-01-09', 1, 0, 1, 0, 0),
(264, 6, '2014-01-10', 0, 0, 0, 0, 0),
(265, 6, '2014-01-11', 0, 0, 0, 0, 0),
(266, 6, '2014-01-12', 0, 0, 0, 0, 0),
(267, 6, '2014-01-13', 0, 0, 0, 0, 0),
(268, 6, '2014-01-14', 0, 0, 0, 0, 0),
(269, 6, '2014-01-15', 0, 0, 0, 0, 0),
(270, 6, '2014-01-16', 0, 0, 0, 0, 0),
(271, 6, '2014-01-17', 0, 0, 0, 0, 0),
(272, 6, '2014-01-18', 0, 0, 0, 0, 0),
(273, 6, '2014-01-19', 0, 0, 0, 0, 0),
(274, 6, '2014-01-20', 0, 0, 0, 0, 0),
(275, 6, '2014-01-21', 0, 0, 0, 0, 0),
(276, 6, '2014-01-22', 0, 0, 0, 0, 0),
(277, 6, '2014-01-23', 0, 0, 0, 0, 0),
(278, 6, '2014-01-24', 0, 0, 0, 0, 0),
(279, 6, '2014-01-25', 0, 0, 0, 0, 0),
(280, 6, '2014-01-26', 0, 0, 0, 0, 0),
(281, 6, '2014-01-27', 0, 0, 0, 0, 0),
(282, 6, '2014-01-28', 0, 0, 0, 0, 0),
(283, 6, '2014-01-29', 0, 0, 0, 0, 0),
(284, 6, '2014-01-30', 0, 0, 0, 0, 0),
(285, 6, '2014-01-31', 0, 0, 0, 0, 0),
(286, 7, '2014-01-01', 0, 0, 0, 0, 0),
(287, 7, '2014-01-02', 0, 0, 0, 0, 0),
(288, 7, '2014-01-03', 0, 0, 0, 0, 0),
(289, 7, '2014-01-04', 0, 0, 0, 0, 0),
(290, 7, '2014-01-05', 0, 0, 0, 0, 0),
(291, 7, '2014-01-06', 1, 1, 0, 0, 0),
(292, 7, '2014-01-07', 1, 1, 0, 0, 0),
(293, 7, '2014-01-08', 1, 1, 0, 0, 0),
(294, 7, '2014-01-09', 1, 1, 0, 0, 0),
(295, 7, '2014-01-10', 0, 0, 0, 0, 0),
(296, 7, '2014-01-11', 0, 0, 0, 0, 0),
(297, 7, '2014-01-12', 0, 0, 0, 0, 0),
(298, 7, '2014-01-13', 0, 0, 0, 0, 0),
(299, 7, '2014-01-14', 0, 0, 0, 0, 0),
(300, 7, '2014-01-15', 0, 0, 0, 0, 0),
(301, 7, '2014-01-16', 0, 0, 0, 0, 0),
(302, 7, '2014-01-17', 0, 0, 0, 0, 0),
(303, 7, '2014-01-18', 0, 0, 0, 0, 0),
(304, 7, '2014-01-19', 0, 0, 0, 0, 0),
(305, 7, '2014-01-20', 0, 0, 0, 0, 0),
(306, 7, '2014-01-21', 0, 0, 0, 0, 0),
(307, 7, '2014-01-22', 0, 0, 0, 0, 0),
(308, 7, '2014-01-23', 0, 0, 0, 0, 0),
(309, 7, '2014-01-24', 0, 0, 0, 0, 0),
(310, 7, '2014-01-25', 0, 0, 0, 0, 0),
(311, 7, '2014-01-26', 0, 0, 0, 0, 0),
(312, 7, '2014-01-27', 0, 0, 0, 0, 0),
(313, 7, '2014-01-28', 0, 0, 0, 0, 0),
(314, 7, '2014-01-29', 0, 0, 0, 0, 0),
(315, 7, '2014-01-30', 0, 0, 0, 0, 0),
(316, 7, '2014-01-31', 0, 0, 0, 0, 0),
(317, 8, '2014-01-01', 1, 1, 1, 0, 0),
(318, 8, '2014-01-02', 1, 1, 1, 0, 0),
(319, 8, '2014-01-03', 1, 1, 1, 0, 0),
(320, 8, '2014-01-04', 1, 1, 1, 0, 0),
(321, 8, '2014-01-05', 1, 0, 0, 0, 0),
(322, 8, '2014-01-06', 1, 1, 1, 0, 0),
(323, 8, '2014-01-07', 1, 1, 1, 0, 0),
(324, 8, '2014-01-08', 1, 1, 1, 0, 0),
(325, 8, '2014-01-09', 1, 1, 1, 0, 0),
(326, 8, '2014-01-10', 0, 0, 0, 0, 0),
(327, 8, '2014-01-11', 0, 0, 0, 0, 0),
(328, 8, '2014-01-12', 0, 0, 0, 0, 0),
(329, 8, '2014-01-13', 0, 0, 0, 0, 0),
(330, 8, '2014-01-14', 0, 0, 0, 0, 0),
(331, 8, '2014-01-15', 0, 0, 0, 0, 0),
(332, 8, '2014-01-16', 0, 0, 0, 0, 0),
(333, 8, '2014-01-17', 0, 0, 0, 0, 0),
(334, 8, '2014-01-18', 0, 0, 0, 0, 0),
(335, 8, '2014-01-19', 0, 0, 0, 0, 0),
(336, 8, '2014-01-20', 0, 0, 0, 0, 0),
(337, 8, '2014-01-21', 0, 0, 0, 0, 0),
(338, 8, '2014-01-22', 0, 0, 0, 0, 0),
(339, 8, '2014-01-23', 0, 0, 0, 0, 0),
(340, 8, '2014-01-24', 0, 0, 0, 0, 0),
(341, 8, '2014-01-25', 0, 0, 0, 0, 0),
(342, 8, '2014-01-26', 0, 0, 0, 0, 0),
(343, 8, '2014-01-27', 0, 0, 0, 0, 0),
(344, 8, '2014-01-28', 0, 0, 0, 0, 0),
(345, 8, '2014-01-29', 0, 0, 0, 0, 0),
(346, 8, '2014-01-30', 0, 0, 0, 0, 0),
(347, 8, '2014-01-31', 0, 0, 0, 0, 0),
(348, 5, '2014-01-01', 0, 0, 0, 0, 0),
(349, 5, '2014-01-02', 0, 0, 0, 0, 0),
(350, 5, '2014-01-03', 0, 0, 0, 0, 0),
(351, 5, '2014-01-04', 0, 0, 0, 0, 0),
(352, 5, '2014-01-05', 0, 0, 0, 0, 0),
(353, 5, '2014-01-06', 0, 0, 0, 0, 0),
(354, 5, '2014-01-07', 0, 0, 0, 0, 0),
(355, 5, '2014-01-08', 0, 0, 0, 0, 0),
(356, 5, '2014-01-09', 0, 0, 0, 0, 0),
(357, 5, '2014-01-10', 0, 0, 0, 0, 0),
(358, 5, '2014-01-11', 0, 0, 0, 0, 0),
(359, 5, '2014-01-12', 0, 0, 0, 0, 0),
(360, 5, '2014-01-13', 0, 0, 0, 0, 0),
(361, 5, '2014-01-14', 0, 0, 0, 0, 0),
(362, 5, '2014-01-15', 0, 0, 0, 0, 0),
(363, 5, '2014-01-16', 0, 0, 0, 0, 0),
(364, 5, '2014-01-17', 0, 0, 0, 0, 0),
(365, 5, '2014-01-18', 0, 0, 0, 0, 0),
(366, 5, '2014-01-19', 0, 0, 0, 0, 0),
(367, 5, '2014-01-20', 0, 0, 0, 0, 0),
(368, 5, '2014-01-21', 0, 0, 0, 0, 0),
(369, 5, '2014-01-22', 0, 0, 0, 0, 0),
(370, 5, '2014-01-23', 0, 0, 0, 0, 0),
(371, 5, '2014-01-24', 0, 0, 0, 0, 0),
(372, 5, '2014-01-25', 0, 0, 0, 0, 0),
(373, 5, '2014-01-26', 0, 0, 0, 0, 0),
(374, 5, '2014-01-27', 0, 0, 0, 0, 0),
(375, 5, '2014-01-28', 0, 0, 0, 0, 0),
(376, 5, '2014-01-29', 0, 0, 0, 0, 0),
(377, 5, '2014-01-30', 0, 0, 0, 0, 0),
(378, 5, '2014-01-31', 0, 0, 0, 0, 0),
(379, 9, '2014-01-01', 0, 0, 0, 0, 0),
(380, 9, '2014-01-02', 0, 0, 0, 0, 0),
(381, 9, '2014-01-03', 0, 0, 0, 0, 0),
(382, 9, '2014-01-04', 0, 0, 0, 0, 0),
(383, 9, '2014-01-05', 0, 0, 0, 0, 0),
(384, 9, '2014-01-06', 0, 0, 0, 0, 0),
(385, 9, '2014-01-07', 1, 1, 1, 0, 0),
(386, 9, '2014-01-08', 1, 1, 1, 0, 0),
(387, 9, '2014-01-09', 1, 1, 1, 0, 0),
(388, 9, '2014-01-10', 0, 0, 0, 0, 0),
(389, 9, '2014-01-11', 0, 0, 0, 0, 0),
(390, 9, '2014-01-12', 0, 0, 0, 0, 0),
(391, 9, '2014-01-13', 0, 0, 0, 0, 0),
(392, 9, '2014-01-14', 0, 0, 0, 0, 0),
(393, 9, '2014-01-15', 0, 0, 0, 0, 0),
(394, 9, '2014-01-16', 0, 0, 0, 0, 0),
(395, 9, '2014-01-17', 0, 0, 0, 0, 0),
(396, 9, '2014-01-18', 0, 0, 0, 0, 0),
(397, 9, '2014-01-19', 0, 0, 0, 0, 0),
(398, 9, '2014-01-20', 0, 0, 0, 0, 0),
(399, 9, '2014-01-21', 0, 0, 0, 0, 0),
(400, 9, '2014-01-22', 0, 0, 0, 0, 0),
(401, 9, '2014-01-23', 0, 0, 0, 0, 0),
(402, 9, '2014-01-24', 0, 0, 0, 0, 0),
(403, 9, '2014-01-25', 0, 0, 0, 0, 0),
(404, 9, '2014-01-26', 0, 0, 0, 0, 0),
(405, 9, '2014-01-27', 0, 0, 0, 0, 0),
(406, 9, '2014-01-28', 0, 0, 0, 0, 0),
(407, 9, '2014-01-29', 0, 0, 0, 0, 0),
(408, 9, '2014-01-30', 0, 0, 0, 0, 0),
(409, 9, '2014-01-31', 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `cafepassion_r2c`
--

CREATE TABLE IF NOT EXISTS `cafepassion_r2c` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_course` int(11) NOT NULL,
  `id_resource` int(11) NOT NULL,
  `value1` double NOT NULL,
  `value2` double NOT NULL,
  PRIMARY KEY (`id`),
  KEY `cafepassion_r2c_1` (`id_course`),
  KEY `cafepassion_r2c_2` (`id_resource`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `cafepassion_r2c`
--


-- --------------------------------------------------------

--
-- Table structure for table `cafepassion_resource`
--

CREATE TABLE IF NOT EXISTS `cafepassion_resource` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `idsupplier` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `unit` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `price` int(10) NOT NULL,
  `description` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `cafepassion_resource_1` (`idsupplier`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=111 ;

--
-- Dumping data for table `cafepassion_resource`
--

INSERT INTO `cafepassion_resource` (`id`, `idsupplier`, `name`, `unit`, `price`, `description`) VALUES
(2, 1, 'Đá viên nhỏ', 'Bao', 15000, 'Nước đá viên - Bao 25kg'),
(14, 1, 'Nước đá ướp', 'Cây', 10000, 'Đá cây ướp trái cây'),
(17, 6, 'Bánh', 'Gói', 5000, ''),
(19, 8, 'Hạt loại 1', 'Kg', 60000, ''),
(20, 8, 'Hạt loại 2', 'Kg', 80000, ''),
(27, 6, 'Xúc xích', 'Gói', 17000, ''),
(35, 9, 'Trà xanh 0 độ', 'Thùng', 160000, 'Thùng 24 chai 500ml'),
(36, 9, 'Dr Thanh', 'Thùng', 185000, 'Thùng 24 chai 370 ml'),
(39, 9, 'Pepsi', 'Thùng', 150000, 'Thùng 24 lon 330 ml'),
(40, 9, 'Mirinda Cam', 'Thùng', 120000, 'Thùng 24 lon 330ml'),
(43, 9, 'Sting dâu', 'Thùng', 170000, 'Thùng 24 chai 330ml'),
(47, 12, 'Ổi', 'Kg', 9000, ''),
(48, 12, 'Củ sắn', 'Kg', 15000, ''),
(49, 12, 'Mít', 'Kg', 18000, ''),
(50, 12, 'Chôm chôm', 'Kg', 10000, ''),
(51, 12, 'Xoài Thái', 'Kg', 15000, ''),
(52, 12, 'Xoài Đài Loan', 'Kg', 15000, ''),
(53, 12, 'Xoài chua', 'Kg', 15000, ''),
(54, 12, 'Mận', 'Kg', 10000, ''),
(55, 12, 'Sơ ri', 'Kg', 12000, ''),
(56, 12, 'Thơm', 'Kg', 12000, ''),
(57, 12, 'Khóm', 'Kg', 10000, ''),
(79, 12, 'Dưa hấu', 'Kg', 10000, ''),
(82, 12, 'Táo', 'Kg', 10000, ''),
(84, 12, 'Cóc', 'Kg', 6000, ''),
(91, 1, 'Đá ống viên lớn', 'Kg', 800, 'Bao 20kg'),
(99, 12, 'Bưởi', 'Kg', 10000, ''),
(101, 8, 'Hạt loại 3', 'Kg', 120000, ''),
(102, 13, 'Duong', 'Kg', 20000, ''),
(103, 9, 'C2', 'Thùng', 105000, '24 chai'),
(104, 9, 'Lipton', 'Hộp', 105000, '100 gói'),
(105, 9, 'Revive', 'Thùng', 174000, '24 chai'),
(106, 9, 'Ô Long', 'Thùng', 135000, '24 chai'),
(107, 12, 'Cà chua', 'Kg', 0, ''),
(108, 12, 'Cà rốt', 'Kg', 0, ''),
(109, 9, 'Mountain Dew', 'Thùng', 142000, '24 chai'),
(110, 12, 'Dừa', 'Trái', 7000, 'gọt sẵn');

-- --------------------------------------------------------

--
-- Table structure for table `cafepassion_session`
--

CREATE TABLE IF NOT EXISTS `cafepassion_session` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idtable` int(11) NOT NULL,
  `iduser` int(11) NOT NULL,
  `idcustomer` int(11) NOT NULL,
  `idemployee` int(11) NOT NULL,
  `datetime` datetime NOT NULL,
  `datetimeend` datetime DEFAULT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `status` int(11) NOT NULL,
  `discount_value` int(11) NOT NULL,
  `discount_percent` int(11) NOT NULL,
  `surtax` int(11) NOT NULL,
  `payment` int(11) NOT NULL,
  `value` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idtable` (`idtable`),
  KEY `iduser` (`iduser`),
  KEY `cafepassion_session_3` (`idcustomer`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `cafepassion_session`
--


-- --------------------------------------------------------

--
-- Table structure for table `cafepassion_session_detail`
--

CREATE TABLE IF NOT EXISTS `cafepassion_session_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idsession` int(11) NOT NULL,
  `idcourse` int(11) NOT NULL,
  `count` int(11) NOT NULL,
  `price` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idsession` (`idsession`),
  KEY `idcourse` (`idcourse`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `cafepassion_session_detail`
--


-- --------------------------------------------------------

--
-- Table structure for table `cafepassion_store`
--

CREATE TABLE IF NOT EXISTS `cafepassion_store` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `note` varchar(125) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `cafepassion_store`
--

INSERT INTO `cafepassion_store` (`id`, `name`, `note`) VALUES
(1, 'Kho nhà', 'Ghi chú gì đây ?');

-- --------------------------------------------------------

--
-- Table structure for table `cafepassion_supplier`
--

CREATE TABLE IF NOT EXISTS `cafepassion_supplier` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `note` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `debt` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=14 ;

--
-- Dumping data for table `cafepassion_supplier`
--

INSERT INTO `cafepassion_supplier` (`id`, `name`, `phone`, `address`, `note`, `debt`) VALUES
(1, 'ĐL NƯỚC ĐÁ', '0913796043', 'Phường 8', 'Cung cấp nước đá', 0),
(6, 'Siêu thị COOP MART', 'chưa cập nhật', 'Vĩnh Long', '', 0),
(8, 'ĐL Cafe hạt', '0703 111 222', 'P4 Vĩnh Long', '', 0),
(9, 'ĐL Nước ngọt Thiên Tân', '', 'P1, TP Vĩnh Long', '', 0),
(12, 'VỰA TRÁI CÂY', '', '', '', 0),
(13, 'NCC A', '80830803', 'p5 tpvl', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `cafepassion_table`
--

CREATE TABLE IF NOT EXISTS `cafepassion_table` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iddomain` int(11) NOT NULL,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `iduser` int(11) DEFAULT NULL,
  `type` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `iddomain` (`iddomain`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=98 ;

--
-- Dumping data for table `cafepassion_table`
--

INSERT INTO `cafepassion_table` (`id`, `iddomain`, `name`, `iduser`, `type`) VALUES
(1, 1, 'L1-01', 1, '0'),
(2, 1, 'L1-02', 1, '0'),
(3, 1, 'L1-03', 1, '0'),
(4, 1, 'L1-04', 1, '0'),
(14, 2, 'L2-01', 1, '0'),
(15, 2, 'L2-02', 1, '0'),
(16, 2, 'L2-03', 1, '0'),
(17, 2, 'L2-04', 1, '0'),
(26, 3, 'SV-01', 1, '0'),
(27, 3, 'SV-02', 1, '0'),
(28, 1, 'L1-05', 1, '0'),
(29, 1, 'L1-06', 1, '0'),
(30, 1, 'L1-07', 1, '0'),
(31, 1, 'L1-08', 1, '0'),
(32, 1, 'L1-09', 1, '0'),
(33, 1, 'L1-10', 1, '0'),
(34, 1, 'L1-11', 1, '0'),
(35, 1, 'L1-12', 1, '0'),
(36, 1, 'L1-13', 1, '0'),
(37, 1, 'L1-14', 1, '0'),
(38, 1, 'L1-15', 1, '0'),
(39, 1, 'L1-16', 1, '0'),
(40, 1, 'L1-17', 1, '0'),
(41, 1, 'L1-18', 1, '0'),
(42, 1, 'L1-19', 1, '0'),
(43, 1, 'L1-20', 1, '0'),
(44, 2, 'L2-05', 1, '0'),
(45, 2, 'L2-06', 1, '0'),
(46, 2, 'L2-07', 1, '0'),
(47, 2, 'L2-08', 1, '0'),
(48, 2, 'L2-09', 1, '0'),
(49, 2, 'L2-10', 1, '0'),
(50, 2, 'L2-11', 1, '0'),
(51, 2, 'L2-12', 1, '0'),
(52, 2, 'L2-13', 1, '0'),
(53, 2, 'L2-14', 1, '0'),
(54, 2, 'L2-15', 1, '0'),
(55, 2, 'L2-16', 1, '0'),
(56, 2, 'L2-17', 1, '0'),
(57, 2, 'L2-18', 1, '0'),
(58, 2, 'L2-19', 1, '0'),
(59, 2, 'L2-20', 1, '0'),
(60, 3, 'SV-03', 1, '0'),
(61, 3, 'SV-04', 1, '0'),
(62, 3, 'SV-05', 1, '0'),
(63, 3, 'SV-06', 1, '0'),
(64, 3, 'SV-07', 1, '0'),
(65, 3, 'SV-08', 1, '0'),
(66, 3, 'SV-09', 1, '0'),
(67, 3, 'SV-10', 1, '0'),
(68, 3, 'SV-11', 1, '0'),
(69, 3, 'SV-12', 1, '0'),
(70, 3, 'SV-13', 1, '0'),
(71, 3, 'SV-14', 1, '0'),
(72, 3, 'SV-15', 1, '0'),
(73, 3, 'SV-16', 1, '0'),
(74, 3, 'SV-17', 1, '0'),
(75, 3, 'SV-18', 1, '0'),
(76, 3, 'SV-19', 1, '0'),
(77, 3, 'SV-20', 1, '0'),
(78, 3, 'SV-21', 1, '0'),
(79, 3, 'SV-22', 1, '0'),
(80, 3, 'SV-23', 1, '0'),
(81, 3, 'SV-24', 1, '0'),
(82, 3, 'SV-25', 1, '0'),
(83, 3, 'SV-26', 1, '0'),
(84, 3, 'SV-27', 1, '0'),
(85, 3, 'SV-28', 1, '0'),
(86, 3, 'SV-29', 1, '0'),
(87, 3, 'SV-30', 1, '0'),
(88, 3, 'SV-31', 1, '0'),
(89, 3, 'SV-32', 1, '0'),
(90, 3, 'SV-33', 1, '0'),
(91, 3, 'SV-34', 1, '0'),
(92, 3, 'SV-35', 1, '0'),
(93, 3, 'SV-36', 1, '0'),
(94, 3, 'SV-37', 1, '0'),
(95, 3, 'SV-38', 1, '0'),
(96, 3, 'SV-39', 1, '0'),
(97, 3, 'SV-40', 1, '0');

-- --------------------------------------------------------

--
-- Table structure for table `cafepassion_table_log`
--

CREATE TABLE IF NOT EXISTS `cafepassion_table_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iduser` int(11) NOT NULL,
  `idtable` int(11) NOT NULL,
  `datetime` datetime NOT NULL,
  `note` varchar(250) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idtable` (`idtable`),
  KEY `iduser` (`iduser`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `cafepassion_table_log`
--


-- --------------------------------------------------------

--
-- Table structure for table `cafepassion_term`
--

CREATE TABLE IF NOT EXISTS `cafepassion_term` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=12 ;

--
-- Dumping data for table `cafepassion_term`
--

INSERT INTO `cafepassion_term` (`id`, `name`, `type`) VALUES
(1, 'Tiền Điện', 0),
(2, 'Tiền Nước', 0),
(3, 'Thuế', 0),
(10, 'Tiền Ăn Nhân Viên', 0),
(11, 'CP Khác', 0);

-- --------------------------------------------------------

--
-- Table structure for table `cafepassion_term_collect`
--

CREATE TABLE IF NOT EXISTS `cafepassion_term_collect` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Dumping data for table `cafepassion_term_collect`
--

INSERT INTO `cafepassion_term_collect` (`id`, `name`) VALUES
(2, 'Phụ Phẩm'),
(3, 'Đặc Biệt');

-- --------------------------------------------------------

--
-- Table structure for table `cafepassion_tracking`
--

CREATE TABLE IF NOT EXISTS `cafepassion_tracking` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_start` date NOT NULL,
  `date_end` date NOT NULL,
  `paid_general` int(11) NOT NULL,
  `paid_pay_roll` int(11) NOT NULL,
  `paid_import` int(11) NOT NULL,
  `collect_general` int(11) NOT NULL,
  `collect_customer` int(11) NOT NULL,
  `collect_selling_debt` int(11) NOT NULL,
  `collect_selling_nodebt` int(11) NOT NULL,
  `estate_rate` int(11) NOT NULL,
  `store_value` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=16 ;

--
-- Dumping data for table `cafepassion_tracking`
--

INSERT INTO `cafepassion_tracking` (`id`, `date_start`, `date_end`, `paid_general`, `paid_pay_roll`, `paid_import`, `collect_general`, `collect_customer`, `collect_selling_debt`, `collect_selling_nodebt`, `estate_rate`, `store_value`) VALUES
(13, '2014-01-01', '2014-01-31', 0, 0, 0, 0, 0, 0, 0, 0, 0),
(15, '2014-02-01', '2014-02-28', 0, 0, 0, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `cafepassion_tracking_course`
--

CREATE TABLE IF NOT EXISTS `cafepassion_tracking_course` (
  `id` int(11) NOT NULL,
  `id_tracking` int(11) NOT NULL,
  `id_td` int(11) NOT NULL,
  `id_course` int(11) NOT NULL,
  `count` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `value` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cafepassion_tracking_course`
--

INSERT INTO `cafepassion_tracking_course` (`id`, `id_tracking`, `id_td`, `id_course`, `count`, `price`, `value`) VALUES
(0, 13, 39, 194, 2, 0, 0),
(0, 13, 39, 335, 4, 0, 0),
(0, 13, 39, 107, 85, 0, 0),
(0, 13, 39, 108, 2, 0, 0),
(0, 13, 39, 255, 28, 0, 0),
(0, 13, 39, 355, 1, 0, 0),
(0, 13, 39, 358, 1, 0, 0),
(0, 13, 39, 268, 1, 0, 0),
(0, 13, 39, 197, 2, 0, 0),
(0, 13, 39, 175, 2, 0, 0),
(0, 13, 39, 176, 3, 0, 0),
(0, 13, 39, 177, 1, 0, 0),
(0, 13, 39, 362, 5, 0, 0),
(0, 13, 39, 363, 1, 0, 0),
(0, 13, 39, 364, 29, 0, 0),
(0, 13, 39, 365, 3, 0, 0),
(0, 13, 39, 224, 20, 0, 0),
(0, 13, 39, 226, 3, 0, 0),
(0, 13, 39, 218, 1, 0, 0),
(0, 13, 39, 368, 2, 0, 0),
(0, 13, 39, 367, 1, 0, 0),
(0, 13, 39, 180, 1, 0, 0),
(0, 13, 39, 128, 2, 0, 0),
(0, 13, 39, 129, 2, 0, 0),
(0, 13, 39, 204, 6, 0, 0),
(0, 13, 39, 209, 3, 0, 0),
(0, 13, 39, 212, 1, 0, 0),
(0, 13, 39, 372, 1, 0, 0),
(0, 13, 39, 222, 2, 0, 0),
(0, 13, 39, 205, 1, 0, 0),
(0, 13, 39, 228, 5, 0, 0),
(0, 13, 43, 335, 1, 0, 0),
(0, 13, 43, 107, 57, 0, 0),
(0, 13, 43, 255, 15, 0, 0),
(0, 13, 43, 112, 4, 0, 0),
(0, 13, 43, 358, 1, 0, 0),
(0, 13, 43, 197, 1, 0, 0),
(0, 13, 43, 175, 5, 0, 0),
(0, 13, 43, 176, 10, 0, 0),
(0, 13, 43, 177, 1, 0, 0),
(0, 13, 43, 363, 2, 0, 0),
(0, 13, 43, 364, 33, 0, 0),
(0, 13, 43, 365, 2, 0, 0),
(0, 13, 43, 224, 6, 0, 0),
(0, 13, 43, 226, 1, 0, 0),
(0, 13, 43, 368, 1, 0, 0),
(0, 13, 43, 328, 7, 0, 0),
(0, 13, 43, 180, 3, 0, 0),
(0, 13, 43, 128, 2, 0, 0),
(0, 13, 43, 204, 4, 0, 0),
(0, 13, 43, 212, 3, 0, 0),
(0, 13, 43, 222, 2, 0, 0),
(0, 13, 43, 205, 1, 0, 0),
(0, 13, 43, 315, 1, 0, 0),
(0, 13, 43, 162, 1, 0, 0),
(0, 13, 44, 335, 1, 0, 0),
(0, 13, 44, 107, 51, 0, 0),
(0, 13, 44, 255, 14, 0, 0),
(0, 13, 44, 112, 1, 0, 0),
(0, 13, 44, 268, 1, 0, 0),
(0, 13, 44, 197, 1, 0, 0),
(0, 13, 44, 175, 4, 0, 0),
(0, 13, 44, 176, 4, 0, 0),
(0, 13, 44, 189, 1, 0, 0),
(0, 13, 44, 363, 1, 0, 0),
(0, 13, 44, 364, 19, 0, 0),
(0, 13, 44, 365, 3, 0, 0),
(0, 13, 44, 224, 8, 0, 0),
(0, 13, 44, 368, 6, 0, 0),
(0, 13, 44, 179, 2, 0, 0),
(0, 13, 44, 180, 2, 0, 0),
(0, 13, 44, 127, 5, 0, 0),
(0, 13, 44, 351, 1, 0, 0),
(0, 13, 44, 129, 2, 0, 0),
(0, 13, 44, 204, 10, 0, 0),
(0, 13, 44, 212, 1, 0, 0),
(0, 13, 44, 222, 1, 0, 0),
(0, 13, 44, 205, 1, 0, 0),
(0, 13, 44, 228, 1, 0, 0),
(0, 13, 38, 370, 1, 0, 0),
(0, 13, 38, 335, 2, 0, 0),
(0, 13, 38, 107, 63, 0, 0),
(0, 13, 38, 255, 15, 0, 0),
(0, 13, 38, 358, 4, 0, 0),
(0, 13, 38, 268, 1, 0, 0),
(0, 13, 38, 203, 1, 0, 0),
(0, 13, 38, 353, 1, 0, 0),
(0, 13, 38, 197, 2, 0, 0),
(0, 13, 38, 174, 1, 0, 0),
(0, 13, 38, 175, 2, 0, 0),
(0, 13, 38, 176, 3, 0, 0),
(0, 13, 38, 177, 2, 0, 0),
(0, 13, 38, 362, 9, 0, 0),
(0, 13, 38, 364, 25, 0, 0),
(0, 13, 38, 365, 1, 0, 0),
(0, 13, 38, 224, 19, 0, 0),
(0, 13, 38, 226, 1, 0, 0),
(0, 13, 38, 218, 1, 0, 0),
(0, 13, 38, 292, 1, 0, 0),
(0, 13, 38, 368, 3, 0, 0),
(0, 13, 38, 371, 1, 0, 0),
(0, 13, 38, 179, 2, 0, 0),
(0, 13, 38, 180, 1, 0, 0),
(0, 13, 38, 332, 1, 0, 0),
(0, 13, 38, 127, 1, 0, 0),
(0, 13, 38, 128, 2, 0, 0),
(0, 13, 38, 351, 2, 0, 0),
(0, 13, 38, 129, 1, 0, 0),
(0, 13, 38, 204, 13, 0, 0),
(0, 13, 38, 199, 1, 0, 0),
(0, 13, 38, 212, 1, 0, 0),
(0, 13, 38, 334, 1, 0, 0),
(0, 13, 38, 228, 1, 0, 0),
(0, 13, 45, 335, 1, 0, 0),
(0, 13, 45, 107, 23, 0, 0),
(0, 13, 45, 255, 2, 0, 0),
(0, 13, 45, 267, 1, 0, 0),
(0, 13, 45, 176, 3, 0, 0),
(0, 13, 45, 364, 4, 0, 0),
(0, 13, 45, 224, 3, 0, 0),
(0, 13, 45, 226, 1, 0, 0),
(0, 13, 45, 368, 2, 0, 0),
(0, 13, 45, 180, 2, 0, 0),
(0, 13, 45, 222, 1, 0, 0),
(0, 13, 36, 335, 2, 0, 0),
(0, 13, 36, 107, 37, 0, 0),
(0, 13, 36, 255, 10, 0, 0),
(0, 13, 36, 268, 1, 0, 0),
(0, 13, 36, 174, 1, 0, 0),
(0, 13, 36, 175, 1, 0, 0),
(0, 13, 36, 176, 4, 0, 0),
(0, 13, 36, 177, 4, 0, 0),
(0, 13, 36, 189, 1, 0, 0),
(0, 13, 36, 224, 14, 0, 0),
(0, 13, 36, 178, 1, 0, 0),
(0, 13, 36, 179, 1, 0, 0),
(0, 13, 36, 180, 3, 0, 0),
(0, 13, 36, 56, 1, 0, 0),
(0, 13, 36, 128, 1, 0, 0),
(0, 13, 36, 204, 8, 0, 0),
(0, 13, 36, 212, 2, 0, 0),
(0, 13, 36, 221, 1, 0, 0),
(0, 13, 36, 222, 3, 0, 0),
(0, 13, 36, 205, 1, 0, 0),
(0, 13, 35, 107, 1, 0, 0),
(0, 13, 35, 255, 1, 0, 0),
(0, 13, 35, 224, 1, 0, 0),
(0, 13, 37, 335, 1, 0, 0),
(0, 13, 37, 107, 90, 0, 0),
(0, 13, 37, 255, 29, 0, 0),
(0, 13, 37, 112, 2, 0, 0),
(0, 13, 37, 355, 1, 0, 0),
(0, 13, 37, 268, 2, 0, 0),
(0, 13, 37, 265, 1, 0, 0),
(0, 13, 37, 203, 1, 0, 0),
(0, 13, 37, 353, 2, 0, 0),
(0, 13, 37, 197, 2, 0, 0),
(0, 13, 37, 174, 2, 0, 0),
(0, 13, 37, 175, 4, 0, 0),
(0, 13, 37, 176, 8, 0, 0),
(0, 13, 37, 177, 1, 0, 0),
(0, 13, 37, 189, 3, 0, 0),
(0, 13, 37, 308, 1, 0, 0),
(0, 13, 37, 364, 11, 0, 0),
(0, 13, 37, 224, 20, 0, 0),
(0, 13, 37, 226, 1, 0, 0),
(0, 13, 37, 218, 2, 0, 0),
(0, 13, 37, 201, 1, 0, 0),
(0, 13, 37, 179, 1, 0, 0),
(0, 13, 37, 180, 1, 0, 0),
(0, 13, 37, 351, 2, 0, 0),
(0, 13, 37, 129, 1, 0, 0),
(0, 13, 37, 204, 15, 0, 0),
(0, 13, 37, 212, 3, 0, 0),
(0, 13, 37, 222, 1, 0, 0),
(0, 13, 37, 334, 4, 0, 0),
(0, 13, 37, 205, 1, 0, 0),
(0, 13, 37, 315, 2, 0, 0),
(0, 13, 37, 228, 1, 0, 0),
(0, 13, 40, 335, 1, 0, 0),
(0, 13, 40, 107, 64, 0, 0),
(0, 13, 40, 255, 5, 0, 0),
(0, 13, 40, 358, 4, 0, 0),
(0, 13, 40, 268, 1, 0, 0),
(0, 13, 40, 175, 3, 0, 0),
(0, 13, 40, 362, 4, 0, 0),
(0, 13, 40, 364, 33, 0, 0),
(0, 13, 40, 365, 1, 0, 0),
(0, 13, 40, 224, 22, 0, 0),
(0, 13, 40, 226, 1, 0, 0),
(0, 13, 40, 369, 4, 0, 0),
(0, 13, 40, 366, 1, 0, 0),
(0, 13, 40, 367, 1, 0, 0),
(0, 13, 40, 373, 2, 0, 0),
(0, 13, 40, 128, 1, 0, 0),
(0, 13, 40, 204, 4, 0, 0),
(0, 13, 40, 212, 2, 0, 0),
(0, 13, 40, 222, 8, 0, 0),
(0, 13, 40, 334, 1, 0, 0),
(0, 13, 40, 205, 2, 0, 0),
(0, 13, 40, 228, 1, 0, 0),
(0, 13, 41, 194, 3, 0, 0),
(0, 13, 41, 335, 2, 0, 0),
(0, 13, 41, 107, 50, 0, 0),
(0, 13, 41, 255, 19, 0, 0),
(0, 13, 41, 355, 1, 0, 0),
(0, 13, 41, 358, 1, 0, 0),
(0, 13, 41, 268, 1, 0, 0),
(0, 13, 41, 353, 1, 0, 0),
(0, 13, 41, 197, 1, 0, 0),
(0, 13, 41, 174, 1, 0, 0),
(0, 13, 41, 175, 6, 0, 0),
(0, 13, 41, 176, 12, 0, 0),
(0, 13, 41, 177, 1, 0, 0),
(0, 13, 41, 189, 2, 0, 0),
(0, 13, 41, 362, 9, 0, 0),
(0, 13, 41, 363, 1, 0, 0),
(0, 13, 41, 364, 23, 0, 0),
(0, 13, 41, 365, 2, 0, 0),
(0, 13, 41, 224, 17, 0, 0),
(0, 13, 41, 226, 2, 0, 0),
(0, 13, 41, 368, 3, 0, 0),
(0, 13, 41, 367, 1, 0, 0),
(0, 13, 41, 373, 1, 0, 0),
(0, 13, 41, 180, 1, 0, 0),
(0, 13, 41, 332, 2, 0, 0),
(0, 13, 41, 128, 2, 0, 0),
(0, 13, 41, 351, 1, 0, 0),
(0, 13, 41, 129, 6, 0, 0),
(0, 13, 41, 204, 2, 0, 0),
(0, 13, 41, 212, 2, 0, 0),
(0, 13, 41, 334, 1, 0, 0),
(0, 13, 41, 205, 3, 0, 0),
(0, 13, 41, 228, 2, 0, 0),
(0, 13, 42, 335, 2, 0, 0),
(0, 13, 42, 107, 45, 0, 0),
(0, 13, 42, 255, 11, 0, 0),
(0, 13, 42, 358, 1, 0, 0),
(0, 13, 42, 268, 1, 0, 0),
(0, 13, 42, 203, 1, 0, 0),
(0, 13, 42, 353, 1, 0, 0),
(0, 13, 42, 197, 1, 0, 0),
(0, 13, 42, 176, 11, 0, 0),
(0, 13, 42, 364, 15, 0, 0),
(0, 13, 42, 365, 1, 0, 0),
(0, 13, 42, 224, 6, 0, 0),
(0, 13, 42, 226, 1, 0, 0),
(0, 13, 42, 292, 2, 0, 0),
(0, 13, 42, 368, 3, 0, 0),
(0, 13, 42, 380, 1, 0, 0),
(0, 13, 42, 202, 2, 0, 0),
(0, 13, 42, 180, 3, 0, 0),
(0, 13, 42, 127, 2, 0, 0),
(0, 13, 42, 128, 2, 0, 0),
(0, 13, 42, 351, 1, 0, 0),
(0, 13, 42, 129, 4, 0, 0),
(0, 13, 42, 204, 3, 0, 0),
(0, 13, 42, 222, 4, 0, 0),
(0, 13, 46, 107, 2, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `cafepassion_tracking_customer`
--

CREATE TABLE IF NOT EXISTS `cafepassion_tracking_customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_tracking` int(11) NOT NULL,
  `id_customer` int(11) NOT NULL,
  `value_session1` int(11) NOT NULL,
  `value_session2` int(11) NOT NULL,
  `value_collect` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `cafepassion_tracking_customer`
--


-- --------------------------------------------------------

--
-- Table structure for table `cafepassion_tracking_daily`
--

CREATE TABLE IF NOT EXISTS `cafepassion_tracking_daily` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_tracking` int(11) NOT NULL,
  `date` date NOT NULL,
  `selling` bigint(20) NOT NULL,
  `import` bigint(20) NOT NULL,
  `store` bigint(20) NOT NULL,
  `paid` bigint(20) NOT NULL,
  `collect` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=119 ;

--
-- Dumping data for table `cafepassion_tracking_daily`
--

INSERT INTO `cafepassion_tracking_daily` (`id`, `id_tracking`, `date`, `selling`, `import`, `store`, `paid`, `collect`) VALUES
(1, 12, '2013-12-01', 0, 0, 0, 0, 0),
(2, 12, '2013-12-02', 0, 0, 0, 0, 0),
(3, 12, '2013-12-03', 0, 0, 0, 0, 0),
(4, 12, '2013-12-04', 0, 0, 0, 0, 0),
(5, 12, '2013-12-05', 0, 0, 0, 0, 0),
(6, 12, '2013-12-06', 390000, 320000, 146000, 0, 2000000),
(7, 12, '2013-12-07', 0, 0, 0, 0, 0),
(8, 12, '2013-12-08', 0, 0, 0, 0, 0),
(9, 12, '2013-12-09', 0, 0, 0, 0, 0),
(10, 12, '2013-12-10', 0, 0, 0, 0, 0),
(11, 12, '2013-12-11', 0, 0, 0, 0, 0),
(12, 12, '2013-12-12', 0, 0, 0, 0, 0),
(13, 12, '2013-12-13', 0, 0, 0, 0, 0),
(14, 12, '2013-12-14', 0, 0, 0, 0, 0),
(15, 12, '2013-12-15', 0, 0, 0, 0, 0),
(16, 12, '2013-12-16', 0, 0, 0, 0, 0),
(17, 12, '2013-12-17', 0, 0, 0, 0, 0),
(18, 12, '2013-12-18', 0, 0, 0, 0, 0),
(19, 12, '2013-12-19', 0, 0, 0, 0, 0),
(20, 12, '2013-12-20', 0, 0, 0, 0, 0),
(21, 12, '2013-12-21', 0, 0, 0, 0, 0),
(22, 12, '2013-12-22', 0, 0, 0, 0, 0),
(23, 12, '2013-12-23', 0, 0, 0, 0, 0),
(24, 12, '2013-12-24', 0, 0, 0, 0, 0),
(25, 12, '2013-12-25', 0, 0, 0, 0, 0),
(26, 12, '2013-12-26', 0, 0, 0, 0, 0),
(27, 12, '2013-12-27', 0, 0, 0, 0, 0),
(28, 12, '2013-12-28', 0, 0, 0, 0, 0),
(29, 12, '2013-12-29', 0, 0, 146000, 0, 0),
(30, 12, '2013-12-30', 0, 0, 146000, 0, 0),
(31, 12, '2013-12-31', 0, 0, 146000, 0, 0),
(32, 13, '2014-01-01', 0, 45000, 0, 0, 0),
(33, 13, '2014-01-02', 0, 120000, 0, 0, 0),
(34, 13, '2014-01-03', 0, 30000, 0, 0, 0),
(35, 13, '2014-01-04', 26000, 0, 0, 0, 0),
(36, 13, '2014-01-05', 940000, 0, 0, 0, 0),
(37, 13, '2014-01-06', 2027000, 155000, 0, 85000, 0),
(38, 13, '2014-01-07', 1512000, 0, 0, 0, 0),
(39, 13, '2014-01-08', 1814000, 0, 0, 442000, 1500000),
(40, 13, '2014-01-09', 1138000, 0, 0, 207000, 2321000),
(41, 13, '2014-01-10', 1509000, 0, 0, 570000, 2317000),
(42, 13, '2014-01-11', 1057000, 0, 0, 128000, 3096000),
(43, 13, '2014-01-12', 1213000, 0, 0, 0, 0),
(44, 13, '2014-01-13', 1247000, 0, 0, 0, 0),
(45, 13, '2014-01-14', 322000, 0, 0, 0, 0),
(46, 13, '2014-01-15', 16000, 0, 0, 0, 0),
(47, 13, '2014-01-16', 0, 0, 0, 0, 0),
(48, 13, '2014-01-17', 0, 0, 0, 0, 0),
(49, 13, '2014-01-18', 0, 0, 0, 0, 0),
(50, 13, '2014-01-19', 0, 0, 0, 0, 0),
(51, 13, '2014-01-20', 0, 0, 0, 0, 0),
(52, 13, '2014-01-21', 0, 0, 0, 0, 0),
(53, 13, '2014-01-22', 0, 0, 0, 0, 0),
(54, 13, '2014-01-23', 0, 0, 0, 0, 0),
(55, 13, '2014-01-24', 0, 0, 0, 0, 0),
(56, 13, '2014-01-25', 0, 0, 0, 0, 0),
(57, 13, '2014-01-26', 0, 0, 0, 0, 0),
(58, 13, '2014-01-27', 0, 0, 0, 0, 0),
(59, 13, '2014-01-28', 0, 0, 0, 0, 0),
(60, 13, '2014-01-29', 0, 0, 0, 0, 0),
(61, 13, '2014-01-30', 0, 0, 0, 0, 0),
(62, 13, '2014-01-31', 0, 0, 0, 0, 0),
(63, 14, '2014-02-01', 0, 0, 0, 0, 0),
(64, 14, '2014-02-02', 0, 0, 0, 0, 0),
(65, 14, '2014-02-03', 0, 0, 0, 0, 0),
(66, 14, '2014-02-04', 0, 0, 0, 0, 0),
(67, 14, '2014-02-05', 0, 0, 0, 0, 0),
(68, 14, '2014-02-06', 0, 0, 0, 0, 0),
(69, 14, '2014-02-07', 0, 0, 0, 0, 0),
(70, 14, '2014-02-08', 0, 0, 0, 0, 0),
(71, 14, '2014-02-09', 0, 0, 0, 0, 0),
(72, 14, '2014-02-10', 0, 0, 0, 0, 0),
(73, 14, '2014-02-11', 0, 0, 0, 0, 0),
(74, 14, '2014-02-12', 0, 0, 0, 0, 0),
(75, 14, '2014-02-13', 0, 0, 0, 0, 0),
(76, 14, '2014-02-14', 0, 0, 0, 0, 0),
(77, 14, '2014-02-15', 0, 0, 0, 0, 0),
(78, 14, '2014-02-16', 0, 0, 0, 0, 0),
(79, 14, '2014-02-17', 0, 0, 0, 0, 0),
(80, 14, '2014-02-18', 0, 0, 0, 0, 0),
(81, 14, '2014-02-19', 0, 0, 0, 0, 0),
(82, 14, '2014-02-20', 0, 0, 0, 0, 0),
(83, 14, '2014-02-21', 0, 0, 0, 0, 0),
(84, 14, '2014-02-22', 0, 0, 0, 0, 0),
(85, 14, '2014-02-23', 0, 0, 0, 0, 0),
(86, 14, '2014-02-24', 0, 0, 0, 0, 0),
(87, 14, '2014-02-25', 0, 0, 0, 0, 0),
(88, 14, '2014-02-26', 0, 0, 0, 0, 0),
(89, 14, '2014-02-27', 0, 0, 0, 0, 0),
(90, 14, '2014-02-28', 0, 0, 0, 0, 0),
(91, 15, '2014-02-01', 0, 0, 0, 0, 0),
(92, 15, '2014-02-02', 0, 0, 0, 0, 0),
(93, 15, '2014-02-03', 0, 0, 0, 0, 0),
(94, 15, '2014-02-04', 0, 0, 0, 0, 0),
(95, 15, '2014-02-05', 0, 0, 0, 0, 0),
(96, 15, '2014-02-06', 0, 0, 0, 0, 0),
(97, 15, '2014-02-07', 0, 0, 0, 0, 0),
(98, 15, '2014-02-08', 0, 0, 0, 0, 0),
(99, 15, '2014-02-09', 0, 0, 0, 0, 0),
(100, 15, '2014-02-10', 0, 0, 0, 0, 0),
(101, 15, '2014-02-11', 0, 0, 0, 0, 0),
(102, 15, '2014-02-12', 0, 0, 0, 0, 0),
(103, 15, '2014-02-13', 0, 0, 0, 0, 0),
(104, 15, '2014-02-14', 0, 0, 0, 0, 0),
(105, 15, '2014-02-15', 0, 0, 0, 0, 0),
(106, 15, '2014-02-16', 0, 0, 0, 0, 0),
(107, 15, '2014-02-17', 0, 0, 0, 0, 0),
(108, 15, '2014-02-18', 0, 0, 0, 0, 0),
(109, 15, '2014-02-19', 0, 0, 0, 0, 0),
(110, 15, '2014-02-20', 0, 0, 0, 0, 0),
(111, 15, '2014-02-21', 0, 0, 0, 0, 0),
(112, 15, '2014-02-22', 0, 0, 0, 0, 0),
(113, 15, '2014-02-23', 0, 0, 0, 0, 0),
(114, 15, '2014-02-24', 0, 0, 0, 0, 0),
(115, 15, '2014-02-25', 0, 0, 0, 0, 0),
(116, 15, '2014-02-26', 0, 0, 0, 0, 0),
(117, 15, '2014-02-27', 0, 0, 0, 0, 0),
(118, 15, '2014-02-28', 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `cafepassion_tracking_store`
--

CREATE TABLE IF NOT EXISTS `cafepassion_tracking_store` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_tracking` int(11) NOT NULL,
  `id_td` int(11) NOT NULL,
  `id_resource` int(11) NOT NULL,
  `count_old` float NOT NULL,
  `count_import` float NOT NULL,
  `count_export` float NOT NULL,
  `price` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1723 ;

--
-- Dumping data for table `cafepassion_tracking_store`
--

INSERT INTO `cafepassion_tracking_store` (`id`, `id_tracking`, `id_td`, `id_resource`, `count_old`, `count_import`, `count_export`, `price`) VALUES
(1707, 12, 6, 19, 0, 2, 0.9, 60000),
(1708, 12, 6, 20, 0, 1, 0, 80000),
(1709, 12, 6, 35, 0, 0, 0, 160000),
(1710, 12, 6, 36, 0, 0, 0, 185000),
(1711, 12, 30, 19, 1.1, 0, 0, 60000),
(1712, 12, 30, 20, 1, 0, 0, 80000),
(1713, 12, 30, 35, 0, 0, 0, 160000),
(1714, 12, 30, 36, 0, 0, 0, 185000),
(1715, 12, 29, 19, 1.1, 0, 0, 60000),
(1716, 12, 29, 20, 1, 0, 0, 80000),
(1717, 12, 29, 35, 0, 0, 0, 160000),
(1718, 12, 29, 36, 0, 0, 0, 185000),
(1719, 12, 31, 19, 1.1, 0, 0, 60000),
(1720, 12, 31, 20, 1, 0, 0, 80000),
(1721, 12, 31, 35, 0, 0, 0, 160000),
(1722, 12, 31, 36, 0, 0, 0, 185000);

-- --------------------------------------------------------

--
-- Table structure for table `cafepassion_unit`
--

CREATE TABLE IF NOT EXISTS `cafepassion_unit` (
  `id` int(25) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=29 ;

--
-- Dumping data for table `cafepassion_unit`
--

INSERT INTO `cafepassion_unit` (`id`, `name`) VALUES
(1, 'Ly'),
(2, 'Điếu'),
(3, 'Chai'),
(4, 'Lon'),
(5, 'Dĩa'),
(6, 'Thùng'),
(7, 'Két'),
(9, 'Bịch'),
(10, 'Gói'),
(20, 'Trái'),
(21, 'Cái'),
(22, 'Hủ'),
(23, 'Kg'),
(24, 'Phần'),
(25, 'Bàn'),
(26, 'Hộp'),
(27, 'Bao'),
(28, 'Cây');

-- --------------------------------------------------------

--
-- Table structure for table `cafepassion_user`
--

CREATE TABLE IF NOT EXISTS `cafepassion_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pass` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gender` int(11) NOT NULL,
  `note` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `datecreate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dateupdate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `dateactivity` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `type` tinyint(4) NOT NULL,
  `code` varchar(13) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

--
-- Dumping data for table `cafepassion_user`
--

INSERT INTO `cafepassion_user` (`id`, `name`, `email`, `pass`, `gender`, `note`, `datecreate`, `dateupdate`, `dateactivity`, `type`, `code`) VALUES
(3, 'Thanh Tân', 'tsontung@yahoo.com', '123456', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 2, ''),
(4, 'Quan Ly', 'tuanbuithanh@gmail.com', '123456', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 4, '');

-- --------------------------------------------------------

--
-- Table structure for table `cafethemxua_category`
--

CREATE TABLE IF NOT EXISTS `cafethemxua_category` (
  `id` int(25) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `picture` binary(255) DEFAULT NULL,
  `enable` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=26 ;

--
-- Dumping data for table `cafethemxua_category`
--

INSERT INTO `cafethemxua_category` (`id`, `name`, `picture`, `enable`) VALUES
(3, 'Cafe', NULL, 1),
(8, 'Sinh tố', NULL, 0),
(11, 'Nước ép', '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0', 1),
(13, 'Yaourt', NULL, 0),
(14, 'Nước giải khát', '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0', 1),
(15, 'Nước pha chế', NULL, 0),
(16, 'Lipton - Trà', '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0', 1),
(17, 'Sữa tươi', NULL, 0),
(21, 'Điểm tâm sáng', 'abc.com\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0', 1),
(23, 'Khác', '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0', 1),
(25, 'Thuốc lá', NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `cafethemxua_collect_customer`
--

CREATE TABLE IF NOT EXISTS `cafethemxua_collect_customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idcustomer` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cafethemxua_customer_collect_1` (`idcustomer`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `cafethemxua_collect_customer`
--


-- --------------------------------------------------------

--
-- Table structure for table `cafethemxua_collect_general`
--

CREATE TABLE IF NOT EXISTS `cafethemxua_collect_general` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_term` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cafethemxua_collect_1` (`id_term`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=12 ;

--
-- Dumping data for table `cafethemxua_collect_general`
--

INSERT INTO `cafethemxua_collect_general` (`id`, `id_term`, `date`, `value`, `note`) VALUES
(5, 2, '2013-05-18', 10, 'd'),
(6, 3, '2013-12-06', 2000000, 'Bổ sung quỹ'),
(7, 3, '2014-01-08', 1500000, 'Bổng sung quỹ (a. Thông)'),
(8, 3, '2014-01-09', 2321000, 'Quy kho 09.01.2014'),
(9, 3, '2014-01-10', 2272000, 'quỹ kho 10-01-2014'),
(10, 3, '2014-01-10', 45000, 'bán chai nhựa'),
(11, 3, '2014-01-11', 3096000, 'quỹ 11-01-2014');

-- --------------------------------------------------------

--
-- Table structure for table `cafethemxua_config`
--

CREATE TABLE IF NOT EXISTS `cafethemxua_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `param` varchar(125) COLLATE utf8_unicode_ci NOT NULL,
  `value` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=15 ;

--
-- Dumping data for table `cafethemxua_config`
--

INSERT INTO `cafethemxua_config` (`id`, `param`, `value`) VALUES
(5, 'DISCOUNT', '0'),
(6, 'ROW_PER_PAGE', '12'),
(7, 'GUEST_VISIT', '9247'),
(8, 'EVERY_5_MINUTES', '2000'),
(9, 'THEME', 'grey'),
(10, 'CATEGORY_AUTO', '3'),
(11, 'SWITCH_BOARD_CALL', '1'),
(12, 'RECEIPT_VIRTUAL_DOUBLE', '1'),
(13, 'CATEGORY_AUTO', '3'),
(14, 'CATEGORY_AUTO', '3');

-- --------------------------------------------------------

--
-- Table structure for table `cafethemxua_course`
--

CREATE TABLE IF NOT EXISTS `cafethemxua_course` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idcategory` int(25) DEFAULT NULL,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `shortname` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `unit` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `price1` bigint(20) NOT NULL,
  `price2` bigint(20) NOT NULL,
  `price3` bigint(20) NOT NULL,
  `price4` bigint(20) NOT NULL,
  `picture` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_discount` int(11) NOT NULL DEFAULT '1',
  `enable` int(11) NOT NULL,
  `prepare` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `foreign_field` (`idcategory`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=386 ;

--
-- Dumping data for table `cafethemxua_course`
--

INSERT INTO `cafethemxua_course` (`id`, `idcategory`, `name`, `shortname`, `unit`, `price1`, `price2`, `price3`, `price4`, `picture`, `is_discount`, `enable`, `prepare`) VALUES
(53, 8, 'Sinh tố Bơ', 'Sinh tố Bơ', 'Ly', 20000, 20000, 20000, 20000, '', 1, 1, 0),
(54, 8, 'Sinh tố Cà chua', 'Sinh tố Cà chua', 'Ly', 15000, 15000, 15000, 15000, '', 1, 1, 0),
(55, 8, 'Sinh tố Cà rốt', 'Sinh tố Cà rốt', 'Ly', 15000, 15000, 15000, 15000, '', 1, 1, 0),
(56, 8, 'Sinh tố cam', 'Sinh tố cam', 'Ly', 15000, 15000, 15000, 15000, '', 1, 1, 0),
(107, 3, 'Cafe đá', 'Cafe đá', 'Ly', 8000, 8000, 8000, 8000, '', 1, 1, 0),
(108, 3, 'Cafe nóng', 'Cafe nóng', 'Ly', 8000, 8000, 8000, 8000, '', 1, 1, 0),
(112, 3, 'Cafe Sữa nóng', 'Cafe Sữa nóng', 'Ly', 10000, 10000, 10000, 10000, '', 1, 1, 0),
(126, 8, 'Sinh tố chanh', 'Sinh tố chanh', 'Ly', 15000, 15000, 15000, 15000, '', 1, 1, 0),
(127, 8, 'Sinh tố dâu', 'Sinh tố dâu', 'Ly', 22000, 22000, 22000, 22000, '', 1, 1, 0),
(128, 8, 'Sinh tố Mãng cầu', 'Sinh tố Mãng cầu', 'Ly', 15000, 15000, 15000, 15000, '', 1, 1, 0),
(129, 8, 'Sinh tố sapô', 'Sinh tố sapô', 'Ly', 15000, 15000, 15000, 15000, '', 1, 1, 0),
(136, 8, 'Sinh tố thập cẩm', 'Sinh tố thập cẩm', 'Ly', 20000, 20000, 20000, 20000, '', 1, 1, 0),
(149, 13, 'Yaourt cam tươi', 'Yaourt cam tươi', 'Ly', 17000, 17000, 17000, 17000, '', 1, 1, 0),
(161, 13, 'Yaourt dâu', 'Yaourt dâu', 'Ly', 20000, 20000, 20000, 20000, '', 1, 1, 0),
(162, 13, 'Yaourt hủ', 'Yaourt hủ', 'Hủ', 10000, 10000, 10000, 10000, '', 1, 1, 0),
(174, 15, 'Dừa đá', 'Dừa đá', 'Ly', 12000, 12000, 12000, 12000, '', 1, 1, 0),
(175, 15, 'Dừa trái', 'Dừa trái', 'Trái', 12000, 12000, 12000, 12000, '', 1, 1, 0),
(176, 15, 'Đá me', 'Đá me', 'Ly', 8000, 8000, 8000, 8000, '', 1, 1, 0),
(177, 15, 'Đá me sữa', 'Đá me sữa', 'Ly', 12000, 12000, 12000, 12000, '', 1, 1, 0),
(178, 15, 'Rau má dừa', 'Rau má dừa', 'Ly', 13000, 13000, 13000, 13000, '', 1, 1, 0),
(179, 15, 'Rau má sữa', 'Rau má sữa', 'Ly', 15000, 15000, 15000, 15000, '', 1, 1, 0),
(180, 15, 'Rau má thường', 'Rau má thường', 'Ly', 8000, 8000, 8000, 8000, '', 1, 1, 0),
(181, 15, 'Tắc xí muội nóng', 'Tắc xí muội nóng', 'Ly', 14000, 14000, 14000, 14000, '', 1, 1, 0),
(182, 15, 'Chanh xí muội nóng', 'Chanh xí muội nóng', 'Ly', 12000, 12000, 12000, 12000, '', 1, 1, 0),
(183, 15, 'Xí muội đá', 'Xí muội đá', 'Ly', 15000, 15000, 15000, 15000, '', 1, 1, 0),
(184, 15, 'Sâm dứa', 'Sâm dứa', 'Ly', 13000, 13000, 13000, 13000, '', 1, 1, 0),
(185, 15, 'Sâm dứa sữa', 'Sâm dứa sữa', 'Ly', 15000, 15000, 15000, 15000, '', 1, 1, 0),
(187, 11, 'Ép cà chua', 'Ép cà chua', 'Ly', 18000, 18000, 18000, 18000, '', 1, 1, 0),
(188, 11, 'Ép carrot', 'Ép carrot', 'Ly', 18000, 18000, 18000, 18000, '', 1, 1, 0),
(189, 11, 'Ép cam', 'Ép cam', 'Ly', 15000, 15000, 15000, 15000, '', 1, 1, 0),
(190, 11, 'Ép dâu', 'Ép dâu', 'Ly', 25000, 25000, 25000, 25000, '', 1, 1, 0),
(191, 11, 'Ép lê', 'Ép lê', 'Ly', 20000, 20000, 20000, 20000, '', 1, 1, 0),
(192, 11, 'Ép táo', 'Ép táo', 'Ly', 20000, 20000, 20000, 20000, '', 1, 1, 0),
(193, 11, 'Ép thơm', 'Ép thơm', 'Ly', 18000, 18000, 18000, 18000, '', 1, 1, 0),
(194, 14, '7 up', '7 up', 'Chai', 12000, 12000, 12000, 12000, '', 1, 1, 0),
(196, 14, 'Cam Twister', 'Cam Twister', 'Chai', 13000, 13000, 13000, 13000, '', 1, 1, 0),
(197, 14, 'Dr Thanh', 'Dr Thanh', 'Chai', 13000, 13000, 13000, 13000, '', 1, 1, 0),
(198, 14, 'Đậu nành', 'Đậu nành', 'Chai', 12000, 12000, 12000, 12000, '', 1, 1, 0),
(199, 14, 'Sting dâu sữa', 'Sting dâu sữa', 'Chai', 15000, 15000, 15000, 15000, '', 1, 1, 0),
(201, 14, 'Nước suối', 'Nước suối', 'Chai', 7000, 7000, 7000, 7000, '', 1, 1, 0),
(202, 14, 'Pepsi', 'Pepsi', 'Chai', 12000, 12000, 12000, 12000, '', 1, 1, 0),
(203, 14, 'Coca (chai nhựa)', 'Coca (chai nhựa)', 'Chai', 12000, 12000, 12000, 12000, '', 1, 1, 0),
(204, 14, 'Sting dâu', 'Sting dâu', 'Chai', 12000, 12000, 12000, 12000, '', 1, 1, 0),
(205, 14, 'Trà xanh 0 độ', 'Trà xanh 0 độ', 'Chai', 12000, 12000, 12000, 12000, '', 1, 1, 0),
(208, 17, 'Sữa dâu tươi', 'Sữa dâu tươi', 'Ly', 20000, 20000, 20000, 20000, '', 1, 1, 0),
(209, 17, 'Sữa nóng', 'Sữa nóng', 'Ly', 10000, 10000, 10000, 10000, '', 1, 1, 0),
(210, 17, 'Sữa thêm', 'Sữa thêm', 'Ly', 5000, 5000, 5000, 5000, '', 1, 1, 0),
(211, 17, 'Sữa đá', 'Sữa đá', 'Ly', 12000, 12000, 12000, 12000, '', 1, 1, 0),
(212, 17, 'Sữa tươi', 'Sữa tươi', 'Ly', 10000, 10000, 10000, 10000, '', 1, 1, 0),
(218, 16, 'Lipton sữa đá', 'Lipton sữa đá', 'Ly', 15000, 15000, 15000, 15000, '', 1, 1, 0),
(219, 16, 'Lipton sữa nóng', 'Lipton sữa nóng', 'Ly', 13000, 13000, 13000, 13000, '', 1, 1, 0),
(220, 16, 'Trà sữa', 'Trà sữa', 'Ly', 15000, 15000, 15000, 15000, '', 1, 1, 0),
(221, 16, 'Trà chanh', 'Trà chanh', 'Ly', 10000, 10000, 10000, 10000, '', 1, 1, 0),
(222, 16, 'Trà đường đá', 'Trà đường đá', 'Ly', 8000, 8000, 8000, 8000, '', 1, 1, 0),
(223, 16, 'Trà đường nóng', 'Trà đường nóng', 'Ly', 8000, 8000, 8000, 8000, '', 1, 1, 0),
(224, 16, 'Lipton đá', 'Lipton đá', 'Ly', 8000, 8000, 8000, 8000, '', 1, 1, 0),
(225, 16, 'Lipton mật ong nóng', 'Lipton mật ong nóng', 'Ly', 13000, 13000, 13000, 13000, '', 1, 1, 0),
(226, 16, 'Lipton nóng', 'Lipton nóng', 'Ly', 8000, 8000, 8000, 8000, '', 1, 1, 0),
(228, 13, 'Yaourt sữa đá', 'Yaourt sữa đá', 'Ly', 15000, 15000, 15000, 15000, '', 1, 1, 0),
(229, 13, 'Yaourt trái cây', 'Yaourt trái cây', 'Ly', 20000, 20000, 20000, 20000, '', 1, 1, 0),
(230, 21, 'Bò bít tết trứng', 'Bò bít tết trứng', 'Phần', 30000, 30000, 30000, 30000, '0', 0, 1, 0),
(231, 21, 'Bò bít tết ko trứng', 'Bò bít tết ko trứng', 'Phần', 25000, 25000, 25000, 25000, '0', 0, 1, 0),
(232, 21, 'Mì Ý', 'Mì Ý', 'Phần', 25000, 25000, 25000, 25000, '', 0, 1, 0),
(233, 21, 'Bánh mì ốp la chả', 'Bánh mì ốp la chả', 'Phần', 12000, 12000, 12000, 12000, '', 0, 0, 0),
(234, 21, 'Bánh mì ốp la', 'Bánh mì ốp la', 'Phần', 10000, 10000, 10000, 10000, '', 0, 0, 0),
(235, 21, 'Mì gói xào bò', 'Mì gói xào bò', 'Phần', 20000, 20000, 20000, 20000, '', 0, 1, 0),
(236, 21, 'Nui xào bò', 'Nui xào bò', 'Phần', 20000, 20000, 20000, 20000, '', 0, 1, 0),
(237, 21, 'Mì gói nấu bò', 'Mì gói nấu bò', 'Phần', 15000, 15000, 15000, 15000, '', 0, 1, 0),
(238, 21, 'Trứng thêm', 'Trứng thêm', 'Cái', 5000, 5000, 5000, 5000, '', 0, 1, 0),
(239, 21, 'Mì gói thêm', 'Mì gói thêm', 'Gói', 5000, 5000, 5000, 5000, '', 0, 1, 0),
(240, 21, 'Bánh mì thêm', 'Bánh mì thêm', 'Cái', 5000, 5000, 5000, 5000, '', 0, 0, 0),
(246, 16, 'Lipton mật ong đá', 'Lipton mật ong đá', 'Ly', 15000, 15000, 15000, 15000, '', 1, 1, 0),
(247, 16, 'Lipton xí muội nóng', 'Lipton xí muội nóng', 'Ly', 13000, 13000, 13000, 13000, '', 1, 1, 0),
(248, 16, 'Lipton xí muội đá', 'Lipton xí muội đá', 'Ly', 15000, 15000, 15000, 15000, '', 1, 1, 0),
(249, 16, 'Lipton bạc hà', 'Lipton bạc hà', 'Ly', 15000, 15000, 15000, 15000, '', 1, 1, 0),
(250, 16, 'Lipton cam', 'Lipton cam', 'Ly', 15000, 15000, 15000, 15000, '', 1, 1, 0),
(252, 16, 'Trà cúc nóng', 'Trà cúc nóng', 'Ly', 10000, 10000, 10000, 10000, '', 1, 1, 0),
(253, 16, 'Trà cúc đá', 'Trà cúc đá', 'Ly', 10000, 10000, 10000, 10000, '', 1, 1, 0),
(255, 3, 'Cafe Sữa đá', 'Cafe Sữa đá', 'Ly', 12000, 12000, 12000, 12000, '', 0, 1, 0),
(260, 3, 'Cafe Miền Tây', 'Cafe Đam mê', 'Ly', 15000, 15000, 15000, 15000, '', 1, 1, 0),
(265, 15, 'Chanh nóng', 'Chanh nóng', 'Ly', 8000, 8000, 8000, 8000, '', 1, 1, 0),
(267, 15, 'Chanh muối nóng', 'Chanh muối nóng', 'Ly', 8000, 8000, 8000, 8000, '', 1, 1, 0),
(268, 15, 'Chanh muối đá', 'Chanh muối đá', 'Ly', 8000, 8000, 8000, 8000, '', 1, 1, 0),
(269, 15, 'Chanh rhum', 'Chanh rhum', 'Ly', 15000, 15000, 15000, 15000, '', 1, 1, 0),
(270, 15, 'Xí muội nóng', 'Xí muội nóng', 'Ly', 14000, 14000, 14000, 14000, '', 1, 1, 0),
(271, 15, 'Chanh xí muội đá', 'Chanh xí muội đá', 'Ly', 12000, 12000, 12000, 12000, '', 1, 1, 0),
(272, 15, 'Chanh muối xí muội', 'Chanh muối xí muội', 'Ly', 10000, 10000, 10000, 10000, '', 1, 1, 0),
(273, 15, 'Tắc xí muội đá', 'Tắc xí muội đá', 'Ly', 15000, 15000, 15000, 15000, '', 1, 1, 0),
(274, 15, 'Bạc hà', 'Bạc hà', 'Ly', 13000, 13000, 13000, 13000, '', 1, 1, 0),
(275, 15, 'Bạc hà sữa', 'Bạc hà sữa', 'Ly', 15000, 15000, 15000, 15000, '', 1, 1, 0),
(276, 15, 'Siro dâu', 'Siro dâu', 'Ly', 13000, 13000, 13000, 13000, '', 1, 1, 0),
(277, 15, 'Đá me xí muội', 'Đá me xí muội', 'Ly', 15000, 15000, 15000, 15000, '', 1, 1, 0),
(278, 15, 'Siro dâu sữa', 'Siro dâu sữa', 'Ly', 15000, 15000, 15000, 15000, '', 1, 1, 0),
(279, 8, 'Sinh tố chanh dây', 'Sinh tố chanh dây', 'Ly', 20000, 20000, 20000, 20000, '', 1, 1, 0),
(280, 8, 'Sinh tố Thơm', 'Sinh tố Thơm', 'Ly', 15000, 15000, 15000, 15000, '', 1, 1, 0),
(281, 8, 'Sinh tố Dừa', 'Sinh tố Dừa', 'Ly', 15000, 15000, 15000, 15000, '', 1, 1, 0),
(282, 8, 'Sinh tố Táo', 'Sinh tố Táo', 'Ly', 20000, 20000, 20000, 20000, '', 1, 1, 0),
(283, 8, 'Sinh tố Lê', 'Sinh tố Lê', 'Ly', 20000, 20000, 20000, 20000, '', 1, 1, 0),
(284, 8, 'ST rau má dừa', 'ST rau má dừa', 'Ly', 15000, 15000, 15000, 15000, '', 1, 1, 0),
(285, 8, 'Sinh tố Bưởi', 'Sinh tố Bưởi', 'Ly', 20000, 20000, 20000, 20000, '', 1, 1, 0),
(286, 8, 'Sinh tố Cafe', 'Sinh tố Cafe', 'Ly', 15000, 15000, 15000, 15000, '', 1, 1, 0),
(287, 8, 'ST tự chọn 2 món', 'ST tự chọn 2 món', 'Ly', 20000, 20000, 20000, 20000, '', 1, 1, 0),
(288, 8, 'ST tự chọn 3 món', 'ST tự chọn 3 món', 'Ly', 25000, 25000, 25000, 25000, '', 1, 1, 0),
(289, 8, 'ST tự chọn 4 món', 'ST tự chọn 4 món', 'Ly', 28000, 28000, 28000, 28000, '', 1, 1, 0),
(290, 8, 'ST chanh muối', 'ST chanh muối', 'Ly', 15000, 15000, 15000, 15000, '', 1, 1, 0),
(291, 8, 'Dâu dằm', 'Dâu dằm', 'Ly', 25000, 25000, 25000, 25000, '', 1, 1, 0),
(292, 8, 'Mãng cầu dằm', 'Mãng cầu dằm', 'Ly', 17000, 17000, 17000, 17000, '', 1, 1, 0),
(293, 8, 'Bơ dầm', 'Bơ dầm', 'Ly', 25000, 25000, 25000, 25000, '', 1, 1, 0),
(305, 11, 'Ép 4 mùa', 'Ép 4 mùa', 'Ly', 28000, 28000, 28000, 28000, '', 1, 1, 0),
(306, 11, 'Ép bưởi', 'Ép bưởi', 'Ly', 20000, 20000, 20000, 20000, '', 1, 1, 0),
(307, 11, 'Ép cam mật ong', 'Ép cam mật ong', 'Ly', 22000, 22000, 22000, 22000, '', 1, 1, 0),
(308, 11, 'Ép cam sữa', 'Ép cam sữa', 'Ly', 18000, 18000, 18000, 18000, '', 1, 1, 0),
(309, 11, 'Ép chanh dây', 'Ép chanh dây', 'Ly', 20000, 20000, 20000, 20000, '', 1, 1, 0),
(310, 11, 'Ép dâu sữa', 'Ép dâu sữa', 'Ly', 26000, 26000, 26000, 26000, '', 1, 1, 0),
(311, 11, 'Ép tự chọn 2 món', 'Ép tự chọn 2 món', 'Ly', 22000, 22000, 22000, 22000, '', 1, 1, 0),
(312, 11, 'Ép tự chọn 3 món', 'Ép tự chọn 3 món', 'Ly', 25000, 25000, 25000, 25000, '', 1, 1, 0),
(313, 13, 'Yaourt bạc hà', 'Yaourt bạc hà', 'Ly', 15000, 15000, 15000, 15000, '', 1, 1, 0),
(314, 13, 'Yaourt bưởi', 'Yaourt bưởi', 'Ly', 15000, 15000, 15000, 15000, '', 1, 1, 0),
(315, 13, 'Yaourt cafe đá', 'Yaourt cafe đá', 'Ly', 15000, 15000, 15000, 15000, '', 1, 1, 0),
(316, 13, 'Yaourt chanh dây', 'Yaourt chanh dây', 'Ly', 17000, 17000, 17000, 17000, '', 1, 1, 0),
(318, 17, 'Đậu nành nấu', 'Đậu nành nấu', 'Ly', 7000, 7000, 7000, 7000, '', 1, 1, 0),
(320, 17, 'Sữa chanh xí muội', 'Sữa chanh xí muội', 'Ly', 15000, 15000, 15000, 15000, '', 1, 1, 0),
(321, 17, 'Sữa tươi cacao đá', 'Sữa tươi cacao đá', 'Ly', 16000, 16000, 16000, 16000, '', 1, 1, 0),
(322, 17, 'Sữa tươi cafe', 'Sữa tươi cafe', 'Ly', 14000, 14000, 14000, 14000, '', 1, 1, 0),
(325, 23, 'Khăn lạnh', 'Khăn lạnh', 'Cái', 2000, 2000, 2000, 2000, '', 1, 1, 0),
(326, 23, 'Nước ép thêm', 'Nước ép thêm', 'Ly', 10000, 10000, 10000, 10000, '', 1, 1, 0),
(327, 23, 'Phụ thu nhạc', 'Phụ thu nhạc', 'Bàn', 5000, 5000, 5000, 5000, '', 0, 1, 0),
(328, 23, 'Phụ thu BĐ khuya/ người', 'Phụ thu BĐ khuya/ người', 'Phần', 2000, 2000, 2000, 2000, '', 0, 1, 0),
(329, 23, 'Rau má thêm', 'Rau má thêm', 'Ly', 5000, 5000, 5000, 5000, '', 1, 1, 0),
(330, 23, 'Trái cây dĩa lớn', 'Trái cây dĩa lớn', 'Dĩa', 35000, 35000, 35000, 35000, '', 1, 1, 0),
(331, 23, 'Trái cây dĩa nhỏ', 'Trái cây dĩa nhỏ', 'Dĩa', 25000, 25000, 25000, 25000, '', 1, 1, 0),
(332, 14, 'Rivive', 'Rivive', 'Chai', 12000, 12000, 12000, 12000, '', 0, 1, 0),
(333, 14, 'Mountain Dew', 'Mountain Dew', 'Chai', 12000, 12000, 12000, 12000, '', 0, 1, 0),
(334, 14, 'Trà Ô Long', 'Trà Ô Long', 'Chai', 12000, 12000, 12000, 12000, '', 0, 1, 0),
(335, 14, 'C2', 'C2', 'Chai', 10000, 10000, 10000, 10000, '', 0, 1, 0),
(338, 21, 'Mì không', 'Mì không', 'Gói', 7000, 7000, 7000, 7000, '', 0, 1, 0),
(349, 14, 'Samurai dâu', 'Samurai', 'Chai', 12000, 12000, 12000, 12000, '', 0, 1, 0),
(350, 14, 'Soda', 'Soda', 'Ly', 15000, 15000, 15000, 15000, '', 0, 1, 0),
(351, 8, 'Sinh tố mít', 'Sinh tố mít', 'Ly', 15000, 15000, 15000, 15000, '', 0, 1, 0),
(353, 14, 'Coca (chai thuỷ tinh)', 'Coca (chai thuỷ tinh)', 'Chai', 8000, 8000, 8000, 8000, '', 0, 1, 0),
(355, 15, 'Cam sữa', 'Cam sữa', 'Ly', 15000, 15000, 15000, 15000, '', 0, 1, 0),
(358, 15, 'Chanh đá', 'Chanh đá', 'Ly', 8000, 8000, 8000, 8000, '', 0, 1, 0),
(360, 25, 'Hero (20điếu)', 'Hero (20điếu)', 'Gói', 18000, 18000, 18000, 18000, '', 0, 1, 0),
(361, 25, 'Hero 1/2gói (10điếu)', 'Hero 1/2gói (10điếu)', 'Gói', 10000, 10000, 10000, 10000, '', 0, 1, 0),
(362, 25, 'Hero 1điếu', 'Hero 1điếu', 'Điếu', 1000, 1000, 1000, 1000, '', 0, 1, 0),
(363, 25, 'Jet (20điếu)', 'Jet (20điếu)', 'Gói', 20000, 20000, 20000, 20000, '', 0, 1, 0),
(364, 25, 'Jet 1 điếu', 'Jet 1 điếu', 'Điếu', 1000, 1000, 1000, 1000, '', 0, 1, 0),
(365, 25, 'Jet 1/2 gói (10điếu)', 'Jet 1/2 gói (10điếu)', 'Gói', 10000, 10000, 10000, 10000, '', 0, 1, 0),
(366, 25, 'Mèo lớn (20điếu)', 'Mèo lớn (20điếu)', 'Gói', 22000, 22000, 22000, 22000, '', 0, 1, 0),
(367, 25, 'Mèo trung (12điếu)', 'Mèo trung (12điếu)', 'Gói', 13000, 13000, 13000, 13000, '', 0, 1, 0),
(368, 25, 'Mèo tép (5điếu)', 'Mèo tép (5điếu)', 'Gói', 6000, 6000, 6000, 6000, '', 0, 1, 0),
(369, 25, 'Mèo (1điếu)', 'Mèo (1điếu)', 'Điếu', 1500, 1500, 1500, 1500, '', 0, 1, 0),
(370, 14, ' Tepy Cam', '', 'Chai', 12000, 12000, 12000, 12000, '', 0, 1, 0),
(371, 14, 'Nutri cam', '', 'Chai', 12000, 12000, 12000, 12000, '', 0, 1, 0),
(372, 15, 'TRà đường ca', 'TRà đường ca', 'Ly', 10000, 10000, 10000, 10000, '', 0, 1, 0),
(373, 14, 'nước suoi Dasani', 'nước suoi mang ve', 'Chai', 7000, 7000, 7000, 7000, '', 0, 1, 0),
(374, 14, 'Cam Fanta (chai thuy tinh)', 'Cam Fanta', 'Chai', 8000, 8000, 8000, 8000, '', 0, 1, 0),
(375, 14, 'Xá xị Fanta', '', 'Chai', 8000, 8000, 8000, 8000, '', 0, 1, 0),
(376, 14, 'Sprite chai thuy tinh', 'Sprite', 'Chai', 8000, 8000, 8000, 8000, '', 0, 1, 0),
(377, 14, 'Cam Fanta ( chai nhựa)', '', 'Chai', 12000, 12000, 12000, 12000, '', 0, 1, 0),
(378, 14, 'Sprite chai nhựa', '', 'Chai', 12000, 12000, 12000, 12000, '', 0, 1, 0),
(379, 14, 'Xá xị chai nhựa', '', 'Chai', 12000, 12000, 12000, 12000, '', 0, 1, 0),
(380, 14, 'Nước suối AQuat', '', 'Chai', 10000, 10000, 10000, 10000, '', 0, 1, 0),
(381, 14, 'Samurai tăng lực', '', 'Chai', 12000, 12000, 12000, 12000, '', 0, 1, 0),
(385, 3, 'ABVC', 'ABVC', 'Bàn', 2, 2, 2, 2, '', 0, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `cafethemxua_customer`
--

CREATE TABLE IF NOT EXISTS `cafethemxua_customer` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  `card` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `note` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `discount` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `cafethemxua_customer`
--

INSERT INTO `cafethemxua_customer` (`id`, `name`, `type`, `card`, `phone`, `address`, `note`, `discount`) VALUES
(1, 'Khách lẻ', 0, '', '', '', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `cafethemxua_domain`
--

CREATE TABLE IF NOT EXISTS `cafethemxua_domain` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=8 ;

--
-- Dumping data for table `cafethemxua_domain`
--

INSERT INTO `cafethemxua_domain` (`id`, `name`) VALUES
(1, 'Số bàn'),
(7, 'Khách vãng lai');

-- --------------------------------------------------------

--
-- Table structure for table `cafethemxua_employee`
--

CREATE TABLE IF NOT EXISTS `cafethemxua_employee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `job` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `gender` tinyint(2) NOT NULL,
  `phone` varchar(13) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `salary_base` int(11) NOT NULL,
  `card` varchar(13) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=10 ;

--
-- Dumping data for table `cafethemxua_employee`
--

INSERT INTO `cafethemxua_employee` (`id`, `name`, `job`, `gender`, `phone`, `address`, `salary_base`, `card`) VALUES
(1, 'Ngọc', 'Phục vụ', 1, '01635758021', 'Mang Thít', 1800000, '12345678'),
(2, 'Trinh', 'Phục vụ', 1, '01649 359 321', 'Đồng Tháp', 1800000, ''),
(3, 'Nguyệt', 'Phục vụ', 1, '0164 220 95 9', 'Đồng Tháp', 1800000, ''),
(4, 'Nhi', 'Phục vụ', 1, '01629 655 287', 'Cần Thơ', 1800000, ''),
(5, 'Duy', 'Phục vụ', 0, '01882356234', 'P2, Tp.Vĩnh Long', 1800000, ''),
(6, 'Dũng', 'Giữ xe', 0, '0907 615 003', 'Quảng Bình', 1800000, ''),
(7, 'Nguyên', 'Nhân viên', 0, '01665685873', 'P3, TP VLong', 1800000, ''),
(8, 'Tân', 'Thu ngân', 0, '0989 975 603', 'Tam Bình', 2500000, ''),
(9, 'Hằng', 'NV', 1, '01286962340', 'vinh long', 1800000, '');

-- --------------------------------------------------------

--
-- Table structure for table `cafethemxua_guest`
--

CREATE TABLE IF NOT EXISTS `cafethemxua_guest` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(16) CHARACTER SET latin1 NOT NULL,
  `entry_time` varchar(32) CHARACTER SET latin1 NOT NULL,
  `exit_time` varchar(32) CHARACTER SET latin1 NOT NULL,
  `agent` varchar(16) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=150 ;

--
-- Dumping data for table `cafethemxua_guest`
--

INSERT INTO `cafethemxua_guest` (`id`, `ip`, `entry_time`, `exit_time`, `agent`) VALUES
(149, '115.78.94.118', '1383319305', '1383322905', '115.78.94.118');

-- --------------------------------------------------------

--
-- Table structure for table `cafethemxua_order_import`
--

CREATE TABLE IF NOT EXISTS `cafethemxua_order_import` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idsupplier` int(11) NOT NULL,
  `date` date NOT NULL,
  `description` varchar(50) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id`),
  KEY `cafethemxua_order_import_1` (`idsupplier`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=359 ;

--
-- Dumping data for table `cafethemxua_order_import`
--

INSERT INTO `cafethemxua_order_import` (`id`, `idsupplier`, `date`, `description`) VALUES
(348, 8, '2013-12-06', ''),
(349, 8, '2014-01-02', ''),
(350, 9, '2013-12-30', 'Nhập hàng lần 1'),
(352, 1, '2013-12-31', 'Đá viên'),
(353, 1, '2014-01-01', 'Đá viên'),
(354, 1, '2014-01-02', 'Đá viên'),
(355, 1, '2014-01-03', 'Đá viên'),
(356, 1, '2014-01-06', 'Đá viên + Đá ướp'),
(357, 12, '2014-01-06', 'Dừa'),
(358, 13, '2014-01-03', 'Trà lài');

-- --------------------------------------------------------

--
-- Table structure for table `cafethemxua_order_import_detail`
--

CREATE TABLE IF NOT EXISTS `cafethemxua_order_import_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idorder` int(11) NOT NULL,
  `idresource` int(11) NOT NULL,
  `count` float NOT NULL,
  `price` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `cafethemxua_order_import_detail_1` (`idorder`),
  KEY `cafethemxua_order_import_detail_2` (`idresource`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=653 ;

--
-- Dumping data for table `cafethemxua_order_import_detail`
--

INSERT INTO `cafethemxua_order_import_detail` (`id`, `idorder`, `idresource`, `count`, `price`) VALUES
(634, 348, 19, 2, 60000),
(635, 348, 20, 1, 80000),
(636, 348, 101, 1, 120000),
(637, 349, 19, 1, 60000),
(638, 350, 35, 2, 160000),
(639, 350, 36, 5, 185000),
(640, 350, 43, 5, 170000),
(641, 350, 103, 5, 105000),
(642, 350, 104, 2, 105000),
(643, 350, 105, 1, 174000),
(644, 350, 106, 1, 135000),
(645, 350, 109, 1, 142000),
(646, 352, 2, 9, 15000),
(647, 353, 2, 3, 15000),
(648, 354, 2, 4, 15000),
(649, 355, 2, 2, 15000),
(650, 356, 2, 5, 15000),
(651, 356, 14, 1, 10000),
(652, 357, 110, 10, 7000);

-- --------------------------------------------------------

--
-- Table structure for table `cafethemxua_paid_customer`
--

CREATE TABLE IF NOT EXISTS `cafethemxua_paid_customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idcustomer` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cafethemxua_customer_paid_1` (`idcustomer`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `cafethemxua_paid_customer`
--


-- --------------------------------------------------------

--
-- Table structure for table `cafethemxua_paid_employee`
--

CREATE TABLE IF NOT EXISTS `cafethemxua_paid_employee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_employee` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(150) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_employee` (`id_employee`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `cafethemxua_paid_employee`
--

INSERT INTO `cafethemxua_paid_employee` (`id`, `id_employee`, `date`, `value`, `note`) VALUES
(4, 2, '2014-01-06', 200000, 'ứng lương'),
(5, 8, '2014-01-03', 500000, 'ung luong');

-- --------------------------------------------------------

--
-- Table structure for table `cafethemxua_paid_general`
--

CREATE TABLE IF NOT EXISTS `cafethemxua_paid_general` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_term` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cafethemxua_paid_1` (`id_term`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=175 ;

--
-- Dumping data for table `cafethemxua_paid_general`
--

INSERT INTO `cafethemxua_paid_general` (`id`, `id_term`, `date`, `value`, `note`) VALUES
(9, 10, '2013-04-01', 157000, 'Chi tiền chợ'),
(10, 10, '2013-04-02', 146000, 'Tiền chợ'),
(11, 10, '2013-04-03', 189000, 'Tiền chợ'),
(12, 10, '2013-04-04', 184000, 'Tiền chợ'),
(66, 2, '2013-04-30', 2100000, 'Tạm tính'),
(111, 3, '2013-07-31', 1500000, 'Thuế TTĐB Tháng 07'),
(112, 1, '2013-07-31', 4000000, 'Tiền điện T07'),
(113, 2, '2013-07-31', 2000000, 'Tiền nước T07'),
(155, 3, '2013-08-31', 800000, 'Thuế TTĐB T08'),
(156, 3, '2013-09-30', 850000, 'Thuế TTĐB T09'),
(158, 1, '2013-08-31', 5800000, 'Tiền điện T08'),
(159, 1, '2013-09-30', 3700000, 'Tiền điện T09'),
(160, 2, '2013-08-31', 2200000, 'Tiền nước T08'),
(161, 2, '2013-09-30', 2300000, 'Tiền nước T09'),
(163, 1, '2013-05-31', 4700000, 'Tiền điện T05'),
(164, 1, '2013-06-30', 3900000, 'Tiền điện T06'),
(165, 2, '2013-05-31', 2350000, 'Tiền nước T05'),
(166, 2, '2013-06-30', 2260000, 'Tiền nước T06'),
(167, 11, '2014-01-06', 85000, 'Chi mua Cam'),
(168, 10, '2014-01-08', 186000, 'tien an sáng(30),com trưa( 84), cơm chều(72)'),
(169, 11, '2014-01-08', 256000, 'Chi mua cong tv 26, than da 50, chanh 30, sapo 16,'),
(170, 10, '2014-01-09', 207000, 'Tiền chợ'),
(171, 10, '2014-01-10', 163000, 'chợ'),
(172, 11, '2014-01-10', 70000, 'Dừa trái '),
(173, 11, '2014-01-10', 337000, '1c jet, 1c meo tet, giay ve sinh, xoai an'),
(174, 10, '2014-01-11', 128000, 'an sáng, chợ');

-- --------------------------------------------------------

--
-- Table structure for table `cafethemxua_paid_pay_roll`
--

CREATE TABLE IF NOT EXISTS `cafethemxua_paid_pay_roll` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_employee` int(11) NOT NULL,
  `date` date NOT NULL,
  `value_base` int(11) NOT NULL,
  `value_sub` int(11) NOT NULL,
  `value_pre` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cafethemxua_paid_pay_roll_1` (`id_employee`),
  KEY `id_employee` (`id_employee`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `cafethemxua_paid_pay_roll`
--


-- --------------------------------------------------------

--
-- Table structure for table `cafethemxua_paid_supplier`
--

CREATE TABLE IF NOT EXISTS `cafethemxua_paid_supplier` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idsupplier` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cafethemxua_supplier_paid_1` (`idsupplier`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=18 ;

--
-- Dumping data for table `cafethemxua_paid_supplier`
--

INSERT INTO `cafethemxua_paid_supplier` (`id`, `idsupplier`, `date`, `value`, `note`) VALUES
(1, 1, '2012-08-01', 2300000, 'được không ?'),
(2, 1, '2012-07-03', 350000, 'Ghi chú gì đây'),
(3, 1, '2012-07-26', 750000, 'Ghi ghi gì gì đó'),
(8, 6, '2012-09-19', 1000000, 'Thử nè được không đó !'),
(9, 1, '2012-09-19', 1000000, 'lung tung quá đi'),
(11, 1, '2012-01-01', 123, 'sdfdsfggf'),
(12, 1, '2012-09-24', 1230000, 'đâu biết'),
(13, 1, '2012-09-24', 1213232, ''),
(14, 1, '2012-09-24', 34243243, ''),
(15, 1, '2012-09-24', 21323, ''),
(16, 1, '2012-09-24', 123323, ''),
(17, 1, '2012-09-24', 21323, '');

-- --------------------------------------------------------

--
-- Table structure for table `cafethemxua_pay_roll`
--

CREATE TABLE IF NOT EXISTS `cafethemxua_pay_roll` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_employee` int(11) NOT NULL,
  `date` date NOT NULL,
  `session1` int(11) NOT NULL,
  `session2` int(11) NOT NULL,
  `session3` int(11) NOT NULL,
  `extra` int(11) NOT NULL,
  `late` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_employee` (`id_employee`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=410 ;

--
-- Dumping data for table `cafethemxua_pay_roll`
--

INSERT INTO `cafethemxua_pay_roll` (`id`, `id_employee`, `date`, `session1`, `session2`, `session3`, `extra`, `late`) VALUES
(131, 1, '2014-01-01', 0, 0, 0, 0, 0),
(132, 1, '2014-01-02', 0, 0, 0, 0, 0),
(133, 1, '2014-01-03', 0, 0, 0, 0, 0),
(134, 1, '2014-01-04', 0, 0, 0, 0, 0),
(135, 1, '2014-01-05', 0, 0, 0, 0, 0),
(136, 1, '2014-01-06', 0, 0, 0, 0, 0),
(137, 1, '2014-01-07', 0, 0, 0, 0, 0),
(138, 1, '2014-01-08', 1, 1, 1, 0, 0),
(139, 1, '2014-01-09', 1, 1, 1, 0, 0),
(140, 1, '2014-01-10', 1, 1, 1, 0, 0),
(141, 1, '2014-01-11', 1, 1, 1, 0, 0),
(142, 1, '2014-01-12', 0, 0, 0, 0, 0),
(143, 1, '2014-01-13', 0, 0, 0, 0, 0),
(144, 1, '2014-01-14', 0, 0, 0, 0, 0),
(145, 1, '2014-01-15', 0, 0, 0, 0, 0),
(146, 1, '2014-01-16', 0, 0, 0, 0, 0),
(147, 1, '2014-01-17', 0, 0, 0, 0, 0),
(148, 1, '2014-01-18', 0, 0, 0, 0, 0),
(149, 1, '2014-01-19', 0, 0, 0, 0, 0),
(150, 1, '2014-01-20', 0, 0, 0, 0, 0),
(151, 1, '2014-01-21', 0, 0, 0, 0, 0),
(152, 1, '2014-01-22', 0, 0, 0, 0, 0),
(153, 1, '2014-01-23', 0, 0, 0, 0, 0),
(154, 1, '2014-01-24', 0, 0, 0, 0, 0),
(155, 1, '2014-01-25', 0, 0, 0, 0, 0),
(156, 1, '2014-01-26', 0, 0, 0, 0, 0),
(157, 1, '2014-01-27', 0, 0, 0, 0, 0),
(158, 1, '2014-01-28', 0, 0, 0, 0, 0),
(159, 1, '2014-01-29', 0, 0, 0, 0, 0),
(160, 1, '2014-01-30', 0, 0, 0, 0, 0),
(161, 1, '2014-01-31', 0, 0, 0, 0, 0),
(162, 2, '2014-01-01', 0, 0, 0, 0, 0),
(163, 2, '2014-01-02', 0, 0, 0, 0, 0),
(164, 2, '2014-01-03', 0, 0, 0, 0, 0),
(165, 2, '2014-01-04', 0, 0, 0, 0, 0),
(166, 2, '2014-01-05', 0, 0, 0, 0, 0),
(167, 2, '2014-01-06', 0, 0, 0, 0, 0),
(168, 2, '2014-01-07', 0, 0, 0, 0, 0),
(169, 2, '2014-01-08', 0, 0, 1, 0, 0),
(170, 2, '2014-01-09', 0, 0, 1, 0, 0),
(171, 2, '2014-01-10', 0, 0, 0, 0, 0),
(172, 2, '2014-01-11', 0, 0, 0, 0, 0),
(173, 2, '2014-01-12', 0, 0, 0, 0, 0),
(174, 2, '2014-01-13', 0, 0, 0, 0, 0),
(175, 2, '2014-01-14', 0, 0, 0, 0, 0),
(176, 2, '2014-01-15', 0, 0, 0, 0, 0),
(177, 2, '2014-01-16', 0, 0, 0, 0, 0),
(178, 2, '2014-01-17', 0, 0, 0, 0, 0),
(179, 2, '2014-01-18', 0, 0, 0, 0, 0),
(180, 2, '2014-01-19', 0, 0, 0, 0, 0),
(181, 2, '2014-01-20', 0, 0, 0, 0, 0),
(182, 2, '2014-01-21', 0, 0, 0, 0, 0),
(183, 2, '2014-01-22', 0, 0, 0, 0, 0),
(184, 2, '2014-01-23', 0, 0, 0, 0, 0),
(185, 2, '2014-01-24', 0, 0, 0, 0, 0),
(186, 2, '2014-01-25', 0, 0, 0, 0, 0),
(187, 2, '2014-01-26', 0, 0, 0, 0, 0),
(188, 2, '2014-01-27', 0, 0, 0, 0, 0),
(189, 2, '2014-01-28', 0, 0, 0, 0, 0),
(190, 2, '2014-01-29', 0, 0, 0, 0, 0),
(191, 2, '2014-01-30', 0, 0, 0, 0, 0),
(192, 2, '2014-01-31', 0, 0, 0, 0, 0),
(193, 3, '2014-01-01', 0, 0, 0, 0, 0),
(194, 3, '2014-01-02', 0, 0, 0, 0, 0),
(195, 3, '2014-01-03', 0, 0, 0, 0, 0),
(196, 3, '2014-01-04', 0, 0, 0, 0, 0),
(197, 3, '2014-01-05', 0, 0, 0, 0, 0),
(198, 3, '2014-01-06', 0, 1, 1, 0, 0),
(199, 3, '2014-01-07', 0, 1, 1, 0, 0),
(200, 3, '2014-01-08', 0, 0, 1, 0, 0),
(201, 3, '2014-01-09', 0, 1, 1, 0, 0),
(202, 3, '2014-01-10', 0, 0, 0, 0, 0),
(203, 3, '2014-01-11', 0, 0, 0, 0, 0),
(204, 3, '2014-01-12', 0, 0, 0, 0, 0),
(205, 3, '2014-01-13', 0, 0, 0, 0, 0),
(206, 3, '2014-01-14', 0, 0, 0, 0, 0),
(207, 3, '2014-01-15', 0, 0, 0, 0, 0),
(208, 3, '2014-01-16', 0, 0, 0, 0, 0),
(209, 3, '2014-01-17', 0, 0, 0, 0, 0),
(210, 3, '2014-01-18', 0, 0, 0, 0, 0),
(211, 3, '2014-01-19', 0, 0, 0, 0, 0),
(212, 3, '2014-01-20', 0, 0, 0, 0, 0),
(213, 3, '2014-01-21', 0, 0, 0, 0, 0),
(214, 3, '2014-01-22', 0, 0, 0, 0, 0),
(215, 3, '2014-01-23', 0, 0, 0, 0, 0),
(216, 3, '2014-01-24', 0, 0, 0, 0, 0),
(217, 3, '2014-01-25', 0, 0, 0, 0, 0),
(218, 3, '2014-01-26', 0, 0, 0, 0, 0),
(219, 3, '2014-01-27', 0, 0, 0, 0, 0),
(220, 3, '2014-01-28', 0, 0, 0, 0, 0),
(221, 3, '2014-01-29', 0, 0, 0, 0, 0),
(222, 3, '2014-01-30', 0, 0, 0, 0, 0),
(223, 3, '2014-01-31', 0, 0, 0, 0, 0),
(224, 4, '2014-01-01', 0, 0, 0, 0, 0),
(225, 4, '2014-01-02', 0, 0, 0, 0, 0),
(226, 4, '2014-01-03', 0, 0, 0, 0, 0),
(227, 4, '2014-01-04', 0, 0, 0, 0, 0),
(228, 4, '2014-01-05', 0, 0, 0, 0, 0),
(229, 4, '2014-01-06', 0, 0, 0, 0, 0),
(230, 4, '2014-01-07', 0, 0, 0, 0, 0),
(231, 4, '2014-01-08', 0, 0, 0, 0, 0),
(232, 4, '2014-01-09', 0, 1, 0, 0, 0),
(233, 4, '2014-01-10', 0, 0, 0, 0, 0),
(234, 4, '2014-01-11', 0, 0, 0, 0, 0),
(235, 4, '2014-01-12', 0, 0, 0, 0, 0),
(236, 4, '2014-01-13', 0, 0, 0, 0, 0),
(237, 4, '2014-01-14', 0, 0, 0, 0, 0),
(238, 4, '2014-01-15', 0, 0, 0, 0, 0),
(239, 4, '2014-01-16', 0, 0, 0, 0, 0),
(240, 4, '2014-01-17', 0, 0, 0, 0, 0),
(241, 4, '2014-01-18', 0, 0, 0, 0, 0),
(242, 4, '2014-01-19', 0, 0, 0, 0, 0),
(243, 4, '2014-01-20', 0, 0, 0, 0, 0),
(244, 4, '2014-01-21', 0, 0, 0, 0, 0),
(245, 4, '2014-01-22', 0, 0, 0, 0, 0),
(246, 4, '2014-01-23', 0, 0, 0, 0, 0),
(247, 4, '2014-01-24', 0, 0, 0, 0, 0),
(248, 4, '2014-01-25', 0, 0, 0, 0, 0),
(249, 4, '2014-01-26', 0, 0, 0, 0, 0),
(250, 4, '2014-01-27', 0, 0, 0, 0, 0),
(251, 4, '2014-01-28', 0, 0, 0, 0, 0),
(252, 4, '2014-01-29', 0, 0, 0, 0, 0),
(253, 4, '2014-01-30', 0, 0, 0, 0, 0),
(254, 4, '2014-01-31', 0, 0, 0, 0, 0),
(255, 6, '2014-01-01', 0, 0, 0, 0, 0),
(256, 6, '2014-01-02', 0, 0, 0, 0, 0),
(257, 6, '2014-01-03', 0, 0, 0, 0, 0),
(258, 6, '2014-01-04', 0, 0, 0, 0, 0),
(259, 6, '2014-01-05', 0, 0, 0, 0, 0),
(260, 6, '2014-01-06', 1, 0, 1, 0, 0),
(261, 6, '2014-01-07', 1, 0, 1, 0, 0),
(262, 6, '2014-01-08', 1, 0, 1, 0, 0),
(263, 6, '2014-01-09', 1, 0, 1, 0, 0),
(264, 6, '2014-01-10', 0, 0, 0, 0, 0),
(265, 6, '2014-01-11', 0, 0, 0, 0, 0),
(266, 6, '2014-01-12', 0, 0, 0, 0, 0),
(267, 6, '2014-01-13', 0, 0, 0, 0, 0),
(268, 6, '2014-01-14', 0, 0, 0, 0, 0),
(269, 6, '2014-01-15', 0, 0, 0, 0, 0),
(270, 6, '2014-01-16', 0, 0, 0, 0, 0),
(271, 6, '2014-01-17', 0, 0, 0, 0, 0),
(272, 6, '2014-01-18', 0, 0, 0, 0, 0),
(273, 6, '2014-01-19', 0, 0, 0, 0, 0),
(274, 6, '2014-01-20', 0, 0, 0, 0, 0),
(275, 6, '2014-01-21', 0, 0, 0, 0, 0),
(276, 6, '2014-01-22', 0, 0, 0, 0, 0),
(277, 6, '2014-01-23', 0, 0, 0, 0, 0),
(278, 6, '2014-01-24', 0, 0, 0, 0, 0),
(279, 6, '2014-01-25', 0, 0, 0, 0, 0),
(280, 6, '2014-01-26', 0, 0, 0, 0, 0),
(281, 6, '2014-01-27', 0, 0, 0, 0, 0),
(282, 6, '2014-01-28', 0, 0, 0, 0, 0),
(283, 6, '2014-01-29', 0, 0, 0, 0, 0),
(284, 6, '2014-01-30', 0, 0, 0, 0, 0),
(285, 6, '2014-01-31', 0, 0, 0, 0, 0),
(286, 7, '2014-01-01', 0, 0, 0, 0, 0),
(287, 7, '2014-01-02', 0, 0, 0, 0, 0),
(288, 7, '2014-01-03', 0, 0, 0, 0, 0),
(289, 7, '2014-01-04', 0, 0, 0, 0, 0),
(290, 7, '2014-01-05', 0, 0, 0, 0, 0),
(291, 7, '2014-01-06', 1, 1, 0, 0, 0),
(292, 7, '2014-01-07', 1, 1, 0, 0, 0),
(293, 7, '2014-01-08', 1, 1, 0, 0, 0),
(294, 7, '2014-01-09', 1, 1, 0, 0, 0),
(295, 7, '2014-01-10', 0, 0, 0, 0, 0),
(296, 7, '2014-01-11', 0, 0, 0, 0, 0),
(297, 7, '2014-01-12', 0, 0, 0, 0, 0),
(298, 7, '2014-01-13', 0, 0, 0, 0, 0),
(299, 7, '2014-01-14', 0, 0, 0, 0, 0),
(300, 7, '2014-01-15', 0, 0, 0, 0, 0),
(301, 7, '2014-01-16', 0, 0, 0, 0, 0),
(302, 7, '2014-01-17', 0, 0, 0, 0, 0),
(303, 7, '2014-01-18', 0, 0, 0, 0, 0),
(304, 7, '2014-01-19', 0, 0, 0, 0, 0),
(305, 7, '2014-01-20', 0, 0, 0, 0, 0),
(306, 7, '2014-01-21', 0, 0, 0, 0, 0),
(307, 7, '2014-01-22', 0, 0, 0, 0, 0),
(308, 7, '2014-01-23', 0, 0, 0, 0, 0),
(309, 7, '2014-01-24', 0, 0, 0, 0, 0),
(310, 7, '2014-01-25', 0, 0, 0, 0, 0),
(311, 7, '2014-01-26', 0, 0, 0, 0, 0),
(312, 7, '2014-01-27', 0, 0, 0, 0, 0),
(313, 7, '2014-01-28', 0, 0, 0, 0, 0),
(314, 7, '2014-01-29', 0, 0, 0, 0, 0),
(315, 7, '2014-01-30', 0, 0, 0, 0, 0),
(316, 7, '2014-01-31', 0, 0, 0, 0, 0),
(317, 8, '2014-01-01', 1, 1, 1, 0, 0),
(318, 8, '2014-01-02', 1, 1, 1, 0, 0),
(319, 8, '2014-01-03', 1, 1, 1, 0, 0),
(320, 8, '2014-01-04', 1, 1, 1, 0, 0),
(321, 8, '2014-01-05', 1, 0, 0, 0, 0),
(322, 8, '2014-01-06', 1, 1, 1, 0, 0),
(323, 8, '2014-01-07', 1, 1, 1, 0, 0),
(324, 8, '2014-01-08', 1, 1, 1, 0, 0),
(325, 8, '2014-01-09', 1, 1, 1, 0, 0),
(326, 8, '2014-01-10', 0, 0, 0, 0, 0),
(327, 8, '2014-01-11', 0, 0, 0, 0, 0),
(328, 8, '2014-01-12', 0, 0, 0, 0, 0),
(329, 8, '2014-01-13', 0, 0, 0, 0, 0),
(330, 8, '2014-01-14', 0, 0, 0, 0, 0),
(331, 8, '2014-01-15', 0, 0, 0, 0, 0),
(332, 8, '2014-01-16', 0, 0, 0, 0, 0),
(333, 8, '2014-01-17', 0, 0, 0, 0, 0),
(334, 8, '2014-01-18', 0, 0, 0, 0, 0),
(335, 8, '2014-01-19', 0, 0, 0, 0, 0),
(336, 8, '2014-01-20', 0, 0, 0, 0, 0),
(337, 8, '2014-01-21', 0, 0, 0, 0, 0),
(338, 8, '2014-01-22', 0, 0, 0, 0, 0),
(339, 8, '2014-01-23', 0, 0, 0, 0, 0),
(340, 8, '2014-01-24', 0, 0, 0, 0, 0),
(341, 8, '2014-01-25', 0, 0, 0, 0, 0),
(342, 8, '2014-01-26', 0, 0, 0, 0, 0),
(343, 8, '2014-01-27', 0, 0, 0, 0, 0),
(344, 8, '2014-01-28', 0, 0, 0, 0, 0),
(345, 8, '2014-01-29', 0, 0, 0, 0, 0),
(346, 8, '2014-01-30', 0, 0, 0, 0, 0),
(347, 8, '2014-01-31', 0, 0, 0, 0, 0),
(348, 5, '2014-01-01', 0, 0, 0, 0, 0),
(349, 5, '2014-01-02', 0, 0, 0, 0, 0),
(350, 5, '2014-01-03', 0, 0, 0, 0, 0),
(351, 5, '2014-01-04', 0, 0, 0, 0, 0),
(352, 5, '2014-01-05', 0, 0, 0, 0, 0),
(353, 5, '2014-01-06', 0, 0, 0, 0, 0),
(354, 5, '2014-01-07', 0, 0, 0, 0, 0),
(355, 5, '2014-01-08', 0, 0, 0, 0, 0),
(356, 5, '2014-01-09', 0, 0, 0, 0, 0),
(357, 5, '2014-01-10', 0, 0, 0, 0, 0),
(358, 5, '2014-01-11', 0, 0, 0, 0, 0),
(359, 5, '2014-01-12', 0, 0, 0, 0, 0),
(360, 5, '2014-01-13', 0, 0, 0, 0, 0),
(361, 5, '2014-01-14', 0, 0, 0, 0, 0),
(362, 5, '2014-01-15', 0, 0, 0, 0, 0),
(363, 5, '2014-01-16', 0, 0, 0, 0, 0),
(364, 5, '2014-01-17', 0, 0, 0, 0, 0),
(365, 5, '2014-01-18', 0, 0, 0, 0, 0),
(366, 5, '2014-01-19', 0, 0, 0, 0, 0),
(367, 5, '2014-01-20', 0, 0, 0, 0, 0),
(368, 5, '2014-01-21', 0, 0, 0, 0, 0),
(369, 5, '2014-01-22', 0, 0, 0, 0, 0),
(370, 5, '2014-01-23', 0, 0, 0, 0, 0),
(371, 5, '2014-01-24', 0, 0, 0, 0, 0),
(372, 5, '2014-01-25', 0, 0, 0, 0, 0),
(373, 5, '2014-01-26', 0, 0, 0, 0, 0),
(374, 5, '2014-01-27', 0, 0, 0, 0, 0),
(375, 5, '2014-01-28', 0, 0, 0, 0, 0),
(376, 5, '2014-01-29', 0, 0, 0, 0, 0),
(377, 5, '2014-01-30', 0, 0, 0, 0, 0),
(378, 5, '2014-01-31', 0, 0, 0, 0, 0),
(379, 9, '2014-01-01', 0, 0, 0, 0, 0),
(380, 9, '2014-01-02', 0, 0, 0, 0, 0),
(381, 9, '2014-01-03', 0, 0, 0, 0, 0),
(382, 9, '2014-01-04', 0, 0, 0, 0, 0),
(383, 9, '2014-01-05', 0, 0, 0, 0, 0),
(384, 9, '2014-01-06', 0, 0, 0, 0, 0),
(385, 9, '2014-01-07', 1, 1, 1, 0, 0),
(386, 9, '2014-01-08', 1, 1, 1, 0, 0),
(387, 9, '2014-01-09', 1, 1, 1, 0, 0),
(388, 9, '2014-01-10', 0, 0, 0, 0, 0),
(389, 9, '2014-01-11', 0, 0, 0, 0, 0),
(390, 9, '2014-01-12', 0, 0, 0, 0, 0),
(391, 9, '2014-01-13', 0, 0, 0, 0, 0),
(392, 9, '2014-01-14', 0, 0, 0, 0, 0),
(393, 9, '2014-01-15', 0, 0, 0, 0, 0),
(394, 9, '2014-01-16', 0, 0, 0, 0, 0),
(395, 9, '2014-01-17', 0, 0, 0, 0, 0),
(396, 9, '2014-01-18', 0, 0, 0, 0, 0),
(397, 9, '2014-01-19', 0, 0, 0, 0, 0),
(398, 9, '2014-01-20', 0, 0, 0, 0, 0),
(399, 9, '2014-01-21', 0, 0, 0, 0, 0),
(400, 9, '2014-01-22', 0, 0, 0, 0, 0),
(401, 9, '2014-01-23', 0, 0, 0, 0, 0),
(402, 9, '2014-01-24', 0, 0, 0, 0, 0),
(403, 9, '2014-01-25', 0, 0, 0, 0, 0),
(404, 9, '2014-01-26', 0, 0, 0, 0, 0),
(405, 9, '2014-01-27', 0, 0, 0, 0, 0),
(406, 9, '2014-01-28', 0, 0, 0, 0, 0),
(407, 9, '2014-01-29', 0, 0, 0, 0, 0),
(408, 9, '2014-01-30', 0, 0, 0, 0, 0),
(409, 9, '2014-01-31', 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `cafethemxua_r2c`
--

CREATE TABLE IF NOT EXISTS `cafethemxua_r2c` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_course` int(11) NOT NULL,
  `id_resource` int(11) NOT NULL,
  `value1` double NOT NULL,
  `value2` double NOT NULL,
  PRIMARY KEY (`id`),
  KEY `cafethemxua_r2c_1` (`id_course`),
  KEY `cafethemxua_r2c_2` (`id_resource`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `cafethemxua_r2c`
--


-- --------------------------------------------------------

--
-- Table structure for table `cafethemxua_resource`
--

CREATE TABLE IF NOT EXISTS `cafethemxua_resource` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `idsupplier` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `unit` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `price` int(10) NOT NULL,
  `description` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `cafethemxua_resource_1` (`idsupplier`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=111 ;

--
-- Dumping data for table `cafethemxua_resource`
--

INSERT INTO `cafethemxua_resource` (`id`, `idsupplier`, `name`, `unit`, `price`, `description`) VALUES
(2, 1, 'Đá viên nhỏ', 'Bao', 15000, 'Nước đá viên - Bao 25kg'),
(14, 1, 'Nước đá ướp', 'Cây', 10000, 'Đá cây ướp trái cây'),
(17, 6, 'Bánh', 'Gói', 5000, ''),
(19, 8, 'Hạt loại 1', 'Kg', 60000, ''),
(20, 8, 'Hạt loại 2', 'Kg', 80000, ''),
(27, 6, 'Xúc xích', 'Gói', 17000, ''),
(35, 9, 'Trà xanh 0 độ', 'Thùng', 160000, 'Thùng 24 chai 500ml'),
(36, 9, 'Dr Thanh', 'Thùng', 185000, 'Thùng 24 chai 370 ml'),
(39, 9, 'Pepsi', 'Thùng', 150000, 'Thùng 24 lon 330 ml'),
(40, 9, 'Mirinda Cam', 'Thùng', 120000, 'Thùng 24 lon 330ml'),
(43, 9, 'Sting dâu', 'Thùng', 170000, 'Thùng 24 chai 330ml'),
(47, 12, 'Ổi', 'Kg', 9000, ''),
(48, 12, 'Củ sắn', 'Kg', 15000, ''),
(49, 12, 'Mít', 'Kg', 18000, ''),
(50, 12, 'Chôm chôm', 'Kg', 10000, ''),
(51, 12, 'Xoài Thái', 'Kg', 15000, ''),
(52, 12, 'Xoài Đài Loan', 'Kg', 15000, ''),
(53, 12, 'Xoài chua', 'Kg', 15000, ''),
(54, 12, 'Mận', 'Kg', 10000, ''),
(55, 12, 'Sơ ri', 'Kg', 12000, ''),
(56, 12, 'Thơm', 'Kg', 12000, ''),
(57, 12, 'Khóm', 'Kg', 10000, ''),
(79, 12, 'Dưa hấu', 'Kg', 10000, ''),
(82, 12, 'Táo', 'Kg', 10000, ''),
(84, 12, 'Cóc', 'Kg', 6000, ''),
(91, 1, 'Đá ống viên lớn', 'Kg', 800, 'Bao 20kg'),
(99, 12, 'Bưởi', 'Kg', 10000, ''),
(101, 8, 'Hạt loại 3', 'Kg', 120000, ''),
(102, 13, 'Duong', 'Kg', 20000, ''),
(103, 9, 'C2', 'Thùng', 105000, '24 chai'),
(104, 9, 'Lipton', 'Hộp', 105000, '100 gói'),
(105, 9, 'Revive', 'Thùng', 174000, '24 chai'),
(106, 9, 'Ô Long', 'Thùng', 135000, '24 chai'),
(107, 12, 'Cà chua', 'Kg', 0, ''),
(108, 12, 'Cà rốt', 'Kg', 0, ''),
(109, 9, 'Mountain Dew', 'Thùng', 142000, '24 chai'),
(110, 12, 'Dừa', 'Trái', 7000, 'gọt sẵn');

-- --------------------------------------------------------

--
-- Table structure for table `cafethemxua_session`
--

CREATE TABLE IF NOT EXISTS `cafethemxua_session` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idtable` int(11) NOT NULL,
  `iduser` int(11) NOT NULL,
  `idcustomer` int(11) NOT NULL,
  `idemployee` int(11) NOT NULL,
  `datetime` datetime NOT NULL,
  `datetimeend` datetime DEFAULT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `status` int(11) NOT NULL,
  `discount_value` int(11) NOT NULL,
  `discount_percent` int(11) NOT NULL,
  `surtax` int(11) NOT NULL,
  `payment` int(11) NOT NULL,
  `value` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idtable` (`idtable`),
  KEY `iduser` (`iduser`),
  KEY `cafethemxua_session_3` (`idcustomer`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=777 ;

--
-- Dumping data for table `cafethemxua_session`
--

INSERT INTO `cafethemxua_session` (`id`, `idtable`, `iduser`, `idcustomer`, `idemployee`, `datetime`, `datetimeend`, `note`, `status`, `discount_value`, `discount_percent`, `surtax`, `payment`, `value`) VALUES
(230, 32, 4, 1, 1, '2014-01-04 20:37:56', '2014-01-04 20:37:56', 'P', 1, 0, 0, 0, 0, 0),
(232, 41, 4, 1, 1, '2014-01-04 20:38:41', '2014-01-04 20:38:41', 'P', 1, 0, 0, 0, 0, 0),
(235, 38, 4, 1, 1, '2014-01-05 07:48:36', '2014-01-05 07:48:36', 'P', 1, 0, 0, 0, 0, 0),
(237, 178, 4, 1, 1, '2014-01-05 08:01:32', '2014-01-05 08:01:32', 'P', 1, 0, 0, 0, 0, 0),
(238, 34, 4, 1, 1, '2014-01-05 08:38:02', '2014-01-05 08:38:02', 'P', 1, 0, 0, 0, 0, 0),
(239, 31, 4, 1, 1, '2014-01-05 08:43:57', '2014-01-05 08:43:57', 'P', 1, 0, 0, 0, 0, 0),
(240, 32, 4, 1, 1, '2014-01-05 09:01:38', '2014-01-05 09:01:38', 'P', 1, 0, 0, 0, 0, 0),
(241, 143, 4, 1, 1, '2014-01-05 09:21:31', '2014-01-05 09:21:31', 'P', 1, 0, 0, 0, 0, 0),
(242, 30, 4, 1, 1, '2014-01-05 09:30:36', '2014-01-05 09:30:36', 'P', 1, 0, 0, 0, 0, 0),
(243, 38, 4, 1, 1, '2014-01-05 09:31:51', '2014-01-05 09:31:51', 'P', 1, 0, 0, 0, 0, 0),
(244, 156, 4, 1, 1, '2014-01-05 12:44:14', '2014-01-05 12:44:14', 'P', 1, 0, 0, 0, 0, 0),
(245, 150, 4, 1, 1, '2014-01-05 12:47:16', '2014-01-05 12:47:16', 'P', 1, 0, 0, 0, 0, 0),
(248, 31, 4, 1, 1, '2014-01-05 13:21:42', '2014-01-05 13:21:42', 'P', 1, 0, 0, 0, 0, 0),
(249, 33, 4, 1, 1, '2014-01-05 13:54:04', '2014-01-05 13:54:04', 'P', 1, 0, 0, 0, 0, 0),
(250, 149, 4, 1, 1, '2014-01-05 13:55:18', '2014-01-05 13:55:18', 'P', 1, 0, 0, 0, 0, 0),
(252, 136, 4, 1, 1, '2014-01-05 17:13:19', '2014-01-05 17:13:19', 'P', 1, 0, 0, 0, 0, 0),
(253, 149, 4, 1, 1, '2014-01-05 17:15:52', '2014-01-05 17:15:52', 'P', 1, 0, 0, 0, 0, 0),
(254, 137, 4, 1, 1, '2014-01-05 17:54:35', '2014-01-05 17:54:35', 'P', 1, 0, 0, 0, 0, 0),
(256, 178, 4, 1, 1, '2014-01-05 18:10:39', '2014-01-05 18:10:39', 'P', 1, 0, 0, 0, 0, 0),
(257, 133, 4, 1, 1, '2014-01-05 18:11:18', '2014-01-05 18:11:18', 'P', 1, 0, 0, 0, 0, 0),
(258, 2, 4, 1, 1, '2014-01-05 19:37:40', '2014-01-05 19:37:40', 'P', 1, 0, 0, 0, 0, 0),
(259, 1, 4, 1, 1, '2014-01-05 19:38:07', '2014-01-05 19:38:07', 'P', 1, 0, 0, 0, 0, 0),
(260, 140, 4, 1, 1, '2014-01-05 19:39:17', '2014-01-05 19:39:17', 'P', 1, 0, 0, 0, 0, 0),
(261, 177, 4, 1, 1, '2014-01-05 19:41:06', '2014-01-05 19:41:06', 'P', 1, 0, 0, 0, 0, 0),
(262, 33, 4, 1, 4, '2014-01-05 19:41:41', '2014-01-05 19:41:41', 'P', 1, 0, 0, 0, 0, 0),
(264, 1, 4, 1, 1, '2014-01-05 19:51:30', '2014-01-05 19:51:30', 'P', 1, 0, 0, 0, 0, 0),
(265, 178, 4, 1, 1, '2014-01-05 19:54:24', '2014-01-05 19:54:24', 'P', 1, 0, 0, 0, 0, 0),
(266, 29, 4, 1, 1, '2014-01-05 20:02:44', '2014-01-05 20:02:44', 'P', 1, 0, 0, 0, 0, 0),
(267, 137, 4, 1, 1, '2014-01-05 20:07:41', '2014-01-05 20:07:41', 'P', 1, 0, 0, 0, 0, 0),
(268, 133, 4, 1, 1, '2014-01-05 20:11:33', '2014-01-05 20:11:33', 'P', 1, 0, 0, 0, 0, 0),
(269, 156, 4, 1, 1, '2014-01-05 20:12:25', '2014-01-05 20:12:25', 'P', 1, 0, 0, 0, 0, 0),
(270, 188, 4, 1, 1, '2014-01-05 20:12:50', '2014-01-05 20:12:50', 'P', 1, 0, 0, 0, 0, 0),
(271, 1, 4, 1, 1, '2014-01-05 20:19:50', '2014-01-05 20:19:50', 'P', 1, 0, 0, 0, 0, 0),
(272, 143, 4, 1, 1, '2014-01-05 20:27:37', '2014-01-05 20:27:37', 'P', 1, 0, 0, 0, 0, 0),
(277, 38, 4, 1, 1, '2014-01-05 21:32:48', '2014-01-05 21:32:48', 'P', 1, 0, 0, 0, 0, 0),
(278, 162, 4, 1, 1, '2014-01-05 22:17:54', '2014-01-05 22:17:54', 'P', 1, 0, 0, 0, 0, 0),
(280, 162, 4, 1, 1, '2014-01-05 23:50:52', '2014-01-05 23:50:52', 'P', 1, 0, 0, 0, 0, 0),
(281, 28, 4, 1, 1, '2014-01-06 06:42:32', '2014-01-06 06:42:32', 'P', 1, 0, 0, 0, 0, 0),
(282, 28, 4, 1, 1, '2014-01-06 06:46:35', '2014-01-06 06:46:35', 'P', 1, 0, 0, 0, 0, 0),
(283, 38, 4, 1, 1, '2014-01-06 07:12:45', '2014-01-06 07:12:45', 'P', 1, 0, 0, 0, 0, 0),
(284, 143, 4, 1, 1, '2014-01-06 07:13:45', '2014-01-06 07:13:45', 'P', 1, 0, 0, 0, 0, 0),
(285, 41, 4, 1, 1, '2014-01-06 07:22:28', '2014-01-06 07:22:28', 'P', 1, 0, 0, 0, 0, 0),
(286, 38, 4, 1, 1, '2014-01-06 07:30:11', '2014-01-06 07:30:11', 'P', 1, 0, 0, 0, 0, 0),
(287, 150, 4, 1, 1, '2014-01-06 07:36:57', '2014-01-06 07:36:57', 'P', 1, 0, 0, 0, 0, 0),
(288, 145, 4, 1, 1, '2014-01-06 07:43:29', '2014-01-06 07:43:29', 'P', 1, 0, 0, 0, 0, 0),
(289, 41, 4, 1, 1, '2014-01-06 07:49:04', '2014-01-06 07:49:04', 'P', 1, 0, 0, 0, 0, 0),
(290, 135, 4, 1, 1, '2014-01-06 07:53:26', '2014-01-06 07:53:26', 'P', 1, 0, 0, 0, 0, 0),
(291, 34, 4, 1, 1, '2014-01-06 08:17:06', '2014-01-06 08:17:06', 'P', 1, 0, 0, 0, 0, 0),
(292, 143, 4, 1, 1, '2014-01-06 08:24:38', '2014-01-06 08:24:38', 'P', 1, 0, 0, 0, 0, 0),
(293, 150, 4, 1, 1, '2014-01-06 09:11:53', '2014-01-06 09:11:53', 'P', 1, 0, 0, 0, 0, 0),
(295, 1, 4, 1, 1, '2014-01-06 09:15:48', '2014-01-06 09:15:48', 'P', 1, 0, 0, 0, 0, 0),
(296, 145, 4, 1, 1, '2014-01-06 09:24:52', '2014-01-06 09:24:52', 'P', 1, 0, 0, 0, 0, 0),
(297, 151, 4, 1, 1, '2014-01-06 09:34:02', '2014-01-06 09:34:02', 'P', 1, 0, 0, 0, 0, 0),
(298, 32, 4, 1, 1, '2014-01-06 09:36:16', '2014-01-06 09:36:16', 'P', 1, 0, 0, 0, 0, 0),
(299, 28, 4, 1, 1, '2014-01-06 09:43:56', '2014-01-06 09:43:56', 'P', 1, 0, 0, 0, 0, 0),
(301, 135, 4, 1, 1, '2014-01-06 10:05:01', '2014-01-06 10:05:01', 'P', 1, 0, 0, 0, 0, 0),
(302, 1, 4, 1, 1, '2014-01-06 10:30:44', '2014-01-06 10:30:44', 'P', 1, 0, 0, 0, 0, 0),
(303, 166, 4, 1, 1, '2014-01-06 10:37:43', '2014-01-06 10:37:43', 'P', 1, 0, 0, 0, 0, 0),
(304, 149, 4, 1, 1, '2014-01-06 10:48:59', '2014-01-06 10:48:59', 'P', 1, 0, 0, 0, 0, 0),
(305, 150, 4, 1, 1, '2014-01-06 12:02:28', '2014-01-06 12:02:28', 'P', 1, 0, 0, 0, 0, 0),
(306, 150, 4, 1, 1, '2014-01-06 13:42:59', '2014-01-06 13:42:59', 'P', 1, 0, 0, 0, 0, 0),
(307, 168, 4, 1, 1, '2014-01-06 14:10:19', '2014-01-06 14:10:19', 'P', 1, 0, 0, 0, 0, 0),
(308, 144, 4, 1, 1, '2014-01-06 14:33:42', '2014-01-06 14:33:42', 'P', 1, 0, 0, 0, 0, 0),
(309, 142, 4, 1, 1, '2014-01-06 14:44:29', '2014-01-06 14:44:29', 'P', 1, 0, 0, 0, 0, 0),
(310, 35, 4, 1, 1, '2014-01-06 14:46:45', '2014-01-06 14:46:45', 'P', 1, 0, 0, 0, 0, 0),
(311, 178, 4, 1, 1, '2014-01-06 14:55:48', '2014-01-06 14:55:48', 'P', 1, 0, 0, 0, 0, 0),
(312, 1, 4, 1, 1, '2014-01-06 14:56:43', '2014-01-06 14:56:43', 'P', 1, 0, 0, 0, 0, 0),
(313, 141, 4, 1, 1, '2014-01-06 14:59:35', '2014-01-06 14:59:35', 'P', 1, 0, 0, 0, 0, 0),
(314, 142, 4, 1, 1, '2014-01-06 15:00:33', '2014-01-06 15:00:33', 'P', 1, 0, 0, 0, 0, 0),
(315, 140, 4, 1, 1, '2014-01-06 15:24:33', '2014-01-06 15:24:33', 'P', 1, 0, 0, 0, 0, 0),
(316, 185, 4, 1, 1, '2014-01-06 15:41:58', '2014-01-06 15:41:58', 'P', 1, 0, 0, 0, 0, 0),
(317, 32, 4, 1, 1, '2014-01-06 16:46:31', '2014-01-06 16:46:31', 'P', 1, 0, 0, 0, 0, 0),
(318, 31, 4, 1, 1, '2014-01-06 16:46:46', '2014-01-06 16:46:46', 'P', 1, 0, 0, 0, 0, 0),
(319, 4, 4, 1, 1, '2014-01-06 17:46:01', '2014-01-06 17:46:01', 'P', 1, 0, 0, 0, 0, 0),
(320, 32, 4, 1, 1, '2014-01-06 17:47:03', '2014-01-06 17:47:03', 'P', 1, 0, 0, 0, 0, 0),
(321, 28, 4, 1, 1, '2014-01-06 17:49:54', '2014-01-06 17:49:54', 'P', 1, 0, 0, 0, 0, 0),
(322, 136, 4, 1, 1, '2014-01-06 18:03:00', '2014-01-06 18:03:00', 'P', 1, 0, 0, 0, 0, 0),
(324, 3, 4, 1, 1, '2014-01-06 18:06:04', '2014-01-06 18:06:04', 'P', 1, 0, 0, 0, 0, 0),
(325, 1, 4, 1, 1, '2014-01-06 18:06:36', '2014-01-06 18:06:36', 'P', 1, 0, 0, 0, 0, 0),
(326, 38, 4, 1, 1, '2014-01-06 18:13:05', '2014-01-06 18:13:05', 'P', 1, 0, 0, 0, 0, 0),
(327, 41, 4, 1, 1, '2014-01-06 18:14:11', '2014-01-06 18:14:11', 'P', 1, 0, 0, 0, 0, 0),
(328, 133, 4, 1, 1, '2014-01-06 18:16:26', '2014-01-06 18:16:26', 'P', 1, 0, 0, 0, 0, 0),
(330, 33, 4, 1, 1, '2014-01-06 18:26:45', '2014-01-06 18:26:45', 'P', 1, 0, 0, 0, 0, 0),
(331, 2, 4, 1, 1, '2014-01-06 18:26:55', '2014-01-06 18:26:55', 'P', 1, 0, 0, 0, 0, 0),
(332, 30, 4, 1, 1, '2014-01-06 18:27:10', '2014-01-06 18:27:10', 'P', 1, 0, 0, 0, 0, 0),
(333, 135, 4, 1, 1, '2014-01-06 18:27:36', '2014-01-06 18:27:36', 'P', 1, 0, 0, 0, 0, 0),
(334, 178, 4, 1, 1, '2014-01-06 18:31:55', '2014-01-06 18:31:55', 'P', 1, 0, 0, 0, 0, 0),
(335, 135, 4, 1, 1, '2014-01-06 18:32:39', '2014-01-06 18:32:39', 'P', 1, 0, 0, 0, 0, 0),
(336, 137, 4, 1, 1, '2014-01-06 18:35:59', '2014-01-06 18:35:59', 'P', 1, 0, 0, 0, 0, 0),
(337, 141, 4, 1, 1, '2014-01-06 18:37:22', '2014-01-06 18:37:22', 'P', 1, 0, 0, 0, 0, 0),
(338, 140, 4, 1, 1, '2014-01-06 18:40:50', '2014-01-06 18:40:50', 'P', 1, 0, 0, 0, 0, 0),
(339, 34, 4, 1, 1, '2014-01-06 18:42:12', '2014-01-06 18:42:12', 'P', 1, 0, 0, 0, 0, 0),
(340, 143, 4, 1, 1, '2014-01-06 18:46:12', '2014-01-06 18:46:12', 'P', 1, 0, 0, 0, 0, 0),
(341, 2, 4, 1, 1, '2014-01-06 18:56:10', '2014-01-06 18:56:10', 'P', 1, 0, 0, 0, 0, 0),
(342, 2, 4, 1, 1, '2014-01-06 18:57:22', '2014-01-06 18:57:22', 'P', 1, 0, 0, 0, 0, 0),
(343, 142, 4, 1, 1, '2014-01-06 18:57:37', '2014-01-06 18:57:37', 'P', 1, 0, 0, 0, 0, 0),
(344, 136, 4, 1, 1, '2014-01-06 19:05:58', '2014-01-06 19:05:58', 'P', 1, 0, 0, 0, 0, 0),
(345, 136, 4, 1, 1, '2014-01-06 19:09:00', '2014-01-06 19:09:00', 'P', 1, 0, 0, 0, 0, 0),
(346, 38, 4, 1, 1, '2014-01-06 19:15:08', '2014-01-06 19:15:08', 'P', 1, 0, 0, 0, 0, 0),
(347, 144, 4, 1, 1, '2014-01-06 19:15:59', '2014-01-06 19:15:59', 'P', 1, 0, 0, 0, 0, 0),
(348, 149, 4, 1, 1, '2014-01-06 19:20:24', '2014-01-06 19:20:24', 'P', 1, 0, 0, 0, 0, 0),
(350, 31, 4, 1, 1, '2014-01-06 19:32:43', '2014-01-06 19:32:43', 'P', 1, 0, 0, 0, 0, 0),
(351, 178, 4, 1, 1, '2014-01-06 19:35:17', '2014-01-06 19:35:17', 'P', 1, 0, 0, 0, 0, 0),
(352, 34, 4, 1, 1, '2014-01-06 19:38:28', '2014-01-06 19:38:28', 'P', 1, 0, 0, 0, 0, 0),
(353, 143, 4, 1, 1, '2014-01-06 19:50:57', '2014-01-06 19:50:57', 'P', 1, 0, 0, 0, 0, 0),
(354, 151, 4, 1, 1, '2014-01-06 19:51:44', '2014-01-06 19:51:44', 'P', 1, 0, 0, 0, 0, 0),
(355, 144, 4, 1, 1, '2014-01-06 20:02:53', '2014-01-06 20:02:53', 'P', 1, 0, 0, 0, 0, 0),
(356, 2, 4, 1, 1, '2014-01-06 20:04:50', '2014-01-06 20:04:50', 'P', 1, 0, 0, 0, 0, 0),
(360, 41, 4, 1, 1, '2014-01-06 20:35:40', '2014-01-06 20:35:40', 'P', 1, 0, 0, 0, 0, 0),
(361, 2, 4, 1, 1, '2014-01-06 20:38:18', '2014-01-06 20:38:18', 'P', 1, 0, 0, 0, 0, 0),
(362, 136, 4, 1, 1, '2014-01-06 21:04:14', '2014-01-06 21:04:14', 'P', 1, 0, 0, 0, 0, 0),
(363, 178, 4, 1, 1, '2014-01-06 21:04:36', '2014-01-06 21:04:36', 'P', 1, 0, 0, 0, 0, 0),
(364, 1, 4, 1, 1, '2014-01-07 08:30:26', '2014-01-07 08:30:26', 'P', 1, 0, 0, 0, 0, 0),
(365, 177, 4, 1, 1, '2014-01-07 08:31:34', '2014-01-07 08:31:34', 'P', 1, 0, 0, 0, 0, 0),
(366, 2, 4, 1, 1, '2014-01-07 08:35:35', '2014-01-07 08:35:35', 'P', 1, 0, 0, 0, 0, 0),
(367, 41, 4, 1, 1, '2014-01-07 08:39:33', '2014-01-07 08:39:33', 'P', 1, 0, 0, 0, 0, 0),
(368, 32, 4, 1, 1, '2014-01-07 09:03:16', '2014-01-07 09:03:16', 'P', 1, 0, 0, 0, 0, 0),
(369, 35, 4, 1, 1, '2014-01-07 09:04:15', '2014-01-07 09:04:15', 'P', 1, 0, 0, 0, 0, 0),
(370, 28, 4, 1, 1, '2014-01-07 09:34:56', '2014-01-07 09:34:56', 'P', 1, 0, 0, 0, 0, 0),
(371, 35, 4, 1, 1, '2014-01-07 09:44:53', '2014-01-07 09:44:53', 'P', 1, 0, 0, 0, 0, 0),
(372, 2, 4, 1, 1, '2014-01-07 10:01:55', '2014-01-07 10:01:55', 'P', 1, 0, 0, 0, 0, 0),
(373, 34, 4, 1, 1, '2014-01-07 10:20:17', '2014-01-07 10:20:17', 'P', 1, 0, 0, 0, 0, 0),
(374, 1, 4, 1, 1, '2014-01-07 10:20:37', '2014-01-07 10:20:37', 'P', 1, 0, 0, 0, 0, 0),
(375, 140, 4, 1, 1, '2014-01-07 10:31:07', '2014-01-07 10:31:07', 'P', 1, 0, 0, 0, 0, 0),
(376, 140, 4, 1, 1, '2014-01-07 10:42:28', '2014-01-07 10:42:28', 'P', 1, 0, 0, 0, 0, 0),
(377, 166, 4, 1, 1, '2014-01-07 11:01:47', '2014-01-07 11:01:47', 'P', 1, 0, 0, 0, 0, 0),
(378, 29, 4, 1, 1, '2014-01-07 11:21:16', '2014-01-07 11:21:16', 'P', 1, 0, 0, 0, 0, 0),
(379, 149, 4, 1, 1, '2014-01-07 11:29:38', '2014-01-07 11:29:38', 'P', 1, 0, 0, 0, 0, 0),
(380, 168, 4, 1, 1, '2014-01-07 11:30:06', '2014-01-07 11:30:06', 'P', 1, 0, 0, 0, 0, 0),
(381, 144, 4, 1, 1, '2014-01-07 11:39:54', '2014-01-07 11:39:54', 'P', 1, 0, 0, 0, 0, 0),
(382, 140, 4, 1, 1, '2014-01-07 11:46:32', '2014-01-07 11:46:32', 'P', 1, 0, 0, 0, 0, 0),
(383, 1, 4, 1, 1, '2014-01-07 11:46:57', '2014-01-07 11:46:57', 'P', 1, 0, 0, 0, 0, 0),
(384, 179, 4, 1, 1, '2014-01-07 12:30:51', '2014-01-07 12:30:51', 'P', 1, 0, 0, 0, 0, 0),
(385, 2, 4, 1, 1, '2014-01-07 13:02:18', '2014-01-07 13:02:18', 'P', 1, 0, 0, 0, 0, 0),
(386, 149, 4, 1, 1, '2014-01-07 13:24:18', '2014-01-07 13:24:18', 'P', 1, 0, 0, 0, 0, 0),
(387, 143, 4, 1, 1, '2014-01-07 13:49:33', '2014-01-07 13:49:33', 'P', 1, 0, 0, 0, 0, 0),
(388, 144, 4, 1, 1, '2014-01-07 13:50:41', '2014-01-07 13:50:41', 'P', 1, 0, 0, 0, 0, 0),
(389, 175, 4, 1, 1, '2014-01-07 14:10:49', '2014-01-07 14:10:49', 'P', 1, 0, 0, 0, 0, 0),
(390, 33, 4, 1, 1, '2014-01-07 15:09:26', '2014-01-07 15:09:26', 'P', 1, 0, 0, 0, 0, 0),
(391, 144, 4, 1, 1, '2014-01-07 15:42:35', '2014-01-07 15:42:35', 'P', 1, 0, 0, 0, 0, 0),
(392, 156, 4, 1, 1, '2014-01-07 16:04:11', '2014-01-07 16:04:11', 'P', 1, 0, 0, 0, 0, 0),
(393, 143, 4, 1, 1, '2014-01-07 16:42:13', '2014-01-07 16:42:13', 'P', 1, 0, 0, 0, 0, 0),
(394, 1, 4, 1, 1, '2014-01-07 16:45:27', '2014-01-07 16:45:27', 'P', 1, 0, 0, 0, 0, 0),
(395, 41, 4, 1, 1, '2014-01-07 17:20:11', '2014-01-07 17:20:11', 'P', 1, 0, 0, 0, 0, 0),
(396, 177, 4, 1, 1, '2014-01-07 17:23:03', '2014-01-07 17:23:03', 'P', 1, 0, 0, 0, 0, 0),
(397, 32, 4, 1, 1, '2014-01-07 17:58:55', '2014-01-07 17:58:55', 'P', 1, 0, 0, 0, 0, 0),
(398, 133, 4, 1, 1, '2014-01-07 18:06:02', '2014-01-07 18:06:02', 'P', 1, 0, 0, 0, 0, 0),
(399, 28, 4, 1, 1, '2014-01-07 18:20:15', '2014-01-07 18:20:15', 'P', 1, 0, 0, 0, 0, 0),
(400, 2, 4, 1, 1, '2014-01-07 18:24:13', '2014-01-07 18:24:13', 'P', 1, 0, 0, 0, 0, 0),
(401, 135, 4, 1, 1, '2014-01-07 18:49:17', '2014-01-07 18:49:17', 'P', 1, 0, 0, 0, 0, 0),
(402, 30, 4, 1, 1, '2014-01-07 18:58:20', '2014-01-07 18:58:20', 'P', 1, 0, 0, 0, 0, 0),
(403, 2, 4, 1, 1, '2014-01-07 19:27:11', '2014-01-07 19:27:11', 'P', 1, 0, 0, 0, 0, 0),
(404, 41, 4, 1, 1, '2014-01-07 19:48:00', '2014-01-07 19:48:00', 'P', 1, 0, 0, 0, 0, 0),
(405, 142, 4, 1, 1, '2014-01-07 19:50:41', '2014-01-07 19:50:41', 'P', 1, 0, 0, 0, 0, 0),
(406, 177, 4, 1, 1, '2014-01-07 19:52:35', '2014-01-07 19:52:35', 'P', 1, 0, 0, 0, 0, 0),
(407, 185, 4, 1, 1, '2014-01-07 20:06:54', '2014-01-07 20:06:54', 'P', 1, 0, 0, 0, 0, 0),
(408, 144, 4, 1, 1, '2014-01-07 20:46:01', '2014-01-07 20:46:01', 'P', 1, 0, 0, 0, 0, 0),
(409, 33, 4, 1, 1, '2014-01-07 20:50:20', '2014-01-07 20:50:20', 'P', 1, 0, 0, 0, 0, 0),
(410, 140, 4, 1, 1, '2014-01-07 21:12:23', '2014-01-07 21:12:23', 'P', 1, 0, 0, 0, 0, 0),
(412, 142, 4, 1, 1, '2014-01-07 21:26:41', '2014-01-07 21:26:41', 'P', 1, 0, 0, 0, 0, 0),
(413, 41, 4, 1, 1, '2014-01-08 06:53:47', '2014-01-08 06:53:47', 'P', 1, 0, 0, 0, 0, 0),
(414, 34, 4, 1, 1, '2014-01-08 06:54:38', '2014-01-08 06:54:38', 'P', 1, 0, 0, 0, 0, 0),
(415, 38, 4, 1, 1, '2014-01-08 07:08:59', '2014-01-08 07:08:59', 'P', 1, 0, 0, 0, 0, 0),
(416, 4, 4, 1, 1, '2014-01-08 07:34:31', '2014-01-08 07:34:31', 'P', 1, 0, 0, 0, 0, 0),
(417, 38, 4, 1, 1, '2014-01-08 07:39:25', '2014-01-08 07:39:25', 'P', 1, 0, 0, 0, 0, 0),
(418, 151, 4, 1, 1, '2014-01-08 07:39:52', '2014-01-08 07:39:52', 'P', 1, 0, 0, 0, 0, 0),
(419, 136, 4, 1, 1, '2014-01-08 08:33:18', '2014-01-08 08:33:18', 'P', 1, 0, 0, 0, 0, 0),
(420, 150, 4, 1, 1, '2014-01-08 09:32:56', '2014-01-08 09:32:56', 'P', 1, 0, 0, 0, 0, 0),
(421, 136, 4, 1, 1, '2014-01-08 09:33:30', '2014-01-08 09:33:30', 'P', 1, 0, 0, 0, 0, 0),
(422, 140, 4, 1, 1, '2014-01-08 09:33:46', '2014-01-08 09:33:46', 'P', 1, 0, 0, 0, 0, 0),
(423, 156, 4, 1, 1, '2014-01-08 09:37:40', '2014-01-08 09:37:40', 'P', 1, 0, 0, 0, 0, 0),
(424, 2, 4, 1, 1, '2014-01-08 09:49:32', '2014-01-08 09:49:32', 'P', 1, 0, 0, 0, 0, 0),
(425, 150, 4, 1, 1, '2014-01-08 10:36:17', '2014-01-08 10:36:17', 'P', 1, 0, 0, 0, 0, 0),
(426, 33, 4, 1, 1, '2014-01-08 10:46:30', '2014-01-08 10:46:30', 'P', 1, 0, 0, 0, 0, 0),
(427, 31, 4, 1, 1, '2014-01-08 10:46:46', '2014-01-08 10:46:46', 'P', 1, 0, 0, 0, 0, 0),
(428, 166, 4, 1, 1, '2014-01-08 10:50:51', '2014-01-08 10:50:51', 'P', 1, 0, 0, 0, 0, 0),
(429, 34, 4, 1, 1, '2014-01-08 11:46:33', '2014-01-08 11:46:33', 'P', 1, 0, 0, 0, 0, 0),
(430, 150, 4, 1, 1, '2014-01-08 11:59:30', '2014-01-08 11:59:30', 'P', 1, 0, 0, 0, 0, 0),
(431, 140, 4, 1, 1, '2014-01-08 12:07:29', '2014-01-08 12:07:29', 'P', 1, 0, 0, 0, 0, 0),
(432, 185, 4, 1, 1, '2014-01-08 12:28:42', '2014-01-08 12:28:42', 'P', 1, 0, 0, 0, 0, 0),
(433, 31, 4, 1, 1, '2014-01-08 14:20:23', '2014-01-08 14:20:23', 'P', 1, 0, 0, 0, 0, 0),
(434, 2, 4, 1, 1, '2014-01-08 14:21:42', '2014-01-08 14:21:42', 'P', 1, 0, 0, 0, 0, 0),
(435, 177, 4, 1, 1, '2014-01-08 14:26:40', '2014-01-08 14:26:40', 'P', 1, 0, 0, 0, 0, 0),
(436, 29, 4, 1, 1, '2014-01-08 14:37:50', '2014-01-08 14:37:50', 'P', 1, 0, 0, 0, 0, 0),
(437, 1, 4, 1, 1, '2014-01-08 15:06:41', '2014-01-08 15:06:41', 'P', 1, 0, 0, 0, 0, 0),
(438, 2, 4, 1, 1, '2014-01-08 15:07:07', '2014-01-08 15:07:07', 'P', 1, 0, 0, 0, 0, 0),
(439, 144, 4, 1, 1, '2014-01-08 15:09:44', '2014-01-08 15:09:44', 'P', 1, 0, 0, 0, 0, 0),
(440, 144, 4, 1, 1, '2014-01-08 15:17:23', '2014-01-08 15:17:23', 'P', 1, 0, 0, 0, 0, 0),
(441, 34, 4, 1, 1, '2014-01-08 15:19:12', '2014-01-08 15:19:12', 'P', 1, 0, 0, 0, 0, 0),
(442, 31, 4, 1, 1, '2014-01-08 16:03:18', '2014-01-08 16:03:18', 'P', 1, 0, 0, 0, 0, 0),
(443, 185, 4, 1, 1, '2014-01-08 16:05:59', '2014-01-08 16:05:59', 'P', 1, 0, 0, 0, 0, 0),
(444, 32, 4, 1, 1, '2014-01-08 16:25:40', '2014-01-08 16:25:40', 'P', 1, 0, 0, 0, 0, 0),
(445, 3, 4, 1, 1, '2014-01-08 17:29:03', '2014-01-08 17:29:03', 'P', 1, 0, 0, 0, 0, 0),
(446, 35, 4, 1, 1, '2014-01-08 17:29:25', '2014-01-08 17:29:25', 'P', 1, 0, 0, 0, 0, 0),
(447, 1, 4, 1, 1, '2014-01-08 17:36:16', '2014-01-08 17:36:16', 'P', 1, 0, 0, 0, 0, 0),
(448, 1, 4, 1, 1, '2014-01-08 17:40:26', '2014-01-08 17:40:26', 'P', 1, 0, 0, 0, 0, 0),
(449, 32, 4, 1, 1, '2014-01-08 17:43:48', '2014-01-08 17:43:48', 'P', 1, 0, 0, 0, 0, 0),
(450, 33, 4, 1, 1, '2014-01-08 17:46:48', '2014-01-08 17:46:48', 'P', 1, 0, 0, 0, 0, 0),
(451, 28, 4, 1, 1, '2014-01-08 17:51:47', '2014-01-08 17:51:47', 'P', 1, 0, 0, 0, 0, 0),
(452, 137, 4, 1, 1, '2014-01-08 17:53:36', '2014-01-08 17:53:36', 'P', 1, 0, 0, 0, 0, 0),
(453, 4, 4, 1, 1, '2014-01-08 17:54:54', '2014-01-08 17:54:54', 'P', 1, 0, 0, 0, 0, 0),
(454, 34, 4, 1, 1, '2014-01-08 17:56:39', '2014-01-08 17:56:39', 'P', 1, 0, 0, 0, 0, 0),
(455, 1, 4, 1, 1, '2014-01-08 17:57:46', '2014-01-08 17:57:46', 'P', 1, 0, 0, 0, 0, 0),
(456, 184, 4, 1, 1, '2014-01-08 17:58:42', '2014-01-08 17:58:42', 'P', 1, 0, 0, 0, 0, 0),
(457, 35, 4, 1, 1, '2014-01-08 18:03:18', '2014-01-08 18:03:18', 'P', 1, 0, 0, 0, 0, 0),
(458, 178, 4, 1, 1, '2014-01-08 18:05:44', '2014-01-08 18:05:44', 'P', 1, 0, 0, 0, 0, 0),
(459, 1, 4, 1, 1, '2014-01-08 18:09:26', '2014-01-08 18:09:26', 'P', 1, 0, 0, 0, 0, 0),
(460, 33, 4, 1, 1, '2014-01-08 18:10:02', '2014-01-08 18:10:02', 'P', 1, 0, 0, 0, 0, 0),
(461, 178, 4, 1, 1, '2014-01-08 18:10:41', '2014-01-08 18:10:41', 'P', 1, 0, 0, 0, 0, 0),
(462, 1, 4, 1, 1, '2014-01-08 18:11:52', '2014-01-08 18:11:52', 'P', 1, 0, 0, 0, 0, 0),
(463, 29, 4, 1, 1, '2014-01-08 18:12:49', '2014-01-08 18:12:49', 'P', 1, 0, 0, 0, 0, 0),
(464, 184, 4, 1, 1, '2014-01-08 18:15:05', '2014-01-08 18:15:05', 'P', 1, 0, 0, 0, 0, 0),
(465, 183, 4, 1, 1, '2014-01-08 18:15:53', '2014-01-08 18:15:53', 'P', 1, 0, 0, 0, 0, 0),
(466, 135, 4, 1, 1, '2014-01-08 18:17:40', '2014-01-08 18:17:40', 'P', 1, 0, 0, 0, 0, 0),
(467, 41, 4, 1, 1, '2014-01-08 18:18:06', '2014-01-08 18:18:06', 'P', 1, 0, 0, 0, 0, 0),
(468, 32, 4, 1, 1, '2014-01-08 18:19:17', '2014-01-08 18:19:17', 'P', 1, 0, 0, 0, 0, 0),
(469, 136, 4, 1, 1, '2014-01-08 18:20:06', '2014-01-08 18:20:06', 'P', 1, 0, 0, 0, 0, 0),
(470, 136, 4, 1, 1, '2014-01-08 18:21:10', '2014-01-08 18:21:10', 'P', 1, 0, 0, 0, 0, 0),
(471, 34, 4, 1, 1, '2014-01-08 18:24:34', '2014-01-08 18:24:34', 'P', 1, 0, 0, 0, 0, 0),
(472, 138, 4, 1, 1, '2014-01-08 18:26:24', '2014-01-08 18:26:24', 'P', 1, 0, 0, 0, 0, 0),
(473, 33, 4, 1, 1, '2014-01-08 18:29:19', '2014-01-08 18:29:19', 'P', 1, 0, 0, 0, 0, 0),
(474, 3, 4, 1, 1, '2014-01-08 18:30:52', '2014-01-08 18:30:52', 'P', 1, 0, 0, 0, 0, 0),
(475, 38, 4, 1, 1, '2014-01-08 18:31:25', '2014-01-08 18:31:25', 'P', 1, 0, 0, 0, 0, 0),
(476, 142, 4, 1, 1, '2014-01-08 18:32:35', '2014-01-08 18:32:35', 'P', 1, 0, 0, 0, 0, 0),
(477, 179, 4, 1, 1, '2014-01-08 18:33:13', '2014-01-08 18:33:13', 'P', 1, 0, 0, 0, 0, 0),
(478, 142, 4, 1, 1, '2014-01-08 18:38:14', '2014-01-08 18:38:14', 'P', 1, 0, 0, 0, 0, 0),
(479, 151, 4, 1, 1, '2014-01-08 18:38:44', '2014-01-08 18:38:44', 'P', 1, 0, 0, 0, 0, 0),
(480, 133, 4, 1, 1, '2014-01-08 18:40:07', '2014-01-08 18:40:07', 'P', 1, 0, 0, 0, 0, 0),
(481, 41, 4, 1, 1, '2014-01-08 18:46:19', '2014-01-08 18:46:19', 'P', 1, 0, 0, 0, 0, 0),
(482, 133, 4, 1, 1, '2014-01-08 18:47:14', '2014-01-08 18:47:14', 'P', 1, 0, 0, 0, 0, 0),
(483, 135, 4, 1, 1, '2014-01-08 18:49:32', '2014-01-08 18:49:32', 'P', 1, 0, 0, 0, 0, 0),
(484, 141, 4, 1, 1, '2014-01-08 18:57:27', '2014-01-08 18:57:27', 'P', 1, 0, 0, 0, 0, 0),
(485, 166, 4, 1, 1, '2014-01-08 19:04:14', '2014-01-08 19:04:14', 'P', 1, 0, 0, 0, 0, 0),
(486, 41, 4, 1, 1, '2014-01-08 19:06:03', '2014-01-08 19:06:03', 'P', 1, 0, 0, 0, 0, 0),
(487, 185, 4, 1, 1, '2014-01-08 19:19:41', '2014-01-08 19:19:41', 'P', 1, 0, 0, 0, 0, 0),
(488, 185, 4, 1, 1, '2014-01-08 19:23:39', '2014-01-08 19:23:39', 'P', 1, 0, 0, 0, 0, 0),
(489, 143, 4, 1, 1, '2014-01-08 19:34:00', '2014-01-08 19:34:00', 'P', 1, 0, 0, 0, 0, 0),
(490, 41, 4, 1, 1, '2014-01-08 19:45:15', '2014-01-08 19:45:15', 'P', 1, 0, 0, 0, 0, 0),
(491, 133, 4, 1, 1, '2014-01-08 20:09:43', '2014-01-08 20:09:43', 'P', 1, 0, 0, 0, 0, 0),
(492, 156, 4, 1, 1, '2014-01-08 20:13:26', '2014-01-08 20:13:26', 'P', 1, 0, 0, 0, 0, 0),
(493, 166, 4, 1, 1, '2014-01-08 20:17:45', '2014-01-08 20:17:45', 'P', 1, 0, 0, 0, 0, 0),
(494, 158, 4, 1, 1, '2014-01-08 20:20:40', '2014-01-08 20:20:40', 'P', 1, 0, 0, 0, 0, 0),
(495, 141, 4, 1, 1, '2014-01-08 20:23:51', '2014-01-08 20:23:51', 'P', 1, 0, 0, 0, 0, 0),
(496, 34, 4, 1, 1, '2014-01-08 20:59:17', '2014-01-08 20:59:17', 'P', 1, 0, 0, 0, 0, 0),
(497, 136, 4, 1, 1, '2014-01-08 21:22:37', '2014-01-08 21:22:37', 'P', 1, 0, 0, 0, 0, 0),
(498, 135, 4, 1, 1, '2014-01-09 06:54:48', '2014-01-09 06:54:48', 'P', 1, 0, 0, 0, 0, 0),
(499, 151, 4, 1, 1, '2014-01-09 07:30:49', '2014-01-09 07:30:49', 'P', 1, 0, 0, 0, 0, 0),
(500, 150, 4, 1, 1, '2014-01-09 07:58:23', '2014-01-09 07:58:23', 'P', 1, 0, 0, 0, 0, 0),
(501, 142, 4, 1, 1, '2014-01-09 07:59:35', '2014-01-09 07:59:35', 'P', 1, 0, 0, 0, 0, 0),
(502, 158, 4, 1, 1, '2014-01-09 08:15:01', '2014-01-09 08:15:01', 'P', 1, 0, 0, 0, 0, 0),
(503, 173, 4, 1, 1, '2014-01-09 08:26:13', '2014-01-09 08:26:13', 'P', 1, 0, 0, 0, 0, 0),
(504, 33, 4, 1, 1, '2014-01-09 08:49:16', '2014-01-09 08:49:16', 'P', 1, 0, 0, 0, 0, 0),
(505, 135, 4, 1, 1, '2014-01-09 08:49:56', '2014-01-09 08:49:56', 'P', 1, 0, 0, 0, 0, 0),
(506, 166, 4, 1, 1, '2014-01-09 08:50:23', '2014-01-09 08:50:23', 'P', 1, 0, 0, 0, 0, 0),
(507, 155, 4, 1, 1, '2014-01-09 08:50:39', '2014-01-09 08:50:39', 'P', 1, 0, 0, 0, 0, 0),
(508, 35, 4, 1, 1, '2014-01-09 09:00:34', '2014-01-09 09:00:34', 'P', 1, 0, 0, 0, 0, 0),
(509, 156, 4, 1, 1, '2014-01-09 09:06:38', '2014-01-09 09:06:38', 'P', 1, 0, 0, 0, 0, 0),
(510, 2, 4, 1, 1, '2014-01-09 09:09:18', '2014-01-09 09:09:18', 'P', 1, 0, 0, 0, 0, 0),
(511, 32, 4, 1, 1, '2014-01-09 10:01:28', '2014-01-09 10:01:28', 'P', 1, 0, 0, 0, 0, 0),
(512, 35, 4, 1, 1, '2014-01-09 10:37:05', '2014-01-09 10:37:05', 'P', 1, 0, 0, 0, 0, 0),
(513, 30, 4, 1, 1, '2014-01-09 10:38:02', '2014-01-09 10:38:02', 'P', 1, 0, 0, 0, 0, 0),
(514, 150, 4, 1, 1, '2014-01-09 11:33:03', '2014-01-09 11:33:03', 'P', 1, 0, 0, 0, 0, 0),
(515, 166, 4, 1, 1, '2014-01-09 11:38:30', '2014-01-09 11:38:30', 'P', 1, 0, 0, 0, 0, 0),
(516, 33, 4, 1, 1, '2014-01-09 11:39:09', '2014-01-09 11:39:09', 'P', 1, 0, 0, 0, 0, 0),
(517, 35, 4, 1, 1, '2014-01-09 12:06:09', '2014-01-09 12:06:09', 'P', 1, 0, 0, 0, 0, 0),
(518, 143, 4, 1, 1, '2014-01-09 12:55:18', '2014-01-09 12:55:18', 'P', 1, 0, 0, 0, 0, 0),
(519, 32, 4, 1, 1, '2014-01-09 13:09:25', '2014-01-09 13:09:25', 'P', 1, 0, 0, 0, 0, 0),
(520, 149, 4, 1, 1, '2014-01-09 14:11:19', '2014-01-09 14:11:19', 'P', 1, 0, 0, 0, 0, 0),
(521, 150, 4, 1, 1, '2014-01-09 14:20:15', '2014-01-09 14:20:15', 'P', 1, 0, 0, 0, 0, 0),
(522, 152, 4, 1, 1, '2014-01-09 14:38:51', '2014-01-09 14:38:51', 'P', 1, 0, 0, 0, 0, 0),
(523, 142, 4, 1, 1, '2014-01-09 14:39:46', '2014-01-09 14:39:46', 'P', 1, 0, 0, 0, 0, 0),
(524, 145, 4, 1, 1, '2014-01-09 14:41:23', '2014-01-09 14:41:23', 'P', 1, 0, 0, 0, 0, 0),
(525, 30, 4, 1, 1, '2014-01-09 15:24:13', '2014-01-09 15:24:13', 'P', 1, 0, 0, 0, 0, 0),
(526, 29, 4, 1, 1, '2014-01-09 15:25:03', '2014-01-09 15:25:03', 'P', 1, 0, 0, 0, 0, 0),
(527, 155, 4, 1, 1, '2014-01-09 16:24:48', '2014-01-09 16:24:48', 'P', 1, 0, 0, 0, 0, 0),
(528, 33, 4, 1, 1, '2014-01-09 16:29:41', '2014-01-09 16:29:41', 'P', 1, 0, 0, 0, 0, 0),
(529, 38, 4, 1, 1, '2014-01-09 16:57:51', '2014-01-09 16:57:51', 'P', 1, 0, 0, 0, 0, 0),
(530, 141, 4, 1, 1, '2014-01-09 18:25:19', '2014-01-09 18:25:19', 'P', 1, 0, 0, 0, 0, 0),
(531, 135, 4, 1, 1, '2014-01-09 18:28:59', '2014-01-09 18:28:59', 'P', 1, 0, 0, 0, 0, 0),
(532, 35, 4, 1, 1, '2014-01-09 18:44:58', '2014-01-09 18:44:58', 'P', 1, 0, 0, 0, 0, 0),
(533, 35, 4, 1, 1, '2014-01-09 18:47:39', '2014-01-09 18:47:39', 'P', 1, 0, 0, 0, 0, 0),
(534, 2, 4, 1, 1, '2014-01-09 18:48:11', '2014-01-09 18:48:11', 'P', 1, 0, 0, 0, 0, 0),
(535, 133, 4, 1, 1, '2014-01-09 18:53:20', '2014-01-09 18:53:20', 'P', 1, 0, 0, 0, 0, 0),
(536, 166, 4, 1, 1, '2014-01-09 19:00:29', '2014-01-09 19:00:29', 'P', 1, 0, 0, 0, 0, 0),
(537, 185, 4, 1, 1, '2014-01-09 19:04:07', '2014-01-09 19:04:07', 'P', 1, 0, 0, 0, 0, 0),
(538, 178, 4, 1, 1, '2014-01-09 19:12:18', '2014-01-09 19:12:18', 'P', 1, 0, 0, 0, 0, 0),
(539, 32, 4, 1, 1, '2014-01-09 19:39:50', '2014-01-09 19:39:50', 'P', 1, 0, 0, 0, 0, 0),
(540, 34, 4, 1, 1, '2014-01-09 19:52:40', '2014-01-09 19:52:40', 'P', 1, 0, 0, 0, 0, 0),
(541, 28, 4, 1, 1, '2014-01-09 19:53:46', '2014-01-09 19:53:46', 'P', 1, 0, 0, 0, 0, 0),
(542, 133, 4, 1, 1, '2014-01-09 20:51:41', '2014-01-09 20:51:41', 'P', 1, 0, 0, 0, 0, 0),
(543, 135, 4, 1, 1, '2014-01-09 21:05:31', '2014-01-09 21:05:31', 'P', 1, 0, 0, 0, 0, 0),
(544, 33, 4, 1, 1, '2014-01-09 21:30:47', '2014-01-09 21:30:47', 'P', 1, 0, 0, 0, 0, 0),
(545, 33, 4, 1, 1, '2014-01-09 21:45:55', '2014-01-09 21:45:55', 'P', 1, 0, 0, 0, 0, 0),
(546, 2, 4, 1, 1, '2014-01-10 09:13:21', '2014-01-10 09:13:21', 'P', 1, 0, 0, 0, 0, 0),
(547, 166, 4, 1, 1, '2014-01-10 09:13:36', '2014-01-10 09:13:36', 'P', 1, 0, 0, 0, 0, 0),
(548, 144, 4, 1, 1, '2014-01-10 09:13:50', '2014-01-10 09:13:50', 'P', 1, 0, 0, 0, 0, 0),
(549, 142, 4, 1, 1, '2014-01-10 09:14:22', '2014-01-10 09:14:22', 'P', 1, 0, 0, 0, 0, 0),
(550, 135, 4, 1, 1, '2014-01-10 09:14:49', '2014-01-10 09:14:49', 'P', 1, 0, 0, 0, 0, 0),
(551, 33, 4, 1, 1, '2014-01-10 09:15:02', '2014-01-10 09:15:02', 'P', 1, 0, 0, 0, 0, 0),
(552, 2, 4, 1, 1, '2014-01-10 09:15:23', '2014-01-10 09:15:23', 'P', 1, 0, 0, 0, 0, 0),
(553, 133, 4, 1, 1, '2014-01-10 09:15:44', '2014-01-10 09:15:44', 'P', 1, 0, 0, 0, 0, 0),
(554, 145, 4, 1, 1, '2014-01-10 09:15:58', '2014-01-10 09:15:58', 'P', 1, 0, 0, 0, 0, 0),
(555, 31, 4, 1, 1, '2014-01-10 09:16:24', '2014-01-10 09:16:24', 'P', 1, 0, 0, 0, 0, 0),
(556, 185, 4, 1, 1, '2014-01-10 09:16:56', '2014-01-10 09:16:56', 'P', 1, 0, 0, 0, 0, 0),
(557, 177, 4, 1, 1, '2014-01-10 09:37:44', '2014-01-10 09:37:44', 'P', 1, 0, 0, 0, 0, 0),
(558, 28, 4, 1, 1, '2014-01-10 09:39:54', '2014-01-10 09:39:54', 'P', 1, 0, 0, 0, 0, 0),
(559, 1, 4, 1, 1, '2014-01-10 09:40:38', '2014-01-10 09:40:38', 'P', 1, 0, 0, 0, 0, 0),
(560, 3, 4, 1, 1, '2014-01-10 09:42:18', '2014-01-10 09:42:18', 'P', 1, 0, 0, 0, 0, 0),
(561, 143, 4, 1, 1, '2014-01-10 09:46:48', '2014-01-10 09:46:48', 'P', 1, 0, 0, 0, 0, 0),
(562, 4, 4, 1, 1, '2014-01-10 10:13:55', '2014-01-10 10:13:55', 'P', 1, 0, 0, 0, 0, 0),
(563, 31, 4, 1, 1, '2014-01-10 10:14:06', '2014-01-10 10:14:06', 'P', 1, 0, 0, 0, 0, 0),
(564, 174, 4, 1, 1, '2014-01-10 10:34:27', '2014-01-10 10:34:27', 'P', 1, 0, 0, 0, 0, 0),
(565, 145, 4, 1, 1, '2014-01-10 11:11:21', '2014-01-10 11:11:21', 'P', 1, 0, 0, 0, 0, 0),
(566, 177, 4, 1, 1, '2014-01-10 11:57:48', '2014-01-10 11:57:48', 'P', 1, 0, 0, 0, 0, 0),
(567, 31, 4, 1, 1, '2014-01-10 11:58:00', '2014-01-10 11:58:00', 'P', 1, 0, 0, 0, 0, 0),
(568, 143, 4, 1, 1, '2014-01-10 11:58:27', '2014-01-10 11:58:27', 'P', 1, 0, 0, 0, 0, 0),
(569, 166, 4, 1, 1, '2014-01-10 12:58:28', '2014-01-10 12:58:28', 'P', 1, 0, 0, 0, 0, 0),
(570, 150, 4, 1, 1, '2014-01-10 13:43:28', '2014-01-10 13:43:28', 'P', 1, 0, 0, 0, 0, 0),
(571, 152, 4, 1, 1, '2014-01-10 13:47:44', '2014-01-10 13:47:44', 'P', 1, 0, 0, 0, 0, 0),
(572, 185, 4, 1, 1, '2014-01-10 14:01:03', '2014-01-10 14:01:03', 'P', 1, 0, 0, 0, 0, 0),
(573, 140, 4, 1, 1, '2014-01-10 15:13:30', '2014-01-10 15:13:30', 'P', 1, 0, 0, 0, 0, 0),
(574, 3, 4, 1, 1, '2014-01-10 15:21:12', '2014-01-10 15:21:12', 'P', 1, 0, 0, 0, 0, 0),
(575, 1, 4, 1, 1, '2014-01-10 15:21:25', '2014-01-10 15:21:25', 'P', 1, 0, 0, 0, 0, 0),
(576, 151, 4, 1, 1, '2014-01-10 15:36:27', '2014-01-10 15:36:27', 'P', 1, 0, 0, 0, 0, 0),
(577, 35, 4, 1, 1, '2014-01-10 15:55:12', '2014-01-10 15:55:12', 'P', 1, 0, 0, 0, 0, 0),
(578, 33, 4, 1, 1, '2014-01-10 16:01:01', '2014-01-10 16:01:01', 'P', 1, 0, 0, 0, 0, 0),
(579, 189, 4, 1, 1, '2014-01-10 17:27:38', '2014-01-10 17:27:38', 'P', 1, 0, 0, 0, 0, 0),
(580, 31, 4, 1, 1, '2014-01-10 17:36:26', '2014-01-10 17:36:26', 'P', 1, 0, 0, 0, 0, 0),
(581, 3, 4, 1, 1, '2014-01-10 17:41:05', '2014-01-10 17:41:05', 'P', 1, 0, 0, 0, 0, 0),
(582, 133, 4, 1, 1, '2014-01-10 17:49:48', '2014-01-10 17:49:48', 'P', 1, 0, 0, 0, 0, 0),
(583, 32, 4, 1, 1, '2014-01-10 17:53:57', '2014-01-10 17:53:57', 'P', 1, 0, 0, 0, 0, 0),
(584, 2, 4, 1, 1, '2014-01-10 18:04:39', '2014-01-10 18:04:39', 'P', 1, 0, 0, 0, 0, 0),
(585, 35, 4, 1, 1, '2014-01-10 18:06:46', '2014-01-10 18:06:46', 'P', 1, 0, 0, 0, 0, 0),
(586, 177, 4, 1, 1, '2014-01-10 18:07:59', '2014-01-10 18:07:59', 'P', 1, 0, 0, 0, 0, 0),
(587, 2, 4, 1, 1, '2014-01-10 18:12:25', '2014-01-10 18:12:25', 'P', 1, 0, 0, 0, 0, 0),
(588, 2, 4, 1, 1, '2014-01-10 18:17:01', '2014-01-10 18:17:01', 'P', 1, 0, 0, 0, 0, 0),
(589, 133, 4, 1, 1, '2014-01-10 18:20:54', '2014-01-10 18:20:54', 'P', 1, 0, 0, 0, 0, 0),
(590, 191, 4, 1, 1, '2014-01-10 18:25:43', '2014-01-10 18:25:43', 'P', 1, 0, 0, 0, 0, 0),
(591, 34, 4, 1, 1, '2014-01-10 18:26:45', '2014-01-10 18:26:45', 'P', 1, 0, 0, 0, 0, 0),
(592, 190, 4, 1, 1, '2014-01-10 18:27:08', '2014-01-10 18:27:08', 'P', 1, 0, 0, 0, 0, 0),
(593, 32, 4, 1, 1, '2014-01-10 18:33:12', '2014-01-10 18:33:12', 'P', 1, 0, 0, 0, 0, 0),
(594, 177, 4, 1, 1, '2014-01-10 18:34:58', '2014-01-10 18:34:58', 'P', 1, 0, 0, 0, 0, 0),
(595, 2, 4, 1, 1, '2014-01-10 18:38:51', '2014-01-10 18:38:51', 'P', 1, 0, 0, 0, 0, 0),
(596, 32, 4, 1, 1, '2014-01-10 18:39:40', '2014-01-10 18:39:40', 'P', 1, 0, 0, 0, 0, 0),
(597, 141, 4, 1, 1, '2014-01-10 18:43:32', '2014-01-10 18:43:32', 'P', 1, 0, 0, 0, 0, 0),
(598, 145, 4, 1, 1, '2014-01-10 18:51:37', '2014-01-10 18:51:37', 'P', 1, 0, 0, 0, 0, 0),
(599, 135, 4, 1, 1, '2014-01-10 18:55:36', '2014-01-10 18:55:36', 'P', 1, 0, 0, 0, 0, 0),
(600, 141, 4, 1, 1, '2014-01-10 18:57:14', '2014-01-10 18:57:14', 'P', 1, 0, 0, 0, 0, 0),
(601, 30, 4, 1, 1, '2014-01-10 18:59:18', '2014-01-10 18:59:18', 'P', 1, 0, 0, 0, 0, 0),
(602, 142, 4, 1, 1, '2014-01-10 19:02:30', '2014-01-10 19:02:30', 'P', 1, 0, 0, 0, 0, 0),
(603, 2, 4, 1, 1, '2014-01-10 19:07:18', '2014-01-10 19:07:18', 'P', 1, 0, 0, 0, 0, 0),
(604, 41, 4, 1, 1, '2014-01-10 19:07:41', '2014-01-10 19:07:41', 'P', 1, 0, 0, 0, 0, 0),
(605, 35, 4, 1, 1, '2014-01-10 19:30:45', '2014-01-10 19:30:45', 'P', 1, 0, 0, 0, 0, 0),
(606, 136, 4, 1, 1, '2014-01-10 19:44:23', '2014-01-10 19:44:23', 'P', 1, 0, 0, 0, 0, 0),
(607, 32, 4, 1, 1, '2014-01-10 19:53:02', '2014-01-10 19:53:02', 'P', 1, 0, 0, 0, 0, 0),
(608, 28, 4, 1, 1, '2014-01-10 19:54:03', '2014-01-10 19:54:03', 'P', 1, 0, 0, 0, 0, 0),
(609, 138, 4, 1, 1, '2014-01-10 20:06:51', '2014-01-10 20:06:51', 'P', 1, 0, 0, 0, 0, 0),
(610, 142, 4, 1, 1, '2014-01-10 20:14:27', '2014-01-10 20:14:27', 'P', 1, 0, 0, 0, 0, 0),
(611, 151, 4, 1, 1, '2014-01-10 20:53:06', '2014-01-10 20:53:06', 'P', 1, 0, 0, 0, 0, 0),
(612, 1, 4, 1, 1, '2014-01-10 20:53:18', '2014-01-10 20:53:18', 'P', 1, 0, 0, 0, 0, 0),
(613, 32, 4, 1, 1, '2014-01-10 20:58:30', '2014-01-10 20:58:30', 'P', 1, 0, 0, 0, 0, 0),
(614, 32, 4, 1, 1, '2014-01-10 21:45:54', '2014-01-10 21:45:54', 'P', 1, 0, 0, 0, 0, 0),
(615, 33, 4, 1, 1, '2014-01-10 22:13:59', '2014-01-10 22:13:59', 'P', 1, 0, 0, 0, 0, 0),
(616, 140, 4, 1, 1, '2014-01-11 06:45:22', '2014-01-11 06:45:22', 'P', 1, 0, 0, 0, 0, 0),
(617, 34, 4, 1, 1, '2014-01-11 06:45:40', '2014-01-11 06:45:40', 'P', 1, 0, 0, 0, 0, 0),
(619, 30, 4, 1, 1, '2014-01-11 07:40:51', '2014-01-11 07:40:51', 'P', 1, 0, 0, 0, 0, 0),
(620, 41, 4, 1, 1, '2014-01-11 08:14:58', '2014-01-11 08:14:58', 'P', 1, 0, 0, 0, 0, 0),
(621, 150, 4, 1, 1, '2014-01-11 08:28:17', '2014-01-11 08:28:17', 'P', 1, 0, 0, 0, 0, 0),
(622, 142, 4, 1, 1, '2014-01-11 08:29:27', '2014-01-11 08:29:27', 'P', 1, 0, 0, 0, 0, 0),
(623, 35, 4, 1, 1, '2014-01-11 08:37:07', '2014-01-11 08:37:07', 'P', 1, 0, 0, 0, 0, 0),
(624, 3, 4, 1, 1, '2014-01-11 09:01:48', '2014-01-11 09:01:48', 'P', 1, 0, 0, 0, 0, 0),
(625, 143, 4, 1, 1, '2014-01-11 09:42:26', '2014-01-11 09:42:26', 'P', 1, 0, 0, 0, 0, 0),
(626, 31, 4, 1, 1, '2014-01-11 09:51:40', '2014-01-11 09:51:40', 'P', 1, 0, 0, 0, 0, 0),
(627, 35, 4, 1, 1, '2014-01-11 10:32:57', '2014-01-11 10:32:57', 'P', 1, 0, 0, 0, 0, 0),
(628, 4, 4, 1, 1, '2014-01-11 12:07:08', '2014-01-11 12:07:08', 'P', 1, 0, 0, 0, 0, 0),
(629, 166, 4, 1, 1, '2014-01-11 12:07:25', '2014-01-11 12:07:25', 'P', 1, 0, 0, 0, 0, 0),
(630, 150, 4, 1, 1, '2014-01-11 12:47:13', '2014-01-11 12:47:13', 'P', 1, 0, 0, 0, 0, 0),
(631, 28, 4, 1, 1, '2014-01-11 13:16:19', '2014-01-11 13:16:19', 'P', 1, 0, 0, 0, 0, 0),
(632, 3, 4, 1, 1, '2014-01-11 13:19:22', '2014-01-11 13:19:22', 'P', 1, 0, 0, 0, 0, 0),
(633, 166, 4, 1, 1, '2014-01-11 13:31:22', '2014-01-11 13:31:22', 'P', 1, 0, 0, 0, 0, 0),
(634, 175, 4, 1, 1, '2014-01-11 13:31:57', '2014-01-11 13:31:57', 'P', 1, 0, 0, 0, 0, 0),
(635, 191, 4, 1, 1, '2014-01-11 14:03:48', '2014-01-11 14:03:48', 'P', 1, 0, 0, 0, 0, 0),
(636, 29, 4, 1, 1, '2014-01-11 14:04:05', '2014-01-11 14:04:05', 'P', 1, 0, 0, 0, 0, 0),
(637, 4, 4, 1, 1, '2014-01-11 14:07:24', '2014-01-11 14:07:24', 'P', 1, 0, 0, 0, 0, 0),
(638, 185, 4, 1, 1, '2014-01-11 14:19:44', '2014-01-11 14:19:44', 'P', 1, 0, 0, 0, 0, 0),
(639, 135, 4, 1, 1, '2014-01-11 14:56:49', '2014-01-11 14:56:49', 'P', 1, 0, 0, 0, 0, 0),
(640, 185, 4, 1, 1, '2014-01-11 15:07:49', '2014-01-11 15:07:49', 'P', 1, 0, 0, 0, 0, 0),
(641, 157, 4, 1, 1, '2014-01-11 16:00:50', '2014-01-11 16:00:50', 'P', 1, 0, 0, 0, 0, 0),
(642, 135, 4, 1, 1, '2014-01-11 16:34:05', '2014-01-11 16:34:05', 'P', 1, 0, 0, 0, 0, 0),
(643, 33, 4, 1, 1, '2014-01-11 18:58:22', '2014-01-11 18:58:22', 'P', 1, 0, 0, 0, 0, 0),
(644, 3, 4, 1, 1, '2014-01-11 18:58:55', '2014-01-11 18:58:55', 'P', 1, 0, 0, 0, 0, 0),
(645, 133, 4, 1, 1, '2014-01-11 18:59:10', '2014-01-11 18:59:10', 'P', 1, 0, 0, 0, 0, 0),
(646, 35, 4, 1, 1, '2014-01-11 19:07:22', '2014-01-11 19:07:22', 'P', 1, 0, 0, 0, 0, 0),
(647, 41, 4, 1, 1, '2014-01-11 19:12:04', '2014-01-11 19:12:04', 'P', 1, 0, 0, 0, 0, 0),
(648, 2, 4, 1, 1, '2014-01-11 19:22:50', '2014-01-11 19:22:50', 'P', 1, 0, 0, 0, 0, 0),
(649, 141, 4, 1, 1, '2014-01-11 19:27:12', '2014-01-11 19:27:12', 'P', 1, 0, 0, 0, 0, 0),
(650, 31, 4, 1, 1, '2014-01-11 19:30:19', '2014-01-11 19:30:19', 'P', 1, 0, 0, 0, 0, 0),
(651, 28, 4, 1, 1, '2014-01-11 19:32:27', '2014-01-11 19:32:27', 'P', 1, 0, 0, 0, 0, 0),
(652, 1, 4, 1, 1, '2014-01-11 19:34:51', '2014-01-11 19:34:51', 'P', 1, 0, 0, 0, 0, 0),
(653, 31, 4, 1, 1, '2014-01-11 19:44:49', '2014-01-11 19:44:49', 'P', 1, 0, 0, 0, 0, 0),
(654, 133, 4, 1, 1, '2014-01-11 19:47:35', '2014-01-11 19:47:35', 'P', 1, 0, 0, 0, 0, 0),
(655, 137, 4, 1, 1, '2014-01-11 19:55:09', '2014-01-11 19:55:09', 'P', 1, 0, 0, 0, 0, 0),
(656, 33, 4, 1, 1, '2014-01-11 19:58:14', '2014-01-11 19:58:14', 'P', 1, 0, 0, 0, 0, 0),
(657, 166, 4, 1, 1, '2014-01-11 20:01:15', '2014-01-11 20:01:15', 'P', 1, 0, 0, 0, 0, 0),
(658, 138, 4, 1, 1, '2014-01-11 20:42:32', '2014-01-11 20:42:32', 'P', 1, 0, 0, 0, 0, 0),
(659, 35, 4, 1, 1, '2014-01-11 21:47:02', '2014-01-11 21:47:02', 'P', 1, 0, 0, 0, 0, 0),
(660, 1, 4, 1, 1, '2014-01-11 22:02:45', '2014-01-11 22:02:45', 'P', 1, 0, 0, 0, 0, 0),
(662, 32, 4, 1, 1, '2014-01-12 00:08:51', '2014-01-12 00:08:51', 'P', 1, 0, 0, 0, 0, 0),
(664, 1, 4, 1, 1, '2014-01-12 01:28:10', '2014-01-12 01:28:10', 'P', 1, 0, 0, 0, 0, 0),
(665, 2, 4, 1, 1, '2014-01-12 01:43:54', '2014-01-12 01:43:54', 'P', 1, 0, 0, 0, 0, 0),
(666, 38, 4, 1, 1, '2014-01-12 07:14:11', '2014-01-12 07:14:11', 'P', 1, 0, 0, 0, 0, 0),
(667, 2, 4, 1, 1, '2014-01-12 07:48:24', '2014-01-12 07:48:24', 'P', 1, 0, 0, 0, 0, 0),
(668, 144, 4, 1, 1, '2014-01-12 07:50:08', '2014-01-12 07:50:08', 'P', 1, 0, 0, 0, 0, 0),
(669, 30, 4, 1, 1, '2014-01-12 07:51:39', '2014-01-12 07:51:39', 'P', 1, 0, 0, 0, 0, 0),
(670, 156, 4, 1, 1, '2014-01-12 07:52:15', '2014-01-12 07:52:15', 'P', 1, 0, 0, 0, 0, 0),
(671, 141, 4, 1, 1, '2014-01-12 07:53:44', '2014-01-12 07:53:44', 'P', 1, 0, 0, 0, 0, 0),
(672, 185, 4, 1, 1, '2014-01-12 08:13:37', '2014-01-12 08:13:37', 'P', 1, 0, 0, 0, 0, 0),
(673, 163, 4, 1, 1, '2014-01-12 08:15:25', '2014-01-12 08:15:25', 'P', 1, 0, 0, 0, 0, 0),
(674, 41, 4, 1, 1, '2014-01-12 08:30:06', '2014-01-12 08:30:06', 'P', 1, 0, 0, 0, 0, 0),
(675, 4, 4, 1, 1, '2014-01-12 08:36:19', '2014-01-12 08:36:19', 'P', 1, 0, 0, 0, 0, 0),
(677, 31, 4, 1, 1, '2014-01-12 08:42:00', '2014-01-12 08:42:00', 'P', 1, 0, 0, 0, 0, 0),
(678, 185, 4, 1, 1, '2014-01-12 08:43:00', '2014-01-12 08:43:00', 'P', 1, 0, 0, 0, 0, 0),
(679, 186, 4, 1, 1, '2014-01-12 08:43:34', '2014-01-12 08:43:34', 'P', 1, 0, 0, 0, 0, 0),
(680, 143, 4, 1, 1, '2014-01-12 09:12:04', '2014-01-12 09:12:04', 'P', 1, 0, 0, 0, 0, 0),
(681, 1, 4, 1, 1, '2014-01-12 09:18:31', '2014-01-12 09:18:31', 'P', 1, 0, 0, 0, 0, 0),
(682, 133, 4, 1, 1, '2014-01-12 09:37:25', '2014-01-12 09:37:25', 'P', 1, 0, 0, 0, 0, 0),
(683, 32, 4, 1, 1, '2014-01-12 09:40:56', '2014-01-12 09:40:56', 'P', 1, 0, 0, 0, 0, 0),
(684, 166, 4, 1, 1, '2014-01-12 09:41:28', '2014-01-12 09:41:28', 'P', 1, 0, 0, 0, 0, 0),
(685, 30, 4, 1, 1, '2014-01-12 10:29:57', '2014-01-12 10:29:57', 'P', 1, 0, 0, 0, 0, 0),
(686, 150, 4, 1, 1, '2014-01-12 11:27:53', '2014-01-12 11:27:53', 'P', 1, 0, 0, 0, 0, 0),
(687, 145, 4, 1, 1, '2014-01-12 11:29:33', '2014-01-12 11:29:33', 'P', 1, 0, 0, 0, 0, 0),
(688, 166, 4, 1, 1, '2014-01-12 11:47:08', '2014-01-12 11:47:08', 'P', 1, 0, 0, 0, 0, 0),
(689, 3, 4, 1, 1, '2014-01-12 14:06:38', '2014-01-12 14:06:38', 'P', 1, 0, 0, 0, 0, 0),
(690, 2, 4, 1, 1, '2014-01-12 14:25:45', '2014-01-12 14:25:45', 'P', 1, 0, 0, 0, 0, 0),
(691, 145, 4, 1, 1, '2014-01-12 15:03:25', '2014-01-12 15:03:25', 'P', 1, 0, 0, 0, 0, 0),
(692, 33, 4, 1, 1, '2014-01-12 15:03:41', '2014-01-12 15:03:41', 'P', 1, 0, 0, 0, 0, 0),
(693, 166, 4, 1, 1, '2014-01-12 15:18:31', '2014-01-12 15:18:31', 'P', 1, 0, 0, 0, 0, 0),
(694, 142, 4, 1, 1, '2014-01-12 15:26:45', '2014-01-12 15:26:45', 'P', 1, 0, 0, 0, 0, 0),
(695, 178, 4, 1, 1, '2014-01-12 17:57:02', '2014-01-12 17:57:02', 'P', 1, 0, 0, 0, 0, 0),
(696, 149, 4, 1, 1, '2014-01-12 17:57:41', '2014-01-12 17:57:41', 'P', 1, 0, 0, 0, 0, 0),
(697, 156, 4, 1, 1, '2014-01-12 18:16:31', '2014-01-12 18:16:31', 'P', 1, 0, 0, 0, 0, 0),
(698, 33, 4, 1, 1, '2014-01-12 18:46:22', '2014-01-12 18:46:22', 'P', 1, 0, 0, 0, 0, 0),
(699, 34, 4, 1, 1, '2014-01-12 19:07:09', '2014-01-12 19:07:09', 'P', 1, 0, 0, 0, 0, 0),
(700, 2, 4, 1, 1, '2014-01-12 20:08:24', '2014-01-12 20:08:24', 'P', 1, 0, 0, 0, 0, 0),
(701, 136, 4, 1, 1, '2014-01-12 20:11:36', '2014-01-12 20:11:36', 'P', 1, 0, 0, 0, 0, 0),
(702, 178, 4, 1, 1, '2014-01-12 20:27:19', '2014-01-12 20:27:19', 'P', 1, 0, 0, 0, 0, 0),
(703, 33, 4, 1, 1, '2014-01-12 20:45:18', '2014-01-12 20:45:18', 'P', 1, 0, 0, 0, 0, 0),
(704, 1, 4, 1, 1, '2014-01-12 20:49:32', '2014-01-12 20:49:32', 'P', 1, 0, 0, 0, 0, 0),
(705, 32, 4, 1, 1, '2014-01-12 20:54:58', '2014-01-12 20:54:58', 'P', 1, 0, 0, 0, 0, 0),
(706, 31, 4, 1, 1, '2014-01-12 20:55:39', '2014-01-12 20:55:39', 'P', 1, 0, 0, 0, 0, 0),
(707, 3, 4, 1, 1, '2014-01-12 20:56:10', '2014-01-12 20:56:10', 'P', 1, 0, 0, 0, 0, 0),
(708, 3, 4, 1, 1, '2014-01-12 21:17:04', '2014-01-12 21:17:04', 'P', 1, 0, 0, 0, 0, 0),
(709, 28, 4, 1, 1, '2014-01-12 21:17:42', '2014-01-12 21:17:42', 'P', 1, 0, 0, 0, 0, 0),
(710, 41, 4, 1, 1, '2014-01-12 21:25:42', '2014-01-12 21:25:42', 'P', 1, 0, 0, 0, 0, 0),
(711, 133, 4, 1, 1, '2014-01-12 21:46:05', '2014-01-12 21:46:05', 'P', 1, 0, 0, 0, 0, 0),
(712, 4, 4, 1, 1, '2014-01-12 21:49:56', '2014-01-12 21:49:56', 'P', 1, 0, 0, 0, 0, 0),
(713, 2, 4, 1, 1, '2014-01-12 22:10:20', '2014-01-12 22:10:20', 'P', 1, 0, 0, 0, 0, 0),
(714, 185, 4, 1, 1, '2014-01-12 22:15:48', '2014-01-12 22:15:48', 'P', 1, 0, 0, 0, 0, 0),
(715, 3, 4, 1, 1, '2014-01-12 22:37:42', '2014-01-12 22:37:42', 'P', 1, 0, 0, 0, 0, 0),
(716, 142, 4, 1, 1, '2014-01-13 07:17:03', '2014-01-13 07:17:03', 'P', 1, 0, 0, 0, 0, 0),
(717, 38, 4, 1, 1, '2014-01-13 08:25:48', '2014-01-13 08:25:48', 'P', 1, 0, 0, 0, 0, 0),
(718, 31, 4, 1, 1, '2014-01-13 08:27:04', '2014-01-13 08:27:04', 'P', 1, 0, 0, 0, 0, 0),
(719, 152, 4, 1, 1, '2014-01-13 08:27:15', '2014-01-13 08:27:15', 'P', 1, 0, 0, 0, 0, 0),
(720, 32, 4, 1, 1, '2014-01-13 08:27:33', '2014-01-13 08:27:33', 'P', 1, 0, 0, 0, 0, 0),
(721, 2, 4, 1, 1, '2014-01-13 08:30:22', '2014-01-13 08:30:22', 'P', 1, 0, 0, 0, 0, 0),
(722, 1, 4, 1, 1, '2014-01-13 08:32:18', '2014-01-13 08:32:18', 'P', 1, 0, 0, 0, 0, 0),
(723, 166, 4, 1, 1, '2014-01-13 08:49:37', '2014-01-13 08:49:37', 'P', 1, 0, 0, 0, 0, 0),
(724, 141, 4, 1, 1, '2014-01-13 08:49:59', '2014-01-13 08:49:59', 'P', 1, 0, 0, 0, 0, 0),
(725, 4, 4, 1, 1, '2014-01-13 09:05:11', '2014-01-13 09:05:11', 'P', 1, 0, 0, 0, 0, 0),
(726, 145, 4, 1, 1, '2014-01-13 09:16:20', '2014-01-13 09:16:20', 'P', 1, 0, 0, 0, 0, 0),
(727, 34, 4, 1, 1, '2014-01-13 09:19:56', '2014-01-13 09:19:56', 'P', 1, 0, 0, 0, 0, 0),
(728, 149, 4, 1, 1, '2014-01-13 09:27:23', '2014-01-13 09:27:23', 'P', 1, 0, 0, 0, 0, 0),
(729, 166, 4, 1, 1, '2014-01-13 09:58:12', '2014-01-13 09:58:12', 'P', 1, 0, 0, 0, 0, 0),
(730, 172, 4, 1, 1, '2014-01-13 10:00:54', '2014-01-13 10:00:54', 'P', 1, 0, 0, 0, 0, 0),
(731, 178, 4, 1, 1, '2014-01-13 10:43:11', '2014-01-13 10:43:11', 'P', 1, 0, 0, 0, 0, 0),
(732, 2, 4, 1, 1, '2014-01-13 10:54:25', '2014-01-13 10:54:25', 'P', 1, 0, 0, 0, 0, 0),
(734, 168, 4, 1, 1, '2014-01-13 11:26:05', '2014-01-13 11:26:05', 'P', 1, 0, 0, 0, 0, 0),
(735, 28, 4, 1, 1, '2014-01-13 12:39:42', '2014-01-13 12:39:42', 'P', 1, 0, 0, 0, 0, 0),
(736, 170, 4, 1, 1, '2014-01-13 14:08:54', '2014-01-13 14:08:54', 'P', 1, 0, 0, 0, 0, 0),
(737, 28, 4, 1, 1, '2014-01-13 14:09:04', '2014-01-13 14:09:04', 'P', 1, 0, 0, 0, 0, 0),
(738, 185, 4, 1, 1, '2014-01-13 14:09:42', '2014-01-13 14:09:42', 'P', 1, 0, 0, 0, 0, 0),
(739, 186, 4, 1, 1, '2014-01-13 14:10:12', '2014-01-13 14:10:12', 'P', 1, 0, 0, 0, 0, 0),
(740, 140, 4, 1, 1, '2014-01-13 14:16:23', '2014-01-13 14:16:23', 'P', 1, 0, 0, 0, 0, 0),
(741, 175, 4, 1, 1, '2014-01-13 14:58:07', '2014-01-13 14:58:07', 'P', 1, 0, 0, 0, 0, 0),
(742, 151, 4, 1, 1, '2014-01-13 15:05:16', '2014-01-13 15:05:16', 'P', 1, 0, 0, 0, 0, 0),
(743, 137, 4, 1, 1, '2014-01-13 15:25:32', '2014-01-13 15:25:32', 'P', 1, 0, 0, 0, 0, 0),
(744, 140, 4, 1, 1, '2014-01-13 17:01:25', '2014-01-13 17:01:25', 'P', 1, 0, 0, 0, 0, 0),
(745, 38, 4, 1, 1, '2014-01-13 17:21:27', '2014-01-13 17:21:27', 'P', 1, 0, 0, 0, 0, 0),
(746, 133, 4, 1, 1, '2014-01-13 17:24:28', '2014-01-13 17:24:28', 'P', 1, 0, 0, 0, 0, 0),
(747, 138, 4, 1, 1, '2014-01-13 17:30:25', '2014-01-13 17:30:25', 'P', 1, 0, 0, 0, 0, 0),
(748, 38, 4, 1, 1, '2014-01-13 18:25:20', '2014-01-13 18:25:20', 'P', 1, 0, 0, 0, 0, 0),
(749, 34, 4, 1, 1, '2014-01-13 18:47:51', '2014-01-13 18:47:51', 'P', 1, 0, 0, 0, 0, 0),
(750, 38, 4, 1, 1, '2014-01-13 19:22:23', '2014-01-13 19:22:23', 'P', 1, 0, 0, 0, 0, 0),
(751, 133, 4, 1, 1, '2014-01-13 19:34:26', '2014-01-13 19:34:26', 'P', 1, 0, 0, 0, 0, 0),
(752, 166, 4, 1, 1, '2014-01-13 19:35:44', '2014-01-13 19:35:44', 'P', 1, 0, 0, 0, 0, 0),
(753, 137, 4, 1, 1, '2014-01-13 19:36:34', '2014-01-13 19:36:34', 'P', 1, 0, 0, 0, 0, 0),
(754, 152, 4, 1, 1, '2014-01-13 19:46:02', '2014-01-13 19:46:02', 'P', 1, 0, 0, 0, 0, 0),
(755, 32, 4, 1, 1, '2014-01-13 20:11:03', '2014-01-13 20:11:03', 'P', 1, 0, 0, 0, 0, 0),
(756, 35, 4, 1, 1, '2014-01-13 20:15:30', '2014-01-13 20:15:30', 'P', 1, 0, 0, 0, 0, 0),
(757, 136, 4, 1, 1, '2014-01-13 20:16:08', '2014-01-13 20:16:08', 'P', 1, 0, 0, 0, 0, 0),
(758, 34, 4, 1, 1, '2014-01-13 20:31:00', '2014-01-13 20:31:00', 'P', 1, 0, 0, 0, 0, 0),
(759, 2, 4, 1, 1, '2014-01-13 20:44:50', '2014-01-13 20:44:50', 'P', 1, 0, 0, 0, 0, 0),
(760, 138, 4, 1, 1, '2014-01-13 21:21:08', '2014-01-13 21:21:08', 'P', 1, 0, 0, 0, 0, 0),
(761, 31, 4, 1, 1, '2014-01-14 06:44:58', '2014-01-14 06:44:58', 'P', 1, 0, 0, 0, 0, 0),
(762, 38, 4, 1, 1, '2014-01-14 07:32:31', '2014-01-14 07:32:31', 'P', 1, 0, 0, 0, 0, 0),
(763, 185, 4, 1, 1, '2014-01-14 07:35:57', '2014-01-14 07:35:57', 'P', 1, 0, 0, 0, 0, 0),
(764, 2, 4, 1, 1, '2014-01-14 07:41:23', '2014-01-14 07:41:23', 'P', 1, 0, 0, 0, 0, 0),
(765, 31, 4, 1, 1, '2014-01-14 07:45:48', '2014-01-14 07:45:48', 'P', 1, 0, 0, 0, 0, 0),
(766, 34, 4, 1, 1, '2014-01-14 08:32:37', '2014-01-14 08:32:37', 'P', 1, 0, 0, 0, 0, 0),
(767, 30, 4, 1, 1, '2014-01-14 08:59:16', '2014-01-14 08:59:16', 'P', 1, 0, 0, 0, 0, 0),
(768, 33, 4, 1, 1, '2014-01-14 09:00:17', '2014-01-14 09:00:17', '', 0, 0, 0, 0, 0, 0),
(769, 30, 4, 1, 1, '2014-01-14 09:01:49', '2014-01-14 09:01:49', '', 0, 0, 0, 0, 0, 0),
(770, 143, 4, 1, 1, '2014-01-14 09:42:45', '2014-01-14 09:42:45', 'P', 0, 0, 0, 0, 0, 0),
(771, 3, 4, 1, 1, '2014-01-14 10:03:44', '2014-01-14 10:03:44', '', 0, 0, 0, 0, 0, 0),
(772, 151, 4, 1, 1, '2014-01-14 10:15:56', '2014-01-14 10:15:56', '', 0, 0, 0, 0, 0, 0),
(773, 34, 4, 1, 1, '2014-01-14 10:41:55', '2014-01-14 10:41:55', '', 0, 0, 0, 0, 0, 0),
(774, 37, 4, 1, 1, '2014-01-15 18:20:49', '2014-01-15 18:20:49', '', 0, 0, 0, 0, 0, 0),
(775, 1, 4, 1, 1, '2014-01-20 16:22:01', '2014-01-20 16:22:01', '', 0, 0, 0, 0, 0, 0),
(776, 149, 4, 1, 1, '2014-02-02 03:30:47', '2014-02-02 03:30:47', '', 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `cafethemxua_session_detail`
--

CREATE TABLE IF NOT EXISTS `cafethemxua_session_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idsession` int(11) NOT NULL,
  `idcourse` int(11) NOT NULL,
  `count` int(11) NOT NULL,
  `price` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idsession` (`idsession`),
  KEY `idcourse` (`idcourse`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1258 ;

--
-- Dumping data for table `cafethemxua_session_detail`
--

INSERT INTO `cafethemxua_session_detail` (`id`, `idsession`, `idcourse`, `count`, `price`) VALUES
(128, 230, 107, 1, 8000),
(129, 230, 255, 1, 10000),
(131, 232, 224, 1, 8000),
(136, 235, 107, 4, 8000),
(140, 235, 222, 1, 10000),
(144, 237, 107, 2, 8000),
(145, 237, 174, 1, 12000),
(146, 237, 255, 3, 10000),
(147, 238, 107, 2, 8000),
(148, 238, 224, 1, 8000),
(149, 239, 224, 1, 8000),
(150, 240, 107, 2, 8000),
(151, 241, 212, 1, 12000),
(152, 242, 204, 2, 12000),
(153, 243, 107, 1, 8000),
(155, 244, 107, 3, 8000),
(157, 244, 180, 1, 12000),
(161, 245, 224, 2, 8000),
(162, 245, 107, 2, 8000),
(165, 244, 175, 1, 12000),
(169, 248, 107, 1, 8000),
(170, 248, 180, 1, 12000),
(173, 249, 224, 2, 8000),
(174, 250, 107, 2, 8000),
(180, 252, 255, 1, 10000),
(181, 252, 128, 1, 15000),
(183, 253, 107, 2, 8000),
(186, 254, 107, 1, 8000),
(187, 254, 222, 1, 8000),
(190, 256, 205, 1, 12000),
(191, 256, 335, 1, 10000),
(192, 257, 107, 1, 8000),
(193, 257, 255, 1, 10000),
(194, 258, 107, 1, 8000),
(195, 259, 107, 1, 8000),
(196, 260, 224, 1, 8000),
(197, 260, 204, 1, 12000),
(198, 261, 107, 1, 8000),
(199, 261, 268, 1, 8000),
(200, 262, 255, 1, 10000),
(201, 262, 107, 2, 8000),
(202, 262, 204, 2, 12000),
(205, 262, 177, 1, 15000),
(206, 262, 180, 1, 12000),
(209, 264, 107, 2, 8000),
(210, 265, 204, 2, 12000),
(211, 266, 107, 3, 8000),
(212, 266, 224, 2, 8000),
(213, 266, 189, 1, 18000),
(215, 267, 107, 1, 8000),
(216, 267, 56, 1, 15000),
(217, 265, 255, 2, 10000),
(218, 265, 335, 1, 10000),
(220, 262, 212, 1, 12000),
(221, 268, 224, 3, 8000),
(222, 268, 177, 3, 15000),
(223, 268, 179, 1, 15000),
(224, 269, 107, 2, 8000),
(226, 271, 107, 1, 8000),
(227, 271, 255, 2, 10000),
(228, 269, 176, 1, 10000),
(229, 262, 176, 2, 10000),
(230, 272, 176, 1, 10000),
(231, 272, 224, 1, 8000),
(232, 272, 221, 1, 10000),
(233, 267, 224, 1, 8000),
(240, 277, 178, 1, 13000),
(241, 265, 222, 1, 8000),
(242, 278, 204, 1, 12000),
(246, 281, 107, 1, 8000),
(247, 282, 107, 1, 8000),
(248, 283, 107, 1, 8000),
(249, 284, 107, 2, 8000),
(250, 284, 201, 1, 8000),
(251, 285, 112, 1, 10000),
(252, 285, 197, 1, 15000),
(253, 286, 107, 2, 8000),
(255, 287, 107, 1, 8000),
(256, 287, 204, 1, 12000),
(257, 288, 107, 2, 8000),
(259, 288, 255, 2, 12000),
(260, 288, 224, 1, 8000),
(262, 289, 107, 3, 8000),
(263, 290, 107, 1, 8000),
(264, 290, 176, 1, 8000),
(265, 289, 222, 1, 8000),
(266, 291, 204, 1, 12000),
(267, 291, 255, 1, 12000),
(268, 291, 107, 3, 8000),
(269, 292, 107, 1, 8000),
(270, 291, 174, 1, 12000),
(272, 292, 204, 2, 12000),
(276, 293, 107, 1, 8000),
(277, 293, 218, 1, 15000),
(280, 293, 175, 1, 12000),
(283, 295, 107, 1, 8000),
(286, 286, 176, 1, 8000),
(287, 296, 255, 2, 12000),
(290, 296, 212, 1, 10000),
(291, 293, 255, 1, 12000),
(292, 297, 107, 4, 8000),
(293, 298, 107, 1, 8000),
(294, 299, 107, 2, 8000),
(297, 301, 107, 2, 8000),
(298, 302, 107, 3, 8000),
(299, 302, 265, 1, 8000),
(300, 302, 197, 1, 15000),
(301, 303, 107, 4, 8000),
(303, 302, 175, 1, 12000),
(304, 302, 204, 1, 12000),
(305, 302, 315, 2, 15000),
(306, 302, 212, 1, 10000),
(307, 302, 255, 1, 12000),
(308, 302, 353, 1, 8000),
(309, 301, 205, 1, 12000),
(310, 304, 107, 1, 8000),
(312, 304, 204, 1, 12000),
(313, 305, 107, 2, 8000),
(316, 306, 176, 1, 8000),
(317, 307, 107, 1, 8000),
(318, 308, 175, 1, 12000),
(319, 308, 107, 1, 8000),
(320, 308, 212, 1, 10000),
(321, 309, 218, 1, 15000),
(322, 309, 224, 2, 8000),
(323, 309, 107, 1, 8000),
(324, 309, 255, 2, 12000),
(325, 310, 176, 1, 8000),
(326, 310, 268, 1, 8000),
(328, 311, 174, 1, 12000),
(329, 311, 107, 1, 8000),
(330, 312, 255, 3, 12000),
(331, 312, 224, 3, 8000),
(332, 312, 176, 1, 8000),
(333, 310, 112, 1, 10000),
(334, 310, 204, 1, 12000),
(335, 313, 107, 2, 8000),
(336, 314, 224, 1, 8000),
(337, 312, 107, 2, 8000),
(338, 312, 351, 1, 15000),
(339, 315, 224, 1, 8000),
(340, 315, 107, 2, 8000),
(352, 317, 224, 1, 8000),
(354, 319, 177, 1, 12000),
(355, 319, 107, 1, 8000),
(356, 320, 107, 5, 8000),
(357, 321, 107, 1, 8000),
(358, 322, 228, 1, 15000),
(359, 320, 189, 1, 18000),
(360, 324, 204, 1, 12000),
(361, 325, 107, 2, 8000),
(362, 321, 129, 1, 15000),
(366, 322, 107, 1, 8000),
(367, 326, 224, 2, 8000),
(369, 326, 179, 1, 15000),
(375, 328, 255, 5, 12000),
(376, 328, 204, 1, 12000),
(377, 328, 353, 1, 8000),
(378, 319, 180, 1, 8000),
(379, 319, 204, 3, 12000),
(380, 331, 224, 1, 8000),
(381, 327, 255, 1, 12000),
(382, 330, 107, 2, 8000),
(383, 331, 107, 1, 8000),
(384, 331, 255, 2, 12000),
(385, 332, 224, 1, 8000),
(386, 332, 107, 1, 8000),
(387, 333, 107, 1, 8000),
(388, 333, 224, 1, 8000),
(389, 334, 107, 1, 8000),
(390, 334, 351, 1, 15000),
(392, 335, 107, 1, 8000),
(394, 336, 107, 3, 8000),
(395, 320, 176, 2, 8000),
(396, 337, 107, 1, 8000),
(397, 337, 224, 1, 8000),
(398, 331, 255, 2, 12000),
(399, 338, 224, 1, 8000),
(400, 338, 335, 1, 10000),
(401, 339, 107, 2, 8000),
(402, 340, 107, 2, 8000),
(403, 340, 176, 1, 8000),
(404, 328, 175, 1, 12000),
(405, 339, 255, 1, 12000),
(406, 320, 224, 1, 8000),
(407, 341, 255, 1, 12000),
(409, 343, 203, 1, 12000),
(411, 343, 189, 1, 18000),
(412, 318, 107, 1, 8000),
(413, 318, 268, 1, 8000),
(414, 344, 107, 2, 8000),
(415, 344, 224, 1, 8000),
(416, 345, 107, 1, 8000),
(417, 345, 204, 1, 12000),
(418, 346, 107, 1, 8000),
(419, 347, 107, 1, 8000),
(420, 347, 224, 2, 8000),
(421, 348, 255, 5, 12000),
(423, 350, 107, 1, 8000),
(425, 352, 107, 1, 8000),
(428, 355, 355, 1, 15000),
(429, 356, 204, 1, 12000),
(433, 360, 107, 1, 8000),
(434, 360, 364, 5, 1000),
(435, 361, 107, 1, 8000),
(436, 354, 334, 4, 12000),
(437, 362, 226, 1, 8000),
(438, 363, 107, 2, 8000),
(439, 363, 204, 1, 12000),
(440, 363, 364, 6, 1000),
(444, 365, 255, 1, 12000),
(445, 365, 175, 2, 12000),
(446, 366, 107, 2, 8000),
(447, 316, 189, 1, 18000),
(448, 316, 308, 1, 22000),
(449, 316, 107, 4, 8000),
(450, 367, 107, 2, 8000),
(451, 368, 107, 2, 8000),
(452, 369, 107, 1, 8000),
(453, 369, 179, 2, 15000),
(454, 370, 107, 5, 8000),
(455, 370, 224, 2, 8000),
(456, 370, 177, 1, 12000),
(457, 370, 370, 1, 12000),
(458, 371, 107, 2, 8000),
(459, 370, 371, 1, 12000),
(460, 370, 364, 5, 1000),
(461, 370, 358, 1, 8000),
(462, 372, 224, 1, 8000),
(463, 373, 224, 1, 8000),
(464, 374, 224, 1, 8000),
(465, 375, 107, 2, 8000),
(466, 375, 218, 1, 15000),
(467, 375, 204, 1, 12000),
(468, 375, 362, 4, 1000),
(469, 373, 226, 1, 8000),
(470, 376, 204, 2, 12000),
(471, 377, 107, 3, 8000),
(472, 377, 224, 1, 8000),
(473, 378, 107, 1, 8000),
(474, 379, 107, 4, 8000),
(475, 380, 255, 1, 12000),
(476, 380, 107, 3, 8000),
(477, 380, 224, 1, 8000),
(478, 380, 176, 1, 8000),
(479, 381, 204, 1, 12000),
(480, 381, 332, 1, 12000),
(481, 382, 107, 2, 8000),
(482, 383, 255, 3, 12000),
(483, 383, 107, 2, 8000),
(484, 382, 368, 1, 7000),
(485, 383, 368, 1, 7000),
(486, 379, 268, 1, 8000),
(487, 384, 107, 1, 8000),
(488, 383, 204, 1, 12000),
(489, 385, 203, 1, 12000),
(490, 386, 335, 1, 10000),
(491, 386, 197, 1, 13000),
(492, 386, 204, 1, 12000),
(493, 383, 362, 5, 1000),
(494, 387, 129, 1, 15000),
(495, 387, 176, 1, 8000),
(496, 386, 358, 1, 8000),
(497, 388, 358, 1, 8000),
(499, 388, 177, 1, 12000),
(500, 388, 204, 4, 12000),
(501, 388, 107, 1, 8000),
(502, 388, 224, 1, 8000),
(503, 387, 255, 1, 12000),
(504, 389, 255, 1, 12000),
(505, 389, 358, 1, 8000),
(506, 389, 364, 5, 1000),
(507, 390, 107, 1, 8000),
(508, 377, 364, 5, 1000),
(509, 391, 255, 3, 12000),
(510, 391, 335, 1, 10000),
(511, 391, 197, 1, 13000),
(512, 392, 224, 1, 8000),
(513, 392, 351, 1, 15000),
(514, 392, 128, 1, 15000),
(515, 392, 174, 1, 12000),
(516, 392, 364, 5, 1000),
(517, 393, 334, 1, 12000),
(518, 393, 204, 1, 12000),
(519, 393, 351, 1, 15000),
(520, 393, 128, 1, 15000),
(521, 394, 107, 2, 8000),
(522, 395, 224, 2, 8000),
(523, 396, 107, 1, 8000),
(524, 396, 224, 1, 8000),
(525, 397, 224, 1, 8000),
(526, 397, 107, 2, 8000),
(527, 397, 353, 1, 8000),
(528, 398, 107, 1, 8000),
(529, 399, 107, 2, 8000),
(530, 400, 224, 1, 8000),
(531, 401, 107, 2, 8000),
(532, 401, 368, 1, 7000),
(533, 402, 204, 1, 12000),
(534, 403, 107, 1, 8000),
(535, 403, 228, 1, 15000),
(536, 404, 107, 2, 8000),
(537, 405, 107, 1, 8000),
(538, 405, 292, 1, 17000),
(539, 405, 365, 1, 10000),
(540, 406, 107, 2, 8000),
(541, 398, 199, 1, 15000),
(542, 398, 255, 3, 12000),
(543, 398, 212, 1, 10000),
(544, 407, 127, 1, 24000),
(545, 398, 180, 1, 8000),
(546, 405, 204, 1, 12000),
(547, 405, 224, 1, 8000),
(548, 408, 107, 9, 8000),
(549, 408, 224, 1, 8000),
(550, 408, 255, 2, 12000),
(551, 409, 107, 3, 8000),
(552, 410, 224, 3, 8000),
(553, 409, 107, 1, 8000),
(554, 409, 176, 1, 8000),
(555, 412, 364, 5, 1000),
(556, 413, 107, 2, 8000),
(558, 414, 255, 1, 12000),
(559, 415, 107, 1, 8000),
(560, 416, 107, 2, 8000),
(561, 417, 107, 1, 8000),
(562, 418, 107, 1, 8000),
(563, 419, 226, 1, 8000),
(564, 419, 255, 1, 12000),
(566, 419, 108, 2, 8000),
(567, 420, 228, 2, 15000),
(568, 421, 224, 1, 8000),
(569, 422, 224, 1, 8000),
(570, 422, 364, 4, 1000),
(572, 423, 255, 1, 12000),
(573, 423, 364, 5, 1000),
(575, 423, 175, 2, 12000),
(576, 423, 129, 1, 15000),
(577, 424, 107, 1, 8000),
(578, 424, 128, 1, 15000),
(579, 424, 224, 1, 8000),
(580, 424, 255, 1, 12000),
(581, 420, 107, 1, 8000),
(582, 425, 364, 5, 1000),
(583, 426, 107, 1, 8000),
(584, 427, 107, 2, 8000),
(585, 427, 176, 1, 8000),
(587, 427, 368, 1, 6000),
(588, 428, 107, 1, 8000),
(589, 428, 365, 1, 10000),
(590, 429, 224, 2, 8000),
(591, 430, 107, 1, 8000),
(592, 430, 268, 1, 8000),
(593, 431, 224, 1, 8000),
(594, 431, 362, 5, 1000),
(595, 431, 107, 1, 8000),
(596, 431, 194, 1, 12000),
(597, 432, 363, 1, 20000),
(598, 433, 107, 1, 8000),
(599, 433, 129, 1, 15000),
(600, 434, 107, 1, 8000),
(601, 435, 255, 6, 12000),
(602, 435, 176, 1, 8000),
(603, 435, 107, 2, 8000),
(604, 435, 209, 1, 10000),
(606, 434, 228, 1, 15000),
(607, 436, 107, 1, 8000),
(608, 435, 177, 1, 12000),
(609, 437, 368, 1, 6000),
(610, 438, 107, 3, 8000),
(611, 437, 107, 4, 8000),
(612, 439, 204, 1, 12000),
(613, 439, 226, 1, 8000),
(614, 439, 255, 1, 12000),
(615, 440, 107, 2, 8000),
(616, 440, 255, 1, 12000),
(617, 441, 255, 4, 12000),
(618, 441, 107, 1, 8000),
(619, 441, 204, 1, 12000),
(620, 441, 197, 1, 13000),
(621, 440, 224, 1, 8000),
(622, 442, 107, 5, 8000),
(623, 442, 224, 1, 8000),
(624, 441, 224, 1, 8000),
(626, 443, 372, 1, 10000),
(627, 444, 107, 2, 8000),
(628, 445, 107, 1, 8000),
(629, 446, 107, 1, 8000),
(630, 447, 205, 1, 12000),
(631, 447, 255, 1, 12000),
(632, 448, 107, 1, 8000),
(633, 449, 107, 1, 8000),
(634, 450, 107, 2, 8000),
(635, 451, 212, 1, 10000),
(636, 451, 107, 1, 8000),
(637, 452, 107, 1, 8000),
(638, 452, 204, 1, 12000),
(639, 453, 107, 2, 8000),
(640, 454, 107, 1, 8000),
(641, 455, 107, 1, 8000),
(642, 455, 176, 1, 8000),
(643, 456, 255, 3, 12000),
(644, 456, 107, 1, 8000),
(646, 457, 335, 1, 10000),
(647, 457, 204, 1, 12000),
(648, 458, 107, 2, 8000),
(649, 458, 224, 1, 8000),
(650, 459, 107, 1, 8000),
(651, 460, 107, 1, 8000),
(652, 460, 358, 1, 8000),
(653, 461, 228, 1, 15000),
(654, 462, 107, 1, 8000),
(655, 463, 107, 1, 8000),
(656, 464, 255, 4, 12000),
(657, 464, 209, 1, 10000),
(658, 464, 218, 1, 15000),
(659, 465, 107, 1, 8000),
(660, 466, 107, 2, 8000),
(661, 467, 224, 2, 8000),
(662, 467, 222, 1, 8000),
(663, 468, 224, 1, 8000),
(664, 468, 107, 1, 8000),
(665, 469, 107, 1, 8000),
(666, 470, 224, 1, 8000),
(667, 471, 107, 1, 8000),
(668, 472, 224, 1, 8000),
(669, 472, 107, 3, 8000),
(670, 473, 107, 1, 8000),
(671, 473, 367, 1, 13000),
(672, 474, 107, 1, 8000),
(673, 475, 194, 1, 12000),
(674, 475, 180, 1, 8000),
(675, 475, 335, 1, 10000),
(676, 476, 107, 2, 8000),
(677, 476, 255, 1, 12000),
(678, 477, 107, 1, 8000),
(679, 477, 255, 2, 12000),
(680, 478, 365, 1, 10000),
(681, 479, 224, 2, 8000),
(682, 479, 107, 1, 8000),
(683, 480, 107, 1, 8000),
(684, 481, 255, 1, 12000),
(685, 481, 355, 1, 15000),
(686, 482, 107, 1, 8000),
(687, 483, 107, 1, 8000),
(688, 483, 197, 1, 13000),
(689, 484, 107, 1, 8000),
(690, 484, 364, 2, 1000),
(691, 485, 107, 2, 8000),
(692, 485, 364, 4, 1000),
(693, 486, 224, 2, 8000),
(694, 486, 335, 1, 10000),
(695, 487, 107, 1, 8000),
(696, 488, 364, 2, 1000),
(697, 489, 107, 1, 8000),
(698, 489, 209, 1, 10000),
(699, 490, 204, 1, 12000),
(700, 491, 128, 1, 15000),
(701, 492, 107, 1, 8000),
(702, 492, 204, 1, 12000),
(703, 493, 364, 5, 1000),
(704, 494, 107, 3, 8000),
(705, 494, 224, 1, 8000),
(706, 494, 335, 1, 10000),
(707, 495, 228, 1, 15000),
(709, 496, 107, 1, 8000),
(710, 494, 365, 1, 10000),
(711, 495, 226, 1, 8000),
(712, 497, 107, 1, 8000),
(713, 497, 222, 1, 8000),
(714, 497, 364, 2, 1000),
(715, 498, 107, 6, 8000),
(716, 499, 107, 2, 8000),
(717, 499, 365, 1, 10000),
(718, 500, 107, 1, 8000),
(719, 501, 107, 1, 8000),
(720, 502, 128, 1, 15000),
(721, 503, 205, 1, 12000),
(722, 504, 107, 2, 8000),
(723, 504, 175, 1, 12000),
(724, 505, 222, 1, 8000),
(725, 506, 228, 1, 15000),
(726, 507, 107, 4, 8000),
(727, 507, 366, 1, 22000),
(728, 508, 255, 2, 12000),
(729, 509, 224, 3, 8000),
(730, 509, 222, 2, 8000),
(731, 509, 107, 1, 8000),
(732, 510, 107, 4, 8000),
(733, 510, 224, 6, 8000),
(734, 510, 255, 2, 12000),
(735, 510, 226, 1, 8000),
(736, 510, 204, 1, 12000),
(737, 511, 107, 2, 8000),
(738, 511, 364, 4, 1000),
(739, 512, 107, 5, 8000),
(740, 513, 107, 1, 8000),
(741, 514, 205, 1, 12000),
(742, 514, 369, 4, 1500),
(743, 515, 335, 1, 10000),
(744, 515, 364, 5, 1000),
(745, 516, 107, 4, 8000),
(746, 516, 224, 2, 8000),
(747, 516, 255, 1, 12000),
(749, 518, 224, 1, 8000),
(750, 518, 268, 1, 8000),
(751, 519, 107, 2, 8000),
(752, 519, 364, 2, 1000),
(753, 516, 364, 5, 1000),
(754, 520, 107, 1, 8000),
(755, 520, 175, 1, 12000),
(756, 521, 224, 1, 8000),
(757, 521, 222, 1, 8000),
(758, 522, 224, 1, 8000),
(759, 523, 358, 1, 8000),
(760, 523, 222, 1, 8000),
(761, 524, 107, 1, 8000),
(762, 524, 222, 1, 8000),
(763, 524, 364, 4, 1000),
(764, 522, 358, 1, 8000),
(767, 526, 107, 2, 8000),
(768, 526, 364, 4, 1000),
(769, 527, 224, 1, 8000),
(770, 527, 222, 1, 8000),
(771, 528, 224, 1, 8000),
(772, 528, 107, 2, 8000),
(773, 529, 222, 1, 8000),
(774, 530, 107, 3, 8000),
(775, 531, 334, 1, 12000),
(776, 532, 107, 1, 8000),
(777, 531, 107, 1, 8000),
(778, 531, 224, 1, 8000),
(779, 533, 364, 2, 1000),
(780, 534, 107, 2, 8000),
(781, 535, 175, 1, 12000),
(782, 536, 107, 1, 8000),
(783, 536, 364, 3, 1000),
(785, 537, 373, 2, 5000),
(786, 538, 224, 2, 8000),
(787, 538, 358, 1, 8000),
(788, 530, 364, 4, 1000),
(789, 535, 212, 2, 10000),
(790, 535, 204, 1, 12000),
(791, 534, 362, 4, 1000),
(792, 538, 107, 1, 8000),
(793, 539, 107, 3, 8000),
(794, 540, 107, 3, 8000),
(795, 541, 204, 2, 12000),
(796, 541, 224, 1, 8000),
(797, 541, 107, 1, 8000),
(798, 530, 367, 1, 13000),
(799, 542, 107, 2, 8000),
(800, 542, 358, 1, 8000),
(801, 543, 107, 1, 8000),
(802, 544, 107, 2, 8000),
(803, 542, 224, 2, 8000),
(804, 545, 107, 2, 8000),
(805, 546, 107, 2, 8000),
(806, 547, 255, 1, 12000),
(807, 548, 107, 1, 8000),
(808, 548, 364, 3, 1000),
(809, 549, 107, 1, 8000),
(810, 550, 107, 1, 8000),
(811, 551, 107, 4, 8000),
(812, 551, 224, 1, 8000),
(813, 552, 107, 2, 8000),
(814, 553, 228, 1, 15000),
(815, 553, 107, 1, 8000),
(816, 554, 107, 2, 8000),
(817, 555, 224, 1, 8000),
(818, 555, 255, 1, 12000),
(821, 552, 224, 1, 8000),
(822, 555, 363, 1, 20000),
(823, 557, 175, 2, 12000),
(824, 557, 212, 1, 10000),
(825, 557, 365, 1, 10000),
(826, 558, 255, 2, 12000),
(827, 558, 368, 1, 6000),
(828, 559, 107, 1, 8000),
(829, 559, 255, 1, 12000),
(830, 560, 255, 2, 12000),
(831, 560, 364, 5, 1000),
(832, 559, 224, 1, 8000),
(833, 561, 224, 1, 8000),
(835, 557, 255, 1, 12000),
(836, 559, 373, 1, 7000),
(837, 558, 197, 1, 13000),
(838, 562, 107, 1, 8000),
(839, 563, 107, 1, 8000),
(840, 564, 107, 1, 8000),
(841, 565, 107, 1, 8000),
(842, 566, 107, 2, 8000),
(843, 567, 362, 4, 1000),
(844, 567, 224, 2, 8000),
(845, 568, 364, 10, 1000),
(846, 568, 107, 2, 8000),
(848, 567, 174, 1, 12000),
(850, 569, 107, 1, 8000),
(852, 569, 362, 3, 1000),
(853, 570, 175, 1, 12000),
(854, 570, 107, 1, 8000),
(855, 570, 129, 1, 15000),
(856, 571, 224, 1, 8000),
(857, 572, 107, 3, 8000),
(858, 572, 255, 2, 12000),
(859, 572, 128, 2, 15000),
(860, 573, 107, 1, 8000),
(861, 574, 107, 1, 8000),
(862, 574, 175, 1, 12000),
(864, 575, 367, 1, 13000),
(865, 576, 176, 1, 8000),
(866, 576, 177, 1, 12000),
(867, 576, 268, 1, 8000),
(868, 577, 107, 1, 8000),
(870, 578, 107, 3, 8000),
(871, 578, 368, 1, 6000),
(872, 577, 362, 2, 1000),
(873, 578, 176, 5, 8000),
(874, 578, 255, 2, 12000),
(875, 578, 224, 1, 8000),
(876, 579, 107, 2, 8000),
(877, 578, 365, 1, 10000),
(878, 580, 107, 2, 8000),
(879, 581, 107, 1, 8000),
(880, 581, 226, 1, 8000),
(881, 582, 107, 1, 8000),
(882, 582, 176, 1, 8000),
(883, 583, 255, 1, 12000),
(884, 584, 204, 1, 12000),
(885, 585, 176, 1, 8000),
(887, 586, 107, 1, 8000),
(888, 585, 335, 1, 10000),
(889, 587, 205, 1, 12000),
(890, 588, 205, 1, 12000),
(891, 589, 107, 1, 8000),
(892, 590, 107, 1, 8000),
(893, 590, 176, 1, 8000),
(894, 590, 368, 1, 6000),
(895, 591, 224, 2, 8000),
(896, 592, 255, 1, 12000),
(897, 592, 353, 1, 8000),
(898, 593, 107, 1, 8000),
(899, 593, 212, 1, 10000),
(900, 594, 224, 2, 8000),
(901, 595, 224, 1, 8000),
(902, 596, 180, 1, 8000),
(903, 597, 255, 1, 12000),
(904, 598, 224, 1, 8000),
(905, 599, 255, 1, 12000),
(906, 599, 351, 1, 15000),
(907, 600, 255, 1, 12000),
(908, 601, 107, 1, 8000),
(909, 601, 255, 1, 12000),
(910, 602, 355, 1, 15000),
(911, 603, 335, 1, 10000),
(912, 604, 175, 2, 12000),
(913, 605, 189, 2, 15000),
(914, 606, 107, 2, 8000),
(915, 607, 358, 1, 8000),
(916, 608, 107, 1, 8000),
(917, 608, 224, 2, 8000),
(918, 609, 226, 1, 8000),
(919, 610, 204, 1, 12000),
(920, 610, 255, 1, 12000),
(921, 611, 176, 2, 8000),
(922, 612, 107, 1, 8000),
(923, 613, 228, 1, 15000),
(924, 613, 334, 1, 12000),
(925, 613, 205, 1, 12000),
(926, 613, 194, 3, 12000),
(927, 613, 332, 2, 12000),
(928, 613, 129, 5, 15000),
(929, 613, 176, 1, 8000),
(930, 614, 364, 5, 1000),
(931, 615, 107, 1, 8000),
(932, 616, 107, 2, 8000),
(933, 616, 222, 1, 8000),
(934, 617, 107, 3, 8000),
(935, 617, 255, 1, 12000),
(936, 617, 107, 1, 8000),
(937, 617, 255, 1, 12000),
(938, 617, 353, 1, 8000),
(939, 619, 107, 1, 8000),
(940, 620, 364, 5, 1000),
(941, 620, 176, 1, 8000),
(942, 620, 180, 2, 8000),
(943, 620, 107, 1, 8000),
(944, 621, 107, 2, 8000),
(945, 621, 222, 1, 8000),
(946, 622, 202, 2, 12000),
(947, 622, 107, 2, 8000),
(948, 622, 176, 1, 8000),
(949, 622, 364, 2, 1000),
(950, 623, 107, 1, 8000),
(951, 623, 255, 1, 12000),
(952, 623, 368, 1, 6000),
(953, 624, 224, 1, 8000),
(954, 623, 226, 1, 8000),
(955, 625, 255, 1, 12000),
(956, 626, 358, 1, 8000),
(957, 626, 176, 2, 8000),
(959, 628, 107, 1, 8000),
(960, 629, 107, 2, 8000),
(961, 625, 107, 1, 8000),
(962, 630, 107, 2, 8000),
(963, 631, 107, 1, 8000),
(964, 632, 107, 1, 8000),
(965, 633, 204, 1, 12000),
(966, 633, 222, 1, 8000),
(967, 634, 129, 2, 15000),
(968, 634, 128, 1, 15000),
(969, 634, 127, 1, 22000),
(970, 635, 224, 3, 8000),
(971, 635, 107, 1, 8000),
(972, 635, 255, 1, 12000),
(973, 636, 255, 1, 12000),
(974, 637, 107, 2, 8000),
(975, 636, 107, 1, 8000),
(976, 636, 127, 1, 22000),
(977, 638, 107, 1, 8000),
(978, 639, 180, 1, 8000),
(979, 639, 176, 2, 8000),
(980, 640, 380, 1, 10000),
(981, 639, 128, 1, 15000),
(982, 639, 268, 1, 8000),
(983, 641, 107, 2, 8000),
(985, 641, 224, 1, 8000),
(986, 641, 203, 1, 12000),
(987, 642, 335, 1, 10000),
(988, 642, 197, 1, 13000),
(989, 642, 292, 1, 17000),
(990, 643, 107, 1, 8000),
(991, 644, 204, 1, 12000),
(992, 644, 107, 3, 8000),
(993, 645, 255, 1, 12000),
(994, 645, 107, 1, 8000),
(995, 645, 292, 1, 17000),
(996, 646, 107, 1, 8000),
(997, 647, 107, 1, 8000),
(998, 647, 255, 1, 12000),
(999, 646, 129, 1, 15000),
(1000, 648, 129, 1, 15000),
(1001, 648, 176, 3, 8000),
(1002, 648, 364, 4, 1000),
(1003, 649, 255, 1, 12000),
(1004, 649, 224, 1, 8000),
(1005, 650, 255, 1, 12000),
(1006, 650, 335, 1, 10000),
(1007, 651, 176, 1, 8000),
(1008, 651, 351, 1, 15000),
(1009, 651, 255, 1, 12000),
(1010, 652, 107, 1, 8000),
(1011, 653, 222, 1, 8000),
(1012, 654, 107, 1, 8000),
(1013, 654, 176, 1, 8000),
(1014, 655, 107, 3, 8000),
(1015, 656, 107, 1, 8000),
(1016, 657, 107, 1, 8000),
(1017, 658, 107, 2, 8000),
(1018, 658, 364, 4, 1000),
(1019, 658, 368, 2, 6000),
(1020, 659, 107, 1, 8000),
(1021, 660, 204, 1, 12000),
(1022, 660, 365, 1, 10000),
(1024, 662, 107, 2, 8000),
(1025, 662, 176, 1, 8000),
(1026, 662, 328, 3, 2000),
(1028, 664, 204, 1, 12000),
(1029, 664, 328, 1, 2000),
(1030, 665, 112, 2, 10000),
(1031, 665, 107, 1, 8000),
(1032, 665, 365, 1, 10000),
(1033, 665, 328, 3, 2000),
(1034, 666, 107, 1, 8000),
(1035, 667, 107, 1, 8000),
(1036, 667, 224, 1, 8000),
(1037, 667, 363, 1, 20000),
(1038, 668, 107, 3, 8000),
(1039, 668, 212, 2, 10000),
(1040, 668, 363, 1, 20000),
(1041, 669, 107, 1, 8000),
(1042, 670, 107, 3, 8000),
(1043, 671, 107, 1, 8000),
(1044, 672, 107, 3, 8000),
(1045, 672, 222, 1, 8000),
(1046, 670, 204, 1, 12000),
(1047, 673, 107, 5, 8000),
(1048, 668, 175, 1, 12000),
(1049, 670, 255, 2, 12000),
(1050, 670, 364, 5, 1000),
(1051, 673, 112, 1, 10000),
(1052, 667, 255, 1, 12000),
(1053, 674, 107, 2, 8000),
(1054, 675, 107, 1, 8000),
(1055, 675, 255, 1, 12000),
(1056, 674, 222, 1, 8000),
(1058, 677, 255, 1, 12000),
(1059, 678, 107, 2, 8000),
(1060, 678, 255, 2, 12000),
(1061, 679, 107, 2, 8000),
(1062, 679, 255, 2, 12000),
(1063, 680, 180, 1, 8000),
(1064, 681, 107, 1, 8000),
(1066, 682, 255, 1, 12000),
(1067, 682, 176, 1, 8000),
(1068, 683, 107, 1, 8000),
(1069, 684, 107, 1, 8000),
(1070, 684, 364, 5, 1000),
(1071, 685, 180, 2, 8000),
(1072, 685, 107, 1, 8000),
(1073, 685, 197, 1, 13000),
(1074, 686, 176, 2, 8000),
(1075, 686, 364, 9, 1000),
(1076, 687, 224, 1, 8000),
(1077, 687, 175, 1, 12000),
(1078, 688, 107, 1, 8000),
(1079, 688, 224, 1, 8000),
(1080, 689, 107, 1, 8000),
(1081, 690, 107, 1, 8000),
(1082, 691, 107, 1, 8000),
(1083, 692, 107, 1, 8000),
(1084, 693, 107, 1, 8000),
(1085, 693, 176, 2, 8000),
(1086, 694, 255, 1, 12000),
(1087, 691, 176, 1, 8000),
(1088, 686, 224, 1, 8000),
(1089, 694, 364, 3, 1000),
(1090, 695, 107, 2, 8000),
(1091, 696, 128, 2, 15000),
(1092, 697, 177, 1, 12000),
(1093, 697, 335, 1, 10000),
(1094, 698, 107, 1, 8000),
(1095, 699, 107, 2, 8000),
(1096, 699, 176, 1, 8000),
(1097, 699, 364, 2, 1000),
(1098, 700, 107, 2, 8000),
(1100, 701, 107, 2, 8000),
(1101, 702, 162, 1, 10000),
(1102, 702, 204, 1, 12000),
(1103, 702, 107, 1, 8000),
(1104, 702, 368, 1, 6000),
(1105, 701, 112, 1, 10000),
(1106, 703, 205, 1, 12000),
(1107, 704, 204, 1, 12000),
(1108, 704, 255, 1, 12000),
(1109, 704, 315, 1, 15000),
(1111, 704, 224, 1, 8000),
(1112, 705, 107, 1, 8000),
(1113, 703, 176, 1, 8000),
(1114, 706, 107, 1, 8000),
(1115, 707, 226, 1, 8000),
(1116, 707, 107, 1, 8000),
(1117, 704, 107, 2, 8000),
(1118, 703, 364, 4, 1000),
(1119, 708, 224, 1, 8000),
(1120, 708, 358, 1, 8000),
(1121, 709, 175, 3, 12000),
(1122, 710, 107, 2, 8000),
(1123, 711, 107, 1, 8000),
(1124, 708, 365, 1, 10000),
(1125, 712, 255, 1, 12000),
(1126, 713, 364, 5, 1000),
(1127, 713, 212, 1, 10000),
(1128, 714, 255, 2, 12000),
(1129, 715, 107, 1, 8000),
(1130, 715, 176, 1, 8000),
(1131, 716, 107, 5, 8000),
(1132, 716, 204, 1, 12000),
(1133, 716, 255, 1, 12000),
(1134, 717, 107, 2, 8000),
(1135, 717, 222, 1, 8000),
(1136, 718, 255, 2, 12000),
(1137, 719, 107, 1, 8000),
(1138, 720, 175, 1, 12000),
(1139, 720, 255, 1, 12000),
(1140, 720, 205, 1, 12000),
(1141, 721, 224, 0, 8000),
(1142, 722, 107, 2, 8000),
(1143, 722, 255, 1, 12000),
(1144, 723, 107, 2, 8000),
(1145, 724, 107, 2, 8000),
(1146, 724, 224, 1, 8000),
(1147, 719, 365, 1, 10000),
(1148, 725, 107, 1, 8000),
(1149, 725, 368, 1, 6000),
(1150, 721, 107, 2, 8000),
(1151, 726, 107, 1, 8000),
(1152, 726, 255, 1, 12000),
(1153, 726, 176, 1, 8000),
(1154, 726, 368, 2, 6000),
(1155, 727, 107, 2, 8000),
(1156, 725, 224, 1, 8000),
(1157, 727, 176, 1, 8000),
(1158, 728, 107, 4, 8000),
(1159, 728, 224, 1, 8000),
(1160, 729, 107, 1, 8000),
(1161, 729, 368, 1, 6000),
(1163, 730, 255, 1, 12000),
(1164, 731, 107, 1, 8000),
(1165, 732, 107, 1, 8000),
(1166, 732, 224, 1, 8000),
(1167, 727, 364, 5, 1000),
(1168, 731, 112, 1, 10000),
(1169, 734, 107, 3, 8000),
(1170, 734, 204, 1, 12000),
(1171, 718, 107, 1, 8000),
(1172, 734, 268, 1, 8000),
(1173, 735, 107, 1, 8000),
(1174, 734, 224, 1, 8000),
(1175, 734, 365, 1, 10000),
(1176, 736, 175, 2, 12000),
(1177, 737, 107, 1, 8000),
(1178, 737, 176, 1, 8000),
(1179, 738, 107, 0, 8000),
(1180, 739, 351, 1, 15000),
(1181, 739, 129, 2, 15000),
(1182, 739, 228, 1, 15000),
(1183, 739, 222, 0, 8000),
(1184, 737, 212, 1, 10000),
(1185, 740, 180, 1, 8000),
(1186, 741, 179, 2, 15000),
(1187, 741, 255, 1, 12000),
(1188, 741, 365, 1, 10000),
(1189, 742, 204, 2, 12000),
(1190, 743, 224, 2, 8000),
(1191, 744, 224, 1, 8000),
(1192, 741, 175, 1, 12000),
(1193, 745, 107, 1, 8000),
(1194, 746, 107, 2, 8000),
(1195, 747, 107, 2, 8000),
(1197, 747, 368, 2, 6000),
(1198, 748, 107, 1, 8000),
(1199, 749, 107, 1, 8000),
(1200, 750, 107, 2, 8000),
(1201, 750, 204, 2, 12000),
(1203, 750, 364, 4, 1000),
(1204, 751, 127, 2, 22000),
(1205, 751, 107, 2, 8000),
(1206, 751, 180, 1, 8000),
(1207, 752, 127, 2, 22000),
(1208, 752, 255, 3, 12000),
(1209, 752, 363, 1, 20000),
(1210, 753, 107, 1, 8000),
(1211, 754, 107, 2, 8000),
(1212, 754, 255, 1, 12000),
(1213, 754, 364, 5, 1000),
(1214, 753, 176, 1, 8000),
(1215, 752, 107, 2, 8000),
(1216, 755, 255, 2, 12000),
(1217, 755, 335, 1, 10000),
(1218, 755, 189, 1, 15000),
(1219, 756, 204, 3, 12000),
(1220, 757, 127, 1, 22000),
(1221, 758, 364, 5, 1000),
(1222, 759, 107, 2, 8000),
(1223, 752, 197, 1, 13000),
(1224, 760, 204, 1, 12000),
(1225, 761, 107, 3, 8000),
(1226, 762, 107, 3, 8000),
(1227, 762, 267, 1, 8000),
(1228, 763, 107, 1, 8000),
(1229, 764, 224, 1, 8000),
(1230, 765, 107, 1, 8000),
(1231, 766, 107, 2, 8000),
(1232, 766, 368, 1, 6000),
(1233, 767, 107, 2, 8000),
(1234, 767, 226, 1, 8000),
(1235, 767, 364, 4, 1000),
(1236, 768, 107, 2, 8000),
(1237, 769, 107, 6, 8000),
(1238, 769, 335, 1, 10000),
(1239, 770, 224, 1, 8000),
(1240, 770, 255, 1, 12000),
(1241, 771, 107, 2, 8000),
(1242, 772, 180, 2, 8000),
(1243, 771, 176, 2, 8000),
(1244, 771, 255, 1, 12000),
(1245, 773, 107, 1, 8000),
(1246, 774, 107, 2, 8000),
(1247, 769, 176, 1, 8000),
(1248, 769, 222, 1, 8000),
(1249, 769, 368, 1, 6000),
(1250, 770, 176, 4, 8000),
(1251, 770, 175, 1, 12000),
(1252, 770, 192, 1, 20000),
(1253, 775, 231, 1, 25000),
(1254, 775, 230, 2, 30000),
(1255, 776, 107, 20, 8000),
(1256, 775, 107, 1, 8000),
(1257, 775, 204, 1, 12000);

-- --------------------------------------------------------

--
-- Table structure for table `cafethemxua_store`
--

CREATE TABLE IF NOT EXISTS `cafethemxua_store` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `note` varchar(125) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `cafethemxua_store`
--

INSERT INTO `cafethemxua_store` (`id`, `name`, `note`) VALUES
(1, 'Kho nhà', 'Ghi chú gì đây ?');

-- --------------------------------------------------------

--
-- Table structure for table `cafethemxua_supplier`
--

CREATE TABLE IF NOT EXISTS `cafethemxua_supplier` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `note` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `debt` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=14 ;

--
-- Dumping data for table `cafethemxua_supplier`
--

INSERT INTO `cafethemxua_supplier` (`id`, `name`, `phone`, `address`, `note`, `debt`) VALUES
(1, 'ĐL NƯỚC ĐÁ', '0913796043', 'Phường 8', 'Cung cấp nước đá', 0),
(6, 'Siêu thị COOP MART', 'chưa cập nhật', 'Vĩnh Long', '', 0),
(8, 'ĐL Cafe hạt', '0703 111 222', 'P4 Vĩnh Long', '', 0),
(9, 'ĐL Nước ngọt Thiên Tân', '', 'P1, TP Vĩnh Long', '', 0),
(12, 'VỰA TRÁI CÂY', '', '', '', 0),
(13, 'NCC A', '80830803', 'p5 tpvl', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `cafethemxua_table`
--

CREATE TABLE IF NOT EXISTS `cafethemxua_table` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iddomain` int(11) NOT NULL,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `iduser` int(11) DEFAULT NULL,
  `type` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `iddomain` (`iddomain`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=192 ;

--
-- Dumping data for table `cafethemxua_table`
--

INSERT INTO `cafethemxua_table` (`id`, `iddomain`, `name`, `iduser`, `type`) VALUES
(1, 1, '01', 1, '0'),
(2, 1, '02', 1, '0'),
(3, 1, '03', 1, '0'),
(4, 1, '04', 1, '0'),
(28, 1, '05', 1, '0'),
(29, 1, '06', 1, '0'),
(30, 1, '07', 1, '0'),
(31, 1, '08', 1, '0'),
(32, 1, '09', 1, '0'),
(33, 1, '10', 1, '0'),
(34, 1, '11', 1, '0'),
(35, 1, '12', 1, '0'),
(37, 1, '13', 1, '0'),
(38, 1, '14', 1, '0'),
(41, 1, '15', 1, '0'),
(133, 1, '16', 1, '0'),
(135, 1, '17', 1, '0'),
(136, 1, '18', 1, '0'),
(137, 1, '19', 1, '0'),
(138, 1, '20', 1, '0'),
(139, 1, '21', 1, '0'),
(140, 1, '22', 1, '0'),
(141, 1, '23', 1, '0'),
(142, 1, '24', 1, '0'),
(143, 1, '25', 1, '0'),
(144, 1, '26', 1, '0'),
(145, 1, '27', 1, '0'),
(146, 1, '28', 1, '0'),
(147, 1, '29', 1, '0'),
(148, 1, '30', 1, '0'),
(149, 1, '31', 1, '0'),
(150, 1, '32', 1, '0'),
(151, 1, '33', 1, '0'),
(152, 1, '34', 1, '0'),
(153, 1, '35', 1, '0'),
(154, 1, '36', 1, '0'),
(155, 1, '37', 1, '0'),
(156, 1, '38', 1, '0'),
(157, 1, '39', 1, '0'),
(158, 1, '40', 1, '0'),
(159, 1, '41', 1, '0'),
(160, 1, '42', 1, '0'),
(161, 1, '43', 1, '0'),
(162, 1, '44', 1, '0'),
(163, 1, '45', 1, '0'),
(164, 1, '46', 1, '0'),
(165, 1, '47', 1, '0'),
(166, 1, '48', 1, '0'),
(167, 1, '49', 1, '0'),
(168, 1, '50', 1, '0'),
(169, 1, '51', 1, '0'),
(170, 1, '52', 1, '0'),
(171, 1, '53', 1, '0'),
(172, 1, '54', 1, '0'),
(173, 1, '55', 1, '0'),
(174, 1, '56', 1, '0'),
(175, 1, '57', 1, '0'),
(176, 1, '58', 1, '0'),
(177, 1, '59', 1, '0'),
(178, 1, '60', 1, '0'),
(179, 1, '61', 1, '0'),
(180, 1, '62', 1, '0'),
(181, 1, '63', 1, '0'),
(182, 1, '64', 1, '0'),
(183, 1, '65', 1, '0'),
(184, 1, '66', 1, '0'),
(185, 7, 'Quý Khách 1', 1, '0'),
(186, 7, 'Quý Khách 2', 1, '0'),
(187, 7, 'Quý Khách 3', 1, '0'),
(188, 7, 'Quý Khách 4', 1, '0'),
(189, 1, '67', 1, '0'),
(190, 1, '68', 1, '0'),
(191, 1, '69', 1, '0');

-- --------------------------------------------------------

--
-- Table structure for table `cafethemxua_table_log`
--

CREATE TABLE IF NOT EXISTS `cafethemxua_table_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iduser` int(11) NOT NULL,
  `idtable` int(11) NOT NULL,
  `datetime` datetime NOT NULL,
  `note` varchar(250) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idtable` (`idtable`),
  KEY `iduser` (`iduser`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `cafethemxua_table_log`
--


-- --------------------------------------------------------

--
-- Table structure for table `cafethemxua_term`
--

CREATE TABLE IF NOT EXISTS `cafethemxua_term` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=12 ;

--
-- Dumping data for table `cafethemxua_term`
--

INSERT INTO `cafethemxua_term` (`id`, `name`, `type`) VALUES
(1, 'Tiền Điện', 0),
(2, 'Tiền Nước', 0),
(3, 'Thuế', 0),
(10, 'Tiền Ăn Nhân Viên', 0),
(11, 'CP Khác', 0);

-- --------------------------------------------------------

--
-- Table structure for table `cafethemxua_term_collect`
--

CREATE TABLE IF NOT EXISTS `cafethemxua_term_collect` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Dumping data for table `cafethemxua_term_collect`
--

INSERT INTO `cafethemxua_term_collect` (`id`, `name`) VALUES
(2, 'Phụ Phẩm'),
(3, 'Đặc Biệt');

-- --------------------------------------------------------

--
-- Table structure for table `cafethemxua_tracking`
--

CREATE TABLE IF NOT EXISTS `cafethemxua_tracking` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_start` date NOT NULL,
  `date_end` date NOT NULL,
  `paid_general` int(11) NOT NULL,
  `paid_pay_roll` int(11) NOT NULL,
  `paid_import` int(11) NOT NULL,
  `collect_general` int(11) NOT NULL,
  `collect_customer` int(11) NOT NULL,
  `collect_selling_debt` int(11) NOT NULL,
  `collect_selling_nodebt` int(11) NOT NULL,
  `estate_rate` int(11) NOT NULL,
  `store_value` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=16 ;

--
-- Dumping data for table `cafethemxua_tracking`
--

INSERT INTO `cafethemxua_tracking` (`id`, `date_start`, `date_end`, `paid_general`, `paid_pay_roll`, `paid_import`, `collect_general`, `collect_customer`, `collect_selling_debt`, `collect_selling_nodebt`, `estate_rate`, `store_value`) VALUES
(13, '2014-01-01', '2014-01-31', 0, 0, 0, 0, 0, 0, 0, 0, 0),
(15, '2014-02-01', '2014-02-28', 0, 0, 0, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `cafethemxua_tracking_course`
--

CREATE TABLE IF NOT EXISTS `cafethemxua_tracking_course` (
  `id` int(11) NOT NULL,
  `id_tracking` int(11) NOT NULL,
  `id_td` int(11) NOT NULL,
  `id_course` int(11) NOT NULL,
  `count` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `value` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cafethemxua_tracking_course`
--

INSERT INTO `cafethemxua_tracking_course` (`id`, `id_tracking`, `id_td`, `id_course`, `count`, `price`, `value`) VALUES
(0, 13, 39, 194, 2, 0, 0),
(0, 13, 39, 335, 4, 0, 0),
(0, 13, 39, 107, 85, 0, 0),
(0, 13, 39, 108, 2, 0, 0),
(0, 13, 39, 255, 28, 0, 0),
(0, 13, 39, 355, 1, 0, 0),
(0, 13, 39, 358, 1, 0, 0),
(0, 13, 39, 268, 1, 0, 0),
(0, 13, 39, 197, 2, 0, 0),
(0, 13, 39, 175, 2, 0, 0),
(0, 13, 39, 176, 3, 0, 0),
(0, 13, 39, 177, 1, 0, 0),
(0, 13, 39, 362, 5, 0, 0),
(0, 13, 39, 363, 1, 0, 0),
(0, 13, 39, 364, 29, 0, 0),
(0, 13, 39, 365, 3, 0, 0),
(0, 13, 39, 224, 20, 0, 0),
(0, 13, 39, 226, 3, 0, 0),
(0, 13, 39, 218, 1, 0, 0),
(0, 13, 39, 368, 2, 0, 0),
(0, 13, 39, 367, 1, 0, 0),
(0, 13, 39, 180, 1, 0, 0),
(0, 13, 39, 128, 2, 0, 0),
(0, 13, 39, 129, 2, 0, 0),
(0, 13, 39, 204, 6, 0, 0),
(0, 13, 39, 209, 3, 0, 0),
(0, 13, 39, 212, 1, 0, 0),
(0, 13, 39, 372, 1, 0, 0),
(0, 13, 39, 222, 2, 0, 0),
(0, 13, 39, 205, 1, 0, 0),
(0, 13, 39, 228, 5, 0, 0),
(0, 13, 43, 335, 1, 0, 0),
(0, 13, 43, 107, 57, 0, 0),
(0, 13, 43, 255, 15, 0, 0),
(0, 13, 43, 112, 4, 0, 0),
(0, 13, 43, 358, 1, 0, 0),
(0, 13, 43, 197, 1, 0, 0),
(0, 13, 43, 175, 5, 0, 0),
(0, 13, 43, 176, 10, 0, 0),
(0, 13, 43, 177, 1, 0, 0),
(0, 13, 43, 363, 2, 0, 0),
(0, 13, 43, 364, 33, 0, 0),
(0, 13, 43, 365, 2, 0, 0),
(0, 13, 43, 224, 6, 0, 0),
(0, 13, 43, 226, 1, 0, 0),
(0, 13, 43, 368, 1, 0, 0),
(0, 13, 43, 328, 7, 0, 0),
(0, 13, 43, 180, 3, 0, 0),
(0, 13, 43, 128, 2, 0, 0),
(0, 13, 43, 204, 4, 0, 0),
(0, 13, 43, 212, 3, 0, 0),
(0, 13, 43, 222, 2, 0, 0),
(0, 13, 43, 205, 1, 0, 0),
(0, 13, 43, 315, 1, 0, 0),
(0, 13, 43, 162, 1, 0, 0),
(0, 13, 44, 335, 1, 0, 0),
(0, 13, 44, 107, 51, 0, 0),
(0, 13, 44, 255, 14, 0, 0),
(0, 13, 44, 112, 1, 0, 0),
(0, 13, 44, 268, 1, 0, 0),
(0, 13, 44, 197, 1, 0, 0),
(0, 13, 44, 175, 4, 0, 0),
(0, 13, 44, 176, 4, 0, 0),
(0, 13, 44, 189, 1, 0, 0),
(0, 13, 44, 363, 1, 0, 0),
(0, 13, 44, 364, 19, 0, 0),
(0, 13, 44, 365, 3, 0, 0),
(0, 13, 44, 224, 8, 0, 0),
(0, 13, 44, 368, 6, 0, 0),
(0, 13, 44, 179, 2, 0, 0),
(0, 13, 44, 180, 2, 0, 0),
(0, 13, 44, 127, 5, 0, 0),
(0, 13, 44, 351, 1, 0, 0),
(0, 13, 44, 129, 2, 0, 0),
(0, 13, 44, 204, 10, 0, 0),
(0, 13, 44, 212, 1, 0, 0),
(0, 13, 44, 222, 1, 0, 0),
(0, 13, 44, 205, 1, 0, 0),
(0, 13, 44, 228, 1, 0, 0),
(0, 13, 38, 370, 1, 0, 0),
(0, 13, 38, 335, 2, 0, 0),
(0, 13, 38, 107, 63, 0, 0),
(0, 13, 38, 255, 15, 0, 0),
(0, 13, 38, 358, 4, 0, 0),
(0, 13, 38, 268, 1, 0, 0),
(0, 13, 38, 203, 1, 0, 0),
(0, 13, 38, 353, 1, 0, 0),
(0, 13, 38, 197, 2, 0, 0),
(0, 13, 38, 174, 1, 0, 0),
(0, 13, 38, 175, 2, 0, 0),
(0, 13, 38, 176, 3, 0, 0),
(0, 13, 38, 177, 2, 0, 0),
(0, 13, 38, 362, 9, 0, 0),
(0, 13, 38, 364, 25, 0, 0),
(0, 13, 38, 365, 1, 0, 0),
(0, 13, 38, 224, 19, 0, 0),
(0, 13, 38, 226, 1, 0, 0),
(0, 13, 38, 218, 1, 0, 0),
(0, 13, 38, 292, 1, 0, 0),
(0, 13, 38, 368, 3, 0, 0),
(0, 13, 38, 371, 1, 0, 0),
(0, 13, 38, 179, 2, 0, 0),
(0, 13, 38, 180, 1, 0, 0),
(0, 13, 38, 332, 1, 0, 0),
(0, 13, 38, 127, 1, 0, 0),
(0, 13, 38, 128, 2, 0, 0),
(0, 13, 38, 351, 2, 0, 0),
(0, 13, 38, 129, 1, 0, 0),
(0, 13, 38, 204, 13, 0, 0),
(0, 13, 38, 199, 1, 0, 0),
(0, 13, 38, 212, 1, 0, 0),
(0, 13, 38, 334, 1, 0, 0),
(0, 13, 38, 228, 1, 0, 0),
(0, 13, 45, 335, 1, 0, 0),
(0, 13, 45, 107, 23, 0, 0),
(0, 13, 45, 255, 2, 0, 0),
(0, 13, 45, 267, 1, 0, 0),
(0, 13, 45, 176, 3, 0, 0),
(0, 13, 45, 364, 4, 0, 0),
(0, 13, 45, 224, 3, 0, 0),
(0, 13, 45, 226, 1, 0, 0),
(0, 13, 45, 368, 2, 0, 0),
(0, 13, 45, 180, 2, 0, 0),
(0, 13, 45, 222, 1, 0, 0),
(0, 13, 36, 335, 2, 0, 0),
(0, 13, 36, 107, 37, 0, 0),
(0, 13, 36, 255, 10, 0, 0),
(0, 13, 36, 268, 1, 0, 0),
(0, 13, 36, 174, 1, 0, 0),
(0, 13, 36, 175, 1, 0, 0),
(0, 13, 36, 176, 4, 0, 0),
(0, 13, 36, 177, 4, 0, 0),
(0, 13, 36, 189, 1, 0, 0),
(0, 13, 36, 224, 14, 0, 0),
(0, 13, 36, 178, 1, 0, 0),
(0, 13, 36, 179, 1, 0, 0),
(0, 13, 36, 180, 3, 0, 0),
(0, 13, 36, 56, 1, 0, 0),
(0, 13, 36, 128, 1, 0, 0),
(0, 13, 36, 204, 8, 0, 0),
(0, 13, 36, 212, 2, 0, 0),
(0, 13, 36, 221, 1, 0, 0),
(0, 13, 36, 222, 3, 0, 0),
(0, 13, 36, 205, 1, 0, 0),
(0, 13, 35, 107, 1, 0, 0),
(0, 13, 35, 255, 1, 0, 0),
(0, 13, 35, 224, 1, 0, 0),
(0, 13, 37, 335, 1, 0, 0),
(0, 13, 37, 107, 90, 0, 0),
(0, 13, 37, 255, 29, 0, 0),
(0, 13, 37, 112, 2, 0, 0),
(0, 13, 37, 355, 1, 0, 0),
(0, 13, 37, 268, 2, 0, 0),
(0, 13, 37, 265, 1, 0, 0),
(0, 13, 37, 203, 1, 0, 0),
(0, 13, 37, 353, 2, 0, 0),
(0, 13, 37, 197, 2, 0, 0),
(0, 13, 37, 174, 2, 0, 0),
(0, 13, 37, 175, 4, 0, 0),
(0, 13, 37, 176, 8, 0, 0),
(0, 13, 37, 177, 1, 0, 0),
(0, 13, 37, 189, 3, 0, 0),
(0, 13, 37, 308, 1, 0, 0),
(0, 13, 37, 364, 11, 0, 0),
(0, 13, 37, 224, 20, 0, 0),
(0, 13, 37, 226, 1, 0, 0),
(0, 13, 37, 218, 2, 0, 0),
(0, 13, 37, 201, 1, 0, 0),
(0, 13, 37, 179, 1, 0, 0),
(0, 13, 37, 180, 1, 0, 0),
(0, 13, 37, 351, 2, 0, 0),
(0, 13, 37, 129, 1, 0, 0),
(0, 13, 37, 204, 15, 0, 0),
(0, 13, 37, 212, 3, 0, 0),
(0, 13, 37, 222, 1, 0, 0),
(0, 13, 37, 334, 4, 0, 0),
(0, 13, 37, 205, 1, 0, 0),
(0, 13, 37, 315, 2, 0, 0),
(0, 13, 37, 228, 1, 0, 0),
(0, 13, 40, 335, 1, 0, 0),
(0, 13, 40, 107, 64, 0, 0),
(0, 13, 40, 255, 5, 0, 0),
(0, 13, 40, 358, 4, 0, 0),
(0, 13, 40, 268, 1, 0, 0),
(0, 13, 40, 175, 3, 0, 0),
(0, 13, 40, 362, 4, 0, 0),
(0, 13, 40, 364, 33, 0, 0),
(0, 13, 40, 365, 1, 0, 0),
(0, 13, 40, 224, 22, 0, 0),
(0, 13, 40, 226, 1, 0, 0),
(0, 13, 40, 369, 4, 0, 0),
(0, 13, 40, 366, 1, 0, 0),
(0, 13, 40, 367, 1, 0, 0),
(0, 13, 40, 373, 2, 0, 0),
(0, 13, 40, 128, 1, 0, 0),
(0, 13, 40, 204, 4, 0, 0),
(0, 13, 40, 212, 2, 0, 0),
(0, 13, 40, 222, 8, 0, 0),
(0, 13, 40, 334, 1, 0, 0),
(0, 13, 40, 205, 2, 0, 0),
(0, 13, 40, 228, 1, 0, 0),
(0, 13, 41, 194, 3, 0, 0),
(0, 13, 41, 335, 2, 0, 0),
(0, 13, 41, 107, 50, 0, 0),
(0, 13, 41, 255, 19, 0, 0),
(0, 13, 41, 355, 1, 0, 0),
(0, 13, 41, 358, 1, 0, 0),
(0, 13, 41, 268, 1, 0, 0),
(0, 13, 41, 353, 1, 0, 0),
(0, 13, 41, 197, 1, 0, 0),
(0, 13, 41, 174, 1, 0, 0),
(0, 13, 41, 175, 6, 0, 0),
(0, 13, 41, 176, 12, 0, 0),
(0, 13, 41, 177, 1, 0, 0),
(0, 13, 41, 189, 2, 0, 0),
(0, 13, 41, 362, 9, 0, 0),
(0, 13, 41, 363, 1, 0, 0),
(0, 13, 41, 364, 23, 0, 0),
(0, 13, 41, 365, 2, 0, 0),
(0, 13, 41, 224, 17, 0, 0),
(0, 13, 41, 226, 2, 0, 0),
(0, 13, 41, 368, 3, 0, 0),
(0, 13, 41, 367, 1, 0, 0),
(0, 13, 41, 373, 1, 0, 0),
(0, 13, 41, 180, 1, 0, 0),
(0, 13, 41, 332, 2, 0, 0),
(0, 13, 41, 128, 2, 0, 0),
(0, 13, 41, 351, 1, 0, 0),
(0, 13, 41, 129, 6, 0, 0),
(0, 13, 41, 204, 2, 0, 0),
(0, 13, 41, 212, 2, 0, 0),
(0, 13, 41, 334, 1, 0, 0),
(0, 13, 41, 205, 3, 0, 0),
(0, 13, 41, 228, 2, 0, 0),
(0, 13, 42, 335, 2, 0, 0),
(0, 13, 42, 107, 45, 0, 0),
(0, 13, 42, 255, 11, 0, 0),
(0, 13, 42, 358, 1, 0, 0),
(0, 13, 42, 268, 1, 0, 0),
(0, 13, 42, 203, 1, 0, 0),
(0, 13, 42, 353, 1, 0, 0),
(0, 13, 42, 197, 1, 0, 0),
(0, 13, 42, 176, 11, 0, 0),
(0, 13, 42, 364, 15, 0, 0),
(0, 13, 42, 365, 1, 0, 0),
(0, 13, 42, 224, 6, 0, 0),
(0, 13, 42, 226, 1, 0, 0),
(0, 13, 42, 292, 2, 0, 0),
(0, 13, 42, 368, 3, 0, 0),
(0, 13, 42, 380, 1, 0, 0),
(0, 13, 42, 202, 2, 0, 0),
(0, 13, 42, 180, 3, 0, 0),
(0, 13, 42, 127, 2, 0, 0),
(0, 13, 42, 128, 2, 0, 0),
(0, 13, 42, 351, 1, 0, 0),
(0, 13, 42, 129, 4, 0, 0),
(0, 13, 42, 204, 3, 0, 0),
(0, 13, 42, 222, 4, 0, 0),
(0, 13, 46, 107, 2, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `cafethemxua_tracking_customer`
--

CREATE TABLE IF NOT EXISTS `cafethemxua_tracking_customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_tracking` int(11) NOT NULL,
  `id_customer` int(11) NOT NULL,
  `value_session1` int(11) NOT NULL,
  `value_session2` int(11) NOT NULL,
  `value_collect` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `cafethemxua_tracking_customer`
--


-- --------------------------------------------------------

--
-- Table structure for table `cafethemxua_tracking_daily`
--

CREATE TABLE IF NOT EXISTS `cafethemxua_tracking_daily` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_tracking` int(11) NOT NULL,
  `date` date NOT NULL,
  `selling` bigint(20) NOT NULL,
  `import` bigint(20) NOT NULL,
  `store` bigint(20) NOT NULL,
  `paid` bigint(20) NOT NULL,
  `collect` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=119 ;

--
-- Dumping data for table `cafethemxua_tracking_daily`
--

INSERT INTO `cafethemxua_tracking_daily` (`id`, `id_tracking`, `date`, `selling`, `import`, `store`, `paid`, `collect`) VALUES
(1, 12, '2013-12-01', 0, 0, 0, 0, 0),
(2, 12, '2013-12-02', 0, 0, 0, 0, 0),
(3, 12, '2013-12-03', 0, 0, 0, 0, 0),
(4, 12, '2013-12-04', 0, 0, 0, 0, 0),
(5, 12, '2013-12-05', 0, 0, 0, 0, 0),
(6, 12, '2013-12-06', 390000, 320000, 146000, 0, 2000000),
(7, 12, '2013-12-07', 0, 0, 0, 0, 0),
(8, 12, '2013-12-08', 0, 0, 0, 0, 0),
(9, 12, '2013-12-09', 0, 0, 0, 0, 0),
(10, 12, '2013-12-10', 0, 0, 0, 0, 0),
(11, 12, '2013-12-11', 0, 0, 0, 0, 0),
(12, 12, '2013-12-12', 0, 0, 0, 0, 0),
(13, 12, '2013-12-13', 0, 0, 0, 0, 0),
(14, 12, '2013-12-14', 0, 0, 0, 0, 0),
(15, 12, '2013-12-15', 0, 0, 0, 0, 0),
(16, 12, '2013-12-16', 0, 0, 0, 0, 0),
(17, 12, '2013-12-17', 0, 0, 0, 0, 0),
(18, 12, '2013-12-18', 0, 0, 0, 0, 0),
(19, 12, '2013-12-19', 0, 0, 0, 0, 0),
(20, 12, '2013-12-20', 0, 0, 0, 0, 0),
(21, 12, '2013-12-21', 0, 0, 0, 0, 0),
(22, 12, '2013-12-22', 0, 0, 0, 0, 0),
(23, 12, '2013-12-23', 0, 0, 0, 0, 0),
(24, 12, '2013-12-24', 0, 0, 0, 0, 0),
(25, 12, '2013-12-25', 0, 0, 0, 0, 0),
(26, 12, '2013-12-26', 0, 0, 0, 0, 0),
(27, 12, '2013-12-27', 0, 0, 0, 0, 0),
(28, 12, '2013-12-28', 0, 0, 0, 0, 0),
(29, 12, '2013-12-29', 0, 0, 146000, 0, 0),
(30, 12, '2013-12-30', 0, 0, 146000, 0, 0),
(31, 12, '2013-12-31', 0, 0, 146000, 0, 0),
(32, 13, '2014-01-01', 0, 45000, 0, 0, 0),
(33, 13, '2014-01-02', 0, 120000, 0, 0, 0),
(34, 13, '2014-01-03', 0, 30000, 0, 0, 0),
(35, 13, '2014-01-04', 26000, 0, 0, 0, 0),
(36, 13, '2014-01-05', 940000, 0, 0, 0, 0),
(37, 13, '2014-01-06', 2027000, 155000, 0, 85000, 0),
(38, 13, '2014-01-07', 1512000, 0, 0, 0, 0),
(39, 13, '2014-01-08', 1814000, 0, 0, 442000, 1500000),
(40, 13, '2014-01-09', 1138000, 0, 0, 207000, 2321000),
(41, 13, '2014-01-10', 1509000, 0, 0, 570000, 2317000),
(42, 13, '2014-01-11', 1057000, 0, 0, 128000, 3096000),
(43, 13, '2014-01-12', 1213000, 0, 0, 0, 0),
(44, 13, '2014-01-13', 1247000, 0, 0, 0, 0),
(45, 13, '2014-01-14', 322000, 0, 0, 0, 0),
(46, 13, '2014-01-15', 16000, 0, 0, 0, 0),
(47, 13, '2014-01-16', 0, 0, 0, 0, 0),
(48, 13, '2014-01-17', 0, 0, 0, 0, 0),
(49, 13, '2014-01-18', 0, 0, 0, 0, 0),
(50, 13, '2014-01-19', 0, 0, 0, 0, 0),
(51, 13, '2014-01-20', 0, 0, 0, 0, 0),
(52, 13, '2014-01-21', 0, 0, 0, 0, 0),
(53, 13, '2014-01-22', 0, 0, 0, 0, 0),
(54, 13, '2014-01-23', 0, 0, 0, 0, 0),
(55, 13, '2014-01-24', 0, 0, 0, 0, 0),
(56, 13, '2014-01-25', 0, 0, 0, 0, 0),
(57, 13, '2014-01-26', 0, 0, 0, 0, 0),
(58, 13, '2014-01-27', 0, 0, 0, 0, 0),
(59, 13, '2014-01-28', 0, 0, 0, 0, 0),
(60, 13, '2014-01-29', 0, 0, 0, 0, 0),
(61, 13, '2014-01-30', 0, 0, 0, 0, 0),
(62, 13, '2014-01-31', 0, 0, 0, 0, 0),
(63, 14, '2014-02-01', 0, 0, 0, 0, 0),
(64, 14, '2014-02-02', 0, 0, 0, 0, 0),
(65, 14, '2014-02-03', 0, 0, 0, 0, 0),
(66, 14, '2014-02-04', 0, 0, 0, 0, 0),
(67, 14, '2014-02-05', 0, 0, 0, 0, 0),
(68, 14, '2014-02-06', 0, 0, 0, 0, 0),
(69, 14, '2014-02-07', 0, 0, 0, 0, 0),
(70, 14, '2014-02-08', 0, 0, 0, 0, 0),
(71, 14, '2014-02-09', 0, 0, 0, 0, 0),
(72, 14, '2014-02-10', 0, 0, 0, 0, 0),
(73, 14, '2014-02-11', 0, 0, 0, 0, 0),
(74, 14, '2014-02-12', 0, 0, 0, 0, 0),
(75, 14, '2014-02-13', 0, 0, 0, 0, 0),
(76, 14, '2014-02-14', 0, 0, 0, 0, 0),
(77, 14, '2014-02-15', 0, 0, 0, 0, 0),
(78, 14, '2014-02-16', 0, 0, 0, 0, 0),
(79, 14, '2014-02-17', 0, 0, 0, 0, 0),
(80, 14, '2014-02-18', 0, 0, 0, 0, 0),
(81, 14, '2014-02-19', 0, 0, 0, 0, 0),
(82, 14, '2014-02-20', 0, 0, 0, 0, 0),
(83, 14, '2014-02-21', 0, 0, 0, 0, 0),
(84, 14, '2014-02-22', 0, 0, 0, 0, 0),
(85, 14, '2014-02-23', 0, 0, 0, 0, 0),
(86, 14, '2014-02-24', 0, 0, 0, 0, 0),
(87, 14, '2014-02-25', 0, 0, 0, 0, 0),
(88, 14, '2014-02-26', 0, 0, 0, 0, 0),
(89, 14, '2014-02-27', 0, 0, 0, 0, 0),
(90, 14, '2014-02-28', 0, 0, 0, 0, 0),
(91, 15, '2014-02-01', 0, 0, 0, 0, 0),
(92, 15, '2014-02-02', 0, 0, 0, 0, 0),
(93, 15, '2014-02-03', 0, 0, 0, 0, 0),
(94, 15, '2014-02-04', 0, 0, 0, 0, 0),
(95, 15, '2014-02-05', 0, 0, 0, 0, 0),
(96, 15, '2014-02-06', 0, 0, 0, 0, 0),
(97, 15, '2014-02-07', 0, 0, 0, 0, 0),
(98, 15, '2014-02-08', 0, 0, 0, 0, 0),
(99, 15, '2014-02-09', 0, 0, 0, 0, 0),
(100, 15, '2014-02-10', 0, 0, 0, 0, 0),
(101, 15, '2014-02-11', 0, 0, 0, 0, 0),
(102, 15, '2014-02-12', 0, 0, 0, 0, 0),
(103, 15, '2014-02-13', 0, 0, 0, 0, 0),
(104, 15, '2014-02-14', 0, 0, 0, 0, 0),
(105, 15, '2014-02-15', 0, 0, 0, 0, 0),
(106, 15, '2014-02-16', 0, 0, 0, 0, 0),
(107, 15, '2014-02-17', 0, 0, 0, 0, 0),
(108, 15, '2014-02-18', 0, 0, 0, 0, 0),
(109, 15, '2014-02-19', 0, 0, 0, 0, 0),
(110, 15, '2014-02-20', 0, 0, 0, 0, 0),
(111, 15, '2014-02-21', 0, 0, 0, 0, 0),
(112, 15, '2014-02-22', 0, 0, 0, 0, 0),
(113, 15, '2014-02-23', 0, 0, 0, 0, 0),
(114, 15, '2014-02-24', 0, 0, 0, 0, 0),
(115, 15, '2014-02-25', 0, 0, 0, 0, 0),
(116, 15, '2014-02-26', 0, 0, 0, 0, 0),
(117, 15, '2014-02-27', 0, 0, 0, 0, 0),
(118, 15, '2014-02-28', 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `cafethemxua_tracking_store`
--

CREATE TABLE IF NOT EXISTS `cafethemxua_tracking_store` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_tracking` int(11) NOT NULL,
  `id_td` int(11) NOT NULL,
  `id_resource` int(11) NOT NULL,
  `count_old` float NOT NULL,
  `count_import` float NOT NULL,
  `count_export` float NOT NULL,
  `price` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1723 ;

--
-- Dumping data for table `cafethemxua_tracking_store`
--

INSERT INTO `cafethemxua_tracking_store` (`id`, `id_tracking`, `id_td`, `id_resource`, `count_old`, `count_import`, `count_export`, `price`) VALUES
(1707, 12, 6, 19, 0, 2, 0.9, 60000),
(1708, 12, 6, 20, 0, 1, 0, 80000),
(1709, 12, 6, 35, 0, 0, 0, 160000),
(1710, 12, 6, 36, 0, 0, 0, 185000),
(1711, 12, 30, 19, 1.1, 0, 0, 60000),
(1712, 12, 30, 20, 1, 0, 0, 80000),
(1713, 12, 30, 35, 0, 0, 0, 160000),
(1714, 12, 30, 36, 0, 0, 0, 185000),
(1715, 12, 29, 19, 1.1, 0, 0, 60000),
(1716, 12, 29, 20, 1, 0, 0, 80000),
(1717, 12, 29, 35, 0, 0, 0, 160000),
(1718, 12, 29, 36, 0, 0, 0, 185000),
(1719, 12, 31, 19, 1.1, 0, 0, 60000),
(1720, 12, 31, 20, 1, 0, 0, 80000),
(1721, 12, 31, 35, 0, 0, 0, 160000),
(1722, 12, 31, 36, 0, 0, 0, 185000);

-- --------------------------------------------------------

--
-- Table structure for table `cafethemxua_unit`
--

CREATE TABLE IF NOT EXISTS `cafethemxua_unit` (
  `id` int(25) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=29 ;

--
-- Dumping data for table `cafethemxua_unit`
--

INSERT INTO `cafethemxua_unit` (`id`, `name`) VALUES
(1, 'Ly'),
(2, 'Điếu'),
(3, 'Chai'),
(4, 'Lon'),
(5, 'Dĩa'),
(6, 'Thùng'),
(7, 'Két'),
(9, 'Bịch'),
(10, 'Gói'),
(20, 'Trái'),
(21, 'Cái'),
(22, 'Hủ'),
(23, 'Kg'),
(24, 'Phần'),
(25, 'Bàn'),
(26, 'Hộp'),
(27, 'Bao'),
(28, 'Cây');

-- --------------------------------------------------------

--
-- Table structure for table `cafethemxua_user`
--

CREATE TABLE IF NOT EXISTS `cafethemxua_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pass` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gender` int(11) NOT NULL,
  `note` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `datecreate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dateupdate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `dateactivity` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `type` tinyint(4) NOT NULL,
  `code` varchar(13) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

--
-- Dumping data for table `cafethemxua_user`
--

INSERT INTO `cafethemxua_user` (`id`, `name`, `email`, `pass`, `gender`, `note`, `datecreate`, `dateupdate`, `dateactivity`, `type`, `code`) VALUES
(3, 'Thanh Tân', 'tsontung@yahoo.com', '123456', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 2, ''),
(4, 'Quản lý', 'tuanbuithanh@gmail.com', '123456', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 4, '');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `cafehappy4_collect_customer`
--
ALTER TABLE `cafehappy4_collect_customer`
  ADD CONSTRAINT `cafehappy4_customer_collect_1` FOREIGN KEY (`idcustomer`) REFERENCES `cafehappy4_customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cafehappy4_collect_general`
--
ALTER TABLE `cafehappy4_collect_general`
  ADD CONSTRAINT `cafehappy4_collect_general_1` FOREIGN KEY (`id_term`) REFERENCES `cafehappy4_term_collect` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cafehappy4_course`
--
ALTER TABLE `cafehappy4_course`
  ADD CONSTRAINT `cafehappy4_course_1` FOREIGN KEY (`idcategory`) REFERENCES `cafehappy4_category` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cafehappy4_order_import`
--
ALTER TABLE `cafehappy4_order_import`
  ADD CONSTRAINT `cafehappy4_order_import_1` FOREIGN KEY (`idsupplier`) REFERENCES `cafehappy4_supplier` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cafehappy4_order_import_detail`
--
ALTER TABLE `cafehappy4_order_import_detail`
  ADD CONSTRAINT `cafehappy4_order_import_detail_1` FOREIGN KEY (`idorder`) REFERENCES `cafehappy4_order_import` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `cafehappy4_order_import_detail_2` FOREIGN KEY (`idresource`) REFERENCES `cafehappy4_resource` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cafehappy4_paid_customer`
--
ALTER TABLE `cafehappy4_paid_customer`
  ADD CONSTRAINT `cafehappy4_customer_paid_1` FOREIGN KEY (`idcustomer`) REFERENCES `cafehappy4_customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cafehappy4_paid_employee`
--
ALTER TABLE `cafehappy4_paid_employee`
  ADD CONSTRAINT `cafehappy4_paid_employee_ibfk_1` FOREIGN KEY (`id_employee`) REFERENCES `cafehappy4_employee` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cafehappy4_paid_general`
--
ALTER TABLE `cafehappy4_paid_general`
  ADD CONSTRAINT `cafehappy4_paid_general_1` FOREIGN KEY (`id_term`) REFERENCES `cafehappy4_term` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cafehappy4_paid_pay_roll`
--
ALTER TABLE `cafehappy4_paid_pay_roll`
  ADD CONSTRAINT `cafehappy4_paid_pay_roll_ibfk_1` FOREIGN KEY (`id_employee`) REFERENCES `cafehappy4_employee` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cafehappy4_paid_supplier`
--
ALTER TABLE `cafehappy4_paid_supplier`
  ADD CONSTRAINT `cafehappy4_supplier_paid_1` FOREIGN KEY (`idsupplier`) REFERENCES `cafehappy4_supplier` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cafehappy4_pay_roll`
--
ALTER TABLE `cafehappy4_pay_roll`
  ADD CONSTRAINT `cafehappy4_pay_roll_ibfk_1` FOREIGN KEY (`id_employee`) REFERENCES `cafehappy4_employee` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cafehappy4_r2c`
--
ALTER TABLE `cafehappy4_r2c`
  ADD CONSTRAINT `cafehappy4_r2c_1` FOREIGN KEY (`id_course`) REFERENCES `cafehappy4_course` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `cafehappy4_r2c_2` FOREIGN KEY (`id_resource`) REFERENCES `cafehappy4_resource` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cafehappy4_resource`
--
ALTER TABLE `cafehappy4_resource`
  ADD CONSTRAINT `cafehappy4_resource_1` FOREIGN KEY (`idsupplier`) REFERENCES `cafehappy4_supplier` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cafehappy4_session`
--
ALTER TABLE `cafehappy4_session`
  ADD CONSTRAINT `cafehappy4_session_1` FOREIGN KEY (`idtable`) REFERENCES `cafehappy4_table` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `cafehappy4_session_2` FOREIGN KEY (`iduser`) REFERENCES `cafehappy4_user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `cafehappy4_session_3` FOREIGN KEY (`idcustomer`) REFERENCES `cafehappy4_customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cafehappy4_session_detail`
--
ALTER TABLE `cafehappy4_session_detail`
  ADD CONSTRAINT `cafehappy4_session_detail_1` FOREIGN KEY (`idsession`) REFERENCES `cafehappy4_session` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `cafehappy4_session_detail_2` FOREIGN KEY (`idcourse`) REFERENCES `cafehappy4_course` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cafehappy4_table`
--
ALTER TABLE `cafehappy4_table`
  ADD CONSTRAINT `cafehappy4_table_1` FOREIGN KEY (`iddomain`) REFERENCES `cafehappy4_domain` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cafepassion_collect_customer`
--
ALTER TABLE `cafepassion_collect_customer`
  ADD CONSTRAINT `cafepassion_customer_collect_1` FOREIGN KEY (`idcustomer`) REFERENCES `cafepassion_customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cafepassion_collect_general`
--
ALTER TABLE `cafepassion_collect_general`
  ADD CONSTRAINT `cafepassion_collect_general_1` FOREIGN KEY (`id_term`) REFERENCES `cafepassion_term_collect` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cafepassion_course`
--
ALTER TABLE `cafepassion_course`
  ADD CONSTRAINT `cafepassion_course_1` FOREIGN KEY (`idcategory`) REFERENCES `cafepassion_category` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cafepassion_order_import`
--
ALTER TABLE `cafepassion_order_import`
  ADD CONSTRAINT `cafepassion_order_import_1` FOREIGN KEY (`idsupplier`) REFERENCES `cafepassion_supplier` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cafepassion_order_import_detail`
--
ALTER TABLE `cafepassion_order_import_detail`
  ADD CONSTRAINT `cafepassion_order_import_detail_1` FOREIGN KEY (`idorder`) REFERENCES `cafepassion_order_import` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `cafepassion_order_import_detail_2` FOREIGN KEY (`idresource`) REFERENCES `cafepassion_resource` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cafepassion_paid_customer`
--
ALTER TABLE `cafepassion_paid_customer`
  ADD CONSTRAINT `cafepassion_customer_paid_1` FOREIGN KEY (`idcustomer`) REFERENCES `cafepassion_customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cafepassion_paid_employee`
--
ALTER TABLE `cafepassion_paid_employee`
  ADD CONSTRAINT `cafepassion_paid_employee_ibfk_1` FOREIGN KEY (`id_employee`) REFERENCES `cafepassion_employee` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cafepassion_paid_general`
--
ALTER TABLE `cafepassion_paid_general`
  ADD CONSTRAINT `cafepassion_paid_general_1` FOREIGN KEY (`id_term`) REFERENCES `cafepassion_term` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cafepassion_paid_pay_roll`
--
ALTER TABLE `cafepassion_paid_pay_roll`
  ADD CONSTRAINT `cafepassion_paid_pay_roll_ibfk_1` FOREIGN KEY (`id_employee`) REFERENCES `cafepassion_employee` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cafepassion_paid_supplier`
--
ALTER TABLE `cafepassion_paid_supplier`
  ADD CONSTRAINT `cafepassion_supplier_paid_1` FOREIGN KEY (`idsupplier`) REFERENCES `cafepassion_supplier` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cafepassion_pay_roll`
--
ALTER TABLE `cafepassion_pay_roll`
  ADD CONSTRAINT `cafepassion_pay_roll_ibfk_1` FOREIGN KEY (`id_employee`) REFERENCES `cafepassion_employee` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cafepassion_r2c`
--
ALTER TABLE `cafepassion_r2c`
  ADD CONSTRAINT `cafepassion_r2c_1` FOREIGN KEY (`id_course`) REFERENCES `cafepassion_course` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `cafepassion_r2c_2` FOREIGN KEY (`id_resource`) REFERENCES `cafepassion_resource` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cafepassion_resource`
--
ALTER TABLE `cafepassion_resource`
  ADD CONSTRAINT `cafepassion_resource_1` FOREIGN KEY (`idsupplier`) REFERENCES `cafepassion_supplier` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cafepassion_session`
--
ALTER TABLE `cafepassion_session`
  ADD CONSTRAINT `cafepassion_session_1` FOREIGN KEY (`idtable`) REFERENCES `cafepassion_table` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `cafepassion_session_2` FOREIGN KEY (`iduser`) REFERENCES `cafepassion_user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `cafepassion_session_3` FOREIGN KEY (`idcustomer`) REFERENCES `cafepassion_customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cafepassion_session_detail`
--
ALTER TABLE `cafepassion_session_detail`
  ADD CONSTRAINT `cafepassion_session_detail_1` FOREIGN KEY (`idsession`) REFERENCES `cafepassion_session` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `cafepassion_session_detail_2` FOREIGN KEY (`idcourse`) REFERENCES `cafepassion_course` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cafepassion_table`
--
ALTER TABLE `cafepassion_table`
  ADD CONSTRAINT `cafepassion_table_1` FOREIGN KEY (`iddomain`) REFERENCES `cafepassion_domain` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cafethemxua_collect_customer`
--
ALTER TABLE `cafethemxua_collect_customer`
  ADD CONSTRAINT `cafethemxua_customer_collect_1` FOREIGN KEY (`idcustomer`) REFERENCES `cafethemxua_customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cafethemxua_collect_general`
--
ALTER TABLE `cafethemxua_collect_general`
  ADD CONSTRAINT `cafethemxua_collect_general_1` FOREIGN KEY (`id_term`) REFERENCES `cafethemxua_term_collect` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cafethemxua_course`
--
ALTER TABLE `cafethemxua_course`
  ADD CONSTRAINT `cafethemxua_course_1` FOREIGN KEY (`idcategory`) REFERENCES `cafethemxua_category` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cafethemxua_order_import`
--
ALTER TABLE `cafethemxua_order_import`
  ADD CONSTRAINT `cafethemxua_order_import_1` FOREIGN KEY (`idsupplier`) REFERENCES `cafethemxua_supplier` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cafethemxua_order_import_detail`
--
ALTER TABLE `cafethemxua_order_import_detail`
  ADD CONSTRAINT `cafethemxua_order_import_detail_1` FOREIGN KEY (`idorder`) REFERENCES `cafethemxua_order_import` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `cafethemxua_order_import_detail_2` FOREIGN KEY (`idresource`) REFERENCES `cafethemxua_resource` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cafethemxua_paid_customer`
--
ALTER TABLE `cafethemxua_paid_customer`
  ADD CONSTRAINT `cafethemxua_customer_paid_1` FOREIGN KEY (`idcustomer`) REFERENCES `cafethemxua_customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cafethemxua_paid_employee`
--
ALTER TABLE `cafethemxua_paid_employee`
  ADD CONSTRAINT `cafethemxua_paid_employee_ibfk_1` FOREIGN KEY (`id_employee`) REFERENCES `cafethemxua_employee` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cafethemxua_paid_general`
--
ALTER TABLE `cafethemxua_paid_general`
  ADD CONSTRAINT `cafethemxua_paid_general_1` FOREIGN KEY (`id_term`) REFERENCES `cafethemxua_term` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cafethemxua_paid_pay_roll`
--
ALTER TABLE `cafethemxua_paid_pay_roll`
  ADD CONSTRAINT `cafethemxua_paid_pay_roll_ibfk_1` FOREIGN KEY (`id_employee`) REFERENCES `cafethemxua_employee` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cafethemxua_paid_supplier`
--
ALTER TABLE `cafethemxua_paid_supplier`
  ADD CONSTRAINT `cafethemxua_supplier_paid_1` FOREIGN KEY (`idsupplier`) REFERENCES `cafethemxua_supplier` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cafethemxua_pay_roll`
--
ALTER TABLE `cafethemxua_pay_roll`
  ADD CONSTRAINT `cafethemxua_pay_roll_ibfk_1` FOREIGN KEY (`id_employee`) REFERENCES `cafethemxua_employee` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cafethemxua_r2c`
--
ALTER TABLE `cafethemxua_r2c`
  ADD CONSTRAINT `cafethemxua_r2c_1` FOREIGN KEY (`id_course`) REFERENCES `cafethemxua_course` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `cafethemxua_r2c_2` FOREIGN KEY (`id_resource`) REFERENCES `cafethemxua_resource` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cafethemxua_resource`
--
ALTER TABLE `cafethemxua_resource`
  ADD CONSTRAINT `cafethemxua_resource_1` FOREIGN KEY (`idsupplier`) REFERENCES `cafethemxua_supplier` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cafethemxua_session`
--
ALTER TABLE `cafethemxua_session`
  ADD CONSTRAINT `cafethemxua_session_1` FOREIGN KEY (`idtable`) REFERENCES `cafethemxua_table` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `cafethemxua_session_2` FOREIGN KEY (`iduser`) REFERENCES `cafethemxua_user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `cafethemxua_session_3` FOREIGN KEY (`idcustomer`) REFERENCES `cafethemxua_customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cafethemxua_session_detail`
--
ALTER TABLE `cafethemxua_session_detail`
  ADD CONSTRAINT `cafethemxua_session_detail_1` FOREIGN KEY (`idsession`) REFERENCES `cafethemxua_session` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `cafethemxua_session_detail_2` FOREIGN KEY (`idcourse`) REFERENCES `cafethemxua_course` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cafethemxua_table`
--
ALTER TABLE `cafethemxua_table`
  ADD CONSTRAINT `cafethemxua_table_1` FOREIGN KEY (`iddomain`) REFERENCES `cafethemxua_domain` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
