-- phpMyAdmin SQL Dump
-- version 4.0.8
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 07, 2014 at 06:42 AM
-- Server version: 5.1.72-cll
-- PHP Version: 5.3.17

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `qlcafe_cafemientay`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_app`
--

CREATE TABLE IF NOT EXISTS `tbl_app` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(125) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(50) CHARACTER SET utf8 NOT NULL,
  `banner` varchar(125) CHARACTER SET utf8 NOT NULL,
  `prefix` varchar(50) CHARACTER SET utf8 NOT NULL,
  `alias` varchar(256) CHARACTER SET utf8 NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_activity` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `type` tinyint(4) NOT NULL,
  `page_view` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_app`
--

INSERT INTO `tbl_app` (`id`, `name`, `phone`, `address`, `email`, `banner`, `prefix`, `alias`, `date_created`, `date_modified`, `date_activity`, `type`, `page_view`) VALUES
(1, 'Karaoke Ba Đức', '0945 03 07 09', 'Phó Cơ Điều P3 - TPVL', '', 'data/images/banner/logo.png', 'tbl_', 'tbl_', '2012-06-30 10:00:00', '0000-00-00 00:00:00', '2012-12-26 00:28:02', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_category`
--

CREATE TABLE IF NOT EXISTS `tbl_category` (
  `id` int(25) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `picture` binary(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=26 ;

--
-- Dumping data for table `tbl_category`
--

INSERT INTO `tbl_category` (`id`, `name`, `picture`) VALUES
(3, 'Cafe', NULL),
(8, 'Sinh tố', NULL),
(11, 'Nước ép', NULL),
(13, 'Yaourt', NULL),
(14, 'Nước giải khát', NULL),
(15, 'Nước pha chế', NULL),
(16, 'Lipton - Trà', NULL),
(17, 'Sữa tươi', NULL),
(21, 'Điểm tâm sáng', NULL),
(23, 'Khác', NULL),
(25, 'Thuốc lá', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_collect_customer`
--

CREATE TABLE IF NOT EXISTS `tbl_collect_customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idcustomer` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_customer_collect_1` (`idcustomer`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_collect_general`
--

CREATE TABLE IF NOT EXISTS `tbl_collect_general` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_term` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_collect_1` (`id_term`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=7 ;

--
-- Dumping data for table `tbl_collect_general`
--

INSERT INTO `tbl_collect_general` (`id`, `id_term`, `date`, `value`, `note`) VALUES
(5, 2, '2013-05-18', 10, 'd'),
(6, 3, '2013-12-06', 2000000, 'Bổ sung quỹ');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_config`
--

CREATE TABLE IF NOT EXISTS `tbl_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `param` varchar(125) COLLATE utf8_unicode_ci NOT NULL,
  `value` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=10 ;

--
-- Dumping data for table `tbl_config`
--

INSERT INTO `tbl_config` (`id`, `param`, `value`) VALUES
(1, 'PRICE_HOUR_NORMAL_1', '70000'),
(2, 'PRICE_HOUR_NORMAL_2', '90000'),
(3, 'PRICE_HOUR_VIP_1', '80000'),
(4, 'PRICE_HOUR_VIP_2', '100000'),
(5, 'DISCOUNT', '0'),
(6, 'ROW_PER_PAGE', '12'),
(7, 'GUEST_VISIT', '9247'),
(8, 'EVERY_5_MINUTES', '2000'),
(9, 'THEME', 'light-blue');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_course`
--

CREATE TABLE IF NOT EXISTS `tbl_course` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idcategory` int(25) DEFAULT NULL,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `shortname` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `unit` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `price1` bigint(20) NOT NULL,
  `price2` bigint(20) NOT NULL,
  `price3` bigint(20) NOT NULL,
  `price4` bigint(20) NOT NULL,
  `picture` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_discount` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `foreign_field` (`idcategory`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=370 ;

--
-- Dumping data for table `tbl_course`
--

INSERT INTO `tbl_course` (`id`, `idcategory`, `name`, `shortname`, `unit`, `price1`, `price2`, `price3`, `price4`, `picture`, `is_discount`) VALUES
(53, 8, 'Sinh tố Bơ', 'Sinh tố Bơ', 'Ly', 20000, 20000, 20000, 20000, '', 1),
(54, 8, 'Sinh tố Cà chua', 'Sinh tố Cà chua', 'Ly', 15000, 15000, 15000, 15000, '', 1),
(55, 8, 'Sinh tố Cà rốt', 'Sinh tố Cà rốt', 'Ly', 15000, 15000, 15000, 15000, '', 1),
(56, 8, 'Sinh tố cam', 'Sinh tố cam', 'Ly', 15000, 15000, 15000, 15000, '', 1),
(107, 3, 'Cafe đá', 'Cafe đá', 'Ly', 8000, 8000, 8000, 8000, '', 1),
(108, 3, 'Cafe nóng', 'Cafe nóng', 'Ly', 8000, 8000, 8000, 8000, '', 1),
(112, 3, 'Cafe Sữa nóng', 'Cafe Sữa nóng', 'Ly', 10000, 10000, 10000, 10000, '', 1),
(126, 8, 'Sinh tố chanh', 'Sinh tố chanh', 'Ly', 15000, 15000, 15000, 15000, '', 1),
(127, 8, 'Sinh tố dâu', 'Sinh tố dâu', 'Ly', 24000, 24000, 24000, 24000, '', 1),
(128, 8, 'Sinh tố Mãng cầu', 'Sinh tố Mãng cầu', 'Ly', 15000, 15000, 15000, 15000, '', 1),
(129, 8, 'Sinh tố sapô', 'Sinh tố sapô', 'Ly', 15000, 15000, 15000, 15000, '', 1),
(136, 8, 'Sinh tố thập cẩm', 'Sinh tố thập cẩm', 'Ly', 20000, 20000, 20000, 20000, '', 1),
(149, 13, 'Yaourt cam tươi', 'Yaourt cam tươi', 'Ly', 17000, 17000, 17000, 17000, '', 1),
(161, 13, 'Yaourt dâu', 'Yaourt dâu', 'Ly', 20000, 20000, 20000, 20000, '', 1),
(162, 13, 'Yaourt hủ', 'Yaourt hủ', 'Hủ', 10000, 10000, 10000, 10000, '', 1),
(174, 15, 'Dừa đá', 'Dừa đá', 'Ly', 12000, 12000, 12000, 12000, '', 1),
(175, 15, 'Dừa trái', 'Dừa trái', 'Trái', 12000, 12000, 12000, 12000, '', 1),
(176, 15, 'Đá me', 'Đá me', 'Ly', 8000, 8000, 8000, 8000, '', 1),
(177, 15, 'Đá me sữa', 'Đá me sữa', 'Ly', 12000, 12000, 12000, 12000, '', 1),
(178, 15, 'Rau má dừa', 'Rau má dừa', 'Ly', 13000, 13000, 13000, 13000, '', 1),
(179, 15, 'Rau má sữa', 'Rau má sữa', 'Ly', 15000, 15000, 15000, 15000, '', 1),
(180, 15, 'Rau má thường', 'Rau má thường', 'Ly', 8000, 8000, 8000, 8000, '', 1),
(181, 15, 'Tắc xí muội nóng', 'Tắc xí muội nóng', 'Ly', 14000, 14000, 14000, 14000, '', 1),
(182, 15, 'Chanh xí muội nóng', 'Chanh xí muội nóng', 'Ly', 12000, 12000, 12000, 12000, '', 1),
(183, 15, 'Xí muội đá', 'Xí muội đá', 'Ly', 15000, 15000, 15000, 15000, '', 1),
(184, 15, 'Sâm dứa', 'Sâm dứa', 'Ly', 13000, 13000, 13000, 13000, '', 1),
(185, 15, 'Sâm dứa sữa', 'Sâm dứa sữa', 'Ly', 15000, 15000, 15000, 15000, '', 1),
(187, 11, 'Ép cà chua', 'Ép cà chua', 'Ly', 18000, 18000, 18000, 18000, '', 1),
(188, 11, 'Ép carrot', 'Ép carrot', 'Ly', 18000, 18000, 18000, 18000, '', 1),
(189, 11, 'Ép cam', 'Ép cam', 'Ly', 18000, 18000, 18000, 18000, '', 1),
(190, 11, 'Ép dâu', 'Ép dâu', 'Ly', 25000, 25000, 25000, 25000, '', 1),
(191, 11, 'Ép lê', 'Ép lê', 'Ly', 20000, 20000, 20000, 20000, '', 1),
(192, 11, 'Ép táo', 'Ép táo', 'Ly', 20000, 20000, 20000, 20000, '', 1),
(193, 11, 'Ép thơm', 'Ép thơm', 'Ly', 18000, 18000, 18000, 18000, '', 1),
(194, 14, '7 up', '7 up', 'Chai', 12000, 12000, 12000, 12000, '', 1),
(196, 14, 'Cam Twister', 'Cam Twister', 'Chai', 13000, 13000, 13000, 13000, '', 1),
(197, 14, 'Dr Thanh', 'Dr Thanh', 'Chai', 13000, 13000, 13000, 13000, '', 1),
(198, 14, 'Đậu nành', 'Đậu nành', 'Chai', 12000, 12000, 12000, 12000, '', 1),
(199, 14, 'Sting dâu sữa', 'Sting dâu sữa', 'Chai', 15000, 15000, 15000, 15000, '', 1),
(200, 14, 'Nước tăng lực', 'Nước tăng lực', 'Chai', 12000, 12000, 12000, 12000, '', 1),
(201, 14, 'Nước suối', 'Nước suối', 'Chai', 8000, 8000, 8000, 8000, '', 1),
(202, 14, 'Pepsi', 'Pepsi', 'Chai', 12000, 12000, 12000, 12000, '', 1),
(203, 14, 'Coca (chai nhựa)', 'Coca (chai nhựa)', 'Chai', 12000, 12000, 12000, 12000, '', 1),
(204, 14, 'Sting dâu', 'Sting dâu', 'Chai', 12000, 12000, 12000, 12000, '', 1),
(205, 14, 'Trà xanh 0 độ', 'Trà xanh 0 độ', 'Chai', 12000, 12000, 12000, 12000, '', 1),
(208, 17, 'Sữa dâu tươi', 'Sữa dâu tươi', 'Ly', 20000, 20000, 20000, 20000, '', 1),
(209, 17, 'Sữa nóng', 'Sữa nóng', 'Ly', 10000, 10000, 10000, 10000, '', 1),
(210, 17, 'Sữa thêm', 'Sữa thêm', 'Ly', 5000, 5000, 5000, 5000, '', 1),
(211, 17, 'Sữa đá', 'Sữa đá', 'Ly', 12000, 12000, 12000, 12000, '', 1),
(212, 17, 'Sữa tươi', 'Sữa tươi', 'Ly', 10000, 10000, 10000, 10000, '', 1),
(218, 16, 'Lipton sữa đá', 'Lipton sữa đá', 'Ly', 15000, 15000, 15000, 15000, '', 1),
(219, 16, 'Lipton sữa nóng', 'Lipton sữa nóng', 'Ly', 13000, 13000, 13000, 13000, '', 1),
(220, 16, 'Trà sữa', 'Trà sữa', 'Ly', 15000, 15000, 15000, 15000, '', 1),
(221, 16, 'Trà chanh', 'Trà chanh', 'Ly', 10000, 10000, 10000, 10000, '', 1),
(222, 16, 'Trà đường đá', 'Trà đường đá', 'Ly', 8000, 8000, 8000, 8000, '', 1),
(223, 16, 'Trà đường nóng', 'Trà đường nóng', 'Ly', 8000, 8000, 8000, 8000, '', 1),
(224, 16, 'Lipton đá', 'Lipton đá', 'Ly', 8000, 8000, 8000, 8000, '', 1),
(225, 16, 'Lipton mật ong nóng', 'Lipton mật ong nóng', 'Ly', 13000, 13000, 13000, 13000, '', 1),
(226, 16, 'Lipton nóng', 'Lipton nóng', 'Ly', 8000, 8000, 8000, 8000, '', 1),
(228, 13, 'Yaourt sữa đá', 'Yaourt sữa đá', 'Ly', 15000, 15000, 15000, 15000, '', 1),
(229, 13, 'Yaourt trái cây', 'Yaourt trái cây', 'Ly', 20000, 20000, 20000, 20000, '', 1),
(230, 21, 'Bò bít tết trứng', 'Bò bít tết trứng', 'Phần', 30000, 30000, 30000, 30000, '0', 0),
(231, 21, 'Bò bít tết ko trứng', 'Bò bít tết ko trứng', 'Phần', 25000, 25000, 25000, 25000, '0', 0),
(232, 21, 'Mì Ý', 'Mì Ý', 'Phần', 25000, 25000, 25000, 25000, '', 0),
(233, 21, 'Bánh mì ốp la chả', 'Bánh mì ốp la chả', 'Phần', 12000, 12000, 12000, 12000, '', 0),
(234, 21, 'Bánh mì ốp la', 'Bánh mì ốp la', 'Phần', 10000, 10000, 10000, 10000, '', 0),
(235, 21, 'Mì gói xào bò', 'Mì gói xào bò', 'Phần', 20000, 20000, 20000, 20000, '', 0),
(236, 21, 'Nui xào bò', 'Nui xào bò', 'Phần', 20000, 20000, 20000, 20000, '', 0),
(237, 21, 'Mì gói nấu bò', 'Mì gói nấu bò', 'Phần', 15000, 15000, 15000, 15000, '', 0),
(238, 21, 'Trứng thêm', 'Trứng thêm', 'Cái', 5000, 5000, 5000, 5000, '', 0),
(239, 21, 'Mì gói thêm', 'Mì gói thêm', 'Gói', 5000, 5000, 5000, 5000, '', 0),
(240, 21, 'Bánh mì thêm', 'Bánh mì thêm', 'Cái', 5000, 5000, 5000, 5000, '', 0),
(246, 16, 'Lipton mật ong đá', 'Lipton mật ong đá', 'Ly', 15000, 15000, 15000, 15000, '', 1),
(247, 16, 'Lipton xí muội nóng', 'Lipton xí muội nóng', 'Ly', 13000, 13000, 13000, 13000, '', 1),
(248, 16, 'Lipton xí muội đá', 'Lipton xí muội đá', 'Ly', 15000, 15000, 15000, 15000, '', 1),
(249, 16, 'Lipton bạc hà', 'Lipton bạc hà', 'Ly', 15000, 15000, 15000, 15000, '', 1),
(250, 16, 'Lipton cam', 'Lipton cam', 'Ly', 15000, 15000, 15000, 15000, '', 1),
(252, 16, 'Trà cúc nóng', 'Trà cúc nóng', 'Ly', 10000, 10000, 10000, 10000, '', 1),
(253, 16, 'Trà cúc đá', 'Trà cúc đá', 'Ly', 10000, 10000, 10000, 10000, '', 1),
(255, 3, 'Cafe Sữa đá', 'Cafe Sữa đá', 'Ly', 12000, 12000, 12000, 12000, '', 0),
(260, 3, 'Cafe Miền Tây', 'Cafe Đam mê', 'Ly', 15000, 15000, 15000, 15000, '', 1),
(265, 15, 'Chanh nóng', 'Chanh nóng', 'Ly', 8000, 8000, 8000, 8000, '', 1),
(267, 15, 'Chanh muối nóng', 'Chanh muối nóng', 'Ly', 8000, 8000, 8000, 8000, '', 1),
(268, 15, 'Chanh muối đá', 'Chanh muối đá', 'Ly', 8000, 8000, 8000, 8000, '', 1),
(269, 15, 'Chanh rhum', 'Chanh rhum', 'Ly', 15000, 15000, 15000, 15000, '', 1),
(270, 15, 'Xí muội nóng', 'Xí muội nóng', 'Ly', 14000, 14000, 14000, 14000, '', 1),
(271, 15, 'Chanh xí muội đá', 'Chanh xí muội đá', 'Ly', 12000, 12000, 12000, 12000, '', 1),
(272, 15, 'Chanh muối xí muội', 'Chanh muối xí muội', 'Ly', 10000, 10000, 10000, 10000, '', 1),
(273, 15, 'Tắc xí muội đá', 'Tắc xí muội đá', 'Ly', 15000, 15000, 15000, 15000, '', 1),
(274, 15, 'Bạc hà', 'Bạc hà', 'Ly', 13000, 13000, 13000, 13000, '', 1),
(275, 15, 'Bạc hà sữa', 'Bạc hà sữa', 'Ly', 15000, 15000, 15000, 15000, '', 1),
(276, 15, 'Siro dâu', 'Siro dâu', 'Ly', 13000, 13000, 13000, 13000, '', 1),
(277, 15, 'Đá me xí muội', 'Đá me xí muội', 'Ly', 15000, 15000, 15000, 15000, '', 1),
(278, 15, 'Siro dâu sữa', 'Siro dâu sữa', 'Ly', 15000, 15000, 15000, 15000, '', 1),
(279, 8, 'Sinh tố chanh dây', 'Sinh tố chanh dây', 'Ly', 20000, 20000, 20000, 20000, '', 1),
(280, 8, 'Sinh tố Thơm', 'Sinh tố Thơm', 'Ly', 15000, 15000, 15000, 15000, '', 1),
(281, 8, 'Sinh tố Dừa', 'Sinh tố Dừa', 'Ly', 15000, 15000, 15000, 15000, '', 1),
(282, 8, 'Sinh tố Táo', 'Sinh tố Táo', 'Ly', 20000, 20000, 20000, 20000, '', 1),
(283, 8, 'Sinh tố Lê', 'Sinh tố Lê', 'Ly', 20000, 20000, 20000, 20000, '', 1),
(284, 8, 'ST rau má dừa', 'ST rau má dừa', 'Ly', 15000, 15000, 15000, 15000, '', 1),
(285, 8, 'Sinh tố Bưởi', 'Sinh tố Bưởi', 'Ly', 20000, 20000, 20000, 20000, '', 1),
(286, 8, 'Sinh tố Cafe', 'Sinh tố Cafe', 'Ly', 15000, 15000, 15000, 15000, '', 1),
(287, 8, 'ST tự chọn 2 món', 'ST tự chọn 2 món', 'Ly', 20000, 20000, 20000, 20000, '', 1),
(288, 8, 'ST tự chọn 3 món', 'ST tự chọn 3 món', 'Ly', 25000, 25000, 25000, 25000, '', 1),
(289, 8, 'ST tự chọn 4 món', 'ST tự chọn 4 món', 'Ly', 28000, 28000, 28000, 28000, '', 1),
(290, 8, 'ST chanh muối', 'ST chanh muối', 'Ly', 15000, 15000, 15000, 15000, '', 1),
(291, 8, 'Dâu dằm', 'Dâu dằm', 'Ly', 25000, 25000, 25000, 25000, '', 1),
(292, 8, 'Mãng cầu dằm', 'Mãng cầu dằm', 'Ly', 17000, 17000, 17000, 17000, '', 1),
(293, 8, 'Bơ dầm', 'Bơ dầm', 'Ly', 25000, 25000, 25000, 25000, '', 1),
(305, 11, 'Ép 4 mùa', 'Ép 4 mùa', 'Ly', 28000, 28000, 28000, 28000, '', 1),
(306, 11, 'Ép bưởi', 'Ép bưởi', 'Ly', 20000, 20000, 20000, 20000, '', 1),
(307, 11, 'Ép cam mật ong', 'Ép cam mật ong', 'Ly', 22000, 22000, 22000, 22000, '', 1),
(308, 11, 'Ép cam sữa', 'Ép cam sữa', 'Ly', 22000, 22000, 22000, 22000, '', 1),
(309, 11, 'Ép chanh dây', 'Ép chanh dây', 'Ly', 20000, 20000, 20000, 20000, '', 1),
(310, 11, 'Ép dâu sữa', 'Ép dâu sữa', 'Ly', 26000, 26000, 26000, 26000, '', 1),
(311, 11, 'Ép tự chọn 2 món', 'Ép tự chọn 2 món', 'Ly', 22000, 22000, 22000, 22000, '', 1),
(312, 11, 'Ép tự chọn 3 món', 'Ép tự chọn 3 món', 'Ly', 25000, 25000, 25000, 25000, '', 1),
(313, 13, 'Yaourt bạc hà', 'Yaourt bạc hà', 'Ly', 15000, 15000, 15000, 15000, '', 1),
(314, 13, 'Yaourt bưởi', 'Yaourt bưởi', 'Ly', 15000, 15000, 15000, 15000, '', 1),
(315, 13, 'Yaourt cafe đá', 'Yaourt cafe đá', 'Ly', 15000, 15000, 15000, 15000, '', 1),
(316, 13, 'Yaourt chanh dây', 'Yaourt chanh dây', 'Ly', 17000, 17000, 17000, 17000, '', 1),
(318, 17, 'Đậu nành nấu', 'Đậu nành nấu', 'Ly', 7000, 7000, 7000, 7000, '', 1),
(320, 17, 'Sữa chanh xí muội', 'Sữa chanh xí muội', 'Ly', 15000, 15000, 15000, 15000, '', 1),
(321, 17, 'Sữa tươi cacao đá', 'Sữa tươi cacao đá', 'Ly', 16000, 16000, 16000, 16000, '', 1),
(322, 17, 'Sữa tươi cafe', 'Sữa tươi cafe', 'Ly', 14000, 14000, 14000, 14000, '', 1),
(325, 23, 'Khăn lạnh', 'Khăn lạnh', 'Cái', 2000, 2000, 2000, 2000, '', 1),
(326, 23, 'Nước ép thêm', 'Nước ép thêm', 'Ly', 10000, 10000, 10000, 10000, '', 1),
(327, 23, 'Phụ thu nhạc', 'Phụ thu nhạc', 'Bàn', 5000, 5000, 5000, 5000, '', 0),
(328, 23, 'Phụ thu PL', 'Phụ thu PL', 'Bàn', 50000, 50000, 50000, 50000, '', 0),
(329, 23, 'Rau má thêm', 'Rau má thêm', 'Ly', 5000, 5000, 5000, 5000, '', 1),
(330, 23, 'Trái cây dĩa lớn', 'Trái cây dĩa lớn', 'Dĩa', 35000, 35000, 35000, 35000, '', 1),
(331, 23, 'Trái cây dĩa nhỏ', 'Trái cây dĩa nhỏ', 'Dĩa', 25000, 25000, 25000, 25000, '', 1),
(332, 14, 'Rivive', 'Rivive', 'Chai', 12000, 12000, 12000, 12000, '', 0),
(333, 14, 'Mountain Dew', 'Mountain Dew', 'Chai', 12000, 12000, 12000, 12000, '', 0),
(334, 14, 'Trà Ô Long', 'Trà Ô Long', 'Chai', 12000, 12000, 12000, 12000, '', 0),
(335, 14, 'C2', 'C2', 'Chai', 10000, 10000, 10000, 10000, '', 0),
(338, 21, 'Mì không', 'Mì không', 'Gói', 7000, 7000, 7000, 7000, '', 0),
(348, 14, 'Cam nutri', '', 'Chai', 12000, 12000, 12000, 12000, '', 0),
(349, 14, 'Samurai', '', 'Chai', 12000, 12000, 12000, 12000, '', 0),
(350, 14, 'Soda', 'Soda', 'Ly', 15000, 15000, 15000, 15000, '', 0),
(351, 8, 'Sinh tố mít', 'Sinh tố mít', 'Ly', 15000, 15000, 15000, 15000, '', 0),
(353, 14, 'Coca (chai thuỷ tinh)', 'Coca (chai thuỷ tinh)', 'Chai', 8000, 8000, 8000, 8000, '', 0),
(355, 15, 'Cam sữa', 'Cam sữa', 'Ly', 15000, 15000, 15000, 15000, '', 0),
(358, 15, 'Chanh đá', 'Chanh đá', 'Ly', 8000, 8000, 8000, 8000, '', 0),
(360, 25, 'Hero (20điếu)', 'Hero (20điếu)', 'Gói', 18000, 18000, 18000, 18000, '', 0),
(361, 25, 'Hero 1/2gói (10điếu)', 'Hero 1/2gói (10điếu)', 'Gói', 10000, 10000, 10000, 10000, '', 0),
(362, 25, 'Hero 1điếu', 'Hero 1điếu', 'Điếu', 1000, 1000, 1000, 1000, '', 0),
(363, 25, 'Jet (20điếu)', 'Jet (20điếu)', 'Gói', 20000, 20000, 20000, 20000, '', 0),
(364, 25, 'Jet 1 điếu', 'Jet 1 điếu', 'Điếu', 1000, 1000, 1000, 1000, '', 0),
(365, 25, 'Jet 1/2 gói (10điếu)', 'Jet 1/2 gói (10điếu)', 'Gói', 10000, 10000, 10000, 10000, '', 0),
(366, 25, 'Mèo lớn (20điếu)', 'Mèo lớn (20điếu)', 'Gói', 22000, 22000, 22000, 22000, '', 0),
(367, 25, 'Mèo trung (12điếu)', 'Mèo trung (12điếu)', 'Gói', 13000, 13000, 13000, 13000, '', 0),
(368, 25, 'Mèo tép (5điếu)', 'Mèo tép (5điếu)', 'Gói', 7000, 7000, 7000, 7000, '', 0),
(369, 25, 'Mèo (1điếu)', 'Mèo (1điếu)', 'Điếu', 1500, 1500, 1500, 1500, '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_customer`
--

CREATE TABLE IF NOT EXISTS `tbl_customer` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  `card` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `note` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `discount` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=14 ;

--
-- Dumping data for table `tbl_customer`
--

INSERT INTO `tbl_customer` (`id`, `name`, `type`, `card`, `phone`, `address`, `note`, `discount`) VALUES
(1, 'Khách lẻ', 0, '', '', '', '', 0),
(12, 'Nguyễn Văn A', 1, '123456789', '0919 111 222', 'Vĩnh Long', '', 5),
(13, 'Nguyễn Văn B', 0, '', '', '', '', 10);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_domain`
--

CREATE TABLE IF NOT EXISTS `tbl_domain` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=8 ;

--
-- Dumping data for table `tbl_domain`
--

INSERT INTO `tbl_domain` (`id`, `name`) VALUES
(1, 'Số bàn'),
(7, 'Khách vãng lai');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_employee`
--

CREATE TABLE IF NOT EXISTS `tbl_employee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `job` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `gender` tinyint(2) NOT NULL,
  `phone` varchar(13) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `salary_base` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=9 ;

--
-- Dumping data for table `tbl_employee`
--

INSERT INTO `tbl_employee` (`id`, `name`, `job`, `gender`, `phone`, `address`, `salary_base`) VALUES
(1, 'Ngọc', 'Phục vụ', 1, '01635758021', 'Mang Thít', 1800000),
(2, 'Trinh', 'Phục vụ', 1, '01649 359 321', 'Đồng Tháp', 1800000),
(3, 'Nguyệt', 'Phục vụ', 1, '0164 220 95 9', 'Đồng Tháp', 1800000),
(4, 'Nhi', 'Phục vụ', 1, '01629 655 287', 'Cần Thơ', 1800000),
(5, 'Duy', 'Phục vụ', 0, '01882356234', 'P2, Tp.Vĩnh Long', 1800000),
(6, 'Dũng', 'Giữ xe', 0, '0907 615 003', 'Quảng Bình', 1800000),
(7, 'Nguyên', 'Nhân viên', 0, '01665685873', 'P3, TP VLong', 1800000),
(8, 'Tân', 'Thu ngân', 0, '0989 975 603', 'Tam Bình', 2500000);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_guest`
--

CREATE TABLE IF NOT EXISTS `tbl_guest` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(16) CHARACTER SET latin1 NOT NULL,
  `entry_time` varchar(32) CHARACTER SET latin1 NOT NULL,
  `exit_time` varchar(32) CHARACTER SET latin1 NOT NULL,
  `agent` varchar(16) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=150 ;

--
-- Dumping data for table `tbl_guest`
--

INSERT INTO `tbl_guest` (`id`, `ip`, `entry_time`, `exit_time`, `agent`) VALUES
(149, '115.78.94.118', '1383319305', '1383322905', '115.78.94.118');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order_import`
--

CREATE TABLE IF NOT EXISTS `tbl_order_import` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idsupplier` int(11) NOT NULL,
  `date` date NOT NULL,
  `description` varchar(50) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_order_import_1` (`idsupplier`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=359 ;

--
-- Dumping data for table `tbl_order_import`
--

INSERT INTO `tbl_order_import` (`id`, `idsupplier`, `date`, `description`) VALUES
(348, 8, '2013-12-06', ''),
(349, 8, '2014-01-02', ''),
(350, 9, '2013-12-30', 'Nhập hàng lần 1'),
(352, 1, '2013-12-31', 'Đá viên'),
(353, 1, '2014-01-01', 'Đá viên'),
(354, 1, '2014-01-02', 'Đá viên'),
(355, 1, '2014-01-03', 'Đá viên'),
(356, 1, '2014-01-06', 'Đá viên + Đá ướp'),
(357, 12, '2014-01-06', 'Dừa'),
(358, 13, '2014-01-03', 'Trà lài');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order_import_detail`
--

CREATE TABLE IF NOT EXISTS `tbl_order_import_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idorder` int(11) NOT NULL,
  `idresource` int(11) NOT NULL,
  `count` float NOT NULL,
  `price` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_order_import_detail_1` (`idorder`),
  KEY `tbl_order_import_detail_2` (`idresource`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=653 ;

--
-- Dumping data for table `tbl_order_import_detail`
--

INSERT INTO `tbl_order_import_detail` (`id`, `idorder`, `idresource`, `count`, `price`) VALUES
(634, 348, 19, 2, 60000),
(635, 348, 20, 1, 80000),
(636, 348, 101, 1, 120000),
(637, 349, 19, 1, 60000),
(638, 350, 35, 2, 160000),
(639, 350, 36, 5, 185000),
(640, 350, 43, 5, 170000),
(641, 350, 103, 5, 105000),
(642, 350, 104, 2, 105000),
(643, 350, 105, 1, 174000),
(644, 350, 106, 1, 135000),
(645, 350, 109, 1, 142000),
(646, 352, 2, 9, 15000),
(647, 353, 2, 3, 15000),
(648, 354, 2, 4, 15000),
(649, 355, 2, 2, 15000),
(650, 356, 2, 5, 15000),
(651, 356, 14, 1, 10000),
(652, 357, 110, 10, 7000);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_paid_customer`
--

CREATE TABLE IF NOT EXISTS `tbl_paid_customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idcustomer` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_customer_paid_1` (`idcustomer`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=19 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_paid_employee`
--

CREATE TABLE IF NOT EXISTS `tbl_paid_employee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_employee` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(150) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_employee` (`id_employee`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `tbl_paid_employee`
--

INSERT INTO `tbl_paid_employee` (`id`, `id_employee`, `date`, `value`, `note`) VALUES
(1, 1, '2013-10-05', 100000, 'Ứng đợt 2'),
(2, 1, '2013-10-01', 200000, 'Ứng đợt 1');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_paid_general`
--

CREATE TABLE IF NOT EXISTS `tbl_paid_general` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_term` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_paid_1` (`id_term`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=168 ;

--
-- Dumping data for table `tbl_paid_general`
--

INSERT INTO `tbl_paid_general` (`id`, `id_term`, `date`, `value`, `note`) VALUES
(9, 10, '2013-04-01', 157000, 'Chi tiền chợ'),
(10, 10, '2013-04-02', 146000, 'Tiền chợ'),
(11, 10, '2013-04-03', 189000, 'Tiền chợ'),
(12, 10, '2013-04-04', 184000, 'Tiền chợ'),
(66, 2, '2013-04-30', 2100000, 'Tạm tính'),
(111, 3, '2013-07-31', 1500000, 'Thuế TTĐB Tháng 07'),
(112, 1, '2013-07-31', 4000000, 'Tiền điện T07'),
(113, 2, '2013-07-31', 2000000, 'Tiền nước T07'),
(155, 3, '2013-08-31', 800000, 'Thuế TTĐB T08'),
(156, 3, '2013-09-30', 850000, 'Thuế TTĐB T09'),
(158, 1, '2013-08-31', 5800000, 'Tiền điện T08'),
(159, 1, '2013-09-30', 3700000, 'Tiền điện T09'),
(160, 2, '2013-08-31', 2200000, 'Tiền nước T08'),
(161, 2, '2013-09-30', 2300000, 'Tiền nước T09'),
(163, 1, '2013-05-31', 4700000, 'Tiền điện T05'),
(164, 1, '2013-06-30', 3900000, 'Tiền điện T06'),
(165, 2, '2013-05-31', 2350000, 'Tiền nước T05'),
(166, 2, '2013-06-30', 2260000, 'Tiền nước T06'),
(167, 11, '2014-01-06', 85000, 'Chi mua Cam');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_paid_pay_roll`
--

CREATE TABLE IF NOT EXISTS `tbl_paid_pay_roll` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_employee` int(11) NOT NULL,
  `date` date NOT NULL,
  `value_base` int(11) NOT NULL,
  `value_sub` int(11) NOT NULL,
  `value_pre` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_paid_pay_roll_1` (`id_employee`),
  KEY `id_employee` (`id_employee`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_paid_supplier`
--

CREATE TABLE IF NOT EXISTS `tbl_paid_supplier` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idsupplier` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_supplier_paid_1` (`idsupplier`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=18 ;

--
-- Dumping data for table `tbl_paid_supplier`
--

INSERT INTO `tbl_paid_supplier` (`id`, `idsupplier`, `date`, `value`, `note`) VALUES
(1, 1, '2012-08-01', 2300000, 'được không ?'),
(2, 1, '2012-07-03', 350000, 'Ghi chú gì đây'),
(3, 1, '2012-07-26', 750000, 'Ghi ghi gì gì đó'),
(8, 6, '2012-09-19', 1000000, 'Thử nè được không đó !'),
(9, 1, '2012-09-19', 1000000, 'lung tung quá đi'),
(11, 1, '2012-01-01', 123, 'sdfdsfggf'),
(12, 1, '2012-09-24', 1230000, 'đâu biết'),
(13, 1, '2012-09-24', 1213232, ''),
(14, 1, '2012-09-24', 34243243, ''),
(15, 1, '2012-09-24', 21323, ''),
(16, 1, '2012-09-24', 123323, ''),
(17, 1, '2012-09-24', 21323, '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_pay_roll`
--

CREATE TABLE IF NOT EXISTS `tbl_pay_roll` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_employee` int(11) NOT NULL,
  `date` date NOT NULL,
  `state` int(11) NOT NULL,
  `extra` int(11) NOT NULL,
  `late` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_employee` (`id_employee`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=38 ;

--
-- Dumping data for table `tbl_pay_roll`
--

INSERT INTO `tbl_pay_roll` (`id`, `id_employee`, `date`, `state`, `extra`, `late`) VALUES
(1, 1, '2013-10-01', 1, 0, 0),
(2, 1, '2013-10-02', 1, 0, 0),
(3, 1, '2013-10-03', 1, 0, 0),
(4, 1, '2013-10-04', 1, 0, 0),
(5, 1, '2013-10-05', 1, 0, 0),
(6, 1, '2013-10-06', 1, 0, 0),
(7, 1, '2013-10-07', 1, 0, 0),
(8, 1, '2013-10-08', 1, 0, 0),
(9, 1, '2013-10-09', 1, 0, 0),
(10, 1, '2013-10-10', 1, 0, 0),
(11, 1, '2013-10-11', 1, 0, 0),
(12, 1, '2013-10-12', 1, 0, 0),
(13, 1, '2013-10-13', 1, 0, 0),
(14, 1, '2013-10-14', 1, 0, 0),
(15, 1, '2013-10-31', 1, 0, 0),
(16, 1, '2013-10-30', 1, 0, 0),
(17, 1, '2013-10-15', 1, 0, 0),
(18, 1, '2013-10-16', 1, 0, 0),
(19, 1, '2013-10-17', 1, 0, 0),
(20, 1, '2013-10-18', 1, 0, 0),
(21, 1, '2013-10-19', 1, 0, 0),
(22, 1, '2013-10-25', 1, 0, 0),
(23, 1, '2013-10-27', 1, 0, 0),
(24, 1, '2013-10-24', 1, 0, 0),
(25, 1, '2013-10-21', 1, 0, 0),
(26, 1, '2013-10-20', 1, 0, 0),
(27, 1, '2013-10-23', 1, 0, 0),
(28, 1, '2013-10-22', 1, 0, 0),
(29, 1, '2013-10-26', 1, 0, 0),
(30, 1, '2013-10-28', 1, 0, 0),
(31, 1, '2013-10-29', 1, 0, 0),
(32, 1, '2014-01-01', 1, 0, 0),
(33, 1, '2014-01-02', 0, 0, 0),
(34, 1, '2014-01-03', 0, 0, 0),
(35, 2, '2014-01-03', 1, 0, 0),
(36, 2, '2014-01-01', 1, 0, 0),
(37, 2, '2014-01-02', 1, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_r2c`
--

CREATE TABLE IF NOT EXISTS `tbl_r2c` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_course` int(11) NOT NULL,
  `id_resource` int(11) NOT NULL,
  `value1` double NOT NULL,
  `value2` double NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_r2c_1` (`id_course`),
  KEY `tbl_r2c_2` (`id_resource`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=159 ;

--
-- Dumping data for table `tbl_r2c`
--

INSERT INTO `tbl_r2c` (`id`, `id_course`, `id_resource`, `value1`, `value2`) VALUES
(103, 107, 19, 1, 40),
(106, 108, 20, 1, 40),
(154, 197, 36, 1, 24),
(157, 205, 35, 1, 24),
(158, 255, 19, 1, 40);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_resource`
--

CREATE TABLE IF NOT EXISTS `tbl_resource` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `idsupplier` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `unit` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `price` int(10) NOT NULL,
  `description` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_resource_1` (`idsupplier`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=111 ;

--
-- Dumping data for table `tbl_resource`
--

INSERT INTO `tbl_resource` (`id`, `idsupplier`, `name`, `unit`, `price`, `description`) VALUES
(2, 1, 'Đá viên nhỏ', 'Bao', 15000, 'Nước đá viên - Bao 25kg'),
(14, 1, 'Nước đá ướp', 'Cây', 10000, 'Đá cây ướp trái cây'),
(17, 6, 'Bánh', 'Gói', 5000, ''),
(19, 8, 'Hạt loại 1', 'Kg', 60000, ''),
(20, 8, 'Hạt loại 2', 'Kg', 80000, ''),
(27, 6, 'Xúc xích', 'Gói', 17000, ''),
(35, 9, 'Trà xanh 0 độ', 'Thùng', 160000, 'Thùng 24 chai 500ml'),
(36, 9, 'Dr Thanh', 'Thùng', 185000, 'Thùng 24 chai 370 ml'),
(39, 9, 'Pepsi', 'Thùng', 150000, 'Thùng 24 lon 330 ml'),
(40, 9, 'Mirinda Cam', 'Thùng', 120000, 'Thùng 24 lon 330ml'),
(43, 9, 'Sting dâu', 'Thùng', 170000, 'Thùng 24 chai 330ml'),
(47, 12, 'Ổi', 'Kg', 9000, ''),
(48, 12, 'Củ sắn', 'Kg', 15000, ''),
(49, 12, 'Mít', 'Kg', 18000, ''),
(50, 12, 'Chôm chôm', 'Kg', 10000, ''),
(51, 12, 'Xoài Thái', 'Kg', 15000, ''),
(52, 12, 'Xoài Đài Loan', 'Kg', 15000, ''),
(53, 12, 'Xoài chua', 'Kg', 15000, ''),
(54, 12, 'Mận', 'Kg', 10000, ''),
(55, 12, 'Sơ ri', 'Kg', 12000, ''),
(56, 12, 'Thơm', 'Kg', 12000, ''),
(57, 12, 'Khóm', 'Kg', 10000, ''),
(79, 12, 'Dưa hấu', 'Kg', 10000, ''),
(82, 12, 'Táo', 'Kg', 10000, ''),
(84, 12, 'Cóc', 'Kg', 6000, ''),
(91, 1, 'Đá ống viên lớn', 'Kg', 800, 'Bao 20kg'),
(99, 12, 'Bưởi', 'Kg', 10000, ''),
(101, 8, 'Hạt loại 3', 'Kg', 120000, ''),
(102, 13, 'Duong', 'Kg', 20000, ''),
(103, 9, 'C2', 'Thùng', 105000, '24 chai'),
(104, 9, 'Lipton', 'Hộp', 105000, '100 gói'),
(105, 9, 'Revive', 'Thùng', 174000, '24 chai'),
(106, 9, 'Ô Long', 'Thùng', 135000, '24 chai'),
(107, 12, 'Cà chua', 'Kg', 0, ''),
(108, 12, 'Cà rốt', 'Kg', 0, ''),
(109, 9, 'Mountain Dew', 'Thùng', 142000, '24 chai'),
(110, 12, 'Dừa', 'Trái', 7000, 'gọt sẵn');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_session`
--

CREATE TABLE IF NOT EXISTS `tbl_session` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idtable` int(11) NOT NULL,
  `iduser` int(11) NOT NULL,
  `idcustomer` int(11) NOT NULL,
  `idemployee` int(11) NOT NULL,
  `datetime` datetime NOT NULL,
  `datetimeend` datetime DEFAULT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `status` int(11) NOT NULL,
  `discount_value` int(11) NOT NULL,
  `discount_percent` int(11) NOT NULL,
  `surtax` int(11) NOT NULL,
  `payment` int(11) NOT NULL,
  `value` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idtable` (`idtable`),
  KEY `iduser` (`iduser`),
  KEY `tbl_session_3` (`idcustomer`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=364 ;

--
-- Dumping data for table `tbl_session`
--

INSERT INTO `tbl_session` (`id`, `idtable`, `iduser`, `idcustomer`, `idemployee`, `datetime`, `datetimeend`, `note`, `status`, `discount_value`, `discount_percent`, `surtax`, `payment`, `value`) VALUES
(230, 32, 4, 1, 1, '2014-01-04 20:37:56', '2014-01-04 20:37:56', 'P', 1, 0, 0, 0, 0, 0),
(232, 41, 4, 1, 1, '2014-01-04 20:38:41', '2014-01-04 20:38:41', 'P', 1, 0, 0, 0, 0, 0),
(235, 38, 4, 1, 1, '2014-01-05 07:48:36', '2014-01-05 07:48:36', 'P', 1, 0, 0, 0, 0, 0),
(237, 178, 4, 1, 1, '2014-01-05 08:01:32', '2014-01-05 08:01:32', 'P', 1, 0, 0, 0, 0, 0),
(238, 34, 4, 1, 1, '2014-01-05 08:38:02', '2014-01-05 08:38:02', 'P', 1, 0, 0, 0, 0, 0),
(239, 31, 4, 1, 1, '2014-01-05 08:43:57', '2014-01-05 08:43:57', 'P', 1, 0, 0, 0, 0, 0),
(240, 32, 4, 1, 1, '2014-01-05 09:01:38', '2014-01-05 09:01:38', 'P', 1, 0, 0, 0, 0, 0),
(241, 143, 4, 1, 1, '2014-01-05 09:21:31', '2014-01-05 09:21:31', 'P', 1, 0, 0, 0, 0, 0),
(242, 30, 4, 1, 1, '2014-01-05 09:30:36', '2014-01-05 09:30:36', 'P', 1, 0, 0, 0, 0, 0),
(243, 38, 4, 1, 1, '2014-01-05 09:31:51', '2014-01-05 09:31:51', 'P', 1, 0, 0, 0, 0, 0),
(244, 156, 4, 1, 1, '2014-01-05 12:44:14', '2014-01-05 12:44:14', 'P', 1, 0, 0, 0, 0, 0),
(245, 150, 4, 1, 1, '2014-01-05 12:47:16', '2014-01-05 12:47:16', 'P', 1, 0, 0, 0, 0, 0),
(248, 31, 4, 1, 1, '2014-01-05 13:21:42', '2014-01-05 13:21:42', 'P', 1, 0, 0, 0, 0, 0),
(249, 33, 4, 1, 1, '2014-01-05 13:54:04', '2014-01-05 13:54:04', 'P', 1, 0, 0, 0, 0, 0),
(250, 149, 4, 1, 1, '2014-01-05 13:55:18', '2014-01-05 13:55:18', 'P', 1, 0, 0, 0, 0, 0),
(252, 136, 4, 1, 1, '2014-01-05 17:13:19', '2014-01-05 17:13:19', 'P', 1, 0, 0, 0, 0, 0),
(253, 149, 4, 1, 1, '2014-01-05 17:15:52', '2014-01-05 17:15:52', 'P', 1, 0, 0, 0, 0, 0),
(254, 137, 4, 1, 1, '2014-01-05 17:54:35', '2014-01-05 17:54:35', 'P', 1, 0, 0, 0, 0, 0),
(256, 178, 4, 1, 1, '2014-01-05 18:10:39', '2014-01-05 18:10:39', 'P', 1, 0, 0, 0, 0, 0),
(257, 133, 4, 1, 1, '2014-01-05 18:11:18', '2014-01-05 18:11:18', 'P', 1, 0, 0, 0, 0, 0),
(258, 2, 4, 1, 1, '2014-01-05 19:37:40', '2014-01-05 19:37:40', 'P', 1, 0, 0, 0, 0, 0),
(259, 1, 4, 1, 1, '2014-01-05 19:38:07', '2014-01-05 19:38:07', 'P', 1, 0, 0, 0, 0, 0),
(260, 140, 4, 1, 1, '2014-01-05 19:39:17', '2014-01-05 19:39:17', 'P', 1, 0, 0, 0, 0, 0),
(261, 177, 4, 1, 1, '2014-01-05 19:41:06', '2014-01-05 19:41:06', 'P', 1, 0, 0, 0, 0, 0),
(262, 33, 4, 1, 4, '2014-01-05 19:41:41', '2014-01-05 19:41:41', 'P', 1, 0, 0, 0, 0, 0),
(264, 1, 4, 1, 1, '2014-01-05 19:51:30', '2014-01-05 19:51:30', 'P', 1, 0, 0, 0, 0, 0),
(265, 178, 4, 1, 1, '2014-01-05 19:54:24', '2014-01-05 19:54:24', 'P', 1, 0, 0, 0, 0, 0),
(266, 29, 4, 1, 1, '2014-01-05 20:02:44', '2014-01-05 20:02:44', 'P', 1, 0, 0, 0, 0, 0),
(267, 137, 4, 1, 1, '2014-01-05 20:07:41', '2014-01-05 20:07:41', 'P', 1, 0, 0, 0, 0, 0),
(268, 133, 4, 1, 1, '2014-01-05 20:11:33', '2014-01-05 20:11:33', 'P', 1, 0, 0, 0, 0, 0),
(269, 156, 4, 1, 1, '2014-01-05 20:12:25', '2014-01-05 20:12:25', 'P', 1, 0, 0, 0, 0, 0),
(270, 188, 4, 1, 1, '2014-01-05 20:12:50', '2014-01-05 20:12:50', 'P', 1, 0, 0, 0, 0, 0),
(271, 1, 4, 1, 1, '2014-01-05 20:19:50', '2014-01-05 20:19:50', 'P', 1, 0, 0, 0, 0, 0),
(272, 143, 4, 1, 1, '2014-01-05 20:27:37', '2014-01-05 20:27:37', 'P', 1, 0, 0, 0, 0, 0),
(277, 38, 4, 1, 1, '2014-01-05 21:32:48', '2014-01-05 21:32:48', 'P', 1, 0, 0, 0, 0, 0),
(278, 162, 4, 1, 1, '2014-01-05 22:17:54', '2014-01-05 22:17:54', 'P', 1, 0, 0, 0, 0, 0),
(280, 162, 4, 1, 1, '2014-01-05 23:50:52', '2014-01-05 23:50:52', 'P', 1, 0, 0, 0, 0, 0),
(281, 28, 4, 1, 1, '2014-01-06 06:42:32', '2014-01-06 06:42:32', 'P', 1, 0, 0, 0, 0, 0),
(282, 28, 4, 1, 1, '2014-01-06 06:46:35', '2014-01-06 06:46:35', 'P', 1, 0, 0, 0, 0, 0),
(283, 38, 4, 1, 1, '2014-01-06 07:12:45', '2014-01-06 07:12:45', 'P', 1, 0, 0, 0, 0, 0),
(284, 143, 4, 1, 1, '2014-01-06 07:13:45', '2014-01-06 07:13:45', 'P', 1, 0, 0, 0, 0, 0),
(285, 41, 4, 1, 1, '2014-01-06 07:22:28', '2014-01-06 07:22:28', 'P', 1, 0, 0, 0, 0, 0),
(286, 38, 4, 1, 1, '2014-01-06 07:30:11', '2014-01-06 07:30:11', 'P', 1, 0, 0, 0, 0, 0),
(287, 150, 4, 1, 1, '2014-01-06 07:36:57', '2014-01-06 07:36:57', 'P', 1, 0, 0, 0, 0, 0),
(288, 145, 4, 1, 1, '2014-01-06 07:43:29', '2014-01-06 07:43:29', 'P', 1, 0, 0, 0, 0, 0),
(289, 41, 4, 1, 1, '2014-01-06 07:49:04', '2014-01-06 07:49:04', 'P', 1, 0, 0, 0, 0, 0),
(290, 135, 4, 1, 1, '2014-01-06 07:53:26', '2014-01-06 07:53:26', 'P', 1, 0, 0, 0, 0, 0),
(291, 34, 4, 1, 1, '2014-01-06 08:17:06', '2014-01-06 08:17:06', 'P', 1, 0, 0, 0, 0, 0),
(292, 143, 4, 1, 1, '2014-01-06 08:24:38', '2014-01-06 08:24:38', 'P', 1, 0, 0, 0, 0, 0),
(293, 150, 4, 1, 1, '2014-01-06 09:11:53', '2014-01-06 09:11:53', 'P', 1, 0, 0, 0, 0, 0),
(295, 1, 4, 1, 1, '2014-01-06 09:15:48', '2014-01-06 09:15:48', 'P', 1, 0, 0, 0, 0, 0),
(296, 145, 4, 1, 1, '2014-01-06 09:24:52', '2014-01-06 09:24:52', 'P', 1, 0, 0, 0, 0, 0),
(297, 151, 4, 1, 1, '2014-01-06 09:34:02', '2014-01-06 09:34:02', 'P', 1, 0, 0, 0, 0, 0),
(298, 32, 4, 1, 1, '2014-01-06 09:36:16', '2014-01-06 09:36:16', 'P', 1, 0, 0, 0, 0, 0),
(299, 28, 4, 1, 1, '2014-01-06 09:43:56', '2014-01-06 09:43:56', 'P', 1, 0, 0, 0, 0, 0),
(301, 135, 4, 1, 1, '2014-01-06 10:05:01', '2014-01-06 10:05:01', 'P', 1, 0, 0, 0, 0, 0),
(302, 1, 4, 1, 1, '2014-01-06 10:30:44', '2014-01-06 10:30:44', 'P', 1, 0, 0, 0, 0, 0),
(303, 166, 4, 1, 1, '2014-01-06 10:37:43', '2014-01-06 10:37:43', 'P', 1, 0, 0, 0, 0, 0),
(304, 149, 4, 1, 1, '2014-01-06 10:48:59', '2014-01-06 10:48:59', 'P', 1, 0, 0, 0, 0, 0),
(305, 150, 4, 1, 1, '2014-01-06 12:02:28', '2014-01-06 12:02:28', 'P', 1, 0, 0, 0, 0, 0),
(306, 150, 4, 1, 1, '2014-01-06 13:42:59', '2014-01-06 13:42:59', 'P', 1, 0, 0, 0, 0, 0),
(307, 168, 4, 1, 1, '2014-01-06 14:10:19', '2014-01-06 14:10:19', 'P', 1, 0, 0, 0, 0, 0),
(308, 144, 4, 1, 1, '2014-01-06 14:33:42', '2014-01-06 14:33:42', 'P', 1, 0, 0, 0, 0, 0),
(309, 142, 4, 1, 1, '2014-01-06 14:44:29', '2014-01-06 14:44:29', 'P', 1, 0, 0, 0, 0, 0),
(310, 35, 4, 1, 1, '2014-01-06 14:46:45', '2014-01-06 14:46:45', 'P', 1, 0, 0, 0, 0, 0),
(311, 178, 4, 1, 1, '2014-01-06 14:55:48', '2014-01-06 14:55:48', 'P', 1, 0, 0, 0, 0, 0),
(312, 1, 4, 1, 1, '2014-01-06 14:56:43', '2014-01-06 14:56:43', 'P', 1, 0, 0, 0, 0, 0),
(313, 141, 4, 1, 1, '2014-01-06 14:59:35', '2014-01-06 14:59:35', 'P', 1, 0, 0, 0, 0, 0),
(314, 142, 4, 1, 1, '2014-01-06 15:00:33', '2014-01-06 15:00:33', 'P', 1, 0, 0, 0, 0, 0),
(315, 140, 4, 1, 1, '2014-01-06 15:24:33', '2014-01-06 15:24:33', 'P', 1, 0, 0, 0, 0, 0),
(316, 185, 4, 1, 1, '2014-01-06 15:41:58', '2014-01-06 15:41:58', '', 0, 0, 0, 0, 0, 0),
(317, 32, 4, 1, 1, '2014-01-06 16:46:31', '2014-01-06 16:46:31', 'P', 1, 0, 0, 0, 0, 0),
(318, 31, 4, 1, 1, '2014-01-06 16:46:46', '2014-01-06 16:46:46', 'P', 1, 0, 0, 0, 0, 0),
(319, 4, 4, 1, 1, '2014-01-06 17:46:01', '2014-01-06 17:46:01', 'P', 1, 0, 0, 0, 0, 0),
(320, 32, 4, 1, 1, '2014-01-06 17:47:03', '2014-01-06 17:47:03', 'P', 1, 0, 0, 0, 0, 0),
(321, 28, 4, 1, 1, '2014-01-06 17:49:54', '2014-01-06 17:49:54', 'P', 1, 0, 0, 0, 0, 0),
(322, 136, 4, 1, 1, '2014-01-06 18:03:00', '2014-01-06 18:03:00', 'P', 1, 0, 0, 0, 0, 0),
(324, 3, 4, 1, 1, '2014-01-06 18:06:04', '2014-01-06 18:06:04', 'P', 1, 0, 0, 0, 0, 0),
(325, 1, 4, 1, 1, '2014-01-06 18:06:36', '2014-01-06 18:06:36', 'P', 1, 0, 0, 0, 0, 0),
(326, 38, 4, 1, 1, '2014-01-06 18:13:05', '2014-01-06 18:13:05', 'P', 1, 0, 0, 0, 0, 0),
(327, 41, 4, 1, 1, '2014-01-06 18:14:11', '2014-01-06 18:14:11', 'P', 1, 0, 0, 0, 0, 0),
(328, 133, 4, 1, 1, '2014-01-06 18:16:26', '2014-01-06 18:16:26', 'P', 1, 0, 0, 0, 0, 0),
(330, 33, 4, 1, 1, '2014-01-06 18:26:45', '2014-01-06 18:26:45', 'P', 1, 0, 0, 0, 0, 0),
(331, 2, 4, 1, 1, '2014-01-06 18:26:55', '2014-01-06 18:26:55', 'P', 1, 0, 0, 0, 0, 0),
(332, 30, 4, 1, 1, '2014-01-06 18:27:10', '2014-01-06 18:27:10', 'P', 1, 0, 0, 0, 0, 0),
(333, 135, 4, 1, 1, '2014-01-06 18:27:36', '2014-01-06 18:27:36', 'P', 1, 0, 0, 0, 0, 0),
(334, 178, 4, 1, 1, '2014-01-06 18:31:55', '2014-01-06 18:31:55', 'P', 1, 0, 0, 0, 0, 0),
(335, 135, 4, 1, 1, '2014-01-06 18:32:39', '2014-01-06 18:32:39', 'P', 1, 0, 0, 0, 0, 0),
(336, 137, 4, 1, 1, '2014-01-06 18:35:59', '2014-01-06 18:35:59', 'P', 1, 0, 0, 0, 0, 0),
(337, 141, 4, 1, 1, '2014-01-06 18:37:22', '2014-01-06 18:37:22', 'P', 1, 0, 0, 0, 0, 0),
(338, 140, 4, 1, 1, '2014-01-06 18:40:50', '2014-01-06 18:40:50', 'P', 1, 0, 0, 0, 0, 0),
(339, 34, 4, 1, 1, '2014-01-06 18:42:12', '2014-01-06 18:42:12', 'P', 1, 0, 0, 0, 0, 0),
(340, 143, 4, 1, 1, '2014-01-06 18:46:12', '2014-01-06 18:46:12', 'P', 1, 0, 0, 0, 0, 0),
(341, 2, 4, 1, 1, '2014-01-06 18:56:10', '2014-01-06 18:56:10', 'P', 1, 0, 0, 0, 0, 0),
(342, 2, 4, 1, 1, '2014-01-06 18:57:22', '2014-01-06 18:57:22', 'P', 1, 0, 0, 0, 0, 0),
(343, 142, 4, 1, 1, '2014-01-06 18:57:37', '2014-01-06 18:57:37', 'P', 1, 0, 0, 0, 0, 0),
(344, 136, 4, 1, 1, '2014-01-06 19:05:58', '2014-01-06 19:05:58', 'P', 1, 0, 0, 0, 0, 0),
(345, 136, 4, 1, 1, '2014-01-06 19:09:00', '2014-01-06 19:09:00', 'P', 1, 0, 0, 0, 0, 0),
(346, 38, 4, 1, 1, '2014-01-06 19:15:08', '2014-01-06 19:15:08', 'P', 1, 0, 0, 0, 0, 0),
(347, 144, 4, 1, 1, '2014-01-06 19:15:59', '2014-01-06 19:15:59', 'P', 1, 0, 0, 0, 0, 0),
(348, 149, 4, 1, 1, '2014-01-06 19:20:24', '2014-01-06 19:20:24', 'P', 1, 0, 0, 0, 0, 0),
(349, 150, 4, 1, 1, '2014-01-06 19:21:33', '2014-01-06 19:21:33', 'P', 1, 0, 0, 0, 0, 0),
(350, 31, 4, 1, 1, '2014-01-06 19:32:43', '2014-01-06 19:32:43', 'P', 1, 0, 0, 0, 0, 0),
(351, 178, 4, 1, 1, '2014-01-06 19:35:17', '2014-01-06 19:35:17', 'P', 1, 0, 0, 0, 0, 0),
(352, 34, 4, 1, 1, '2014-01-06 19:38:28', '2014-01-06 19:38:28', 'P', 1, 0, 0, 0, 0, 0),
(353, 143, 4, 1, 1, '2014-01-06 19:50:57', '2014-01-06 19:50:57', 'P', 1, 0, 0, 0, 0, 0),
(354, 151, 4, 1, 1, '2014-01-06 19:51:44', '2014-01-06 19:51:44', 'P', 1, 0, 0, 0, 0, 0),
(355, 144, 4, 1, 1, '2014-01-06 20:02:53', '2014-01-06 20:02:53', 'P', 1, 0, 0, 0, 0, 0),
(356, 2, 4, 1, 1, '2014-01-06 20:04:50', '2014-01-06 20:04:50', 'P', 1, 0, 0, 0, 0, 0),
(360, 41, 4, 1, 1, '2014-01-06 20:35:40', '2014-01-06 20:35:40', 'P', 1, 0, 0, 0, 0, 0),
(361, 2, 4, 1, 1, '2014-01-06 20:38:18', '2014-01-06 20:38:18', 'P', 1, 0, 0, 0, 0, 0),
(362, 136, 4, 1, 1, '2014-01-06 21:04:14', '2014-01-06 21:04:14', 'P', 1, 0, 0, 0, 0, 0),
(363, 178, 4, 1, 1, '2014-01-06 21:04:36', '2014-01-06 21:04:36', 'P', 1, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_session_detail`
--

CREATE TABLE IF NOT EXISTS `tbl_session_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idsession` int(11) NOT NULL,
  `idcourse` int(11) NOT NULL,
  `count` int(11) NOT NULL,
  `price` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idsession` (`idsession`),
  KEY `idcourse` (`idcourse`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=442 ;

--
-- Dumping data for table `tbl_session_detail`
--

INSERT INTO `tbl_session_detail` (`id`, `idsession`, `idcourse`, `count`, `price`) VALUES
(128, 230, 107, 1, 8000),
(129, 230, 255, 1, 10000),
(131, 232, 224, 1, 8000),
(136, 235, 107, 4, 8000),
(140, 235, 222, 1, 10000),
(144, 237, 107, 2, 8000),
(145, 237, 174, 1, 12000),
(146, 237, 255, 3, 10000),
(147, 238, 107, 2, 8000),
(148, 238, 224, 1, 8000),
(149, 239, 224, 1, 8000),
(150, 240, 107, 2, 8000),
(151, 241, 212, 1, 12000),
(152, 242, 204, 2, 12000),
(153, 243, 107, 1, 8000),
(155, 244, 107, 3, 8000),
(157, 244, 180, 1, 12000),
(161, 245, 224, 2, 8000),
(162, 245, 107, 2, 8000),
(165, 244, 175, 1, 12000),
(169, 248, 107, 1, 8000),
(170, 248, 180, 1, 12000),
(173, 249, 224, 2, 8000),
(174, 250, 107, 2, 8000),
(180, 252, 255, 1, 10000),
(181, 252, 128, 1, 15000),
(183, 253, 107, 2, 8000),
(186, 254, 107, 1, 8000),
(187, 254, 222, 1, 8000),
(190, 256, 205, 1, 12000),
(191, 256, 335, 1, 10000),
(192, 257, 107, 1, 8000),
(193, 257, 255, 1, 10000),
(194, 258, 107, 1, 8000),
(195, 259, 107, 1, 8000),
(196, 260, 224, 1, 8000),
(197, 260, 204, 1, 12000),
(198, 261, 107, 1, 8000),
(199, 261, 268, 1, 8000),
(200, 262, 255, 1, 10000),
(201, 262, 107, 2, 8000),
(202, 262, 204, 2, 12000),
(205, 262, 177, 1, 15000),
(206, 262, 180, 1, 12000),
(209, 264, 107, 2, 8000),
(210, 265, 204, 2, 12000),
(211, 266, 107, 3, 8000),
(212, 266, 224, 2, 8000),
(213, 266, 189, 1, 18000),
(215, 267, 107, 1, 8000),
(216, 267, 56, 1, 15000),
(217, 265, 255, 2, 10000),
(218, 265, 335, 1, 10000),
(220, 262, 212, 1, 12000),
(221, 268, 224, 3, 8000),
(222, 268, 177, 3, 15000),
(223, 268, 179, 1, 15000),
(224, 269, 107, 2, 8000),
(226, 271, 107, 1, 8000),
(227, 271, 255, 2, 10000),
(228, 269, 176, 1, 10000),
(229, 262, 176, 2, 10000),
(230, 272, 176, 1, 10000),
(231, 272, 224, 1, 8000),
(232, 272, 221, 1, 10000),
(233, 267, 224, 1, 8000),
(240, 277, 178, 1, 13000),
(241, 265, 222, 1, 8000),
(242, 278, 204, 1, 12000),
(246, 281, 107, 1, 8000),
(247, 282, 107, 1, 8000),
(248, 283, 107, 1, 8000),
(249, 284, 107, 2, 8000),
(250, 284, 201, 1, 8000),
(251, 285, 112, 1, 10000),
(252, 285, 197, 1, 15000),
(253, 286, 107, 2, 8000),
(255, 287, 107, 1, 8000),
(256, 287, 204, 1, 12000),
(257, 288, 107, 2, 8000),
(259, 288, 255, 2, 12000),
(260, 288, 224, 1, 8000),
(262, 289, 107, 3, 8000),
(263, 290, 107, 1, 8000),
(264, 290, 176, 1, 8000),
(265, 289, 222, 1, 8000),
(266, 291, 204, 1, 12000),
(267, 291, 255, 1, 12000),
(268, 291, 107, 3, 8000),
(269, 292, 107, 1, 8000),
(270, 291, 174, 1, 12000),
(272, 292, 204, 2, 12000),
(276, 293, 107, 1, 8000),
(277, 293, 218, 1, 15000),
(280, 293, 175, 1, 12000),
(283, 295, 107, 1, 8000),
(286, 286, 176, 1, 8000),
(287, 296, 255, 2, 12000),
(290, 296, 212, 1, 10000),
(291, 293, 255, 1, 12000),
(292, 297, 107, 4, 8000),
(293, 298, 107, 1, 8000),
(294, 299, 107, 2, 8000),
(297, 301, 107, 2, 8000),
(298, 302, 107, 3, 8000),
(299, 302, 265, 1, 8000),
(300, 302, 197, 1, 15000),
(301, 303, 107, 4, 8000),
(303, 302, 175, 1, 12000),
(304, 302, 204, 1, 12000),
(305, 302, 315, 2, 15000),
(306, 302, 212, 1, 10000),
(307, 302, 255, 1, 12000),
(308, 302, 353, 1, 8000),
(309, 301, 205, 1, 12000),
(310, 304, 107, 1, 8000),
(312, 304, 204, 1, 12000),
(313, 305, 107, 2, 8000),
(316, 306, 176, 1, 8000),
(317, 307, 107, 1, 8000),
(318, 308, 175, 1, 12000),
(319, 308, 107, 1, 8000),
(320, 308, 212, 1, 10000),
(321, 309, 218, 1, 15000),
(322, 309, 224, 2, 8000),
(323, 309, 107, 1, 8000),
(324, 309, 255, 2, 12000),
(325, 310, 176, 1, 8000),
(326, 310, 268, 1, 8000),
(328, 311, 174, 1, 12000),
(329, 311, 107, 1, 8000),
(330, 312, 255, 3, 12000),
(331, 312, 224, 3, 8000),
(332, 312, 176, 1, 8000),
(333, 310, 112, 1, 10000),
(334, 310, 204, 1, 12000),
(335, 313, 107, 2, 8000),
(336, 314, 224, 1, 8000),
(337, 312, 107, 2, 8000),
(338, 312, 351, 1, 15000),
(339, 315, 224, 1, 8000),
(340, 315, 107, 2, 8000),
(341, 316, 107, 2, 8000),
(352, 317, 224, 1, 8000),
(354, 319, 177, 1, 12000),
(355, 319, 107, 1, 8000),
(356, 320, 107, 5, 8000),
(357, 321, 107, 1, 8000),
(358, 322, 228, 1, 15000),
(359, 320, 189, 1, 18000),
(360, 324, 204, 1, 12000),
(361, 325, 107, 2, 8000),
(362, 321, 129, 1, 15000),
(366, 322, 107, 1, 8000),
(367, 326, 224, 2, 8000),
(369, 326, 179, 1, 15000),
(375, 328, 255, 5, 12000),
(376, 328, 204, 1, 12000),
(377, 328, 353, 1, 8000),
(378, 319, 180, 1, 8000),
(379, 319, 204, 3, 12000),
(380, 331, 224, 1, 8000),
(381, 327, 255, 1, 12000),
(382, 330, 107, 2, 8000),
(383, 331, 107, 1, 8000),
(384, 331, 255, 2, 12000),
(385, 332, 224, 1, 8000),
(386, 332, 107, 1, 8000),
(387, 333, 107, 1, 8000),
(388, 333, 224, 1, 8000),
(389, 334, 107, 1, 8000),
(390, 334, 351, 1, 15000),
(392, 335, 107, 1, 8000),
(394, 336, 107, 3, 8000),
(395, 320, 176, 2, 8000),
(396, 337, 107, 1, 8000),
(397, 337, 224, 1, 8000),
(398, 331, 255, 2, 12000),
(399, 338, 224, 1, 8000),
(400, 338, 335, 1, 10000),
(401, 339, 107, 2, 8000),
(402, 340, 107, 2, 8000),
(403, 340, 176, 1, 8000),
(404, 328, 175, 1, 12000),
(405, 339, 255, 1, 12000),
(406, 320, 224, 1, 8000),
(407, 341, 255, 1, 12000),
(409, 343, 203, 1, 12000),
(411, 343, 189, 1, 18000),
(412, 318, 107, 1, 8000),
(413, 318, 268, 1, 8000),
(414, 344, 107, 2, 8000),
(415, 344, 224, 1, 8000),
(416, 345, 107, 1, 8000),
(417, 345, 204, 1, 12000),
(418, 346, 107, 1, 8000),
(419, 347, 107, 1, 8000),
(420, 347, 224, 2, 8000),
(421, 348, 255, 5, 12000),
(423, 350, 107, 1, 8000),
(425, 352, 107, 1, 8000),
(428, 355, 355, 1, 15000),
(429, 356, 204, 1, 12000),
(433, 360, 107, 1, 8000),
(434, 360, 364, 5, 1000),
(435, 361, 107, 1, 8000),
(436, 354, 334, 4, 12000),
(437, 362, 226, 1, 8000),
(438, 363, 107, 2, 8000),
(439, 363, 204, 1, 12000),
(440, 363, 364, 6, 1000),
(441, 316, 363, 1, 20000);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_store`
--

CREATE TABLE IF NOT EXISTS `tbl_store` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `note` varchar(125) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_store`
--

INSERT INTO `tbl_store` (`id`, `name`, `note`) VALUES
(1, 'Kho nhà', 'Ghi chú gì đây ?');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_supplier`
--

CREATE TABLE IF NOT EXISTS `tbl_supplier` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `note` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `debt` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=14 ;

--
-- Dumping data for table `tbl_supplier`
--

INSERT INTO `tbl_supplier` (`id`, `name`, `phone`, `address`, `note`, `debt`) VALUES
(1, 'ĐL NƯỚC ĐÁ', '0913796043', 'Phường 8', 'Cung cấp nước đá', 0),
(6, 'Siêu thị COOP MART', 'chưa cập nhật', 'Vĩnh Long', '', 0),
(8, 'ĐL Cafe hạt', '0703 111 222', 'P4 Vĩnh Long', '', 0),
(9, 'ĐL Nước ngọt Thiên Tân', '', 'P1, TP Vĩnh Long', '', 0),
(12, 'VỰA TRÁI CÂY', '', '', '', 0),
(13, 'NCC A', '80830803', 'p5 tpvl', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_table`
--

CREATE TABLE IF NOT EXISTS `tbl_table` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iddomain` int(11) NOT NULL,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `iduser` int(11) DEFAULT NULL,
  `type` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `iddomain` (`iddomain`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=189 ;

--
-- Dumping data for table `tbl_table`
--

INSERT INTO `tbl_table` (`id`, `iddomain`, `name`, `iduser`, `type`) VALUES
(1, 1, '01', 1, '0'),
(2, 1, '02', 1, '0'),
(3, 1, '03', 1, '0'),
(4, 1, '04', 1, '0'),
(28, 1, '05', 1, '0'),
(29, 1, '06', 1, '0'),
(30, 1, '07', 1, '0'),
(31, 1, '08', 1, '0'),
(32, 1, '09', 1, '0'),
(33, 1, '10', 1, '0'),
(34, 1, '11', 1, '0'),
(35, 1, '12', 1, '0'),
(37, 1, '13', 1, '0'),
(38, 1, '14', 1, '0'),
(41, 1, '15', 1, '0'),
(133, 1, '16', 1, '0'),
(135, 1, '17', 1, '0'),
(136, 1, '18', 1, '0'),
(137, 1, '19', 1, '0'),
(138, 1, '20', 1, '0'),
(139, 1, '21', 1, '0'),
(140, 1, '22', 1, '0'),
(141, 1, '23', 1, '0'),
(142, 1, '24', 1, '0'),
(143, 1, '25', 1, '0'),
(144, 1, '26', 1, '0'),
(145, 1, '27', 1, '0'),
(146, 1, '28', 1, '0'),
(147, 1, '29', 1, '0'),
(148, 1, '30', 1, '0'),
(149, 1, '31', 1, '0'),
(150, 1, '32', 1, '0'),
(151, 1, '33', 1, '0'),
(152, 1, '34', 1, '0'),
(153, 1, '35', 1, '0'),
(154, 1, '36', 1, '0'),
(155, 1, '37', 1, '0'),
(156, 1, '38', 1, '0'),
(157, 1, '39', 1, '0'),
(158, 1, '40', 1, '0'),
(159, 1, '41', 1, '0'),
(160, 1, '42', 1, '0'),
(161, 1, '43', 1, '0'),
(162, 1, '44', 1, '0'),
(163, 1, '45', 1, '0'),
(164, 1, '46', 1, '0'),
(165, 1, '47', 1, '0'),
(166, 1, '48', 1, '0'),
(167, 1, '49', 1, '0'),
(168, 1, '50', 1, '0'),
(169, 1, '51', 1, '0'),
(170, 1, '52', 1, '0'),
(171, 1, '53', 1, '0'),
(172, 1, '54', 1, '0'),
(173, 1, '55', 1, '0'),
(174, 1, '56', 1, '0'),
(175, 1, '57', 1, '0'),
(176, 1, '58', 1, '0'),
(177, 1, '59', 1, '0'),
(178, 1, '60', 1, '0'),
(179, 1, '61', 1, '0'),
(180, 1, '62', 1, '0'),
(181, 1, '63', 1, '0'),
(182, 1, '64', 1, '0'),
(183, 1, '65', 1, '0'),
(184, 1, '66', 1, '0'),
(185, 7, 'Quý Khách 1', 1, '0'),
(186, 7, 'Quý Khách 2', 1, '0'),
(187, 7, 'Quý Khách 3', 1, '0'),
(188, 7, 'Quý Khách 4', 1, '0');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_table_log`
--

CREATE TABLE IF NOT EXISTS `tbl_table_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iduser` int(11) NOT NULL,
  `idtable` int(11) NOT NULL,
  `datetime` datetime NOT NULL,
  `note` varchar(250) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idtable` (`idtable`),
  KEY `iduser` (`iduser`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=516 ;

--
-- Dumping data for table `tbl_table_log`
--

INSERT INTO `tbl_table_log` (`id`, `iduser`, `idtable`, `datetime`, `note`) VALUES
(1, 1, 2, '2014-01-02 16:22:31', 'tính tiền 30.000'),
(2, 1, 1, '2014-01-02 22:40:59', 'Tạo mới giao dịch'),
(3, 1, 1, '2014-01-02 22:41:05', 'Cập nhật món Cafe Sữa nóng 0'),
(4, 1, 1, '2014-01-02 22:41:11', 'Cập nhật món Cafe Sữa nóng -1'),
(5, 1, 1, '2014-01-02 22:41:11', 'Cập nhật món Cafe Sữa nóng -2'),
(6, 1, 1, '2014-01-02 22:41:11', 'Cập nhật món Cafe Sữa nóng -3'),
(7, 1, 1, '2014-01-02 22:41:11', 'Cập nhật món Cafe Sữa nóng -4'),
(8, 1, 1, '2014-01-02 22:41:12', 'Cập nhật món Cafe Sữa nóng -5'),
(9, 1, 32, '2014-01-02 22:41:56', 'Tạo mới giao dịch'),
(10, 1, 32, '2014-01-02 22:42:07', 'Cập nhật món Cafe đá 2'),
(11, 1, 32, '2014-01-02 22:42:10', 'Cập nhật món Cafe đá 1'),
(12, 1, 49, '2014-01-02 22:43:39', 'Tạo mới giao dịch'),
(13, 1, 14, '2014-01-03 07:07:18', 'tính tiền 21.000'),
(14, 1, 32, '2014-01-03 11:21:18', 'Tạo mới giao dịch'),
(15, 1, 32, '2014-01-03 11:21:24', 'Cập nhật món Cafe đá 2'),
(16, 1, 32, '2014-01-03 11:21:28', 'Cập nhật món Cafe đá 1'),
(17, 1, 29, '2014-01-03 11:24:27', 'Tạo mới giao dịch'),
(18, 1, 29, '2014-01-03 11:24:33', 'Cập nhật món Cacao nóng 0'),
(19, 1, 29, '2014-01-03 11:24:37', 'Cập nhật món Cacao nóng -1'),
(20, 1, 29, '2014-01-03 11:24:38', 'Cập nhật món Cacao nóng -2'),
(21, 1, 29, '2014-01-03 11:24:41', 'Cập nhật món Cacao nóng -1'),
(22, 1, 29, '2014-01-03 11:24:41', 'Cập nhật món Cacao nóng 0'),
(23, 1, 29, '2014-01-03 11:24:42', 'Cập nhật món Cacao nóng 1'),
(24, 1, 1, '2014-01-03 11:26:52', 'Tạo mới giao dịch'),
(25, 1, 1, '2014-01-03 11:26:54', 'Cập nhật món Cafe Sữa đá 2'),
(26, 1, 14, '2014-01-03 11:28:43', 'Tạo mới giao dịch'),
(27, 1, 14, '2014-01-03 11:29:22', 'Cập nhật món Cafe đá 2'),
(28, 1, 1, '2014-01-03 12:08:47', 'Tạo mới giao dịch'),
(29, 1, 1, '2014-01-03 12:10:23', 'Tạo mới giao dịch'),
(30, 1, 1, '2014-01-03 12:33:04', 'Tạo mới giao dịch'),
(31, 1, 2, '2014-01-03 12:43:32', 'Tạo mới giao dịch'),
(32, 1, 1, '2014-01-03 12:44:57', 'Tạo mới giao dịch'),
(33, 1, 1, '2014-01-03 12:47:02', 'Tạo mới giao dịch'),
(34, 1, 28, '2014-01-03 13:06:54', 'Tạo mới giao dịch'),
(35, 1, 28, '2014-01-03 13:06:56', 'Cập nhật món Cafe đá 2'),
(36, 1, 4, '2014-01-03 13:12:52', 'Tạo mới giao dịch'),
(37, 1, 4, '2014-01-03 13:12:57', 'Cập nhật món Cafe đá 2'),
(38, 1, 4, '2014-01-03 13:28:17', 'Cập nhật món Jet 0'),
(39, 1, 4, '2014-01-03 13:28:21', 'Cập nhật món Jet -1'),
(40, 1, 4, '2014-01-03 13:28:24', 'Cập nhật món Jet 0'),
(41, 1, 4, '2014-01-03 13:28:27', 'Cập nhật món Jet 1'),
(42, 1, 4, '2014-01-03 13:28:45', 'Cập nhật món Jet 0'),
(43, 1, 4, '2014-01-03 13:29:49', 'Cập nhật món Jet 1'),
(44, 1, 1, '2014-01-03 13:59:11', 'Tạo mới giao dịch'),
(45, 1, 99, '2014-01-03 15:43:24', 'Tạo mới giao dịch'),
(46, 1, 2, '2014-01-03 15:53:43', 'tính tiền 33.000'),
(47, 1, 3, '2014-01-03 15:54:22', 'Tạo mới giao dịch'),
(48, 1, 1, '2014-01-03 16:00:44', 'Tạo mới giao dịch'),
(49, 1, 63, '2014-01-03 17:55:15', 'Tạo mới giao dịch'),
(50, 1, 60, '2014-01-03 17:55:25', 'Tạo mới giao dịch'),
(51, 4, 63, '2014-01-03 18:20:48', 'Tạo mới giao dịch'),
(52, 4, 63, '2014-01-03 18:20:50', 'Cập nhật món Cafe đá 2'),
(53, 4, 60, '2014-01-03 18:21:08', 'Tạo mới giao dịch'),
(54, 4, 1, '2014-01-03 18:21:46', 'Tạo mới giao dịch'),
(55, 4, 1, '2014-01-03 18:21:47', 'Cập nhật món Yaourt bạc hà 2'),
(56, 4, 1, '2014-01-03 18:22:11', 'Tạo mới giao dịch'),
(57, 4, 45, '2014-01-03 18:31:24', 'Tạo mới giao dịch'),
(58, 4, 15, '2014-01-03 18:47:02', 'Tạo mới giao dịch'),
(59, 4, 15, '2014-01-03 18:47:04', 'Cập nhật món Cafe đá 2'),
(60, 4, 15, '2014-01-03 18:47:07', 'Cập nhật món Cafe đá 3'),
(61, 4, 15, '2014-01-03 18:47:17', 'Cập nhật món Cafe đá 2'),
(62, 4, 1, '2014-01-03 19:05:09', 'Tạo mới giao dịch'),
(63, 4, 26, '2014-01-03 19:19:19', 'Tạo mới giao dịch'),
(64, 4, 27, '2014-01-03 19:20:38', 'Tạo mới giao dịch'),
(65, 4, 47, '2014-01-03 19:37:16', 'Tạo mới giao dịch'),
(66, 4, 47, '2014-01-03 19:37:17', 'Cập nhật món Coca cola 2'),
(67, 4, 44, '2014-01-03 19:38:53', 'Tạo mới giao dịch'),
(68, 4, 44, '2014-01-03 19:38:54', 'Cập nhật món Cafe đá 2'),
(69, 4, 62, '2014-01-03 19:43:41', 'Tạo mới giao dịch'),
(70, 4, 62, '2014-01-03 19:43:42', 'Cập nhật món Cafe đá 2'),
(71, 4, 62, '2014-01-03 19:43:46', 'Cập nhật món Cafe đá 3'),
(72, 4, 62, '2014-01-03 19:43:47', 'Cập nhật món Cafe đá 4'),
(73, 4, 133, '2014-01-03 19:44:36', 'Tạo mới giao dịch'),
(74, 4, 15, '2014-01-03 19:46:16', 'Tạo mới giao dịch'),
(75, 4, 15, '2014-01-03 19:46:17', 'Cập nhật món Cafe Sữa đá 2'),
(76, 4, 30, '2014-01-03 19:51:26', 'Tạo mới giao dịch'),
(77, 4, 134, '2014-01-03 19:53:02', 'Tạo mới giao dịch'),
(78, 4, 134, '2014-01-03 19:53:03', 'Cập nhật món Cafe đá 2'),
(79, 4, 46, '2014-01-03 19:55:30', 'Tạo mới giao dịch'),
(80, 4, 135, '2014-01-03 19:58:15', 'Tạo mới giao dịch'),
(81, 4, 135, '2014-01-03 19:58:16', 'Cập nhật món Cafe đá 2'),
(82, 4, 135, '2014-01-03 19:58:28', 'Cập nhật món Rivive 2'),
(83, 4, 136, '2014-01-03 20:04:06', 'Tạo mới giao dịch'),
(84, 4, 136, '2014-01-03 20:04:28', 'Cập nhật món Cafe Sữa đá 2'),
(85, 4, 136, '2014-01-03 20:04:38', 'Cập nhật món Cafe Sữa đá 3'),
(86, 4, 136, '2014-01-03 20:04:39', 'Cập nhật món Cafe Sữa đá 4'),
(87, 4, 2, '2014-01-03 20:07:57', 'Tạo mới giao dịch'),
(88, 4, 2, '2014-01-03 20:07:58', 'Cập nhật món Trà Ô Long 2'),
(89, 4, 135, '2014-01-03 20:18:59', 'Cập nhật món Rivive 3'),
(90, 4, 4, '2014-01-03 20:38:33', 'Tạo mới giao dịch'),
(91, 1, 17, '2014-01-03 21:25:08', 'tính tiền 30.000'),
(92, 4, 1, '2014-01-03 21:37:35', 'Tạo mới giao dịch'),
(93, 1, 15, '2014-01-03 22:06:09', 'tính tiền 40.000'),
(94, 4, 123, '2014-01-03 22:06:53', 'Tạo mới giao dịch'),
(95, 1, 4, '2014-01-03 22:13:46', 'tính tiền 23.000'),
(96, 1, 135, '2014-01-03 22:44:40', 'tính tiền 62.000'),
(97, 4, 103, '2014-01-04 14:39:19', 'Tạo mới giao dịch'),
(98, 4, 103, '2014-01-04 14:39:35', 'Cập nhật món Cafe Sữa đá 2'),
(99, 1, 103, '2014-01-04 14:52:50', 'tính tiền 52.000'),
(100, 4, 32, '2014-01-04 19:10:18', 'Tạo mới giao dịch'),
(101, 4, 1, '2014-01-04 19:22:47', 'Tạo mới giao dịch'),
(102, 4, 1, '2014-01-04 20:32:41', 'Tạo mới giao dịch'),
(103, 4, 1, '2014-01-04 20:32:44', 'Cập nhật món Cacao đá 2'),
(104, 4, 1, '2014-01-04 20:32:45', 'Cập nhật món Cacao đá 3'),
(105, 4, 32, '2014-01-04 20:37:57', 'Tạo mới giao dịch'),
(106, 4, 1, '2014-01-04 20:38:26', 'Tạo mới giao dịch'),
(107, 4, 41, '2014-01-04 20:38:41', 'Tạo mới giao dịch'),
(108, 4, 2, '2014-01-04 20:39:00', 'Tạo mới giao dịch'),
(109, 1, 32, '2014-01-04 20:48:43', 'tính tiền 18.000'),
(110, 4, 2, '2014-01-04 20:52:27', 'Cập nhật món Đá me 2'),
(111, 1, 41, '2014-01-04 21:11:04', 'tính tiền 8.000'),
(112, 4, 30, '2014-01-04 21:14:44', 'Tạo mới giao dịch'),
(113, 4, 30, '2014-01-04 21:14:45', 'Cập nhật món Coca cola 2'),
(114, 4, 38, '2014-01-05 07:48:36', 'Tạo mới giao dịch'),
(115, 4, 38, '2014-01-05 07:49:42', 'Cập nhật món Hero 1/2 gói 2'),
(116, 4, 38, '2014-01-05 07:49:45', 'Cập nhật món Hero 1/2 gói 3'),
(117, 4, 38, '2014-01-05 07:49:48', 'Cập nhật món Hero 1/2 gói 4'),
(118, 4, 38, '2014-01-05 07:50:52', 'Cập nhật món Cafe đá 2'),
(119, 4, 38, '2014-01-05 07:50:54', 'Cập nhật món Cafe đá 3'),
(120, 4, 133, '2014-01-05 07:55:27', 'Tạo mới giao dịch'),
(121, 4, 38, '2014-01-05 07:56:11', 'Cập nhật món Cafe đá 4'),
(122, 4, 178, '2014-01-05 08:01:32', 'Tạo mới giao dịch'),
(123, 1, 133, '2014-01-05 08:06:14', 'tính tiền 18.000'),
(124, 4, 178, '2014-01-05 08:33:26', 'Cập nhật món Cafe đá 2'),
(125, 4, 178, '2014-01-05 08:33:35', 'Cập nhật món Cafe Sữa đá 2'),
(126, 4, 178, '2014-01-05 08:33:36', 'Cập nhật món Cafe Sữa đá 3'),
(127, 4, 34, '2014-01-05 08:38:02', 'Tạo mới giao dịch'),
(128, 1, 38, '2014-01-05 08:43:36', 'tính tiền 54.000'),
(129, 4, 34, '2014-01-05 08:43:44', 'Cập nhật món Cafe đá 2'),
(130, 4, 31, '2014-01-05 08:43:57', 'Tạo mới giao dịch'),
(131, 4, 32, '2014-01-05 09:01:38', 'Tạo mới giao dịch'),
(132, 1, 178, '2014-01-05 09:15:48', 'tính tiền 58.000'),
(133, 1, 34, '2014-01-05 09:16:50', 'tính tiền 24.000'),
(134, 4, 32, '2014-01-05 09:21:09', 'Cập nhật món Cafe đá 2'),
(135, 4, 143, '2014-01-05 09:21:31', 'Tạo mới giao dịch'),
(136, 4, 30, '2014-01-05 09:30:36', 'Tạo mới giao dịch'),
(137, 4, 30, '2014-01-05 09:30:38', 'Cập nhật món Sting dâu 2'),
(138, 4, 38, '2014-01-05 09:31:51', 'Tạo mới giao dịch'),
(139, 1, 31, '2014-01-05 09:40:09', 'tính tiền 8.000'),
(140, 1, 30, '2014-01-05 09:55:05', 'tính tiền 36.000'),
(141, 1, 32, '2014-01-05 09:56:56', 'tính tiền 16.000'),
(142, 1, 38, '2014-01-05 10:07:52', 'tính tiền 8.000'),
(143, 1, 143, '2014-01-05 10:30:22', 'tính tiền 12.000'),
(144, 4, 156, '2014-01-05 12:44:14', 'Tạo mới giao dịch'),
(145, 4, 150, '2014-01-05 12:47:16', 'Tạo mới giao dịch'),
(146, 4, 150, '2014-01-05 12:47:43', 'Cập nhật món Cafe đá 2'),
(147, 4, 156, '2014-01-05 12:49:16', 'Cập nhật món Cafe đá 2'),
(148, 4, 150, '2014-01-05 12:54:29', 'Cập nhật món Lipton đá 2'),
(149, 1, 150, '2014-01-05 12:56:28', 'tính tiền 52.000'),
(150, 4, 3, '2014-01-05 13:01:17', 'Tạo mới giao dịch'),
(151, 4, 144, '2014-01-05 13:12:43', 'Tạo mới giao dịch'),
(152, 4, 31, '2014-01-05 13:21:42', 'Tạo mới giao dịch'),
(153, 4, 144, '2014-01-05 13:48:36', 'Cập nhật món Sting dâu 2'),
(154, 4, 33, '2014-01-05 13:54:04', 'Tạo mới giao dịch'),
(155, 4, 33, '2014-01-05 13:54:08', 'Cập nhật món Lipton đá 2'),
(156, 4, 149, '2014-01-05 13:55:18', 'Tạo mới giao dịch'),
(157, 4, 149, '2014-01-05 14:10:42', 'Cập nhật món Cafe đá 2'),
(158, 4, 31, '2014-01-05 14:30:56', 'Cập nhật món Mèo tép 2'),
(159, 4, 143, '2014-01-05 14:34:10', 'Tạo mới giao dịch'),
(160, 4, 143, '2014-01-05 14:34:11', 'Cập nhật món Trà Ô Long 2'),
(161, 4, 156, '2014-01-05 14:45:11', 'Cập nhật món Cafe đá 3'),
(162, 4, 31, '2014-01-05 15:34:19', 'Cập nhật món Mèo tép 3'),
(163, 1, 31, '2014-01-05 17:12:12', 'tính tiền 41.000'),
(164, 1, 33, '2014-01-05 17:12:19', 'tính tiền 16.000'),
(165, 1, 149, '2014-01-05 17:12:30', 'tính tiền 23.000'),
(166, 1, 156, '2014-01-05 17:12:41', 'tính tiền 68.000'),
(167, 4, 136, '2014-01-05 17:13:19', 'Tạo mới giao dịch'),
(168, 4, 149, '2014-01-05 17:15:52', 'Tạo mới giao dịch'),
(169, 4, 149, '2014-01-05 17:15:53', 'Cập nhật món Cafe đá 2'),
(170, 4, 137, '2014-01-05 17:54:35', 'Tạo mới giao dịch'),
(171, 4, 1, '2014-01-05 18:04:29', 'Tạo mới giao dịch'),
(172, 1, 136, '2014-01-05 18:08:15', 'tính tiền 32.000'),
(173, 4, 178, '2014-01-05 18:10:39', 'Tạo mới giao dịch'),
(174, 4, 133, '2014-01-05 18:11:18', 'Tạo mới giao dịch'),
(175, 1, 178, '2014-01-05 18:19:19', 'tính tiền 22.000'),
(176, 1, 137, '2014-01-05 18:36:42', 'tính tiền 16.000'),
(177, 4, 2, '2014-01-05 19:37:40', 'Tạo mới giao dịch'),
(178, 4, 1, '2014-01-05 19:38:07', 'Tạo mới giao dịch'),
(179, 1, 133, '2014-01-05 19:38:51', 'tính tiền 18.000'),
(180, 4, 140, '2014-01-05 19:39:17', 'Tạo mới giao dịch'),
(181, 4, 140, '2014-01-05 19:39:26', 'Cập nhật món Lipton đá 2'),
(182, 4, 140, '2014-01-05 19:39:39', 'Cập nhật món Lipton đá 1'),
(183, 4, 177, '2014-01-05 19:41:06', 'Tạo mới giao dịch'),
(184, 4, 33, '2014-01-05 19:41:41', 'Tạo mới giao dịch'),
(185, 4, 33, '2014-01-05 19:42:42', 'Cập nhật món Sting dâu 2'),
(186, 4, 31, '2014-01-05 19:49:13', 'Tạo mới giao dịch'),
(187, 4, 1, '2014-01-05 19:51:00', 'Cập nhật món Cafe đá 2'),
(188, 4, 1, '2014-01-05 19:51:01', 'Cập nhật món Cafe đá 3'),
(189, 4, 1, '2014-01-05 19:51:09', 'Cập nhật món Cafe đá 2'),
(190, 4, 1, '2014-01-05 19:51:10', 'Cập nhật món Cafe đá 1'),
(191, 1, 1, '2014-01-05 19:51:28', 'tính tiền 8.000'),
(192, 4, 1, '2014-01-05 19:51:30', 'Tạo mới giao dịch'),
(193, 4, 1, '2014-01-05 19:51:31', 'Cập nhật món Cafe đá 2'),
(194, 4, 31, '2014-01-05 19:52:44', 'Cập nhật món Cafe đá 2'),
(195, 4, 178, '2014-01-05 19:54:24', 'Tạo mới giao dịch'),
(196, 4, 33, '2014-01-05 19:56:20', 'Cập nhật món Cafe đá 2'),
(197, 4, 29, '2014-01-05 20:02:44', 'Tạo mới giao dịch'),
(198, 1, 1, '2014-01-05 20:07:13', 'tính tiền 16.000'),
(199, 4, 137, '2014-01-05 20:07:41', 'Tạo mới giao dịch'),
(200, 1, 177, '2014-01-05 20:08:23', 'tính tiền 16.000'),
(201, 4, 133, '2014-01-05 20:11:33', 'Tạo mới giao dịch'),
(202, 4, 133, '2014-01-05 20:11:34', 'Cập nhật món Lipton đá 2'),
(203, 4, 133, '2014-01-05 20:11:34', 'Cập nhật món Lipton đá 3'),
(204, 4, 133, '2014-01-05 20:11:59', 'Cập nhật món Đá me sữa 2'),
(205, 4, 133, '2014-01-05 20:11:59', 'Cập nhật món Đá me sữa 3'),
(206, 4, 156, '2014-01-05 20:12:25', 'Tạo mới giao dịch'),
(207, 4, 156, '2014-01-05 20:12:25', 'Cập nhật món Cafe đá 2'),
(208, 4, 188, '2014-01-05 20:12:51', 'Tạo mới giao dịch'),
(209, 4, 1, '2014-01-05 20:19:50', 'Tạo mới giao dịch'),
(210, 4, 1, '2014-01-05 20:19:56', 'Cập nhật món Cafe Sữa đá 2'),
(211, 1, 1, '2014-01-05 20:20:45', 'tính tiền 28.000'),
(212, 4, 33, '2014-01-05 20:27:16', 'Cập nhật món Đá me 2'),
(213, 4, 143, '2014-01-05 20:27:37', 'Tạo mới giao dịch'),
(214, 1, 133, '2014-01-05 20:31:14', 'tính tiền 84.000'),
(215, 1, 156, '2014-01-05 20:31:26', 'tính tiền 26.000'),
(216, 1, 188, '2014-01-05 20:53:59', 'tính tiền 0'),
(217, 1, 31, '2014-01-05 21:07:15', 'tính tiền 16.000'),
(218, 4, 178, '2014-01-05 21:07:46', 'Cập nhật món Jet 3 điếu 2'),
(219, 1, 137, '2014-01-05 21:08:43', 'tính tiền 39.000'),
(220, 1, 140, '2014-01-05 21:13:15', 'tính tiền 20.000'),
(221, 4, 178, '2014-01-05 21:19:21', 'Cập nhật món Sting dâu 2'),
(222, 4, 178, '2014-01-05 21:19:36', 'Cập nhật món Sting dâu 3'),
(223, 4, 178, '2014-01-05 21:19:48', 'Cập nhật món Sting dâu 2'),
(224, 4, 178, '2014-01-05 21:19:57', 'Cập nhật món Sting dâu 1'),
(225, 4, 178, '2014-01-05 21:20:24', 'Cập nhật món Sting dâu 2'),
(226, 4, 29, '2014-01-05 21:21:37', 'Cập nhật món Cacao đá 0'),
(227, 4, 29, '2014-01-05 21:21:45', 'Cập nhật món Cafe đá 2'),
(228, 4, 29, '2014-01-05 21:22:09', 'Cập nhật món Cafe đá 3'),
(229, 4, 29, '2014-01-05 21:22:36', 'Cập nhật món Lipton đá 2'),
(230, 4, 1, '2014-01-05 21:25:27', 'Tạo mới giao dịch'),
(231, 4, 30, '2014-01-05 21:25:55', 'Tạo mới giao dịch'),
(232, 4, 31, '2014-01-05 21:27:55', 'Tạo mới giao dịch'),
(233, 1, 31, '2014-01-05 21:28:28', 'tính tiền 0'),
(234, 4, 1, '2014-01-05 21:28:38', 'Tạo mới giao dịch'),
(235, 1, 1, '2014-01-05 21:28:46', 'tính tiền 0'),
(236, 1, 143, '2014-01-05 21:31:40', 'tính tiền 28.000'),
(237, 4, 38, '2014-01-05 21:32:49', 'Tạo mới giao dịch'),
(238, 4, 178, '2014-01-05 21:37:07', 'Cập nhật món Cafe Sữa đá 2'),
(239, 1, 29, '2014-01-05 21:46:24', 'tính tiền 58.000'),
(240, 1, 33, '2014-01-05 21:56:04', 'tính tiền 109.000'),
(241, 1, 38, '2014-01-05 21:57:32', 'tính tiền 13.000'),
(242, 4, 162, '2014-01-05 22:17:55', 'Tạo mới giao dịch'),
(243, 1, 178, '2014-01-05 22:20:47', 'tính tiền 68.000'),
(244, 4, 1, '2014-01-05 22:41:52', 'Tạo mới giao dịch'),
(245, 1, 1, '2014-01-05 22:42:32', 'tính tiền 0'),
(246, 1, 162, '2014-01-05 23:04:28', 'tính tiền 20.000'),
(247, 1, 2, '2014-01-05 23:15:45', 'tính tiền 8.000'),
(248, 4, 162, '2014-01-05 23:50:52', 'Tạo mới giao dịch'),
(249, 1, 162, '2014-01-05 23:51:05', 'tính tiền 0'),
(250, 1, 149, '2014-01-05 23:51:09', 'tính tiền 19.000'),
(251, 4, 28, '2014-01-06 06:42:32', 'Tạo mới giao dịch'),
(252, 1, 28, '2014-01-06 06:44:58', 'tính tiền 8.000'),
(253, 4, 28, '2014-01-06 06:46:35', 'Tạo mới giao dịch'),
(254, 1, 28, '2014-01-06 07:12:21', 'tính tiền 8.000'),
(255, 4, 38, '2014-01-06 07:12:45', 'Tạo mới giao dịch'),
(256, 1, 38, '2014-01-06 07:13:04', 'tính tiền 8.000'),
(257, 4, 143, '2014-01-06 07:13:45', 'Tạo mới giao dịch'),
(258, 4, 143, '2014-01-06 07:21:00', 'Cập nhật món Cafe đá 2'),
(259, 1, 143, '2014-01-06 07:22:14', 'tính tiền 24.000'),
(260, 4, 41, '2014-01-06 07:22:28', 'Tạo mới giao dịch'),
(261, 4, 38, '2014-01-06 07:30:11', 'Tạo mới giao dịch'),
(262, 1, 41, '2014-01-06 07:34:45', 'tính tiền 25.000'),
(263, 4, 150, '2014-01-06 07:36:57', 'Tạo mới giao dịch'),
(264, 4, 145, '2014-01-06 07:43:29', 'Tạo mới giao dịch'),
(265, 4, 145, '2014-01-06 07:43:33', 'Cập nhật món Cafe đá 2'),
(266, 4, 145, '2014-01-06 07:43:44', 'Cập nhật món Cacao sữa đá 2'),
(267, 4, 145, '2014-01-06 07:43:56', 'Cập nhật món Cafe Sữa đá 2'),
(268, 4, 145, '2014-01-06 07:43:59', 'Cập nhật món Cafe Sữa đá 3'),
(269, 4, 41, '2014-01-06 07:49:04', 'Tạo mới giao dịch'),
(270, 4, 135, '2014-01-06 07:53:26', 'Tạo mới giao dịch'),
(271, 4, 41, '2014-01-06 08:00:06', 'Cập nhật món Cafe đá 2'),
(272, 4, 34, '2014-01-06 08:17:06', 'Tạo mới giao dịch'),
(273, 4, 143, '2014-01-06 08:24:38', 'Tạo mới giao dịch'),
(274, 4, 34, '2014-01-06 08:27:56', 'Cập nhật món Cafe đá 2'),
(275, 4, 34, '2014-01-06 08:35:46', 'Cập nhật món Cafe đá 3'),
(276, 4, 41, '2014-01-06 08:37:33', 'Cập nhật món Cafe đá 3'),
(277, 1, 145, '2014-01-06 08:41:19', 'tính tiền 53.000'),
(278, 1, 150, '2014-01-06 08:50:54', 'tính tiền 20.000'),
(279, 1, 135, '2014-01-06 08:56:12', 'tính tiền 16.000'),
(280, 1, 34, '2014-01-06 09:00:46', 'tính tiền 65.000'),
(281, 4, 150, '2014-01-06 09:11:53', 'Tạo mới giao dịch'),
(282, 4, 31, '2014-01-06 09:15:09', 'Tạo mới giao dịch'),
(283, 4, 1, '2014-01-06 09:15:48', 'Tạo mới giao dịch'),
(284, 1, 1, '2014-01-06 09:18:09', 'tính tiền 8.000'),
(285, 4, 143, '2014-01-06 09:18:43', 'Cập nhật món Sting dâu 2'),
(286, 4, 38, '2014-01-06 09:21:48', 'Cập nhật món Cafe đá 2'),
(287, 4, 38, '2014-01-06 09:21:54', 'Cập nhật món Cafe đá 3'),
(288, 4, 38, '2014-01-06 09:22:02', 'Cập nhật món Cafe đá 2'),
(289, 4, 145, '2014-01-06 09:24:52', 'Tạo mới giao dịch'),
(290, 4, 145, '2014-01-06 09:24:54', 'Cập nhật món Cafe Sữa đá 2'),
(291, 1, 41, '2014-01-06 09:30:12', 'tính tiền 32.000'),
(292, 4, 151, '2014-01-06 09:34:02', 'Tạo mới giao dịch'),
(293, 4, 151, '2014-01-06 09:34:03', 'Cập nhật món Cafe đá 2'),
(294, 4, 151, '2014-01-06 09:34:05', 'Cập nhật món Cafe đá 3'),
(295, 4, 151, '2014-01-06 09:34:06', 'Cập nhật món Cafe đá 4'),
(296, 4, 32, '2014-01-06 09:36:16', 'Tạo mới giao dịch'),
(297, 4, 28, '2014-01-06 09:43:56', 'Tạo mới giao dịch'),
(298, 4, 28, '2014-01-06 09:43:57', 'Cập nhật món Cafe đá 2'),
(299, 4, 37, '2014-01-06 09:45:45', 'Tạo mới giao dịch'),
(300, 4, 37, '2014-01-06 09:45:46', 'Cập nhật món Cafe đá 2'),
(301, 4, 37, '2014-01-06 09:45:48', 'Cập nhật món Cafe đá 3'),
(302, 4, 151, '2014-01-06 09:46:25', 'Cập nhật món Cafe đá 5'),
(303, 4, 151, '2014-01-06 09:46:29', 'Cập nhật món Cafe đá 4'),
(304, 4, 151, '2014-01-06 09:47:00', 'Cập nhật món Jet 2 điếu 2'),
(305, 4, 151, '2014-01-06 09:47:25', 'Cập nhật món Jet 2 điếu 1'),
(306, 1, 151, '2014-01-06 09:48:02', 'tính tiền 34.000'),
(307, 1, 32, '2014-01-06 09:58:10', 'tính tiền 8.000'),
(308, 4, 135, '2014-01-06 10:05:01', 'Tạo mới giao dịch'),
(309, 4, 1, '2014-01-06 10:30:44', 'Tạo mới giao dịch'),
(310, 4, 1, '2014-01-06 10:30:48', 'Cập nhật món Cafe đá 2'),
(311, 4, 1, '2014-01-06 10:30:59', 'Cập nhật món Cafe đá 3'),
(312, 1, 143, '2014-01-06 10:32:15', 'tính tiền 32.000'),
(313, 4, 166, '2014-01-06 10:37:43', 'Tạo mới giao dịch'),
(314, 1, 150, '2014-01-06 10:39:51', 'tính tiền 55.000'),
(315, 1, 145, '2014-01-06 10:40:01', 'tính tiền 34.000'),
(316, 4, 1, '2014-01-06 10:45:46', 'Cập nhật món Yaourt cafe đá 2'),
(317, 4, 135, '2014-01-06 10:48:22', 'Cập nhật món Cafe đá 2'),
(318, 4, 149, '2014-01-06 10:48:59', 'Tạo mới giao dịch'),
(319, 4, 166, '2014-01-06 10:49:13', 'Cập nhật món Cafe đá 2'),
(320, 4, 38, '2014-01-06 10:54:54', 'Cập nhật món Jet 5 điếu 2'),
(321, 4, 38, '2014-01-06 10:55:02', 'Cập nhật món Jet 5 điếu 3'),
(322, 4, 38, '2014-01-06 10:55:19', 'Cập nhật món Jet 5 điếu 2'),
(323, 4, 38, '2014-01-06 10:55:25', 'Cập nhật món Jet 5 điếu 1'),
(324, 4, 38, '2014-01-06 10:55:53', 'Cập nhật món Jet 5 điếu 2'),
(325, 1, 149, '2014-01-06 10:59:06', 'tính tiền 20.000'),
(326, 1, 1, '2014-01-06 11:02:23', 'tính tiền 131.000'),
(327, 1, 38, '2014-01-06 11:06:41', 'tính tiền 34.000'),
(328, 4, 150, '2014-01-06 12:02:28', 'Tạo mới giao dịch'),
(329, 4, 150, '2014-01-06 12:02:32', 'Cập nhật món Cafe đá 2'),
(330, 1, 28, '2014-01-06 12:06:27', 'tính tiền 16.000'),
(331, 4, 166, '2014-01-06 12:16:24', 'Cập nhật món Cafe đá 3'),
(332, 4, 166, '2014-01-06 12:16:26', 'Cập nhật món Cafe đá 4'),
(333, 1, 150, '2014-01-06 13:08:36', 'tính tiền 19.000'),
(334, 1, 135, '2014-01-06 13:12:33', 'tính tiền 28.000'),
(335, 1, 166, '2014-01-06 13:29:22', 'tính tiền 41.000'),
(336, 4, 150, '2014-01-06 13:42:59', 'Tạo mới giao dịch'),
(337, 4, 168, '2014-01-06 14:10:20', 'Tạo mới giao dịch'),
(338, 1, 168, '2014-01-06 14:10:42', 'tính tiền 8.000'),
(339, 4, 144, '2014-01-06 14:33:42', 'Tạo mới giao dịch'),
(340, 4, 142, '2014-01-06 14:44:29', 'Tạo mới giao dịch'),
(341, 4, 142, '2014-01-06 14:44:42', 'Cập nhật món Lipton đá 2'),
(342, 4, 142, '2014-01-06 14:45:14', 'Cập nhật món Cafe Sữa đá 2'),
(343, 4, 35, '2014-01-06 14:46:45', 'Tạo mới giao dịch'),
(344, 1, 142, '2014-01-06 14:52:41', 'tính tiền 70.000'),
(345, 4, 178, '2014-01-06 14:55:49', 'Tạo mới giao dịch'),
(346, 4, 1, '2014-01-06 14:56:43', 'Tạo mới giao dịch'),
(347, 4, 141, '2014-01-06 14:59:35', 'Tạo mới giao dịch'),
(348, 4, 141, '2014-01-06 15:00:10', 'Cập nhật món Cafe đá 2'),
(349, 4, 142, '2014-01-06 15:00:33', 'Tạo mới giao dịch'),
(350, 4, 142, '2014-01-06 15:05:07', 'Cập nhật món Lipton đá 2'),
(351, 4, 142, '2014-01-06 15:05:09', 'Cập nhật món Lipton đá 3'),
(352, 1, 142, '2014-01-06 15:08:03', 'tính tiền 8.000'),
(353, 4, 1, '2014-01-06 15:09:22', 'Cập nhật món Lipton đá 2'),
(354, 4, 1, '2014-01-06 15:09:24', 'Cập nhật món Lipton đá 3'),
(355, 4, 1, '2014-01-06 15:23:18', 'Cập nhật món Cafe Sữa đá 2'),
(356, 4, 1, '2014-01-06 15:24:08', 'Cập nhật món Cafe Sữa đá 3'),
(357, 4, 140, '2014-01-06 15:24:33', 'Tạo mới giao dịch'),
(358, 1, 141, '2014-01-06 15:26:09', 'tính tiền 16.000'),
(359, 1, 144, '2014-01-06 15:38:10', 'tính tiền 30.000'),
(360, 1, 178, '2014-01-06 15:38:49', 'tính tiền 20.000'),
(361, 4, 185, '2014-01-06 15:41:58', 'Tạo mới giao dịch'),
(362, 4, 185, '2014-01-06 15:42:03', 'Cập nhật món Cafe đá 2'),
(363, 4, 140, '2014-01-06 16:25:36', 'Cập nhật món Cafe đá 2'),
(364, 1, 140, '2014-01-06 16:26:06', 'tính tiền 30.000'),
(365, 1, 35, '2014-01-06 16:39:42', 'tính tiền 50.000'),
(366, 4, 32, '2014-01-06 16:46:31', 'Tạo mới giao dịch'),
(367, 4, 140, '2014-01-06 16:46:46', 'Tạo mới giao dịch'),
(368, 1, 32, '2014-01-06 17:26:35', 'tính tiền 8.000'),
(369, 4, 4, '2014-01-06 17:46:01', 'Tạo mới giao dịch'),
(370, 4, 32, '2014-01-06 17:47:03', 'Tạo mới giao dịch'),
(371, 4, 28, '2014-01-06 17:49:54', 'Tạo mới giao dịch'),
(372, 4, 136, '2014-01-06 18:03:00', 'Tạo mới giao dịch'),
(373, 4, 3, '2014-01-06 18:03:23', 'Tạo mới giao dịch'),
(374, 4, 1, '2014-01-06 18:05:40', 'Cập nhật món Cafe đá 2'),
(375, 4, 3, '2014-01-06 18:06:04', 'Tạo mới giao dịch'),
(376, 1, 1, '2014-01-06 18:06:30', 'tính tiền 99.000'),
(377, 4, 1, '2014-01-06 18:06:36', 'Tạo mới giao dịch'),
(378, 4, 1, '2014-01-06 18:06:37', 'Cập nhật món Cafe đá 2'),
(379, 4, 38, '2014-01-06 18:13:05', 'Tạo mới giao dịch'),
(380, 4, 38, '2014-01-06 18:13:06', 'Cập nhật món Lipton đá 2'),
(381, 4, 41, '2014-01-06 18:14:11', 'Tạo mới giao dịch'),
(382, 4, 41, '2014-01-06 18:14:17', 'Cập nhật món Cafe đá 2'),
(383, 4, 41, '2014-01-06 18:14:18', 'Cập nhật món Cafe đá 3'),
(384, 4, 31, '2014-01-06 18:15:26', 'Cập nhật món Cafe đá 2'),
(385, 4, 133, '2014-01-06 18:16:26', 'Tạo mới giao dịch'),
(386, 4, 133, '2014-01-06 18:16:27', 'Cập nhật món Cafe Sữa đá 2'),
(387, 4, 133, '2014-01-06 18:16:28', 'Cập nhật món Cafe Sữa đá 3'),
(388, 4, 4, '2014-01-06 18:18:05', 'Cập nhật món Sting dâu 2'),
(389, 4, 4, '2014-01-06 18:18:07', 'Cập nhật món Sting dâu 3'),
(390, 4, 143, '2014-01-06 18:18:23', 'Tạo mới giao dịch'),
(391, 4, 133, '2014-01-06 18:26:35', 'Cập nhật món Cafe Sữa đá 4'),
(392, 4, 33, '2014-01-06 18:26:45', 'Tạo mới giao dịch'),
(393, 4, 2, '2014-01-06 18:26:55', 'Tạo mới giao dịch'),
(394, 4, 30, '2014-01-06 18:27:10', 'Tạo mới giao dịch'),
(395, 4, 135, '2014-01-06 18:27:36', 'Tạo mới giao dịch'),
(396, 4, 32, '2014-01-06 18:28:50', 'Cập nhật món Cafe đá 2'),
(397, 1, 41, '2014-01-06 18:30:12', 'tính tiền 12.000'),
(398, 1, 135, '2014-01-06 18:31:01', 'tính tiền 16.000'),
(399, 4, 178, '2014-01-06 18:31:55', 'Tạo mới giao dịch'),
(400, 4, 135, '2014-01-06 18:32:39', 'Tạo mới giao dịch'),
(401, 1, 135, '2014-01-06 18:33:14', 'tính tiền 8.000'),
(402, 4, 31, '2014-01-06 18:33:18', 'Cập nhật món Cafe đá 3'),
(403, 4, 33, '2014-01-06 18:34:12', 'Cập nhật món Cafe đá 2'),
(404, 4, 32, '2014-01-06 18:34:49', 'Cập nhật món Cafe đá 3'),
(405, 4, 137, '2014-01-06 18:35:59', 'Tạo mới giao dịch'),
(406, 4, 137, '2014-01-06 18:36:00', 'Cập nhật món Cafe đá 2'),
(407, 4, 137, '2014-01-06 18:36:02', 'Cập nhật món Cafe đá 3'),
(408, 1, 136, '2014-01-06 18:37:11', 'tính tiền 23.000'),
(409, 4, 141, '2014-01-06 18:37:22', 'Tạo mới giao dịch'),
(410, 1, 178, '2014-01-06 18:38:43', 'tính tiền 26.000'),
(411, 4, 143, '2014-01-06 18:39:48', 'Cập nhật món Cafe Sữa đá 2'),
(412, 4, 32, '2014-01-06 18:40:28', 'Cập nhật món Cafe đá 4'),
(413, 4, 140, '2014-01-06 18:40:50', 'Tạo mới giao dịch'),
(414, 4, 34, '2014-01-06 18:42:12', 'Tạo mới giao dịch'),
(415, 4, 34, '2014-01-06 18:42:21', 'Cập nhật món Cafe đá 2'),
(416, 4, 2, '2014-01-06 18:44:03', 'Cập nhật món Cafe Sữa đá 2'),
(417, 4, 2, '2014-01-06 18:44:04', 'Cập nhật món Cafe Sữa đá 3'),
(418, 4, 2, '2014-01-06 18:44:18', 'Cập nhật món Cafe Sữa đá 4'),
(419, 4, 2, '2014-01-06 18:44:34', 'Cập nhật món Cafe Sữa đá 3'),
(420, 4, 2, '2014-01-06 18:44:36', 'Cập nhật món Cafe Sữa đá 2'),
(421, 4, 143, '2014-01-06 18:46:13', 'Tạo mới giao dịch'),
(422, 1, 2, '2014-01-06 18:48:55', 'tính tiền 67.000'),
(423, 4, 133, '2014-01-06 18:51:10', 'Cập nhật món Cafe Sữa đá 5'),
(424, 4, 143, '2014-01-06 18:52:19', 'Cập nhật món Cafe đá 2'),
(425, 1, 1, '2014-01-06 18:53:34', 'tính tiền 21.000'),
(426, 1, 4, '2014-01-06 18:54:39', 'tính tiền 64.000'),
(427, 4, 32, '2014-01-06 18:54:49', 'Cập nhật món Cafe đá 5'),
(428, 4, 32, '2014-01-06 18:55:09', 'Cập nhật món Đá me 2'),
(429, 4, 2, '2014-01-06 18:56:10', 'Tạo mới giao dịch'),
(430, 1, 2, '2014-01-06 18:57:02', 'tính tiền 12.000'),
(431, 4, 2, '2014-01-06 18:57:22', 'Tạo mới giao dịch'),
(432, 4, 142, '2014-01-06 18:57:37', 'Tạo mới giao dịch'),
(433, 1, 32, '2014-01-06 18:59:33', 'tính tiền 82.000'),
(434, 1, 30, '2014-01-06 19:02:02', 'tính tiền 16.000'),
(435, 1, 38, '2014-01-06 19:02:38', 'tính tiền 39.000'),
(436, 1, 142, '2014-01-06 19:02:49', 'tính tiền 38.000'),
(437, 1, 137, '2014-01-06 19:05:26', 'tính tiền 24.000'),
(438, 4, 136, '2014-01-06 19:05:58', 'Tạo mới giao dịch'),
(439, 4, 136, '2014-01-06 19:05:59', 'Cập nhật món Cafe đá 2'),
(440, 1, 136, '2014-01-06 19:06:25', 'tính tiền 24.000'),
(441, 1, 133, '2014-01-06 19:06:29', 'tính tiền 92.000'),
(442, 4, 136, '2014-01-06 19:09:00', 'Tạo mới giao dịch'),
(443, 1, 28, '2014-01-06 19:09:31', 'tính tiền 23.000'),
(444, 1, 136, '2014-01-06 19:09:39', 'tính tiền 20.000'),
(445, 1, 140, '2014-01-06 19:09:53', 'tính tiền 18.000'),
(446, 1, 143, '2014-01-06 19:10:49', 'tính tiền 24.000'),
(447, 1, 141, '2014-01-06 19:11:03', 'tính tiền 16.000'),
(448, 1, 2, '2014-01-06 19:12:17', 'tính tiền 0'),
(449, 1, 3, '2014-01-06 19:12:47', 'tính tiền 12.000'),
(450, 1, 150, '2014-01-06 19:13:40', 'tính tiền 8.000'),
(451, 1, 34, '2014-01-06 19:15:01', 'tính tiền 28.000'),
(452, 4, 38, '2014-01-06 19:15:08', 'Tạo mới giao dịch'),
(453, 1, 31, '2014-01-06 19:15:36', 'tính tiền 16.000'),
(454, 4, 144, '2014-01-06 19:15:59', 'Tạo mới giao dịch'),
(455, 4, 144, '2014-01-06 19:16:15', 'Cập nhật món Lipton đá 2'),
(456, 1, 144, '2014-01-06 19:19:40', 'tính tiền 24.000'),
(457, 1, 38, '2014-01-06 19:19:44', 'tính tiền 8.000'),
(458, 4, 149, '2014-01-06 19:20:24', 'Tạo mới giao dịch'),
(459, 4, 149, '2014-01-06 19:20:25', 'Cập nhật món Cafe Sữa đá 2'),
(460, 4, 149, '2014-01-06 19:20:26', 'Cập nhật món Cafe Sữa đá 3'),
(461, 4, 149, '2014-01-06 19:20:27', 'Cập nhật món Cafe Sữa đá 4'),
(462, 4, 149, '2014-01-06 19:20:28', 'Cập nhật món Cafe Sữa đá 5'),
(463, 4, 150, '2014-01-06 19:21:33', 'Tạo mới giao dịch'),
(464, 1, 149, '2014-01-06 19:23:10', 'tính tiền 60.000'),
(465, 1, 150, '2014-01-06 19:28:55', 'tính tiền 0'),
(466, 4, 31, '2014-01-06 19:32:43', 'Tạo mới giao dịch'),
(467, 4, 178, '2014-01-06 19:35:17', 'Tạo mới giao dịch'),
(468, 1, 178, '2014-01-06 19:37:48', 'tính tiền 3.000'),
(469, 4, 34, '2014-01-06 19:38:28', 'Tạo mới giao dịch'),
(470, 1, 34, '2014-01-06 19:48:28', 'tính tiền 8.000'),
(471, 4, 143, '2014-01-06 19:50:57', 'Tạo mới giao dịch'),
(472, 4, 151, '2014-01-06 19:51:44', 'Tạo mới giao dịch'),
(473, 4, 151, '2014-01-06 19:51:45', 'Cập nhật món Trà Ô Long 2'),
(474, 1, 143, '2014-01-06 19:54:14', 'tính tiền 10.000'),
(475, 4, 151, '2014-01-06 19:56:42', 'Cập nhật món Trà Ô Long 3'),
(476, 4, 144, '2014-01-06 20:02:53', 'Tạo mới giao dịch'),
(477, 1, 144, '2014-01-06 20:04:40', 'tính tiền 15.000'),
(478, 4, 2, '2014-01-06 20:04:51', 'Tạo mới giao dịch'),
(479, 1, 2, '2014-01-06 20:07:11', 'tính tiền 12.000'),
(480, 1, 33, '2014-01-06 20:12:08', 'tính tiền 16.000'),
(481, 4, 1, '2014-01-06 20:19:01', 'Tạo mới giao dịch'),
(482, 1, 1, '2014-01-06 20:19:10', 'tính tiền 0'),
(483, 4, 151, '2014-01-06 20:20:03', 'Cập nhật món Trà Ô Long 4'),
(484, 4, 1, '2014-01-06 20:21:08', 'Tạo mới giao dịch'),
(485, 1, 1, '2014-01-06 20:21:15', 'tính tiền 22.000'),
(486, 4, 1, '2014-01-06 20:26:10', 'Tạo mới giao dịch'),
(487, 4, 1, '2014-01-06 20:26:11', 'Cập nhật món Jet 4 điếu 2'),
(488, 1, 1, '2014-01-06 20:26:33', 'tính tiền 0'),
(489, 4, 41, '2014-01-06 20:35:40', 'Tạo mới giao dịch'),
(490, 4, 41, '2014-01-06 20:36:27', 'Cập nhật món Jet 1 điếu 2'),
(491, 4, 41, '2014-01-06 20:36:28', 'Cập nhật món Jet 1 điếu 3'),
(492, 4, 41, '2014-01-06 20:36:29', 'Cập nhật món Jet 1 điếu 4'),
(493, 4, 41, '2014-01-06 20:36:30', 'Cập nhật món Jet 1 điếu 5'),
(494, 4, 41, '2014-01-06 20:36:31', 'Cập nhật món Jet 1 điếu 6'),
(495, 4, 41, '2014-01-06 20:36:31', 'Cập nhật món Jet 1 điếu 7'),
(496, 4, 41, '2014-01-06 20:36:33', 'Cập nhật món Jet 1 điếu 6'),
(497, 4, 41, '2014-01-06 20:36:34', 'Cập nhật món Jet 1 điếu 5'),
(498, 4, 2, '2014-01-06 20:38:19', 'Tạo mới giao dịch'),
(499, 4, 151, '2014-01-06 20:46:12', 'Cập nhật món Trà Ô Long 2'),
(500, 4, 151, '2014-01-06 20:46:13', 'Cập nhật món Trà Ô Long 3'),
(501, 4, 151, '2014-01-06 20:46:14', 'Cập nhật món Trà Ô Long 4'),
(502, 4, 136, '2014-01-06 21:04:14', 'Tạo mới giao dịch'),
(503, 4, 178, '2014-01-06 21:04:36', 'Tạo mới giao dịch'),
(504, 4, 178, '2014-01-06 21:04:36', 'Cập nhật món Cafe đá 2'),
(505, 4, 178, '2014-01-06 21:04:56', 'Cập nhật món Jet 1 điếu 2'),
(506, 4, 178, '2014-01-06 21:04:57', 'Cập nhật món Jet 1 điếu 3'),
(507, 1, 2, '2014-01-06 21:46:04', 'tính tiền 8.000'),
(508, 4, 178, '2014-01-06 21:59:39', 'Cập nhật món Jet 1 điếu 4'),
(509, 4, 178, '2014-01-06 21:59:41', 'Cập nhật món Jet 1 điếu 5'),
(510, 4, 178, '2014-01-06 21:59:41', 'Cập nhật món Jet 1 điếu 6'),
(511, 1, 31, '2014-01-06 22:01:14', 'tính tiền 8.000'),
(512, 1, 151, '2014-01-06 22:03:22', 'tính tiền 48.000'),
(513, 1, 178, '2014-01-06 22:03:26', 'tính tiền 34.000'),
(514, 1, 136, '2014-01-06 22:05:08', 'tính tiền 8.000'),
(515, 1, 41, '2014-01-06 22:07:48', 'tính tiền 13.000');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_term`
--

CREATE TABLE IF NOT EXISTS `tbl_term` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=12 ;

--
-- Dumping data for table `tbl_term`
--

INSERT INTO `tbl_term` (`id`, `name`, `type`) VALUES
(1, 'Tiền Điện', 0),
(2, 'Tiền Nước', 0),
(3, 'Thuế', 0),
(10, 'Tiền Ăn Nhân Viên', 0),
(11, 'CP Khác', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_term_collect`
--

CREATE TABLE IF NOT EXISTS `tbl_term_collect` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Dumping data for table `tbl_term_collect`
--

INSERT INTO `tbl_term_collect` (`id`, `name`) VALUES
(2, 'Phụ Phẩm'),
(3, 'Đặc Biệt');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tracking`
--

CREATE TABLE IF NOT EXISTS `tbl_tracking` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_start` date NOT NULL,
  `date_end` date NOT NULL,
  `paid_general` int(11) NOT NULL,
  `paid_pay_roll` int(11) NOT NULL,
  `paid_import` int(11) NOT NULL,
  `collect_general` int(11) NOT NULL,
  `collect_customer` int(11) NOT NULL,
  `collect_selling_debt` int(11) NOT NULL,
  `collect_selling_nodebt` int(11) NOT NULL,
  `estate_rate` int(11) NOT NULL,
  `store_value` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=15 ;

--
-- Dumping data for table `tbl_tracking`
--

INSERT INTO `tbl_tracking` (`id`, `date_start`, `date_end`, `paid_general`, `paid_pay_roll`, `paid_import`, `collect_general`, `collect_customer`, `collect_selling_debt`, `collect_selling_nodebt`, `estate_rate`, `store_value`) VALUES
(13, '2014-01-01', '2014-01-03', 0, 0, 0, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tracking_course`
--

CREATE TABLE IF NOT EXISTS `tbl_tracking_course` (
  `id` int(11) NOT NULL,
  `id_tracking` int(11) NOT NULL,
  `id_td` int(11) NOT NULL,
  `id_course` int(11) NOT NULL,
  `count` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `value` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_tracking_course`
--

INSERT INTO `tbl_tracking_course` (`id`, `id_tracking`, `id_td`, `id_course`, `count`, `price`, `value`) VALUES
(0, 12, 6, 213, 2, 0, 0),
(0, 12, 6, 107, 34, 0, 0),
(0, 13, 34, 107, 6, 0, 0),
(0, 13, 34, 255, 3, 0, 0),
(0, 13, 34, 197, 1, 0, 0),
(0, 13, 34, 218, 1, 0, 0),
(0, 13, 34, 180, 1, 0, 0),
(0, 13, 34, 332, 4, 0, 0),
(0, 13, 34, 128, 1, 0, 0),
(0, 13, 34, 129, 1, 0, 0),
(0, 13, 34, 334, 2, 0, 0),
(0, 13, 35, 107, 1, 0, 0),
(0, 13, 35, 255, 1, 0, 0),
(0, 13, 35, 224, 1, 0, 0),
(0, 13, 36, 335, 2, 0, 0),
(0, 13, 36, 107, 39, 0, 0),
(0, 13, 36, 255, 10, 0, 0),
(0, 13, 36, 266, 2, 0, 0),
(0, 13, 36, 268, 1, 0, 0),
(0, 13, 36, 174, 1, 0, 0),
(0, 13, 36, 175, 1, 0, 0),
(0, 13, 36, 176, 4, 0, 0),
(0, 13, 36, 177, 4, 0, 0),
(0, 13, 36, 189, 1, 0, 0),
(0, 13, 36, 336, 1, 0, 0),
(0, 13, 36, 352, 3, 0, 0),
(0, 13, 36, 341, 5, 0, 0),
(0, 13, 36, 343, 1, 0, 0),
(0, 13, 36, 344, 1, 0, 0),
(0, 13, 36, 224, 14, 0, 0),
(0, 13, 36, 217, 4, 0, 0),
(0, 13, 36, 178, 1, 0, 0),
(0, 13, 36, 179, 1, 0, 0),
(0, 13, 36, 180, 3, 0, 0),
(0, 13, 36, 56, 1, 0, 0),
(0, 13, 36, 128, 1, 0, 0),
(0, 13, 36, 204, 8, 0, 0),
(0, 13, 36, 212, 2, 0, 0),
(0, 13, 36, 221, 1, 0, 0),
(0, 13, 36, 222, 3, 0, 0),
(0, 13, 36, 205, 1, 0, 0),
(0, 13, 37, 335, 1, 0, 0),
(0, 13, 37, 107, 88, 0, 0),
(0, 13, 37, 255, 29, 0, 0),
(0, 13, 37, 112, 2, 0, 0),
(0, 13, 37, 355, 1, 0, 0),
(0, 13, 37, 268, 2, 0, 0),
(0, 13, 37, 265, 1, 0, 0),
(0, 13, 37, 203, 1, 0, 0),
(0, 13, 37, 353, 2, 0, 0),
(0, 13, 37, 197, 2, 0, 0),
(0, 13, 37, 174, 2, 0, 0),
(0, 13, 37, 175, 4, 0, 0),
(0, 13, 37, 176, 8, 0, 0),
(0, 13, 37, 177, 1, 0, 0),
(0, 13, 37, 189, 2, 0, 0),
(0, 13, 37, 364, 11, 0, 0),
(0, 13, 37, 224, 20, 0, 0),
(0, 13, 37, 226, 1, 0, 0),
(0, 13, 37, 218, 2, 0, 0),
(0, 13, 37, 201, 1, 0, 0),
(0, 13, 37, 179, 1, 0, 0),
(0, 13, 37, 180, 1, 0, 0),
(0, 13, 37, 351, 2, 0, 0),
(0, 13, 37, 129, 1, 0, 0),
(0, 13, 37, 204, 15, 0, 0),
(0, 13, 37, 212, 3, 0, 0),
(0, 13, 37, 222, 1, 0, 0),
(0, 13, 37, 334, 4, 0, 0),
(0, 13, 37, 205, 1, 0, 0),
(0, 13, 37, 315, 2, 0, 0),
(0, 13, 37, 228, 1, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tracking_customer`
--

CREATE TABLE IF NOT EXISTS `tbl_tracking_customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_tracking` int(11) NOT NULL,
  `id_customer` int(11) NOT NULL,
  `value_session1` int(11) NOT NULL,
  `value_session2` int(11) NOT NULL,
  `value_collect` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tracking_daily`
--

CREATE TABLE IF NOT EXISTS `tbl_tracking_daily` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_tracking` int(11) NOT NULL,
  `date` date NOT NULL,
  `selling` bigint(20) NOT NULL,
  `import` bigint(20) NOT NULL,
  `store` bigint(20) NOT NULL,
  `paid` bigint(20) NOT NULL,
  `collect` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=91 ;

--
-- Dumping data for table `tbl_tracking_daily`
--

INSERT INTO `tbl_tracking_daily` (`id`, `id_tracking`, `date`, `selling`, `import`, `store`, `paid`, `collect`) VALUES
(1, 12, '2013-12-01', 0, 0, 0, 0, 0),
(2, 12, '2013-12-02', 0, 0, 0, 0, 0),
(3, 12, '2013-12-03', 0, 0, 0, 0, 0),
(4, 12, '2013-12-04', 0, 0, 0, 0, 0),
(5, 12, '2013-12-05', 0, 0, 0, 0, 0),
(6, 12, '2013-12-06', 390000, 320000, 146000, 0, 2000000),
(7, 12, '2013-12-07', 0, 0, 0, 0, 0),
(8, 12, '2013-12-08', 0, 0, 0, 0, 0),
(9, 12, '2013-12-09', 0, 0, 0, 0, 0),
(10, 12, '2013-12-10', 0, 0, 0, 0, 0),
(11, 12, '2013-12-11', 0, 0, 0, 0, 0),
(12, 12, '2013-12-12', 0, 0, 0, 0, 0),
(13, 12, '2013-12-13', 0, 0, 0, 0, 0),
(14, 12, '2013-12-14', 0, 0, 0, 0, 0),
(15, 12, '2013-12-15', 0, 0, 0, 0, 0),
(16, 12, '2013-12-16', 0, 0, 0, 0, 0),
(17, 12, '2013-12-17', 0, 0, 0, 0, 0),
(18, 12, '2013-12-18', 0, 0, 0, 0, 0),
(19, 12, '2013-12-19', 0, 0, 0, 0, 0),
(20, 12, '2013-12-20', 0, 0, 0, 0, 0),
(21, 12, '2013-12-21', 0, 0, 0, 0, 0),
(22, 12, '2013-12-22', 0, 0, 0, 0, 0),
(23, 12, '2013-12-23', 0, 0, 0, 0, 0),
(24, 12, '2013-12-24', 0, 0, 0, 0, 0),
(25, 12, '2013-12-25', 0, 0, 0, 0, 0),
(26, 12, '2013-12-26', 0, 0, 0, 0, 0),
(27, 12, '2013-12-27', 0, 0, 0, 0, 0),
(28, 12, '2013-12-28', 0, 0, 0, 0, 0),
(29, 12, '2013-12-29', 0, 0, 146000, 0, 0),
(30, 12, '2013-12-30', 0, 0, 146000, 0, 0),
(31, 12, '2013-12-31', 0, 0, 146000, 0, 0),
(32, 13, '2014-01-01', 0, 0, 146000, 0, 0),
(33, 13, '2014-01-02', 0, 0, 206000, 0, 0),
(34, 13, '2014-01-03', 228000, 0, 188000, 0, 0),
(35, 13, '2014-01-04', 26000, 0, 188000, 0, 0),
(36, 13, '2014-01-05', 940000, 0, 110000, 0, 0),
(37, 13, '2014-01-06', 1971000, 0, -82500, 0, 0),
(38, 13, '2014-01-07', 0, 0, 19500, 0, 0),
(39, 13, '2014-01-08', 0, 0, 0, 0, 0),
(40, 13, '2014-01-09', 0, 0, 0, 0, 0),
(41, 13, '2014-01-10', 0, 0, 0, 0, 0),
(42, 13, '2014-01-11', 0, 0, 0, 0, 0),
(43, 13, '2014-01-12', 0, 0, 0, 0, 0),
(44, 13, '2014-01-13', 0, 0, 0, 0, 0),
(45, 13, '2014-01-14', 0, 0, 0, 0, 0),
(46, 13, '2014-01-15', 0, 0, 0, 0, 0),
(47, 13, '2014-01-16', 0, 0, 0, 0, 0),
(48, 13, '2014-01-17', 0, 0, 0, 0, 0),
(49, 13, '2014-01-18', 0, 0, 0, 0, 0),
(50, 13, '2014-01-19', 0, 0, 0, 0, 0),
(51, 13, '2014-01-20', 0, 0, 0, 0, 0),
(52, 13, '2014-01-21', 0, 0, 0, 0, 0),
(53, 13, '2014-01-22', 0, 0, 0, 0, 0),
(54, 13, '2014-01-23', 0, 0, 0, 0, 0),
(55, 13, '2014-01-24', 0, 0, 0, 0, 0),
(56, 13, '2014-01-25', 0, 0, 0, 0, 0),
(57, 13, '2014-01-26', 0, 0, 0, 0, 0),
(58, 13, '2014-01-27', 0, 0, 0, 0, 0),
(59, 13, '2014-01-28', 0, 0, 0, 0, 0),
(60, 13, '2014-01-29', 0, 0, 0, 0, 0),
(61, 13, '2014-01-30', 0, 0, 0, 0, 0),
(62, 13, '2014-01-31', 0, 0, 0, 0, 0),
(63, 14, '2014-02-01', 0, 0, 0, 0, 0),
(64, 14, '2014-02-02', 0, 0, 0, 0, 0),
(65, 14, '2014-02-03', 0, 0, 0, 0, 0),
(66, 14, '2014-02-04', 0, 0, 0, 0, 0),
(67, 14, '2014-02-05', 0, 0, 0, 0, 0),
(68, 14, '2014-02-06', 0, 0, 0, 0, 0),
(69, 14, '2014-02-07', 0, 0, 0, 0, 0),
(70, 14, '2014-02-08', 0, 0, 0, 0, 0),
(71, 14, '2014-02-09', 0, 0, 0, 0, 0),
(72, 14, '2014-02-10', 0, 0, 0, 0, 0),
(73, 14, '2014-02-11', 0, 0, 0, 0, 0),
(74, 14, '2014-02-12', 0, 0, 0, 0, 0),
(75, 14, '2014-02-13', 0, 0, 0, 0, 0),
(76, 14, '2014-02-14', 0, 0, 0, 0, 0),
(77, 14, '2014-02-15', 0, 0, 0, 0, 0),
(78, 14, '2014-02-16', 0, 0, 0, 0, 0),
(79, 14, '2014-02-17', 0, 0, 0, 0, 0),
(80, 14, '2014-02-18', 0, 0, 0, 0, 0),
(81, 14, '2014-02-19', 0, 0, 0, 0, 0),
(82, 14, '2014-02-20', 0, 0, 0, 0, 0),
(83, 14, '2014-02-21', 0, 0, 0, 0, 0),
(84, 14, '2014-02-22', 0, 0, 0, 0, 0),
(85, 14, '2014-02-23', 0, 0, 0, 0, 0),
(86, 14, '2014-02-24', 0, 0, 0, 0, 0),
(87, 14, '2014-02-25', 0, 0, 0, 0, 0),
(88, 14, '2014-02-26', 0, 0, 0, 0, 0),
(89, 14, '2014-02-27', 0, 0, 0, 0, 0),
(90, 14, '2014-02-28', 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tracking_store`
--

CREATE TABLE IF NOT EXISTS `tbl_tracking_store` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_tracking` int(11) NOT NULL,
  `id_td` int(11) NOT NULL,
  `id_resource` int(11) NOT NULL,
  `count_old` float NOT NULL,
  `count_import` float NOT NULL,
  `count_export` float NOT NULL,
  `price` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1791 ;

--
-- Dumping data for table `tbl_tracking_store`
--

INSERT INTO `tbl_tracking_store` (`id`, `id_tracking`, `id_td`, `id_resource`, `count_old`, `count_import`, `count_export`, `price`) VALUES
(1707, 12, 6, 19, 0, 2, 0.9, 60000),
(1708, 12, 6, 20, 0, 1, 0, 80000),
(1709, 12, 6, 35, 0, 0, 0, 160000),
(1710, 12, 6, 36, 0, 0, 0, 185000),
(1711, 12, 30, 19, 1.1, 0, 0, 60000),
(1712, 12, 30, 20, 1, 0, 0, 80000),
(1713, 12, 30, 35, 0, 0, 0, 160000),
(1714, 12, 30, 36, 0, 0, 0, 185000),
(1715, 12, 29, 19, 1.1, 0, 0, 60000),
(1716, 12, 29, 20, 1, 0, 0, 80000),
(1717, 12, 29, 35, 0, 0, 0, 160000),
(1718, 12, 29, 36, 0, 0, 0, 185000),
(1719, 12, 31, 19, 1.1, 0, 0, 60000),
(1720, 12, 31, 20, 1, 0, 0, 80000),
(1721, 12, 31, 35, 0, 0, 0, 160000),
(1722, 12, 31, 36, 0, 0, 0, 185000),
(1743, 13, 33, 19, 1.1, 1, 0, 60000),
(1744, 13, 33, 20, 1, 0, 0, 80000),
(1745, 13, 33, 35, 0, 0, 0, 160000),
(1746, 13, 33, 36, 0, 0, 0, 185000),
(1751, 13, 34, 19, 2.1, 0, 0.3, 60000),
(1752, 13, 34, 20, 1, 0, 0, 80000),
(1753, 13, 34, 35, 0, 0, 0, 160000),
(1754, 13, 34, 36, 0, 0, 0, 185000),
(1759, 13, 35, 19, 1.8, 0, 0, 60000),
(1760, 13, 35, 20, 1, 0, 0, 80000),
(1761, 13, 35, 35, 0, 0, 0, 160000),
(1762, 13, 35, 36, 0, 0, 0, 185000),
(1767, 13, 36, 19, 1.8, 0, 1.3, 60000),
(1768, 13, 36, 20, 1, 0, 0, 80000),
(1769, 13, 36, 35, 0, 0, 0, 160000),
(1770, 13, 36, 36, 0, 0, 0, 185000),
(1775, 13, 32, 19, 1.1, 0, 0, 60000),
(1776, 13, 32, 20, 1, 0, 0, 80000),
(1777, 13, 32, 35, 0, 0, 0, 160000),
(1778, 13, 32, 36, 0, 0, 0, 185000),
(1783, 13, 38, 19, -0.7, 0, 0, 60000),
(1784, 13, 38, 20, 1, 0, 0, 80000),
(1785, 13, 38, 35, 0, 0, 0, 160000),
(1786, 13, 38, 36, -0.1, 0, 0, 185000),
(1787, 13, 37, 19, 0.5, 0, 2.9, 60000),
(1788, 13, 37, 20, 1, 0, 0, 80000),
(1789, 13, 37, 35, 0, 0, 0, 160000),
(1790, 13, 37, 36, 0, 0, 0.1, 185000);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_unit`
--

CREATE TABLE IF NOT EXISTS `tbl_unit` (
  `id` int(25) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=29 ;

--
-- Dumping data for table `tbl_unit`
--

INSERT INTO `tbl_unit` (`id`, `name`) VALUES
(1, 'Ly'),
(2, 'Điếu'),
(3, 'Chai'),
(4, 'Lon'),
(5, 'Dĩa'),
(6, 'Thùng'),
(7, 'Két'),
(9, 'Bịch'),
(10, 'Gói'),
(20, 'Trái'),
(21, 'Cái'),
(22, 'Hủ'),
(23, 'Kg'),
(24, 'Phần'),
(25, 'Bàn'),
(26, 'Hộp'),
(27, 'Bao'),
(28, 'Cây');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE IF NOT EXISTS `tbl_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pass` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gender` int(11) NOT NULL,
  `note` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `datecreate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dateupdate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `dateactivity` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `type` tinyint(4) NOT NULL,
  `code` varchar(13) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`id`, `name`, `email`, `pass`, `gender`, `note`, `datecreate`, `dateupdate`, `dateactivity`, `type`, `code`) VALUES
(3, 'Thanh Tân', 'tsontung@yahoo.com', '123456', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 2, ''),
(4, 'Quan Ly', 'mientaycoffee@gmail.com', '01012014', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 4, '');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_collect_customer`
--
ALTER TABLE `tbl_collect_customer`
  ADD CONSTRAINT `tbl_customer_collect_1` FOREIGN KEY (`idcustomer`) REFERENCES `tbl_customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_collect_general`
--
ALTER TABLE `tbl_collect_general`
  ADD CONSTRAINT `tbl_collect_general_1` FOREIGN KEY (`id_term`) REFERENCES `tbl_term_collect` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_course`
--
ALTER TABLE `tbl_course`
  ADD CONSTRAINT `tbl_course_1` FOREIGN KEY (`idcategory`) REFERENCES `tbl_category` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_order_import`
--
ALTER TABLE `tbl_order_import`
  ADD CONSTRAINT `tbl_order_import_1` FOREIGN KEY (`idsupplier`) REFERENCES `tbl_supplier` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_order_import_detail`
--
ALTER TABLE `tbl_order_import_detail`
  ADD CONSTRAINT `tbl_order_import_detail_1` FOREIGN KEY (`idorder`) REFERENCES `tbl_order_import` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_order_import_detail_2` FOREIGN KEY (`idresource`) REFERENCES `tbl_resource` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_paid_customer`
--
ALTER TABLE `tbl_paid_customer`
  ADD CONSTRAINT `tbl_customer_paid_1` FOREIGN KEY (`idcustomer`) REFERENCES `tbl_customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_paid_employee`
--
ALTER TABLE `tbl_paid_employee`
  ADD CONSTRAINT `tbl_paid_employee_ibfk_1` FOREIGN KEY (`id_employee`) REFERENCES `tbl_employee` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_paid_general`
--
ALTER TABLE `tbl_paid_general`
  ADD CONSTRAINT `tbl_paid_general_1` FOREIGN KEY (`id_term`) REFERENCES `tbl_term` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_paid_pay_roll`
--
ALTER TABLE `tbl_paid_pay_roll`
  ADD CONSTRAINT `tbl_paid_pay_roll_ibfk_1` FOREIGN KEY (`id_employee`) REFERENCES `tbl_employee` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_paid_supplier`
--
ALTER TABLE `tbl_paid_supplier`
  ADD CONSTRAINT `tbl_supplier_paid_1` FOREIGN KEY (`idsupplier`) REFERENCES `tbl_supplier` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_pay_roll`
--
ALTER TABLE `tbl_pay_roll`
  ADD CONSTRAINT `tbl_pay_roll_ibfk_1` FOREIGN KEY (`id_employee`) REFERENCES `tbl_employee` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_r2c`
--
ALTER TABLE `tbl_r2c`
  ADD CONSTRAINT `tbl_r2c_1` FOREIGN KEY (`id_course`) REFERENCES `tbl_course` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_r2c_2` FOREIGN KEY (`id_resource`) REFERENCES `tbl_resource` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_resource`
--
ALTER TABLE `tbl_resource`
  ADD CONSTRAINT `tbl_resource_1` FOREIGN KEY (`idsupplier`) REFERENCES `tbl_supplier` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_session`
--
ALTER TABLE `tbl_session`
  ADD CONSTRAINT `tbl_session_1` FOREIGN KEY (`idtable`) REFERENCES `tbl_table` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_session_2` FOREIGN KEY (`iduser`) REFERENCES `tbl_user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_session_3` FOREIGN KEY (`idcustomer`) REFERENCES `tbl_customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_session_detail`
--
ALTER TABLE `tbl_session_detail`
  ADD CONSTRAINT `tbl_session_detail_1` FOREIGN KEY (`idsession`) REFERENCES `tbl_session` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_session_detail_2` FOREIGN KEY (`idcourse`) REFERENCES `tbl_course` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_table`
--
ALTER TABLE `tbl_table`
  ADD CONSTRAINT `tbl_table_1` FOREIGN KEY (`iddomain`) REFERENCES `tbl_domain` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
