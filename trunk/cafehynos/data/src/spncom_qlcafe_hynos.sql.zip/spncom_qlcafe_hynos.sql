-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 26, 2014 at 12:55 AM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `spncom_qlcafe_hynos`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_app`
--

CREATE TABLE IF NOT EXISTS `tbl_app` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(125) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(50) CHARACTER SET utf8 NOT NULL,
  `banner` varchar(125) CHARACTER SET utf8 NOT NULL,
  `prefix` varchar(50) CHARACTER SET utf8 NOT NULL,
  `alias` varchar(256) CHARACTER SET utf8 NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_activity` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `type` tinyint(4) NOT NULL,
  `page_view` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_app`
--

INSERT INTO `tbl_app` (`id`, `name`, `phone`, `address`, `email`, `banner`, `prefix`, `alias`, `date_created`, `date_modified`, `date_activity`, `type`, `page_view`) VALUES
(1, 'Karaoke Ba Đức', '0945 03 07 09', 'Phó Cơ Điều P3 - TPVL', '', 'data/images/banner/logo.png', 'tbl_', 'tbl_', '2012-06-30 17:00:00', '0000-00-00 00:00:00', '2012-12-26 07:28:02', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_category`
--

CREATE TABLE IF NOT EXISTS `tbl_category` (
  `id` int(25) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `picture` binary(255) DEFAULT NULL,
  `enable` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=36 ;

--
-- Dumping data for table `tbl_category`
--

INSERT INTO `tbl_category` (`id`, `name`, `picture`, `enable`) VALUES
(13, 'Cafe', '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0', 1),
(15, 'Nước ép', NULL, 1),
(16, 'Kem', '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0', 1),
(17, 'Yaoua', NULL, 1),
(18, 'Nước uống đóng chai', '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0', 1),
(19, 'Nước chế biến', NULL, 1),
(20, 'Trà', NULL, 1),
(21, 'Sữa', '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0', 1),
(22, 'Ca cao', NULL, 1),
(23, 'Chanh', '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0', 1),
(24, 'Thuốc lá', '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0', 1),
(32, 'Sinh tố', NULL, 1),
(33, 'Trái cây ăn', NULL, 1),
(34, 'Khăn lạnh', NULL, 1),
(35, 'Dừa', '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_collect_customer`
--

CREATE TABLE IF NOT EXISTS `tbl_collect_customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idcustomer` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_customer_collect_1` (`idcustomer`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `tbl_collect_customer`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbl_collect_general`
--

CREATE TABLE IF NOT EXISTS `tbl_collect_general` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_term` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_collect_1` (`id_term`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=6 ;

--
-- Dumping data for table `tbl_collect_general`
--

INSERT INTO `tbl_collect_general` (`id`, `id_term`, `date`, `value`, `note`) VALUES
(5, 2, '2013-05-18', 10, 'd');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_config`
--

CREATE TABLE IF NOT EXISTS `tbl_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `param` varchar(125) COLLATE utf8_unicode_ci NOT NULL,
  `value` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=13 ;

--
-- Dumping data for table `tbl_config`
--

INSERT INTO `tbl_config` (`id`, `param`, `value`) VALUES
(1, 'ROW_PER_PAGE', '12'),
(2, 'EVERY_5_MINUTES', '2000'),
(3, 'GUEST_VISIT', '3167'),
(5, 'DISCOUNT', '0'),
(6, 'NAME', 'CAFE HYNOS'),
(7, 'ADDRESS', '83 Trần Đại Nghĩa, P.3, TP.VL'),
(8, 'PHONE', '0908710099'),
(9, 'CATEGORY_AUTO', '22'),
(10, 'SWITCH_BOARD_CALL', '1'),
(11, 'RECEIPT_VIRTUAL_DOUBLE', '1'),
(12, 'N_MONTH_LOG', '1');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_course`
--

CREATE TABLE IF NOT EXISTS `tbl_course` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idcategory` int(25) DEFAULT NULL,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `shortname` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `unit` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `price1` bigint(20) NOT NULL,
  `price2` bigint(20) NOT NULL,
  `price3` bigint(20) NOT NULL,
  `price4` bigint(20) NOT NULL,
  `picture` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_discount` int(11) NOT NULL,
  `prepare` int(11) NOT NULL,
  `enable` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `foreign_field` (`idcategory`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=350 ;

--
-- Dumping data for table `tbl_course`
--

INSERT INTO `tbl_course` (`id`, `idcategory`, `name`, `shortname`, `unit`, `price1`, `price2`, `price3`, `price4`, `picture`, `is_discount`, `prepare`, `enable`) VALUES
(148, 13, 'Cafe đá', 'Cafe đá', 'Ly', 10000, 10000, 10000, 10000, '', 1, 0, 1),
(149, 13, 'Cafe đen', 'Cafe đen', 'Ly', 10000, 10000, 10000, 10000, '', 1, 0, 1),
(150, 13, 'Cafe sữa nóng', 'Cafe sữa nóng', 'Ly', 15000, 15000, 15000, 15000, '', 1, 0, 1),
(151, 13, 'Cafe sữa đá', 'Cafe sữa đá', 'Ly', 16000, 16000, 16000, 16000, '', 1, 0, 1),
(162, 16, 'Kem sôcôla', 'Kem sôcôla', 'Ly', 28000, 28000, 28000, 28000, '', 1, 0, 1),
(163, 16, 'Kem dâu ', 'Kem dâu tây', 'Ly', 28000, 28000, 28000, 28000, '', 1, 0, 1),
(164, 16, 'Kem cafe ', 'Kem cafe ', 'Ly', 27000, 27000, 27000, 27000, '', 1, 0, 1),
(165, 16, 'Kem sầu riêng', 'Kem sầu riêng', 'Ly', 28000, 28000, 28000, 28000, '', 1, 0, 1),
(166, 16, 'Kem trái cây', 'Kem trái cây', 'Ly', 30000, 30000, 30000, 30000, '', 1, 0, 1),
(167, 16, 'Kem thập cẩm', 'Kem thập cẩm', 'Ly', 30000, 30000, 30000, 30000, '', 1, 0, 1),
(168, 16, 'Kem 3 màu', 'Kem 3 màu', 'Ly', 30000, 30000, 30000, 30000, '', 1, 0, 1),
(169, 20, 'Lipton đá', 'Lipton đá', 'Ly', 12000, 12000, 12000, 12000, '', 1, 0, 1),
(170, 20, 'Lipton nóng', 'Lipton nóng', 'Ly', 10000, 10000, 10000, 10000, '', 1, 0, 1),
(171, 20, 'Lipton mật ong', 'Lipton mật ong', 'Ly', 16000, 16000, 16000, 16000, '', 1, 0, 1),
(172, 20, 'Trà đường nóng', 'Trà đường nóng', 'Ly', 10000, 10000, 10000, 10000, '', 1, 0, 1),
(173, 20, 'Trà đường đá', 'Trà đường đá', 'Ly', 10000, 10000, 10000, 10000, '', 1, 0, 1),
(174, 20, 'Trà chanh nóng', 'tra chanh nong', 'Ly', 11000, 11000, 11000, 11000, '', 1, 0, 1),
(175, 20, 'Trà chanh đá', 'Trà chanh đá', 'Ly', 11000, 11000, 11000, 11000, '', 1, 0, 1),
(176, 20, 'Lipton sữa đá', 'Lipton sữa đá', 'Ly', 16000, 16000, 16000, 16000, '', 1, 0, 1),
(177, 20, 'Lipton sữa nóng', 'Lipton sữa nóng', 'Ly', 15000, 15000, 15000, 15000, '', 1, 0, 1),
(178, 17, 'Yaoua sữa đá', 'Yaoua sữa đá', 'Ly', 16000, 16000, 16000, 16000, '', 1, 0, 1),
(179, 17, 'Yaoua trái cây', 'Yaoua trái cây', 'Ly', 18000, 18000, 18000, 18000, '', 1, 0, 1),
(180, 17, 'Yaoua dâu tươi', 'Yaoua dâu tươi', 'Ly', 18000, 18000, 18000, 18000, '', 1, 0, 1),
(181, 17, 'Yaoua mơ', 'yaoua mo', 'Ly', 17000, 17000, 17000, 17000, '', 1, 0, 1),
(182, 17, 'Yaoua mứt', 'Yaoua mứt', 'Ly', 17000, 17000, 17000, 17000, '', 1, 0, 1),
(183, 17, 'Yaoua cam', 'Yaoua cam', 'Ly', 17000, 17000, 17000, 17000, '', 1, 0, 1),
(184, 17, 'Yaoua hủ', 'Yaoua hủ', 'Hủ', 11000, 11000, 11000, 11000, '', 1, 0, 1),
(185, 18, 'Sting dâu', 'Sting dâu', 'Chai', 16000, 16000, 16000, 16000, '', 1, 0, 1),
(186, 18, 'Đậu nành', 'Đậu nành', 'Chai', 17000, 17000, 17000, 17000, '', 1, 0, 1),
(187, 18, 'Bò húc', 'Bò húc', 'Lon', 18000, 18000, 18000, 18000, '', 0, 0, 1),
(188, 18, 'Number one sua ', 'Number one sua ', 'Chai', 19000, 19000, 19000, 19000, '', 0, 0, 1),
(189, 18, 'Sá xị', 'Sá xị', 'Lon', 16000, 16000, 16000, 16000, '', 0, 1, 1),
(190, 18, 'Pepsi ', 'Pepsi ', 'Lon', 16000, 16000, 16000, 16000, '', 1, 0, 1),
(191, 18, '7 up', '7 up', 'Lon', 16000, 16000, 16000, 16000, '', 0, 0, 1),
(192, 18, 'Trà xanh', 'Trà xanh', 'Chai', 17000, 17000, 17000, 17000, '', 1, 0, 1),
(193, 18, 'Dr.Thanh', 'Dr.Thanh', 'Chai', 17000, 17000, 17000, 17000, '', 1, 0, 1),
(194, 18, 'Cam lon', 'Cam lon', 'Lon', 17000, 17000, 17000, 17000, '', 1, 0, 1),
(195, 18, 'Nước suối', 'Nước suối', 'Chai', 10000, 10000, 10000, 10000, '', 0, 0, 1),
(196, 15, 'Nước ép dâu', 'Nước ép dâu', 'Ly', 25000, 25000, 25000, 25000, '', 1, 0, 1),
(197, 15, 'Nước ép lê', 'Nước ép lê', 'Ly', 25000, 25000, 25000, 25000, '', 1, 0, 1),
(198, 15, 'Nước ép táo', 'nuoc ep tao', 'Ly', 25000, 25000, 25000, 25000, '', 1, 0, 1),
(199, 15, 'Nước ép cà chua', 'nuoc ep ca chua', 'Ly', 25000, 25000, 25000, 25000, '', 1, 0, 1),
(200, 15, 'Nước ép cà rốt', 'nuoc ep ca rot', 'Ly', 25000, 25000, 25000, 25000, '', 1, 0, 1),
(201, 15, 'Nước ép cam', 'Nước ép cam', 'Ly', 25000, 25000, 25000, 25000, '', 1, 0, 1),
(202, 19, 'Me đá', 'Me đá', 'Ly', 12000, 12000, 12000, 12000, '', 1, 0, 1),
(203, 19, 'Tắc xí muội', 'Tắc xí muội', 'Bao', 15000, 15000, 15000, 15000, '', 0, 0, 1),
(204, 19, 'Xí muội đá', 'Xí muội đá', 'Bao', 15000, 15000, 15000, 15000, '', 0, 0, 1),
(205, 19, 'Xí muội nóng', 'Xí muội nóng', 'Ly', 13000, 13000, 13000, 13000, '', 1, 0, 1),
(206, 19, 'Rau má thường', 'Rau má thường', 'Ly', 15000, 15000, 15000, 15000, '', 1, 0, 1),
(207, 19, 'Rau má dừa', 'Rau má dừa', 'Ly', 17000, 17000, 17000, 17000, '', 1, 0, 1),
(208, 19, 'Rau má sữa', 'Rau má sữa', 'Ly', 17000, 17000, 17000, 17000, '', 1, 0, 1),
(209, 19, 'Xirô dâu', 'Xirô dâu', 'Ly', 15000, 15000, 15000, 15000, '', 1, 0, 1),
(210, 19, 'Xirô dâu sua', 'Xirô sữa', 'Bao', 17000, 17000, 17000, 17000, '', 0, 0, 1),
(211, 21, 'Sữa quế', 'Sữa quế', 'Ly', 16000, 16000, 16000, 16000, '', 1, 0, 1),
(212, 21, 'Sữa đá', 'Sữa đá', 'Ly', 16000, 16000, 16000, 16000, '', 1, 0, 1),
(213, 21, 'Sữa tươi đá', 'Sữa tươi đá', 'Bao', 15000, 15000, 15000, 15000, '', 0, 0, 1),
(214, 21, 'Sữa tươi không đá', 'Sữa tươi (không đá)', 'Bao', 16000, 16000, 16000, 16000, '', 0, 0, 1),
(215, 22, 'Cacao đá', 'Cacao đá', 'Ly', 15000, 15000, 15000, 15000, '', 0, 0, 1),
(216, 22, 'Cacao nóng', 'Ca cao nóng', 'Ly', 14000, 14000, 14000, 14000, '', 0, 0, 1),
(217, 22, 'Cacao sữa đá', 'Cacao sữa đá', 'Ly', 18000, 18000, 18000, 18000, '', 0, 0, 1),
(218, 22, 'Cacao sữa nóng', 'Cacao sữa nóng', 'Ly', 17000, 17000, 17000, 17000, '', 0, 0, 1),
(219, 19, 'Me đá sữa ', 'Me da sữa ', 'Ly', 15000, 15000, 15000, 15000, '', 1, 0, 1),
(220, 23, 'Chanh tươi nóng', 'Chanh tươi nóng', 'Ly', 11000, 11000, 11000, 11000, '', 1, 0, 1),
(222, 23, 'Chanh muối đá', 'Chanh muối đá', 'Ly', 12000, 12000, 12000, 12000, '', 1, 0, 1),
(223, 23, 'Chanh muối nóng', 'Chanh muối nóng', 'Ly', 11000, 11000, 11000, 11000, '', 1, 0, 1),
(224, 23, 'Chanh dây (có hạt)', 'Chanh dây (có hạt)', 'Ly', 25000, 25000, 25000, 25000, '', 1, 0, 1),
(225, 23, 'Chanh tươi đá', 'Chanh tươi đá', 'Ly', 12000, 12000, 12000, 12000, '', 0, 0, 1),
(235, 24, '555 (gói lớn)', '555 (gói lớn)', 'Gói', 37000, 37000, 37000, 37000, '', 1, 0, 1),
(236, 24, 'Mèo gói    (goi lớn)', 'Mèo gói    (goi lớn)', 'Gói', 27000, 27000, 27000, 27000, '', 1, 0, 1),
(237, 24, '555 (điếu)', '555 (điếu)', 'Điếu', 2500, 2500, 2500, 2500, '', 1, 0, 1),
(238, 24, 'Mèo tép', 'Mèo tép', 'Bao', 8000, 8000, 8000, 8000, '', 1, 0, 1),
(239, 24, 'Mèo (điếu)', 'Mèo (điếu)', 'Điếu', 2000, 2000, 2000, 2000, '', 1, 0, 1),
(240, 21, 'bạc xĩu nóng', 'bạc xĩu nóng', 'Bao', 15000, 15000, 15000, 15000, '', 0, 0, 1),
(241, 21, 'bạc xĩu đá', 'bạc xĩu đá', 'Ly', 16000, 16000, 16000, 16000, '', 1, 0, 1),
(242, 21, 'sữa nóng', 'sữa nóng', 'Bao', 15000, 15000, 15000, 15000, '', 0, 0, 1),
(248, 18, 'sting sữa', 'sting sua', 'Chai', 18000, 18000, 18000, 18000, '', 1, 0, 1),
(249, 21, 'sữa thêm', 'sữa thêm', 'Ly', 7000, 7000, 7000, 7000, '', 1, 0, 1),
(250, 23, 'Chanh giây (không hạt)', 'Chanh giây (không hạt)', 'Ly', 25000, 25000, 25000, 25000, '', 1, 0, 1),
(251, 23, 'Chanh dây sữa', 'Chanh dây sữa', 'Ly', 28000, 28000, 28000, 28000, '', 1, 0, 1),
(254, 32, 'sinh tố bơ', 'sinh tố bơ', 'Ly', 26000, 26000, 26000, 26000, '', 1, 0, 1),
(255, 32, 'sinh tố mãng cầu', 'sinh tố mãng cầu', 'Ly', 25000, 25000, 25000, 25000, '', 1, 0, 1),
(256, 32, 'sinh tố dâu', 'sinh tố dâu', 'Ly', 26000, 26000, 26000, 26000, '', 1, 0, 1),
(257, 32, 'sinh tố cà chua', 'sinh tố cà chua', 'Ly', 25000, 25000, 25000, 25000, '', 1, 0, 1),
(258, 32, 'sinh tố cà rót', 'sinh tố cà rót', 'Ly', 25000, 25000, 25000, 25000, '', 1, 0, 1),
(259, 32, 'sinh tố chanh giây', 'sinh tố chanh giây', 'Ly', 25000, 25000, 25000, 25000, '', 1, 0, 1),
(260, 32, 'sinh tố chanh tuyết', 'sinh tố chanh tuyết', 'Ly', 25000, 25000, 25000, 25000, '', 1, 0, 1),
(261, 32, 'sinh tố sapô chê', 'sinh tố sapô chê', 'Ly', 25000, 25000, 25000, 25000, '', 1, 0, 1),
(263, 32, 'sinh tố thập cẩm', 'sinh tố thập cẩm', 'Ly', 28000, 28000, 28000, 28000, '', 1, 0, 1),
(264, 32, 'sinh tố tự chọn 2 món', 'sinh tố tự chọn 2 món', 'Ly', 27000, 27000, 27000, 27000, '', 1, 0, 1),
(265, 32, 'sinh tố tự chọn 3 món', 'sinh tố tự chọn 3 món', 'Ly', 28000, 28000, 28000, 28000, '', 1, 0, 1),
(266, 32, 'sinh tố táo', 'sinh tố táo', 'Ly', 25000, 25000, 25000, 25000, '', 1, 0, 1),
(267, 32, 'sinh tố lê', 'sinh tố lê', 'Bao', 25000, 25000, 25000, 25000, '', 0, 0, 1),
(268, 33, 'bơ dầm', 'bơ dầm', 'Ly', 28000, 28000, 28000, 28000, '', 1, 0, 1),
(269, 33, 'mãng cầu dầm', 'mãng cầu dầm', 'Ly', 28000, 28000, 28000, 28000, '', 1, 0, 1),
(270, 33, 'sapô dầm', 'sapô dầm', 'Ly', 25000, 25000, 25000, 25000, '', 1, 0, 1),
(271, 33, 'trái cây dĩa lớn', 'trái cây dĩa lớn', 'Dĩa', 40000, 0, 0, 0, '', 1, 0, 1),
(272, 33, 'tráy cây dĩa nhỏ', 'trai cay (dia nho)', 'Dĩa', 30000, 30000, 30000, 30000, '', 1, 0, 1),
(273, 33, 'dâu dầm', 'dâu dầm', 'Ly', 24000, 24000, 24000, 24000, '', 1, 0, 1),
(274, 21, 'sữa tươi càfê', 'sữa tươi càfê', 'Bao', 16000, 16000, 16000, 16000, '', 0, 0, 1),
(275, 21, 'sữa tươi bịch', 'sữa tươi bịch', 'Bao', 16000, 16000, 16000, 16000, '', 0, 0, 1),
(276, 34, 'khăn lạnh', '', 'Cái', 2000, 0, 0, 0, '', 1, 0, 1),
(277, 34, 'khăn nóng', '', 'Cái', 2000, 0, 0, 0, '', 1, 0, 1),
(278, 20, 'trà gừng nóng', 'trà gừng nóng', 'Ly', 11000, 11000, 11000, 11000, '', 1, 0, 1),
(279, 20, 'trà cúc đá', 'trà cúc đá', 'Ly', 12000, 12000, 12000, 12000, '', 1, 0, 1),
(281, 20, 'trà cúc nóng', 'trà cúc nóng', 'Ly', 11000, 11000, 11000, 11000, '', 1, 0, 1),
(282, 20, 'trà gừng đá', 'trà gừng đá', 'Ly', 14000, 14000, 14000, 14000, '', 1, 0, 1),
(284, 20, 'Lipton cam', 'Lipton cam', 'Ly', 15000, 15000, 15000, 15000, '', 1, 0, 1),
(285, 15, 'nước ép thơm', 'nước ép thơm', 'Ly', 25000, 25000, 25000, 25000, '', 1, 0, 1),
(286, 19, 'bạc hà sua', 'bạc hà sua', 'Ly', 16000, 16000, 16000, 16000, '', 0, 0, 1),
(287, 21, 'sữa hồng', 'sữa hồng', 'Ly', 17000, 17000, 17000, 17000, '', 1, 0, 1),
(288, 13, 'càfê kem', 'càfê kem', 'Ly', 16000, 16000, 16000, 16000, '', 1, 0, 1),
(293, 18, 'C2', 'C2', 'Chai', 15000, 15000, 15000, 15000, '', 1, 0, 1),
(294, 19, 'Sâm dứa sữa', 'Sâm dứa sữa', 'Ly', 16000, 16000, 16000, 16000, '', 1, 0, 1),
(295, 19, 'sâm dứa bạc hà', 'sâm dứa bạc hà', 'Ly', 14000, 14000, 14000, 14000, '', 1, 0, 1),
(296, 24, 'Meo (gói nhỏ)', 'meo (goi nho)', 'Gói', 14000, 14000, 14000, 14000, '', 0, 1, 1),
(297, 20, 'Lípton mật ong nóng', 'lipton mat ong nong', 'Ly', 15000, 15000, 15000, 15000, '', 1, 0, 1),
(298, 17, 'yaoua bạc hà', 'yaoua bạc hà', 'Ly', 17000, 17000, 17000, 17000, '', 1, 0, 1),
(299, 16, 'kem sữa cafe', 'kem sữa cafe', 'Ly', 30000, 30000, 30000, 30000, '', 1, 0, 1),
(300, 32, 'Sinh tố cam', 'Sinh tố cam', 'Bao', 25000, 25000, 25000, 25000, '', 0, 0, 1),
(302, 35, 'Dừa lạnh', 'dua lanh', 'Trái', 16000, 16000, 16000, 16000, '', 1, 0, 1),
(305, 32, 'Sinh tố cà chua + càrót', 'sinh to ca chua + ca rot', 'Ly', 25000, 25000, 25000, 25000, '', 1, 0, 1),
(307, 15, 'nước ép chanh dây', 'nuoc ep chanh day', 'Ly', 25000, 25000, 25000, 25000, '', 1, 0, 1),
(309, 15, 'Ép cam (không đá)', 'Ep cam (khong da)', 'Ly', 25000, 25000, 25000, 25000, '', 1, 0, 1),
(310, 32, 'Sinh tố hạnh phúc', 'sinh to hanh phuc', 'Ly', 25000, 25000, 25000, 25000, '', 1, 0, 1),
(311, 15, 'Nước ép 2 món', 'nuoc ep 2 mon', 'Ly', 27000, 27000, 27000, 27000, '', 1, 0, 1),
(312, 15, 'Cam mật ong ', 'cam mat ong ', 'Ly', 25000, 25000, 25000, 25000, '', 1, 0, 1),
(313, 16, 'kem thập cẩm trái cây', 'kem thap cam trai cay', 'Ly', 30000, 30000, 30000, 30000, '', 1, 0, 1),
(314, 17, 'yaoua sua da (ly dat biet)', 'yaua sua da (dat biet)', 'Ly', 22000, 22000, 22000, 22000, '', 1, 0, 1),
(315, 15, 'Cam sữa đá', 'cam sua da', 'Ly', 28000, 28000, 28000, 28000, '', 1, 0, 1),
(316, 15, 'Nước ép thập cẩm', 'nuoc ep thap cam', 'Ly', 30000, 30000, 30000, 30000, '', 1, 0, 1),
(317, 15, 'nước ép cà + cải ', 'nuoc ep ca + cai', 'Ly', 27000, 27000, 27000, 27000, '', 1, 0, 1),
(319, 20, 'tra gung mat ong (nong)', 'tra gung mat ong (nong)', 'Ly', 15000, 15000, 15000, 15000, '', 1, 0, 1),
(320, 20, 'lipton xí muôi ', 'lipton xi muoi', 'Ly', 15000, 15000, 15000, 15000, '', 1, 0, 1),
(321, 16, 'kem dừa', 'kem dừa', 'Ly', 28000, 28000, 28000, 28000, '', 1, 0, 1),
(322, 32, 'Sinh tố mít', 'sinh to mit', 'Bao', 25000, 25000, 25000, 25000, '', 0, 0, 1),
(323, 19, 'xí muội bạc hà', 'xi muoi bac ha', 'Ly', 14000, 14000, 14000, 14000, '', 1, 0, 1),
(324, 20, 'lipton bac ha', '', 'Ly', 15000, 15000, 15000, 15000, '', 1, 0, 1),
(325, 23, 'Chanh dây sinh tố', 'chanh day sinh to', 'Ly', 27000, 27000, 27000, 27000, '', 0, 5, 1),
(326, 35, 'Dừa đá', 'dua da', 'Trái', 17000, 17000, 17000, 17000, '', 1, 0, 1),
(327, 18, 'numberone', 'numberone', 'Chai', 17000, 17000, 17000, 17000, '', 0, 1, 1),
(330, 18, 'Pepsi (sua)', 'pepsi (sua)', 'Lon', 18000, 18000, 18000, 18000, '', 1, 1, 1),
(331, 16, 'Kem dâu tươi', 'kem dâu tươi', 'Ly', 30000, 30000, 30000, 30000, '', 0, 1, 1),
(332, 21, 'sữa bạc hà', 'sua bac ha', 'Ly', 16000, 16000, 16000, 16000, '', 0, 1, 1),
(333, 32, 'sinh to bo (dat biet)', 'sinh to bo', 'Bao', 28000, 28000, 28000, 28000, '', 0, 1, 0),
(334, 23, 'chanh day sua ', 'chanh day sua ', 'Ly', 28000, 28000, 28000, 28000, '', 0, 1, 1),
(335, 32, 'sinh tô rau ma', 'sinh to rau ma', 'Bao', 25000, 25000, 25000, 25000, '', 0, 1, 1),
(336, 20, 'lipton cam sua ', 'lipton cam sua ', 'Ly', 18000, 18000, 18000, 18000, '', 0, 1, 1),
(338, 19, 'Sam dua bac ha sua', 'Sam dua bac ha sua', 'Ly', 16000, 16000, 16000, 16000, '', 0, 1, 1),
(339, 19, 'Bac ha da', 'Bac ha da', 'Ly', 15000, 15000, 15000, 15000, '', 0, 1, 1),
(341, 18, 'revive', 'revive', 'Chai', 17000, 17000, 17000, 17000, '', 0, 1, 1),
(342, 23, 'chanh day mat ong', 'chanh day mat ong ', 'Ly', 27000, 27000, 27000, 27000, '', 0, 1, 1),
(343, 13, 'Cafe sinh to', 'Cafe sinh to', 'Ly', 25000, 25000, 25000, 25000, '', 0, 1, 1),
(344, 23, 'chanh day (nong)', 'chanh day (nong)', 'Ly', 25000, 25000, 25000, 25000, '', 0, 1, 1),
(345, 32, 'sinh to thom ', 'sinh to thom ', 'Ly', 25000, 25000, 25000, 25000, '', 0, 1, 1),
(346, 17, 'yaoua cafe ', 'yaoau cafe', 'Ly', 18000, 18000, 18000, 18000, '', 0, 1, 1),
(347, 17, 'yaoua cafe ', 'yaoau cafe', 'Ly', 18000, 18000, 18000, 18000, '', 0, 1, 1),
(348, 24, 'YETT', 'YETT', 'Bao', 20000, 20000, 20000, 20000, '', 0, 1, 1),
(349, 15, 'nuoc ep mang cau ', 'nuoc ep mang cau ', 'Ly', 27000, 27000, 27000, 27000, '', 0, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_customer`
--

CREATE TABLE IF NOT EXISTS `tbl_customer` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  `card` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `note` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `discount` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=6 ;

--
-- Dumping data for table `tbl_customer`
--

INSERT INTO `tbl_customer` (`id`, `name`, `type`, `card`, `phone`, `address`, `note`, `discount`) VALUES
(1, 'lacadr', 0, '', '0703822487', '', '', 0),
(2, 'dua lanh', 0, '', '01259669583', '', '', 0),
(3, 'cafe hiep tai', 0, '', '0919282500', '', '', 0),
(4, 'gas', 0, '', '0703883883', '', '', 0),
(5, 'lam (tien)', 0, '', '01663005556', '', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_domain`
--

CREATE TABLE IF NOT EXISTS `tbl_domain` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=6 ;

--
-- Dumping data for table `tbl_domain`
--

INSERT INTO `tbl_domain` (`id`, `name`) VALUES
(1, 'SÂN VƯƠN '),
(2, 'PHONG LANH'),
(4, 'Khách lẻ'),
(5, 'Ngân hang');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_employee`
--

CREATE TABLE IF NOT EXISTS `tbl_employee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `job` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gender` tinyint(2) NOT NULL,
  `phone` varchar(13) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `salary_base` int(11) NOT NULL,
  `card` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=34 ;

--
-- Dumping data for table `tbl_employee`
--

INSERT INTO `tbl_employee` (`id`, `name`, `job`, `gender`, `phone`, `address`, `salary_base`, `card`) VALUES
(21, 'Duy', '', 0, '', 'Vĩnh Long', 0, ''),
(22, 'Nhi', 'PHUC VU', 0, '', 'Vĩnh Long', 1700000, ''),
(23, 'Ngọc', 'PV', 0, '', 'Vĩnh Long', 1700000, ''),
(26, 'Vĩnh', 'PHA CHẾ (pha chế ca sáng)', 0, '', 'Vĩnh Long', 1500000, ''),
(28, 'Mãi', 'bảo vệ (ca tối)', 0, '', 'Vĩnh Long', 900000, ''),
(29, 'Hiền', 'bảo vệ (ca tối)', 0, '', 'Vĩnh Long', 1700000, ''),
(30, 'Thuy Dung', 'PV', 0, '', 'Vĩnh Long', 1700000, ''),
(31, 'Toàn', 'bảo vệ', 0, '', 'Vĩnh Long', 1700000, ''),
(32, 'Ngọc Châu', 'pv', 0, '', 'Vũng Liêm VL', 1700000, ''),
(33, 'trâm', '', 0, '', 'Vĩnh Long', 1700000, '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_guest`
--

CREATE TABLE IF NOT EXISTS `tbl_guest` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(16) CHARACTER SET latin1 NOT NULL,
  `entry_time` varchar(32) CHARACTER SET latin1 NOT NULL,
  `exit_time` varchar(32) CHARACTER SET latin1 NOT NULL,
  `agent` varchar(16) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=54 ;

--
-- Dumping data for table `tbl_guest`
--

INSERT INTO `tbl_guest` (`id`, `ip`, `entry_time`, `exit_time`, `agent`) VALUES
(52, '42.118.194.80', '1387810601', '1387814201', '42.118.194.80'),
(53, '42.117.212.214', '1387811364', '1387814964', '42.117.212.214');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order_import`
--

CREATE TABLE IF NOT EXISTS `tbl_order_import` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idsupplier` int(11) NOT NULL,
  `date` date NOT NULL,
  `description` varchar(50) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_order_import_1` (`idsupplier`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `tbl_order_import`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbl_order_import_detail`
--

CREATE TABLE IF NOT EXISTS `tbl_order_import_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idorder` int(11) NOT NULL,
  `idresource` int(11) NOT NULL,
  `count` float NOT NULL,
  `price` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_order_import_detail_1` (`idorder`),
  KEY `tbl_order_import_detail_2` (`idresource`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `tbl_order_import_detail`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbl_paid_customer`
--

CREATE TABLE IF NOT EXISTS `tbl_paid_customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idcustomer` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_customer_paid_1` (`idcustomer`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=19 ;

--
-- Dumping data for table `tbl_paid_customer`
--

INSERT INTO `tbl_paid_customer` (`id`, `idcustomer`, `date`, `value`, `note`) VALUES
(18, 1, '2013-05-16', 1, '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_paid_employee`
--

CREATE TABLE IF NOT EXISTS `tbl_paid_employee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_employee` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(150) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_employee` (`id_employee`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `tbl_paid_employee`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbl_paid_general`
--

CREATE TABLE IF NOT EXISTS `tbl_paid_general` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_term` int(11) NOT NULL,
  `id_employee` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_paid_1` (`id_term`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=89 ;

--
-- Dumping data for table `tbl_paid_general`
--

INSERT INTO `tbl_paid_general` (`id`, `id_term`, `id_employee`, `date`, `value`, `note`) VALUES
(9, 10, 0, '2013-04-01', 157000, 'Chi tiền chợ'),
(10, 10, 0, '2013-04-02', 146000, 'Tiền chợ'),
(11, 10, 0, '2013-04-03', 189000, 'Tiền chợ'),
(12, 10, 0, '2013-04-04', 184000, 'Tiền chợ'),
(13, 10, 0, '2013-04-05', 173000, 'Tiền chợ'),
(14, 10, 0, '2013-04-06', 213000, 'Tiền chợ'),
(15, 10, 0, '2013-04-07', 123000, 'Tiền chợ'),
(16, 10, 0, '2013-04-08', 224000, 'Tiền chợ'),
(17, 10, 0, '2013-04-09', 200000, 'Tiền chợ'),
(23, 10, 0, '2013-04-10', 102000, 'Tiền chợ'),
(25, 10, 0, '2013-04-11', 106000, 'Tiền chợ'),
(27, 10, 0, '2013-04-13', 163000, 'Tiền chợ'),
(33, 10, 0, '2013-04-14', 221000, 'Tiền chợ'),
(34, 10, 0, '2013-04-15', 122000, 'Tiền chợ'),
(35, 10, 0, '2013-04-17', 222000, 'Tiền chợ'),
(36, 10, 0, '2013-04-18', 118000, 'Tiền chợ'),
(38, 10, 0, '2013-04-19', 122000, 'Tiền chợ'),
(39, 10, 0, '2013-04-20', 134000, 'Tiền chợ\r\n'),
(42, 10, 0, '2013-04-22', 120000, 'Tiền chợ\r\n'),
(43, 1, 0, '2013-04-20', 649000, 'Tiền điện sinh hoạt'),
(45, 10, 0, '2013-04-23', 97000, 'Tiền chợ'),
(47, 10, 0, '2013-04-24', 65000, 'Tiền chợ'),
(49, 10, 0, '2013-04-25', 177000, 'Tiền chợ'),
(51, 10, 0, '2013-04-26', 100000, 'Tiền chợ'),
(52, 10, 0, '2013-04-27', 102000, 'Tiền chợ'),
(54, 10, 0, '2013-04-28', 103000, 'Tiền chợ'),
(55, 10, 0, '2013-04-29', 126000, 'Tiền chợ'),
(57, 10, 0, '2013-05-01', 95000, 'Tiền chợ'),
(59, 10, 0, '2013-05-03', 183000, 'Tiền chợ'),
(60, 10, 0, '2013-05-02', 62000, 'Tiền chợ'),
(61, 10, 0, '2013-05-04', 85000, 'Tiền chợ'),
(62, 10, 0, '2013-05-05', 89000, 'Tiền chợ\r\n'),
(63, 10, 0, '2013-05-06', 32000, 'Tiền chợ'),
(64, 4, 0, '2013-04-30', 10500000, 'Lương NV chưa tính phụ cấp'),
(65, 1, 0, '2013-04-30', 6000000, ''),
(66, 2, 0, '2013-04-30', 1500000, 'Tạm tính'),
(67, 10, 0, '2013-05-07', 211000, 'Tiền chợ\r\n'),
(70, 10, 0, '2013-05-08', 115000, 'Tiền chợ'),
(71, 10, 0, '2013-05-09', 117000, 'Tiền chợ'),
(73, 10, 0, '2013-05-10', 81000, 'Tiền chợ'),
(74, 10, 0, '2013-05-11', 99000, 'Tiền chợ\r\n'),
(75, 10, 0, '2013-05-12', 330000, 'Tiền chợ'),
(76, 10, 0, '2013-05-13', 85000, 'Tiền chợ\r\n'),
(77, 10, 0, '2013-05-14', 74500, 'Tiền chợ'),
(79, 3, 0, '2013-04-30', 5600000, 'Thuế TTĐB'),
(80, 12, 0, '2013-04-30', 3250000, 'chi tiền đầu chai cho NV'),
(81, 10, 0, '2013-05-15', 221000, ''),
(82, 10, 0, '2013-05-16', 106000, ''),
(83, 10, 0, '2013-05-17', 129000, ''),
(85, 10, 0, '2013-05-18', 99000, ''),
(86, 10, 0, '2013-05-19', 85000, ''),
(88, 10, 0, '2013-05-20', 40000, '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_paid_supplier`
--

CREATE TABLE IF NOT EXISTS `tbl_paid_supplier` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idsupplier` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_supplier_paid_1` (`idsupplier`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=9 ;

--
-- Dumping data for table `tbl_paid_supplier`
--

INSERT INTO `tbl_paid_supplier` (`id`, `idsupplier`, `date`, `value`, `note`) VALUES
(8, 6, '2012-09-19', 1000000, 'Thử nè được không đó !');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_pay_roll`
--

CREATE TABLE IF NOT EXISTS `tbl_pay_roll` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idemployee` int(11) NOT NULL,
  `date` date NOT NULL,
  `state` int(11) NOT NULL,
  `extra` int(11) NOT NULL,
  `late` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_pay_roll_1` (`idemployee`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `tbl_pay_roll`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbl_r2c`
--

CREATE TABLE IF NOT EXISTS `tbl_r2c` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_course` int(11) NOT NULL,
  `id_resource` int(11) NOT NULL,
  `value1` double NOT NULL,
  `value2` double NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_r2c_1` (`id_course`),
  KEY `tbl_r2c_2` (`id_resource`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `tbl_r2c`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbl_resource`
--

CREATE TABLE IF NOT EXISTS `tbl_resource` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `idsupplier` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `unit` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `price` int(10) NOT NULL,
  `description` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_resource_1` (`idsupplier`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `tbl_resource`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbl_session`
--

CREATE TABLE IF NOT EXISTS `tbl_session` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idtable` int(11) NOT NULL,
  `iduser` int(11) NOT NULL,
  `idcustomer` int(11) NOT NULL,
  `idemployee` int(11) NOT NULL,
  `datetime` datetime NOT NULL,
  `datetimeend` datetime DEFAULT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `status` int(11) NOT NULL,
  `discount_value` int(11) NOT NULL,
  `discount_percent` int(11) NOT NULL,
  `surtax` int(11) NOT NULL,
  `payment` int(11) NOT NULL,
  `value` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idtable` (`idtable`),
  KEY `iduser` (`iduser`),
  KEY `tbl_session_3` (`idcustomer`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=47132 ;

--
-- Dumping data for table `tbl_session`
--

INSERT INTO `tbl_session` (`id`, `idtable`, `iduser`, `idcustomer`, `idemployee`, `datetime`, `datetimeend`, `note`, `status`, `discount_value`, `discount_percent`, `surtax`, `payment`, `value`) VALUES
(47131, 72, 1, 1, 1, '2014-12-26 06:31:09', '2014-12-26 06:31:09', '', 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_session_detail`
--

CREATE TABLE IF NOT EXISTS `tbl_session_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idsession` int(11) NOT NULL,
  `idcourse` int(11) NOT NULL,
  `count` int(11) NOT NULL,
  `price` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idsession` (`idsession`),
  KEY `idcourse` (`idcourse`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=86097 ;

--
-- Dumping data for table `tbl_session_detail`
--

INSERT INTO `tbl_session_detail` (`id`, `idsession`, `idcourse`, `count`, `price`) VALUES
(86096, 47131, 148, 1, 10000);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_store`
--

CREATE TABLE IF NOT EXISTS `tbl_store` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `note` varchar(125) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_store`
--

INSERT INTO `tbl_store` (`id`, `name`, `note`) VALUES
(1, 'Kho nhà', 'Ghi chú gì đây ?');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_supplier`
--

CREATE TABLE IF NOT EXISTS `tbl_supplier` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `note` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `debt` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=7 ;

--
-- Dumping data for table `tbl_supplier`
--

INSERT INTO `tbl_supplier` (`id`, `name`, `phone`, `address`, `note`, `debt`) VALUES
(6, 'Coop Mart', '070', 'Vĩnh Long', 'Cung cấp mọi thứ', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_table`
--

CREATE TABLE IF NOT EXISTS `tbl_table` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iddomain` int(11) NOT NULL,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `iduser` int(11) DEFAULT NULL,
  `type` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `iddomain` (`iddomain`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=74 ;

--
-- Dumping data for table `tbl_table`
--

INSERT INTO `tbl_table` (`id`, `iddomain`, `name`, `iduser`, `type`) VALUES
(2, 1, 'SV: 19', 0, '0'),
(3, 1, 'SV: 20', 0, '0'),
(4, 1, 'SV: 21', 0, '0'),
(28, 1, 'SV: 22', 1, '0'),
(29, 2, 'PL: 01', 1, '0'),
(30, 2, 'PL: 02', 1, '0'),
(31, 2, 'PL: 03', 1, '0'),
(32, 2, 'PL: 04', 1, '0'),
(33, 2, 'PL: 05', 1, '0'),
(34, 2, 'PL: 06', 1, '0'),
(35, 2, 'PL: 07', 1, '0'),
(36, 2, 'PL: 08', 1, '0'),
(37, 2, 'PL: 09', 1, '0'),
(38, 2, 'PL; 10', 1, '0'),
(39, 2, 'PL: 11', 1, '0'),
(40, 2, 'PL: 12', 1, '0'),
(41, 2, 'PL: 13', 1, '0'),
(42, 2, 'PL: 14', 1, '0'),
(43, 2, 'PL: 15', 1, '0'),
(44, 2, 'PL: 16', 1, '0'),
(45, 2, 'PL: 17', 1, '0'),
(49, 4, '1', 1, '0'),
(50, 4, '2', 1, '0'),
(51, 4, '3', 1, '0'),
(52, 4, '4', 1, '0'),
(53, 4, '5', 1, '0'),
(54, 4, '6', 1, '0'),
(55, 4, '7', 1, '0'),
(56, 4, '8', 1, '0'),
(57, 4, '9', 1, '0'),
(58, 4, '10', 1, '0'),
(63, 1, 'SV: 23', 1, '0'),
(70, 2, 'PL: 18A', 1, '0'),
(71, 1, 'SV: 24', 1, '0'),
(72, 2, 'PL: 18B', 1, '0'),
(73, 5, 'N.H: 1', 1, '0');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_table_log`
--

CREATE TABLE IF NOT EXISTS `tbl_table_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iduser` int(11) NOT NULL,
  `idtable` int(11) NOT NULL,
  `idemployee` int(11) NOT NULL,
  `datetime` datetime NOT NULL,
  `note` varchar(250) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idtable` (`idtable`),
  KEY `iduser` (`iduser`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=194346 ;

--
-- Dumping data for table `tbl_table_log`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbl_term`
--

CREATE TABLE IF NOT EXISTS `tbl_term` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=27 ;

--
-- Dumping data for table `tbl_term`
--

INSERT INTO `tbl_term` (`id`, `name`, `type`) VALUES
(1, 'Tiền Điện ', 0),
(2, 'Tiền Nước', 0),
(3, 'Thuế', 0),
(4, 'Lương Nhân Viên', 0),
(10, 'Tiền Ăn Nhân Viên', 0),
(11, 'CP Khác', 0),
(12, 'Tiền Phụ Cấp', 0),
(13, '21/06- bat dau gop giay 50.000.000d ', 0),
(14, '28/06- gop lan 1: 3.500.000d', 0),
(15, '5 /06 gop lan 2 ;3.500.000', 0),
(16, 'chj 9 -100.000.000 dong thang -ngay -29 ', 0),
(17, 'lam 10.000.000 ;;10 ngay gop 1 lan '''''''''' 1 lan 700.000 ', 0),
(20, 'vang 24 cam / 170.000.000 thang dong / 8 .500.000 ', 0),
(21, 'vong bo thang dong ...450.000 ', 0),
(22, 'xe 20000000 / thang dong  ...1000000 ', 0),
(23, 'gop ngay 19 - 07 -7.000.000 -2 tuan ', 0),
(24, 'gop ngay 2 - 08 -7.000.000 -2 tuan ', 0),
(25, 'gop ngay  23 - 08 -10.500.000 -3 tuan ', 0),
(26, 'gop ngay 13 -09 -10.500.000 - 3 tuan ', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_term_collect`
--

CREATE TABLE IF NOT EXISTS `tbl_term_collect` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Dumping data for table `tbl_term_collect`
--

INSERT INTO `tbl_term_collect` (`id`, `name`) VALUES
(2, 'Phụ Phẩm'),
(3, 'Đặc Biệt');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tracking`
--

CREATE TABLE IF NOT EXISTS `tbl_tracking` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_start` date NOT NULL,
  `date_end` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=17 ;

--
-- Dumping data for table `tbl_tracking`
--

INSERT INTO `tbl_tracking` (`id`, `date_start`, `date_end`) VALUES
(1, '2013-08-01', '2013-08-31'),
(2, '2013-09-01', '2013-09-30'),
(3, '2013-10-01', '2013-10-31'),
(4, '2013-11-01', '2013-11-30'),
(5, '2013-12-01', '2013-12-31'),
(6, '2014-01-01', '2014-01-31'),
(8, '2014-02-01', '2014-02-28'),
(9, '2014-03-01', '2014-03-31'),
(11, '2014-04-01', '2014-04-30'),
(12, '2014-05-01', '2014-05-31'),
(13, '2014-06-01', '2014-06-30'),
(14, '2014-07-01', '2014-07-31'),
(15, '2014-08-01', '2014-08-31'),
(16, '2014-09-01', '2014-09-30');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tracking_course`
--

CREATE TABLE IF NOT EXISTS `tbl_tracking_course` (
  `id` int(11) NOT NULL,
  `id_tracking` int(11) NOT NULL,
  `id_td` int(11) NOT NULL,
  `id_course` int(11) NOT NULL,
  `count` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `value` int(11) NOT NULL,
  `prepare` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_tracking_course`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbl_tracking_customer`
--

CREATE TABLE IF NOT EXISTS `tbl_tracking_customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_tracking` int(11) NOT NULL,
  `id_customer` int(11) NOT NULL,
  `value_session1` int(11) NOT NULL,
  `value_session2` int(11) NOT NULL,
  `value_collect` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `tbl_tracking_customer`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbl_tracking_daily`
--

CREATE TABLE IF NOT EXISTS `tbl_tracking_daily` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_tracking` int(11) NOT NULL,
  `date` date NOT NULL,
  `selling` bigint(20) NOT NULL,
  `import` bigint(20) NOT NULL,
  `store` bigint(20) NOT NULL,
  `paid` bigint(20) NOT NULL,
  `collect` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=428 ;

--
-- Dumping data for table `tbl_tracking_daily`
--

INSERT INTO `tbl_tracking_daily` (`id`, `id_tracking`, `date`, `selling`, `import`, `store`, `paid`, `collect`) VALUES
(1, 8, '2014-02-01', 4233000, 0, 0, 0, 0),
(2, 8, '2014-02-02', 5303000, 0, 0, 0, 0),
(3, 8, '2014-02-03', 4385000, 0, 0, 0, 0),
(4, 8, '2014-02-04', 4851000, 0, 0, 0, 0),
(5, 8, '2014-02-05', 4969000, 0, 0, 0, 0),
(6, 8, '2014-02-06', 3934000, 0, 0, 0, 0),
(7, 8, '2014-02-07', 2464000, 0, 0, 0, 0),
(8, 8, '2014-02-08', 2502000, 0, 0, 0, 0),
(9, 8, '2014-02-09', 2701000, 0, 0, 0, 0),
(10, 8, '2014-02-10', 1425000, 0, 0, 0, 0),
(11, 8, '2014-02-11', 3030000, 0, 0, 0, 0),
(12, 8, '2014-02-12', 2947000, 0, 0, 0, 0),
(13, 8, '2014-02-13', 2566000, 0, 0, 0, 0),
(14, 8, '2014-02-14', 3204000, 0, 0, 0, 0),
(15, 8, '2014-02-15', 0, 0, 0, 0, 0),
(16, 8, '2014-02-16', 1454000, 0, 0, 0, 0),
(17, 8, '2014-02-17', 0, 0, 0, 0, 0),
(18, 8, '2014-02-18', 1587000, 0, 0, 0, 0),
(19, 8, '2014-02-19', 0, 0, 0, 0, 0),
(20, 8, '2014-02-20', 0, 0, 0, 0, 0),
(21, 8, '2014-02-21', 0, 0, 0, 0, 0),
(22, 8, '2014-02-22', 0, 0, 0, 0, 0),
(23, 8, '2014-02-23', 0, 0, 0, 0, 0),
(24, 8, '2014-02-24', 0, 0, 0, 0, 0),
(25, 8, '2014-02-25', 0, 0, 0, 0, 0),
(26, 8, '2014-02-26', 0, 0, 0, 0, 0),
(27, 8, '2014-02-27', 0, 0, 0, 0, 0),
(28, 8, '2014-02-28', 0, 0, 0, 0, 0),
(29, 3, '2013-10-01', 2619000, 0, 0, 0, 0),
(30, 3, '2013-10-02', 3065000, 0, 0, 0, 0),
(31, 3, '2013-10-03', 2480000, 0, 0, 0, 0),
(32, 3, '2013-10-04', 2895000, 0, 0, 0, 0),
(33, 3, '2013-10-05', 2331000, 0, 0, 0, 0),
(34, 3, '2013-10-06', 2383000, 0, 0, 0, 0),
(35, 3, '2013-10-07', 3079000, 0, 0, 0, 0),
(36, 3, '2013-10-08', 3047000, 0, 0, 0, 0),
(37, 3, '2013-10-09', 3028000, 0, 0, 0, 0),
(38, 3, '2013-10-10', 3021000, 0, 0, 0, 0),
(39, 3, '2013-10-11', 3227000, 0, 0, 0, 0),
(40, 3, '2013-10-12', 2911000, 0, 0, 0, 0),
(41, 3, '2013-10-13', 2704000, 0, 0, 0, 0),
(42, 3, '2013-10-14', 2742000, 0, 0, 0, 0),
(43, 3, '2013-10-15', 2730000, 0, 0, 0, 0),
(44, 3, '2013-10-16', 2599000, 0, 0, 0, 0),
(45, 3, '2013-10-17', 2881000, 0, 0, 0, 0),
(46, 3, '2013-10-18', 3214000, 0, 0, 0, 0),
(47, 3, '2013-10-19', 3805000, 0, 0, 0, 0),
(48, 3, '2013-10-20', 3038000, 0, 0, 0, 0),
(49, 3, '2013-10-21', 2978000, 0, 0, 0, 0),
(50, 3, '2013-10-22', 2979000, 0, 0, 0, 0),
(51, 3, '2013-10-23', 2650000, 0, 0, 0, 0),
(52, 3, '2013-10-24', 2919000, 0, 0, 0, 0),
(53, 3, '2013-10-25', 3012000, 0, 0, 0, 0),
(54, 3, '2013-10-26', 2863000, 0, 0, 0, 0),
(55, 3, '2013-10-27', 3244000, 0, 0, 0, 0),
(56, 3, '2013-10-28', 2843000, 0, 0, 0, 0),
(57, 3, '2013-10-29', 2587000, 0, 0, 0, 0),
(58, 3, '2013-10-30', 2528000, 0, 0, 0, 0),
(59, 3, '2013-10-31', 2984000, 0, 0, 0, 0),
(60, 2, '2013-09-01', 2918000, 0, 0, 0, 0),
(61, 2, '2013-09-02', 3153000, 0, 0, 0, 0),
(62, 2, '2013-09-03', 2600000, 0, 0, 0, 0),
(63, 2, '2013-09-04', 2853000, 0, 0, 0, 0),
(64, 2, '2013-09-05', 2422000, 0, 0, 0, 0),
(65, 2, '2013-09-06', 2668000, 0, 0, 0, 0),
(66, 2, '2013-09-07', 2671000, 0, 0, 0, 0),
(67, 2, '2013-09-08', 2417000, 0, 0, 0, 0),
(68, 2, '2013-09-09', 1686000, 0, 0, 0, 0),
(69, 2, '2013-09-10', 2341000, 0, 0, 0, 0),
(70, 2, '2013-09-11', 2839000, 0, 0, 0, 0),
(71, 2, '2013-09-12', 2061000, 0, 0, 0, 0),
(72, 2, '2013-09-13', 3300000, 0, 0, 0, 0),
(73, 2, '2013-09-14', 2476000, 0, 0, 0, 0),
(74, 2, '2013-09-15', 2902000, 0, 0, 0, 0),
(75, 2, '2013-09-16', 3010000, 0, 0, 0, 0),
(76, 2, '2013-09-17', 2640000, 0, 0, 0, 0),
(77, 2, '2013-09-18', 2766000, 0, 0, 0, 0),
(78, 2, '2013-09-19', 2855000, 0, 0, 0, 0),
(79, 2, '2013-09-20', 1770000, 0, 0, 0, 0),
(80, 2, '2013-09-21', 2576000, 0, 0, 0, 0),
(81, 2, '2013-09-22', 1980000, 0, 0, 0, 0),
(82, 2, '2013-09-23', 2554000, 0, 0, 0, 0),
(83, 2, '2013-09-24', 2640000, 0, 0, 0, 0),
(84, 2, '2013-09-25', 2993000, 0, 0, 0, 0),
(85, 2, '2013-09-26', 3052000, 0, 0, 0, 0),
(86, 2, '2013-09-27', 2508000, 0, 0, 0, 0),
(87, 2, '2013-09-28', 2277000, 0, 0, 0, 0),
(88, 2, '2013-09-29', 1175000, 0, 0, 0, 0),
(89, 2, '2013-09-30', 3062000, 0, 0, 0, 0),
(90, 1, '2013-08-01', 0, 0, 0, 0, 0),
(91, 1, '2013-08-02', 0, 0, 0, 0, 0),
(92, 1, '2013-08-03', 0, 0, 0, 0, 0),
(93, 1, '2013-08-04', 0, 0, 0, 0, 0),
(94, 1, '2013-08-05', 0, 0, 0, 0, 0),
(95, 1, '2013-08-06', 0, 0, 0, 0, 0),
(96, 1, '2013-08-07', 0, 0, 0, 0, 0),
(97, 1, '2013-08-08', 0, 0, 0, 0, 0),
(98, 1, '2013-08-09', 0, 0, 0, 0, 0),
(99, 1, '2013-08-10', 0, 0, 0, 0, 0),
(100, 1, '2013-08-11', 0, 0, 0, 0, 0),
(101, 1, '2013-08-12', 0, 0, 0, 0, 0),
(102, 1, '2013-08-13', 0, 0, 0, 0, 0),
(103, 1, '2013-08-14', 661000, 0, 0, 0, 0),
(104, 1, '2013-08-15', 3617000, 0, 0, 0, 0),
(105, 1, '2013-08-16', 3022000, 0, 0, 0, 0),
(106, 1, '2013-08-17', 3011000, 0, 0, 0, 0),
(107, 1, '2013-08-18', 3398000, 0, 0, 0, 0),
(108, 1, '2013-08-19', 2525000, 0, 0, 0, 0),
(109, 1, '2013-08-20', 3018000, 0, 0, 0, 0),
(110, 1, '2013-08-21', 2591000, 0, 0, 0, 0),
(111, 1, '2013-08-22', 2554000, 0, 0, 0, 0),
(112, 1, '2013-08-23', 2956000, 0, 0, 0, 0),
(113, 1, '2013-08-24', 2710000, 0, 0, 0, 0),
(114, 1, '2013-08-25', 2419000, 0, 0, 0, 0),
(115, 1, '2013-08-26', 2765000, 0, 0, 0, 0),
(116, 1, '2013-08-27', 2512000, 0, 0, 0, 0),
(117, 1, '2013-08-28', 2514000, 0, 0, 0, 0),
(118, 1, '2013-08-29', 2678000, 0, 0, 0, 0),
(119, 1, '2013-08-30', 2869000, 0, 0, 0, 0),
(120, 1, '2013-08-31', 2712000, 0, 0, 0, 0),
(121, 4, '2013-11-01', 3175000, 0, 0, 0, 0),
(122, 4, '2013-11-02', 3314000, 0, 0, 0, 0),
(123, 4, '2013-11-03', 3044000, 0, 0, 0, 0),
(124, 4, '2013-11-04', 3051000, 0, 0, 0, 0),
(125, 4, '2013-11-05', 2449000, 0, 0, 0, 0),
(126, 4, '2013-11-06', 2641000, 0, 0, 0, 0),
(127, 4, '2013-11-07', 2774000, 0, 0, 0, 0),
(128, 4, '2013-11-08', 2828000, 0, 0, 0, 0),
(129, 4, '2013-11-09', 2787000, 0, 0, 0, 0),
(130, 4, '2013-11-10', 3537000, 0, 0, 0, 0),
(131, 4, '2013-11-11', 2471000, 0, 0, 0, 0),
(132, 4, '2013-11-12', 3365000, 0, 0, 0, 0),
(133, 4, '2013-11-13', 3216000, 0, 0, 0, 0),
(134, 4, '2013-11-14', 3282000, 0, 0, 0, 0),
(135, 4, '2013-11-15', 3247000, 0, 0, 0, 0),
(136, 4, '2013-11-16', 2322000, 0, 0, 0, 0),
(137, 4, '2013-11-17', 3751000, 0, 0, 0, 0),
(138, 4, '2013-11-18', 2816000, 0, 0, 0, 0),
(139, 4, '2013-11-19', 2932000, 0, 0, 0, 0),
(140, 4, '2013-11-20', 3889000, 0, 0, 0, 0),
(141, 4, '2013-11-21', 2537000, 0, 0, 0, 0),
(142, 4, '2013-11-22', 2995000, 0, 0, 0, 0),
(143, 4, '2013-11-23', 3279000, 0, 0, 0, 0),
(144, 4, '2013-11-24', 3159000, 0, 0, 0, 0),
(145, 4, '2013-11-25', 3439000, 0, 0, 0, 0),
(146, 4, '2013-11-26', 2974000, 0, 0, 0, 0),
(147, 4, '2013-11-27', 2665000, 0, 0, 0, 0),
(148, 4, '2013-11-28', 2915000, 0, 0, 0, 0),
(149, 4, '2013-11-29', 3401000, 0, 0, 0, 0),
(150, 4, '2013-11-30', 3156000, 0, 0, 0, 0),
(151, 5, '2013-12-01', 3250000, 0, 0, 0, 0),
(152, 5, '2013-12-02', 2923000, 0, 0, 0, 0),
(153, 5, '2013-12-03', 2955000, 0, 0, 0, 0),
(154, 5, '2013-12-04', 3193000, 0, 0, 0, 0),
(155, 5, '2013-12-05', 3015000, 0, 0, 0, 0),
(156, 5, '2013-12-06', 2852000, 0, 0, 0, 0),
(157, 5, '2013-12-07', 3029000, 0, 0, 0, 0),
(158, 5, '2013-12-08', 3366000, 0, 0, 0, 0),
(159, 5, '2013-12-09', 3075000, 0, 0, 0, 0),
(160, 5, '2013-12-10', 4993000, 0, 0, 0, 0),
(161, 5, '2013-12-11', 2760000, 0, 0, 0, 0),
(162, 5, '2013-12-12', 2788000, 0, 0, 0, 0),
(163, 5, '2013-12-13', 3181000, 0, 0, 0, 0),
(164, 5, '2013-12-14', 2765000, 0, 0, 0, 0),
(165, 5, '2013-12-15', 3378000, 0, 0, 0, 0),
(166, 5, '2013-12-16', 2876000, 0, 0, 0, 0),
(167, 5, '2013-12-17', 2891000, 0, 0, 0, 0),
(168, 5, '2013-12-18', 2645000, 0, 0, 0, 0),
(169, 5, '2013-12-19', 2185000, 0, 0, 0, 0),
(170, 5, '2013-12-20', 2529000, 0, 0, 0, 0),
(171, 5, '2013-12-21', 2550000, 0, 0, 0, 0),
(172, 5, '2013-12-22', 2406000, 0, 0, 0, 0),
(173, 5, '2013-12-23', 3184000, 0, 0, 0, 0),
(174, 5, '2013-12-24', 3341000, 0, 0, 0, 0),
(175, 5, '2013-12-25', 3118000, 0, 0, 0, 0),
(176, 5, '2013-12-26', 3081000, 0, 0, 0, 0),
(177, 5, '2013-12-27', 2769000, 0, 0, 0, 0),
(178, 5, '2013-12-28', 2706000, 0, 0, 0, 0),
(179, 5, '2013-12-29', 2750000, 0, 0, 0, 0),
(180, 5, '2013-12-30', 3019000, 0, 0, 0, 0),
(181, 5, '2013-12-31', 2633000, 0, 0, 0, 0),
(182, 6, '2014-01-01', 3052000, 0, 0, 0, 0),
(183, 6, '2014-01-02', 2784000, 0, 0, 0, 0),
(184, 6, '2014-01-03', 2411000, 0, 0, 0, 0),
(185, 6, '2014-01-04', 2466000, 0, 0, 0, 0),
(186, 6, '2014-01-05', 2457000, 0, 0, 0, 0),
(187, 6, '2014-01-06', 2382000, 0, 0, 0, 0),
(188, 6, '2014-01-07', 1993000, 0, 0, 0, 0),
(189, 6, '2014-01-08', 2591000, 0, 0, 0, 0),
(190, 6, '2014-01-09', 2618000, 0, 0, 0, 0),
(191, 6, '2014-01-10', 1803000, 0, 0, 0, 0),
(192, 6, '2014-01-11', 1979000, 0, 0, 0, 0),
(193, 6, '2014-01-12', 2770000, 0, 0, 0, 0),
(194, 6, '2014-01-13', 2238000, 0, 0, 0, 0),
(195, 6, '2014-01-14', 2508000, 0, 0, 0, 0),
(196, 6, '2014-01-15', 2002000, 0, 0, 0, 0),
(197, 6, '2014-01-16', 1531000, 0, 0, 0, 0),
(198, 6, '2014-01-17', 2228000, 0, 0, 0, 0),
(199, 6, '2014-01-18', 2310000, 0, 0, 0, 0),
(200, 6, '2014-01-19', 2457000, 0, 0, 0, 0),
(201, 6, '2014-01-20', 2253000, 0, 0, 0, 0),
(202, 6, '2014-01-21', 2123000, 0, 0, 0, 0),
(203, 6, '2014-01-22', 1956000, 0, 0, 0, 0),
(204, 6, '2014-01-23', 2133000, 0, 0, 0, 0),
(205, 6, '2014-01-24', 2471000, 0, 0, 0, 0),
(206, 6, '2014-01-25', 1564000, 0, 0, 0, 0),
(207, 6, '2014-01-26', 1961000, 0, 0, 0, 0),
(208, 6, '2014-01-27', 2080000, 0, 0, 0, 0),
(209, 6, '2014-01-28', 2705000, 0, 0, 0, 0),
(210, 6, '2014-01-29', 3662000, 0, 0, 0, 0),
(211, 6, '2014-01-30', 1529000, 0, 0, 0, 0),
(212, 6, '2014-01-31', 6336000, 0, 0, 0, 0),
(213, 9, '2014-03-01', 3019000, 0, 0, 0, 0),
(214, 9, '2014-03-02', 1109000, 0, 0, 0, 0),
(215, 9, '2014-03-03', 2853000, 0, 0, 0, 0),
(216, 9, '2014-03-04', 3151000, 0, 0, 0, 0),
(217, 9, '2014-03-05', 3210000, 0, 0, 0, 0),
(218, 9, '2014-03-06', 3016000, 0, 0, 0, 0),
(219, 9, '2014-03-07', 2869000, 0, 0, 0, 0),
(220, 9, '2014-03-08', 3302000, 0, 0, 0, 0),
(221, 9, '2014-03-09', 3542000, 0, 0, 0, 0),
(222, 9, '2014-03-10', 3149000, 0, 0, 0, 0),
(223, 9, '2014-03-11', 3094000, 0, 0, 0, 0),
(224, 9, '2014-03-12', 3164000, 0, 0, 0, 0),
(225, 9, '2014-03-13', 2736000, 0, 0, 0, 0),
(226, 9, '2014-03-14', 2858000, 0, 0, 0, 0),
(227, 9, '2014-03-15', 1253000, 0, 0, 0, 0),
(228, 9, '2014-03-16', 2237000, 0, 0, 0, 0),
(229, 9, '2014-03-17', 2448000, 0, 0, 0, 0),
(230, 9, '2014-03-18', 2765000, 0, 0, 0, 0),
(231, 9, '2014-03-19', 1686000, 0, 0, 0, 0),
(232, 9, '2014-03-20', 1915000, 0, 0, 0, 0),
(233, 9, '2014-03-21', 2905000, 0, 0, 0, 0),
(234, 9, '2014-03-22', 2794000, 0, 0, 0, 0),
(235, 9, '2014-03-23', 2978000, 0, 0, 0, 0),
(236, 9, '2014-03-24', 2885000, 0, 0, 0, 0),
(237, 9, '2014-03-25', 3173000, 0, 0, 0, 0),
(238, 9, '2014-03-26', 2494000, 0, 0, 0, 0),
(239, 9, '2014-03-27', 2736000, 0, 0, 0, 0),
(240, 9, '2014-03-28', 3073000, 0, 0, 0, 0),
(241, 9, '2014-03-29', 3421000, 0, 0, 0, 0),
(242, 9, '2014-03-30', 4040000, 0, 0, 0, 0),
(243, 9, '2014-03-31', 2874000, 0, 0, 0, 0),
(244, 10, '0000-00-00', 0, 0, 0, 0, 0),
(245, 11, '2014-04-01', 3518000, 0, 0, 0, 0),
(246, 11, '2014-04-02', 3260000, 0, 0, 0, 0),
(247, 11, '2014-04-03', 3429000, 0, 0, 0, 0),
(248, 11, '2014-04-04', 2865000, 0, 0, 0, 0),
(249, 11, '2014-04-05', 0, 0, 0, 0, 0),
(250, 11, '2014-04-06', 0, 0, 0, 0, 0),
(251, 11, '2014-04-07', 2889000, 0, 0, 0, 0),
(252, 11, '2014-04-08', 0, 0, 0, 0, 0),
(253, 11, '2014-04-09', 0, 0, 0, 0, 0),
(254, 11, '2014-04-10', 0, 0, 0, 0, 0),
(255, 11, '2014-04-11', 0, 0, 0, 0, 0),
(256, 11, '2014-04-12', 0, 0, 0, 0, 0),
(257, 11, '2014-04-13', 0, 0, 0, 0, 0),
(258, 11, '2014-04-14', 0, 0, 0, 0, 0),
(259, 11, '2014-04-15', 0, 0, 0, 0, 0),
(260, 11, '2014-04-16', 0, 0, 0, 0, 0),
(261, 11, '2014-04-17', 0, 0, 0, 0, 0),
(262, 11, '2014-04-18', 0, 0, 0, 0, 0),
(263, 11, '2014-04-19', 0, 0, 0, 0, 0),
(264, 11, '2014-04-20', 0, 0, 0, 0, 0),
(265, 11, '2014-04-21', 0, 0, 0, 0, 0),
(266, 11, '2014-04-22', 0, 0, 0, 0, 0),
(267, 11, '2014-04-23', 0, 0, 0, 0, 0),
(268, 11, '2014-04-24', 0, 0, 0, 0, 0),
(269, 11, '2014-04-25', 0, 0, 0, 0, 0),
(270, 11, '2014-04-26', 0, 0, 0, 0, 0),
(271, 11, '2014-04-27', 0, 0, 0, 0, 0),
(272, 11, '2014-04-28', 0, 0, 0, 0, 0),
(273, 11, '2014-04-29', 0, 0, 0, 0, 0),
(274, 11, '2014-04-30', 0, 0, 0, 0, 0),
(275, 12, '2014-05-01', 3584000, 0, 0, 0, 0),
(276, 12, '2014-05-02', 2668000, 0, 0, 0, 0),
(277, 12, '2014-05-03', 3314000, 0, 0, 0, 0),
(278, 12, '2014-05-04', 2123000, 0, 0, 0, 0),
(279, 12, '2014-05-05', 3435000, 0, 0, 0, 0),
(280, 12, '2014-05-06', 3483000, 0, 0, 0, 0),
(281, 12, '2014-05-07', 3709000, 0, 0, 0, 0),
(282, 12, '2014-05-08', 3248000, 0, 0, 0, 0),
(283, 12, '2014-05-09', 3215000, 0, 0, 0, 0),
(284, 12, '2014-05-10', 3127000, 0, 0, 0, 0),
(285, 12, '2014-05-11', 2871000, 0, 0, 0, 0),
(286, 12, '2014-05-12', 2667000, 0, 0, 0, 0),
(287, 12, '2014-05-13', 0, 0, 0, 0, 0),
(288, 12, '2014-05-14', 0, 0, 0, 0, 0),
(289, 12, '2014-05-15', 0, 0, 0, 0, 0),
(290, 12, '2014-05-16', 0, 0, 0, 0, 0),
(291, 12, '2014-05-17', 0, 0, 0, 0, 0),
(292, 12, '2014-05-18', 0, 0, 0, 0, 0),
(293, 12, '2014-05-19', 0, 0, 0, 0, 0),
(294, 12, '2014-05-20', 0, 0, 0, 0, 0),
(295, 12, '2014-05-21', 0, 0, 0, 0, 0),
(296, 12, '2014-05-22', 0, 0, 0, 0, 0),
(297, 12, '2014-05-23', 0, 0, 0, 0, 0),
(298, 12, '2014-05-24', 0, 0, 0, 0, 0),
(299, 12, '2014-05-25', 0, 0, 0, 0, 0),
(300, 12, '2014-05-26', 0, 0, 0, 0, 0),
(301, 12, '2014-05-27', 0, 0, 0, 0, 0),
(302, 12, '2014-05-28', 0, 0, 0, 0, 0),
(303, 12, '2014-05-29', 0, 0, 0, 0, 0),
(304, 12, '2014-05-30', 0, 0, 0, 0, 0),
(305, 12, '2014-05-31', 3197000, 0, 0, 0, 0),
(306, 13, '2014-06-01', 0, 0, 0, 0, 0),
(307, 13, '2014-06-02', 0, 0, 0, 0, 0),
(308, 13, '2014-06-03', 0, 0, 0, 0, 0),
(309, 13, '2014-06-04', 0, 0, 0, 0, 0),
(310, 13, '2014-06-05', 0, 0, 0, 0, 0),
(311, 13, '2014-06-06', 0, 0, 0, 0, 0),
(312, 13, '2014-06-07', 0, 0, 0, 0, 0),
(313, 13, '2014-06-08', 0, 0, 0, 0, 0),
(314, 13, '2014-06-09', 0, 0, 0, 0, 0),
(315, 13, '2014-06-10', 2925000, 0, 0, 0, 0),
(316, 13, '2014-06-11', 0, 0, 0, 0, 0),
(317, 13, '2014-06-12', 0, 0, 0, 0, 0),
(318, 13, '2014-06-13', 0, 0, 0, 0, 0),
(319, 13, '2014-06-14', 0, 0, 0, 0, 0),
(320, 13, '2014-06-15', 0, 0, 0, 0, 0),
(321, 13, '2014-06-16', 0, 0, 0, 0, 0),
(322, 13, '2014-06-17', 0, 0, 0, 0, 0),
(323, 13, '2014-06-18', 0, 0, 0, 0, 0),
(324, 13, '2014-06-19', 0, 0, 0, 0, 0),
(325, 13, '2014-06-20', 0, 0, 0, 0, 0),
(326, 13, '2014-06-21', 0, 0, 0, 0, 0),
(327, 13, '2014-06-22', 0, 0, 0, 0, 0),
(328, 13, '2014-06-23', 0, 0, 0, 0, 0),
(329, 13, '2014-06-24', 0, 0, 0, 0, 0),
(330, 13, '2014-06-25', 0, 0, 0, 0, 0),
(331, 13, '2014-06-26', 0, 0, 0, 0, 0),
(332, 13, '2014-06-27', 0, 0, 0, 0, 0),
(333, 13, '2014-06-28', 0, 0, 0, 0, 0),
(334, 13, '2014-06-29', 0, 0, 0, 0, 0),
(335, 13, '2014-06-30', 0, 0, 0, 0, 0),
(336, 14, '2014-07-01', 0, 0, 0, 0, 0),
(337, 14, '2014-07-02', 0, 0, 0, 0, 0),
(338, 14, '2014-07-03', 0, 0, 0, 0, 0),
(339, 14, '2014-07-04', 0, 0, 0, 0, 0),
(340, 14, '2014-07-05', 0, 0, 0, 0, 0),
(341, 14, '2014-07-06', 0, 0, 0, 0, 0),
(342, 14, '2014-07-07', 0, 0, 0, 0, 0),
(343, 14, '2014-07-08', 0, 0, 0, 0, 0),
(344, 14, '2014-07-09', 0, 0, 0, 0, 0),
(345, 14, '2014-07-10', 0, 0, 0, 0, 0),
(346, 14, '2014-07-11', 0, 0, 0, 0, 0),
(347, 14, '2014-07-12', 0, 0, 0, 0, 0),
(348, 14, '2014-07-13', 0, 0, 0, 0, 0),
(349, 14, '2014-07-14', 0, 0, 0, 0, 0),
(350, 14, '2014-07-15', 0, 0, 0, 0, 0),
(351, 14, '2014-07-16', 0, 0, 0, 0, 0),
(352, 14, '2014-07-17', 0, 0, 0, 0, 0),
(353, 14, '2014-07-18', 0, 0, 0, 0, 0),
(354, 14, '2014-07-19', 0, 0, 0, 0, 0),
(355, 14, '2014-07-20', 0, 0, 0, 0, 0),
(356, 14, '2014-07-21', 0, 0, 0, 0, 0),
(357, 14, '2014-07-22', 0, 0, 0, 0, 0),
(358, 14, '2014-07-23', 0, 0, 0, 0, 0),
(359, 14, '2014-07-24', 0, 0, 0, 0, 0),
(360, 14, '2014-07-25', 0, 0, 0, 0, 0),
(361, 14, '2014-07-26', 0, 0, 0, 0, 0),
(362, 14, '2014-07-27', 0, 0, 0, 0, 0),
(363, 14, '2014-07-28', 0, 0, 0, 0, 0),
(364, 14, '2014-07-29', 0, 0, 0, 0, 0),
(365, 14, '2014-07-30', 0, 0, 0, 0, 0),
(366, 14, '2014-07-31', 0, 0, 0, 0, 0),
(367, 15, '2014-08-01', 0, 0, 0, 0, 0),
(368, 15, '2014-08-02', 0, 0, 0, 0, 0),
(369, 15, '2014-08-03', 0, 0, 0, 0, 0),
(370, 15, '2014-08-04', 0, 0, 0, 0, 0),
(371, 15, '2014-08-05', 0, 0, 0, 0, 0),
(372, 15, '2014-08-06', 0, 0, 0, 0, 0),
(373, 15, '2014-08-07', 0, 0, 0, 0, 0),
(374, 15, '2014-08-08', 0, 0, 0, 0, 0),
(375, 15, '2014-08-09', 0, 0, 0, 0, 0),
(376, 15, '2014-08-10', 0, 0, 0, 0, 0),
(377, 15, '2014-08-11', 0, 0, 0, 0, 0),
(378, 15, '2014-08-12', 0, 0, 0, 0, 0),
(379, 15, '2014-08-13', 0, 0, 0, 0, 0),
(380, 15, '2014-08-14', 2965000, 0, 0, 0, 0),
(381, 15, '2014-08-15', 0, 0, 0, 0, 0),
(382, 15, '2014-08-16', 0, 0, 0, 0, 0),
(383, 15, '2014-08-17', 0, 0, 0, 0, 0),
(384, 15, '2014-08-18', 0, 0, 0, 0, 0),
(385, 15, '2014-08-19', 0, 0, 0, 0, 0),
(386, 15, '2014-08-20', 0, 0, 0, 0, 0),
(387, 15, '2014-08-21', 0, 0, 0, 0, 0),
(388, 15, '2014-08-22', 0, 0, 0, 0, 0),
(389, 15, '2014-08-23', 0, 0, 0, 0, 0),
(390, 15, '2014-08-24', 0, 0, 0, 0, 0),
(391, 15, '2014-08-25', 0, 0, 0, 0, 0),
(392, 15, '2014-08-26', 0, 0, 0, 0, 0),
(393, 15, '2014-08-27', 0, 0, 0, 0, 0),
(394, 15, '2014-08-28', 0, 0, 0, 0, 0),
(395, 15, '2014-08-29', 0, 0, 0, 0, 0),
(396, 15, '2014-08-30', 0, 0, 0, 0, 0),
(397, 15, '2014-08-31', 0, 0, 0, 0, 0),
(398, 16, '2014-09-01', 0, 0, 0, 0, 0),
(399, 16, '2014-09-02', 0, 0, 0, 0, 0),
(400, 16, '2014-09-03', 0, 0, 0, 0, 0),
(401, 16, '2014-09-04', 0, 0, 0, 0, 0),
(402, 16, '2014-09-05', 0, 0, 0, 0, 0),
(403, 16, '2014-09-06', 0, 0, 0, 0, 0),
(404, 16, '2014-09-07', 0, 0, 0, 0, 0),
(405, 16, '2014-09-08', 0, 0, 0, 0, 0),
(406, 16, '2014-09-09', 0, 0, 0, 0, 0),
(407, 16, '2014-09-10', 0, 0, 0, 0, 0),
(408, 16, '2014-09-11', 0, 0, 0, 0, 0),
(409, 16, '2014-09-12', 0, 0, 0, 0, 0),
(410, 16, '2014-09-13', 0, 0, 0, 0, 0),
(411, 16, '2014-09-14', 0, 0, 0, 0, 0),
(412, 16, '2014-09-15', 0, 0, 0, 0, 0),
(413, 16, '2014-09-16', 0, 0, 0, 0, 0),
(414, 16, '2014-09-17', 0, 0, 0, 0, 0),
(415, 16, '2014-09-18', 0, 0, 0, 0, 0),
(416, 16, '2014-09-19', 0, 0, 0, 0, 0),
(417, 16, '2014-09-20', 0, 0, 0, 0, 0),
(418, 16, '2014-09-21', 0, 0, 0, 0, 0),
(419, 16, '2014-09-22', 0, 0, 0, 0, 0),
(420, 16, '2014-09-23', 0, 0, 0, 0, 0),
(421, 16, '2014-09-24', 0, 0, 0, 0, 0),
(422, 16, '2014-09-25', 0, 0, 0, 0, 0),
(423, 16, '2014-09-26', 0, 0, 0, 0, 0),
(424, 16, '2014-09-27', 0, 0, 0, 0, 0),
(425, 16, '2014-09-28', 0, 0, 0, 0, 0),
(426, 16, '2014-09-29', 0, 0, 0, 0, 0),
(427, 16, '2014-09-30', 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tracking_store`
--

CREATE TABLE IF NOT EXISTS `tbl_tracking_store` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_tracking` int(11) NOT NULL,
  `id_td` int(11) NOT NULL,
  `id_resource` int(11) NOT NULL,
  `count_old` float NOT NULL,
  `count_import` float NOT NULL,
  `count_export` float NOT NULL,
  `price` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `tbl_tracking_store`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbl_unit`
--

CREATE TABLE IF NOT EXISTS `tbl_unit` (
  `id` int(25) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=20 ;

--
-- Dumping data for table `tbl_unit`
--

INSERT INTO `tbl_unit` (`id`, `name`) VALUES
(1, 'Ly'),
(2, 'Điếu'),
(3, 'Chai'),
(4, 'Lon'),
(5, 'Dĩa'),
(6, 'Thùng'),
(7, 'Két'),
(9, 'Bịch'),
(10, 'Gói'),
(11, 'Cái'),
(12, 'Cây'),
(13, 'Giờ'),
(14, 'Bao'),
(15, 'Con'),
(16, 'Kg'),
(17, 'Hộp'),
(18, 'Hủ'),
(19, 'Trái');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE IF NOT EXISTS `tbl_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pass` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gender` int(11) NOT NULL,
  `note` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `datecreate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dateupdate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `dateactivity` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `type` tinyint(4) NOT NULL,
  `code` varchar(13) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=10 ;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`id`, `name`, `email`, `pass`, `gender`, `note`, `datecreate`, `dateupdate`, `dateactivity`, `type`, `code`) VALUES
(1, 'Quản lý', 'quanly@gmail.com', '123456', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 4, ''),
(2, 'Quí Hữu', 'quihuu@gmail.com', '123456', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, ''),
(9, 'Bán hàng', 'banhang@gmail.com', '123456', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, '');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_collect_customer`
--
ALTER TABLE `tbl_collect_customer`
  ADD CONSTRAINT `tbl_customer_collect_1` FOREIGN KEY (`idcustomer`) REFERENCES `tbl_customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_collect_general`
--
ALTER TABLE `tbl_collect_general`
  ADD CONSTRAINT `tbl_collect_general_1` FOREIGN KEY (`id_term`) REFERENCES `tbl_term_collect` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_course`
--
ALTER TABLE `tbl_course`
  ADD CONSTRAINT `tbl_course_1` FOREIGN KEY (`idcategory`) REFERENCES `tbl_category` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_order_import`
--
ALTER TABLE `tbl_order_import`
  ADD CONSTRAINT `tbl_order_import_1` FOREIGN KEY (`idsupplier`) REFERENCES `tbl_supplier` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_order_import_detail`
--
ALTER TABLE `tbl_order_import_detail`
  ADD CONSTRAINT `tbl_order_import_detail_1` FOREIGN KEY (`idorder`) REFERENCES `tbl_order_import` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_order_import_detail_2` FOREIGN KEY (`idresource`) REFERENCES `tbl_resource` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_paid_customer`
--
ALTER TABLE `tbl_paid_customer`
  ADD CONSTRAINT `tbl_customer_paid_1` FOREIGN KEY (`idcustomer`) REFERENCES `tbl_customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_paid_employee`
--
ALTER TABLE `tbl_paid_employee`
  ADD CONSTRAINT `tbl_paid_employee_ibfk_1` FOREIGN KEY (`id_employee`) REFERENCES `tbl_employee` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_paid_general`
--
ALTER TABLE `tbl_paid_general`
  ADD CONSTRAINT `tbl_paid_general_1` FOREIGN KEY (`id_term`) REFERENCES `tbl_term` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_paid_supplier`
--
ALTER TABLE `tbl_paid_supplier`
  ADD CONSTRAINT `tbl_supplier_paid_1` FOREIGN KEY (`idsupplier`) REFERENCES `tbl_supplier` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_pay_roll`
--
ALTER TABLE `tbl_pay_roll`
  ADD CONSTRAINT `tbl_pay_roll_1` FOREIGN KEY (`idemployee`) REFERENCES `tbl_employee` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_r2c`
--
ALTER TABLE `tbl_r2c`
  ADD CONSTRAINT `tbl_r2c_1` FOREIGN KEY (`id_course`) REFERENCES `tbl_course` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_r2c_2` FOREIGN KEY (`id_resource`) REFERENCES `tbl_resource` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_resource`
--
ALTER TABLE `tbl_resource`
  ADD CONSTRAINT `tbl_resource_1` FOREIGN KEY (`idsupplier`) REFERENCES `tbl_supplier` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_session`
--
ALTER TABLE `tbl_session`
  ADD CONSTRAINT `tbl_session_1` FOREIGN KEY (`idtable`) REFERENCES `tbl_table` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_session_2` FOREIGN KEY (`iduser`) REFERENCES `tbl_user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_session_3` FOREIGN KEY (`idcustomer`) REFERENCES `tbl_customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_session_detail`
--
ALTER TABLE `tbl_session_detail`
  ADD CONSTRAINT `tbl_session_detail_1` FOREIGN KEY (`idsession`) REFERENCES `tbl_session` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_session_detail_2` FOREIGN KEY (`idcourse`) REFERENCES `tbl_course` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_table`
--
ALTER TABLE `tbl_table`
  ADD CONSTRAINT `tbl_table_1` FOREIGN KEY (`iddomain`) REFERENCES `tbl_domain` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_table_log`
--
ALTER TABLE `tbl_table_log`
  ADD CONSTRAINT `tbl_table_log_ibfk_1` FOREIGN KEY (`idtable`) REFERENCES `tbl_table` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_table_log_ibfk_2` FOREIGN KEY (`iduser`) REFERENCES `tbl_user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
